//
//  KSModelMagzine.m
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-21.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSModelMagzine.h"
#import "KSGetMagzineListOperation.h"

@implementation KSModelMagzine
@synthesize magzineId=_magzineId, issueNumber=_issueNumber,
status=_status,stageNumber=_stageNumber,priceCn=_priceCn,priceUs=_priceUs,
pubDate=_pubDate,isSpecialIssue=_isSpecialIssue,customIssueNumber=_customIssueNumber,
coverSummary=_coverSummary,coverTitle=_coverTitle, cover_2=_cover_2, cover_3 = _cover_3, 
isFree = _isFree, isGiven = _isGiven, isPurchased=_isPurchased, isNew = _isNew, isDownload = _isDownload, isSubscribed = _isSubscribed, articlesNumber = _articlesNumber, downloadArticlesNumber = _downloadArticlesNumber, fileSize = _fileSize,adPic = _adPic,adUrl=_adUrl;
@synthesize rateDownload = _rateDownload;
@synthesize isArticlesDownload = _isArticlesDownload;
@synthesize isDeviceDonate = _isDeviceDonate;

- (void) dealloc{
    [_customIssueNumber release];
    
    [_coverSummary release];
    [_coverTitle release];
    [_cover_3 release];
    [_cover_2 release];
    [_fileSize release];
    
    [super dealloc];
}

+ (KSModelMagzine *) magzineWith:(NSDictionary *)dict{
    KSModelMagzine *result = [[[KSModelMagzine alloc] init] autorelease];
    result.magzineId = [[dict valueForKeyPath:@"id"] intValue];
    result.issueNumber = [[dict valueForKeyPath:@"issue_number"] intValue];
    result.status = [[dict valueForKeyPath:@"status"] intValue];
    result.stageNumber = [[dict valueForKeyPath:@"stage_number"] intValue];
    result.priceUs = [[dict valueForKeyPath:@"price_us"] intValue];
    result.priceCn = [[dict valueForKeyPath:@"price_cn"] intValue];
    result.pubDate = [[dict valueForKeyPath:@"publication_time"] intValue];
    result.isSpecialIssue = [[dict valueForKeyPath:@"is_special_issue"] intValue]==1;
    result.coverTitle = [dict valueForKeyPath:@"cover_title"];
    result.coverSummary = [dict valueForKeyPath:@"cover_description"];
    result.isFree = DICT_BOOLVAL(dict, @"isfree");
    result.fileSize = DICT_VAL(dict, @"file_size");
    result.customIssueNumber = DICT_VAL(dict, @"custom_issue_number");
    result.articlesNumber = DICT_INTVAL(dict, @"article_nums");
    result.adPic = DICT_VAL(dict, @"ad_pic");
    result.adUrl = DICT_VAL(dict, @"ad_url");
    return result;
}

+ (KSModelMagzine *) itemByDbDict:(NSDictionary *)dict{
    KSModelMagzine *item = [[[KSModelMagzine alloc] init] autorelease];
    item.magzineId = [[dict valueForKeyPath:@"magzine_id"] intValue];
    item.issueNumber = [[dict valueForKeyPath:@"issue_number"] intValue];
    item.status = [[dict valueForKeyPath:@"status"] intValue];
    item.stageNumber = [[dict valueForKeyPath:@"stage_number"] intValue];
    item.priceUs = [[dict valueForKeyPath:@"price_us"] intValue];
    item.priceCn = [[dict valueForKeyPath:@"price_cn"] intValue];
    item.pubDate = [[dict valueForKeyPath:@"pub_date"] intValue];
    item.isSpecialIssue = [[dict valueForKeyPath:@"is_special_issue"] intValue]==1;
    item.customIssueNumber = [dict valueForKeyPath:@"custom_number"];
    item.coverTitle = [dict valueForKeyPath:@"cover_title"];
    item.coverSummary = [dict valueForKeyPath:@"cover_summary"];
    item.isFree = [[dict valueForKeyPath:@"is_free"] intValue]==1;
    item.isNew = [[dict valueForKeyPath:@"is_new"] intValue]==1;
    item.isPurchased = [[dict valueForKeyPath:@"is_purchased"] intValue]==1;
    item.isDownload = [[dict valueForKeyPath:@"is_download"] intValue]==1;
    item.articlesNumber = [[dict valueForKeyPath:@"articles_num"] intValue];
    item.downloadArticlesNumber = [[dict valueForKeyPath:@"download_articles_num"] intValue];
    item.fileSize = [dict valueForKeyPath:@"file_size"];
    item.cover_2 = [KSModelMagzine magzineCover:item.magzineId index:2];
    item.cover_3 = [KSModelMagzine magzineCover:item.magzineId index:3];
    item.isSubscribed = [self isSubscribed:item];
    item.isGiven = [self isGiven:item]||[self isDeviceDonate:item];
    //item.isDeviceDonate = [self isDeviceDonate:item];
    
    item.rateDownload = [[dict valueForKey:@"rate_download"] isKindOfClass:[NSNull class]]?0:[[dict valueForKey:@"rate_download"] floatValue];
    item.isArticlesDownload = DICT_INTVAL(dict, @"is_articles_download")==1;
    item.adPic = [[KSBootstrap root] stringByAppendingFormat:@"/magzineUnpack%d/%@", item.magzineId, DICT_VAL(dict, @"ad_pic")];
    item.adUrl = DICT_VAL(dict, @"ad_url");
    return item;
}

+ (NSArray *)magzines{
    NSMutableArray *result = [NSMutableArray arrayWithCapacity:20];
    //FMResultSet *rs = [[KSDB db] executeQuery:@"select * from magzines order by magzine_id desc"];
    FMResultSet *rs = [[KSDB db] executeQuery:@"select * from magzines order by pub_date desc"];
    int i = 0;
    while (rs.next) {
        NSDictionary *dict = [rs resultDict];
        if (i == 0) {
            KSModelMagzine *item = [self itemByDbDict:dict];
            item.isNew = YES;
            [result addObject:item];
            i++;
        }else
        [result addObject:[self itemByDbDict:dict]];
    }
    return result;
}

+ (KSModelMagzine *) loadById:(NSInteger)magzineId{
    FMResultSet *rs = [[KSDB db] executeQuery:@"select * from magzines where magzine_id=?", INTEGER(magzineId)];
    if(rs.next){
        return [self itemByDbDict:[rs resultDict]];
    }
    return nil;
}
+ (KSModelMagzine *) loadByIssueNumber:(NSInteger)issueNumber{
    FMResultSet *rs = [[KSDB db] executeQuery:@"select * from magzines where issue_number=?", INTEGER(issueNumber)];
    if(rs.next){
        return [self itemByDbDict:[rs resultDict]];
    }
    return nil;
}
+ (KSModelMagzine *) loadByCustomIssueNumber:(NSString*)customIssueNumber{
    FMResultSet *rs = [[KSDB db] executeQuery:@"select * from magzines where is_special_issue=1 and custom_issue_number=?", customIssueNumber];
    if(rs.next){
        return [self itemByDbDict:[rs resultDict]];
    }
    return nil;
}
+ (BOOL) isSubscribed:(KSModelMagzine *)magzine{
    NSNumber *pubDate = INTEGER(magzine.pubDate);
    //如果是登录了财新网通行证，则需要调出网站的订阅记录
    NSString* email = [KSBootstrap currentUser];
    if(email == nil){
        return [[KSDB db] intForQuery:@"select count(*) from subscribed where start<=? and end>? and email is null", pubDate, pubDate]>0;        
    }else{
        return [[KSDB db] intForQuery:@"select count(*) from subscribed where (start<=? and end>? and (email is null or email=?))", pubDate, pubDate,email]>0;
    }

}
+ (BOOL) isGiven:(KSModelMagzine *)magzine{
    NSString *user = [KSBootstrap currentUser];
    if(user == nil) return NO;
    //return [[KSDB db] intForQuery:@"select count(*) from my_free where issue_number=? and user_email=?", INTEGER(magzine.issueNumber), user]>0;
    NSInteger c =  [[KSDB db] intForQuery:@"select count(*) from my_free where issue_number=? and user_email=?", INTEGER(magzine.magzineId), user]>0;
    return c && !magzine.isSubscribed && !magzine.isPurchased;
}
+ (BOOL)isDeviceDonate:(KSModelMagzine *)magzine {
    NSInteger c =  [[KSDB db] intForQuery:@"SELECT count(*) FROM my_device_free WHERE issue_number=? AND device_udid=?", INTEGER(magzine.magzineId), [KSDB stringForKey:KEY_DEVICE_UDID_STR]]>0;
    return c && !magzine.isSubscribed && !magzine.isPurchased;
//    NSInteger c =  [[KSDB db] intForQuery:@"select count(1) from magzines where magzine_id=? AND magzine_id in(select periodical_ids from device_udid limit 1)",INTEGER(magzine.magzineId)]>0;
//    return c && !magzine.isSubscribed && !magzine.isPurchased;
}
+ (NSString *)magzineCover:(NSInteger)magzineId index:(NSInteger)index{
    return [[KSBootstrap root] stringByAppendingFormat:@"/magzineUnpack%d/files/cover%d.jpg", magzineId, index];
}

+ (BOOL) updateMagzine:(NSInteger)magzineId key:(NSString*)key value:(NSValue *)value{
    NSString *sql = [NSString stringWithFormat:@"update magzines set %@=? where magzine_id=?", key];
    return [[KSDB db] executeUpdate:sql, value, [NSNumber numberWithInt:magzineId]];
}

+ (NSString *)magzinePath:(NSInteger)magzineId{
    return [[KSBootstrap root] stringByAppendingFormat:@"/magzineUnpack%d/", magzineId];
}

+ (NSMutableArray *)loadSubscribed {
    NSMutableArray *result = [NSMutableArray arrayWithCapacity:1];
    FMResultSet *rs = nil;
    NSString* email = [KSBootstrap currentUser];
    if(email == nil){
        rs = [[KSDB db] executeQuery:@"select * from subscribed where (email is null or email='')"];
    }else {
        rs = [[KSDB db] executeQuery:@"select * from subscribed where (email is null or email='') or email=?",email];
    }
    while (rs.next) {
        NSDictionary *dict = [rs resultDict];
        [result addObject:dict];
    }
    return result;
}
+ (NSMutableArray *)loadAllFreeLogic {
    NSMutableArray *result = [NSMutableArray arrayWithCapacity:1];
    FMResultSet *rs = [[KSDB db] executeQuery:@"select * from my_free_logic"];
    while (rs.next) {
        NSDictionary *dict = [rs resultDict];
        [result addObject:dict];
    }
    return result;
}
+ (NSMutableArray *)loadAllFree:(NSString *)user {
    NSMutableArray *result = [NSMutableArray arrayWithCapacity:1];
    FMResultSet *rs = [[KSDB db] executeQuery:@"select * from magzines where magzine_id in(select issue_number from my_free where user_email=?) order by magzine_id desc",user];
    while (rs.next) 
    {
        NSDictionary *dict = [rs resultDict];
        [result addObject:[self itemByDbDict:dict]];
    }
    return result;
}
+ (NSMutableArray *)loadAllDonated:(NSString *)user {
    NSMutableArray *result = [NSMutableArray arrayWithCapacity:1];
    FMResultSet *rs = [[KSDB db] executeQuery:@"select * from magzines where issue_number in(select issue_number from my_free where user_email=?) order by magzine_id desc",user];
    while (rs.next) 
    {
        NSDictionary *dict = [rs resultDict];
        [result addObject:[self itemByDbDict:dict]];
    }
    return result;
}

+ (NSInteger)getBookmarkArticleId:(NSInteger)magzineId{
    NSString *user = [KSBootstrap currentUser];
    if(!user){user = @"anonymouse";}
    return [[KSDB db] intForQuery:@"select article_id from my_bookmarks where magzine_id=? and user_email=?", INTEGER(magzineId), user];
}
+ (NSInteger)getLastReadArticleId:(NSInteger)magzineId {
    return [[KSDB db] intForQuery:@"select article_id from last_read_article where magzine_id=?", INTEGER(magzineId)];
}
- (BOOL) insert{
    NSString *sql = @"insert into magzines(magzine_id, issue_number, stage_number, is_special_issue, custom_number, status, pub_date, cover_title, cover_summary, price_cn, price_us, is_free, is_new, is_purchased, is_download, download_articles_num, articles_num, file_size,ad_pic,ad_url,rate_download) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?)";
    return [[KSDB db] executeUpdate:sql, INTEGER(_magzineId), INTEGER(_issueNumber), INTEGER(_stageNumber), INTEGER(_isSpecialIssue?1:0), _customIssueNumber, INTEGER(_status), INTEGER(_pubDate), _coverTitle, _coverSummary, FLOAT(_priceCn), FLOAT(_priceUs), INTEGER(_isFree?1:0), INTEGER(_isNew?1:0), INTEGER(_isPurchased?1:0), INTEGER(_isDownload?1:0), INTEGER(_downloadArticlesNumber), INTEGER(_articlesNumber), _fileSize,_adPic?_adPic:@"",_adUrl?_adUrl:@"",FLOAT(_rateDownload)];
}

- (BOOL) update:(NSString*)key value:(NSValue *)value{
    return [KSModelMagzine updateMagzine:_magzineId key:key value:value];
}

- (BOOL) isMybook{
    return _isFree || _isGiven || _isPurchased || _isSubscribed ;//|| _isDeviceDonate;
}

-(NSString *) description{
    return [NSString stringWithFormat:@"id:%d, issue_number:%d, title:%@", _magzineId, _issueNumber, _coverTitle];
}
- (NSString *) formattedPubDate:(BOOL)fullYear{
    if(fullYear){
        return @"";
    }
    return @"";
}
- (BOOL)remove:(BOOL)dropMetadata{
    BOOL isDir=NO;
    NSString *magzinePath = [KSModelMagzine magzinePath:_magzineId];
    NSFileManager *fileManager = [[NSFileManager alloc] init];
    if(!dropMetadata){
        //置articles为未下载
        [[KSDB db] executeUpdate:@"update articles set is_download=0 where magzine_id=?", INTEGER(_magzineId)];
        //更改数据库记录
        [[KSDB db] executeUpdate:@"update magzines set download_articles_num=0 ,is_articles_download=0, is_download=0,rate_download='0' where magzine_id=?", INTEGER(_magzineId)];
        //[self update:@"download_articles_num" value:INTEGER(0)];
        //删除文件
        NSArray *subpaths;
        if ([fileManager fileExistsAtPath:magzinePath isDirectory:&isDir] && isDir){
            subpaths = [fileManager subpathsAtPath:magzinePath];
        }
        for (NSString *sub in subpaths) {
            NSString *abs = [magzinePath stringByAppendingPathComponent:sub];
            if([fileManager fileExistsAtPath:abs isDirectory:&isDir] && isDir){
                if([@"files" isEqualToString:sub])continue;
                [fileManager removeItemAtPath:abs error:nil];
            }
        }
    }else{
        [[KSDB db] executeUpdate:@"delete from articles where magzine_id=?", INTEGER(_magzineId)];
        [[KSDB db] executeUpdate:@"delete from magzines where magzine_id=?", INTEGER(_magzineId)];
        if ([fileManager fileExistsAtPath:magzinePath isDirectory:&isDir] && isDir){
            [fileManager removeItemAtPath:magzinePath error:nil];
        }
    }
    [fileManager release];
    KSDINFO(@"magzine(%d) is %@deleted...", _magzineId, dropMetadata?@"real ":@"");
    [KSBootstrap notify:NOTIFY_MAGZINE_DELETED data:[NSDictionary dictionaryWithObjectsAndKeys:INTEGER(_magzineId), @"magzine_id", INTEGER(dropMetadata?1:0), @"drop_metadata", nil]];
    return YES;
}
@end


@implementation KSModelMagzineCoverArticle
@synthesize magzineId = _magzineId, articleId = _articleId, articleTitle = _articleTitle, ranking = _ranking;
- (void)dealloc{
    RELEASE_SAFELY(_articleTitle);
    [super dealloc];
}
+ (KSModelMagzineCoverArticle *)magzineCoverArticleWith:(NSDictionary *)dict magzineId:(NSInteger)magzineId{
    KSModelMagzineCoverArticle *item = [[[KSModelMagzineCoverArticle alloc] init] autorelease];
    item.magzineId = magzineId;
    item.articleId = DICT_INTVAL(dict, @"id");
    item.articleTitle = DICT_VAL(dict, @"title");
    return item;    
}
+ (KSModelMagzineCoverArticle *) itemByDbDict:(NSDictionary *)dict{
    KSModelMagzineCoverArticle *item = [[[KSModelMagzineCoverArticle alloc] init] autorelease];
    item.magzineId = DICT_INTVAL(dict, @"magzine_id");
    item.articleId = DICT_INTVAL(dict, @"article_id");
    item.articleTitle = DICT_VAL(dict, @"article_title");
    item.ranking = DICT_INTVAL(dict, @"ranking");
    return item;
}
+ (NSArray *)magzineCoverArticles:(NSInteger)magzineId{
    NSMutableArray *result = [NSMutableArray arrayWithCapacity:4];
    FMResultSet *rs = [[KSDB db] executeQuery:@"select * from magzine_cover_articles where magzine_id=? order by ranking asc", INTEGER(magzineId)];
    while (rs.next) {
        NSDictionary *dict = [rs resultDict];
        [result addObject:[self itemByDbDict:dict]];
    }
    return result;
}

- (BOOL)insert{
    NSString *sql = @"insert into magzine_cover_articles(magzine_id, article_id, article_title, ranking) values(?, ?, ?, ?)";
    return [[KSDB db] executeUpdate:sql, INTEGER(_magzineId), INTEGER(_articleId), _articleTitle, INTEGER(_ranking)];
}
@end