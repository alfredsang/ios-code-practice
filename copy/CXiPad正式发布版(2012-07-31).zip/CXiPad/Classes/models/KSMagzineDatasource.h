//
//  KSMagzineDatasource.h
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-11-27.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KSModelMagzine.h"

@protocol KSMagzineDatasource <NSObject>
@required
- (NSArray *) magzines;
@end
