//
//  KSModelComment.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 1/4/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KSModelComment.h"
#import "DateUtil.h"

@implementation KSModelComment 
@synthesize content = _content;
@synthesize commentId = _commentId;
@synthesize postTime = _postTime;
@synthesize author = _author;
@synthesize address = _address;
@synthesize image = _image;
@synthesize articleId = _articleId;

- (void)dealloc {
    [_content release];
    [_author release];
    [_address release];
    [_image release];
    
    [super dealloc];
}
+ (KSModelComment *)commentWithDict:(NSDictionary *)dict {
    KSModelComment *comment = [[KSModelComment alloc] init];
    comment.commentId = DICT_INTVAL(dict, @"id");
    comment.content = DICT_VAL(dict, @"content");
    comment.postTime = DICT_INTVAL(dict, @"createtime");
    comment.author = DICT_VAL(dict, @"email");
    //comment.address = DICT_VAL(dict, @"address");
    //comment.image = DICT_VAL(dict, @"image");
    
    return [comment autorelease];
}

+ (KSModelComment *)commentWithCXDict:(NSDictionary *)dict {
    KSModelComment *comment = [[KSModelComment alloc] init];
    comment.articleId = DICT_INTVAL(dict, @"topic_id");
    comment.commentId = DICT_INTVAL(dict, @"comment_id");
    comment.content = DICT_VAL(dict, @"comment_content");
    comment.postTime = [[DateUtil dateFromString:DICT_VAL(dict, @"create_time") format:@"yyyy-MM-dd HH:mm:ss"] timeIntervalSince1970];
    comment.author = DICT_VAL(dict, @"user_name");
    //comment.address = DICT_VAL(dict, @"address");
    //comment.image = DICT_VAL(dict, @"image");
    
    return [comment autorelease];
}

@end
