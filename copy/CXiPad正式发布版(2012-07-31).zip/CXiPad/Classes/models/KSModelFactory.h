//
//  KSModelFactory.h
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-21.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CJSONDeserializer.h"
#import "KSModelArticle.h"
#import "KSModelMagzine.h"
#import "KSModelCatalog.h"

@interface KSModelFactory : NSObject
@property(nonatomic, copy) NSString *root;
+ (KSModelFactory *) sharedFactory:(NSString *)rootDir;
- (KSModelArticle *) articleById:(NSInteger) articleId magzineId:(NSInteger) magzineId;
- (KSModelMagzine *) magzineById:(NSInteger) magzineId;
- (KSModelCatalog *) catalogById:(NSInteger) magzineId;
@end
