//
//  KSModelCollectionItem.h
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-20.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KSModelMagzine.h"

@interface KSModelCollectionItem : NSObject
@property(nonatomic, retain) NSString *title;
@property(nonatomic, retain) NSString *summary;
@property(nonatomic, assign) NSInteger articleId;
@property(nonatomic, assign) NSInteger magzineId;
@property(nonatomic, assign) NSInteger pubDate;
@property(nonatomic, assign) NSTimeInterval createDate;
@property(nonatomic, retain) NSString *cover;
@property(nonatomic, retain) NSString *userEmail;
@property(nonatomic, retain)NSString *magazineTitle;
@property(nonatomic, retain)NSString *stageNumber;


+ (NSArray *) collectionItems;
+ (BOOL) isInCollection:(NSInteger)articleId;
+ (BOOL) markCollection:(NSInteger)articleId;
+ (BOOL)unMarkCollection:(NSInteger)articleId;
- (BOOL) insert;
- (BOOL) removeFromDb;
@end
