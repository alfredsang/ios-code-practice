//
//  KSModelSearchItem.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-22.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSModelSearchItem.h"

@implementation KSModelSearchItem
@synthesize articleId = _articleId, image = _image, imageFile = _imageFile, imageDownload = _imageDownload,
title = _title, summary = _summary, magzineId = _magzineId, pubDate = _pubDate, lock = _lock;
@synthesize isFree = _isFree;
@synthesize magazineTitle = _magazineTitle;
@synthesize stageNumber = _stageNumber;

+ (KSModelSearchItem *) searchItemWith:(NSDictionary *)dict{
    KSModelSearchItem *result = [[[KSModelSearchItem alloc] init] autorelease];
    result.articleId = DICT_INTVAL(dict, @"id");
    result.title = DICT_VAL(dict, @"title");
    result.magzineId = DICT_INTVAL(dict, @"magazine_id");
    result.summary = DICT_VAL(dict, @"summary");
    result.pubDate = DICT_INTVAL(dict, @"publish_date");
    //KSDINFO(@"%@",DICT_VAL(dict, @"magzine_title"));
    result.magazineTitle = DICT_VAL(dict, @"magzine_title");
    result.stageNumber = DICT_VAL(dict, @"stage_number");
    result.image = DICT_VAL(dict, @"image");
    result.isFree = DICT_INTVAL(dict, @"isfree") == 1;
    KSModelMagzine *mag = [KSModelMagzine loadById:result.magzineId];
    result.lock =  !(mag.isMybook || result.isFree);
    //result.imageFile = KSPathForCachesResource(STR_FORMAT(@"cover_%d.jpg", result.articleId));
    return result;
}
- (void)setSummary:(NSString *)summary {
    [_summary release];
    if ((NSNull *)summary == [NSNull null]) {
        _summary = nil;
    }else {
        _summary = [summary retain];
    }
}
- (void)setTitle:(NSString *)title {
    [_title release];
    if ((NSNull *)title == [NSNull null]) {
        _title = nil;
    }else {
        _title = [title retain];
    }
}
- (void)setMagazineTitle:(NSString *)magazineTitle {
    [_magazineTitle release];
    if ((NSNull *)magazineTitle == [NSNull null]) {
        _magazineTitle = nil;
    }else {
        _magazineTitle = [magazineTitle retain];
    }
}
- (void) dealloc{
    [_title release];
    [_summary release];
    [_image release];
    [_magazineTitle release];
    [_stageNumber release];
    [_imageFile release];
    
    [super dealloc];
}
@end
