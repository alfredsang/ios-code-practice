//
//  KSCatalog.h
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-24.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>




@interface KSModelCatalogItem : NSObject
@property(nonatomic, assign) NSInteger catalogId;
@property(nonatomic, assign) NSInteger articleId;
@property(nonatomic, retain) NSString *title;
@property(nonatomic, assign) BOOL isFree;
@property(nonatomic, assign) BOOL isAritcle;
@property(nonatomic, readonly) NSMutableArray *childs;
- (void) addChild:(KSModelCatalogItem *)item;
@end




@interface KSModelCatalog : NSObject
@property(nonatomic, retain) NSDictionary *dict;
@property(nonatomic, assign) NSInteger catalogId;
@property(nonatomic, assign) NSInteger magazineId;
@property(nonatomic, retain) NSString *title;
@property(nonatomic, retain) NSString *catalogColor;
@property(nonatomic, assign) NSInteger parentId;
@property(nonatomic, assign) NSInteger ranking;

+ (KSModelCatalog *) catalogWith:(NSDictionary *)dict;
- (NSArray *) childsInRoot;
- (NSArray *) childsIn:(NSInteger)catalogId;
+(NSMutableArray*)catalogInMagazineId:(NSInteger)magazineId;
+(NSMutableArray*)catalogLeve1InMagazineId:(NSInteger)magazineId inCatalog:(BOOL)inCatalog;
+(NSMutableArray*)catalogLeve2InMagazineId:(NSInteger)magazineId;
@end
