//
//  KSModelComment.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 1/4/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface KSModelComment : NSObject{
    NSInteger _commentId;
    NSString *_content;
    NSInteger _postTime;
    NSString *_author;
    NSString *_address;
    NSString *_image;
    NSInteger _articleId;
    
}
@property(nonatomic, assign)NSInteger commentId;
@property(nonatomic, retain)NSString *content;
@property(nonatomic, assign)NSInteger postTime;
@property(nonatomic, retain)NSString *author;
@property(nonatomic, retain)NSString *address;
@property(nonatomic, retain)NSString *image;
@property(nonatomic, assign)NSInteger articleId;

+ (KSModelComment *)commentWithDict:(NSDictionary *)dict;
+ (KSModelComment *)commentWithCXDict:(NSDictionary *)dict;
@end
