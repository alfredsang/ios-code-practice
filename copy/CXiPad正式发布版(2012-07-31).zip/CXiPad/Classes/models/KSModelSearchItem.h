//
//  KSModelSearchItem.h
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-22.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface KSModelSearchItem : NSObject {
    NSString *_magazineTitle;
}
@property(nonatomic, retain) NSString *title;
@property(nonatomic, retain) NSString *summary;
@property(nonatomic, assign) NSInteger articleId;
@property(nonatomic, assign) NSInteger magzineId;
@property(nonatomic, retain) NSString *magazineTitle;
@property(nonatomic, retain) NSString *stageNumber;
@property(nonatomic, assign) NSInteger pubDate;
@property(nonatomic, retain) NSString *image;
@property(nonatomic, retain) NSString *imageFile;
@property(nonatomic, assign) BOOL lock;
@property(nonatomic, assign) BOOL imageDownload;
@property(nonatomic, assign) BOOL isFree;


+ (KSModelSearchItem *) searchItemWith:(NSDictionary *)dict;
@end
