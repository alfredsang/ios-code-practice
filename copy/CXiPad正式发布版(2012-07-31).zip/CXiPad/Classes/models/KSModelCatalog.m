//
//  KSCatalog.m
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-24.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSModelCatalog.h"

#pragma mark -
#pragma mark KSModelCatalogItem
@implementation KSModelCatalogItem
@synthesize catalogId=_catalogId, articleId=_articleId, title=_title,
isFree = _isFree, isAritcle=_isAritcle, childs=_childs;
- (id) init{
    if(self=[super init]){
        _childs = [[NSMutableArray alloc] init];
        _catalogId = 0;
        _articleId = 0;
        _isFree = NO;
        _isAritcle = NO;
    }
    return self;
}
- (void) addChild:(KSModelCatalogItem *)item{
    [_childs addObject:item];
}

- (NSString *) description{
    return [NSString stringWithFormat:@"id:%d, title:%@, isAritle:%d", _catalogId, _title, _isAritcle];
}

- (void) dealloc{
    [_title release];
    [_childs release];
    [super dealloc];
}
@end

#pragma mark -
#pragma mark KSModelCatalog
@implementation KSModelCatalog
@synthesize dict=_dict;
@synthesize magazineId,catalogId,title,parentId,ranking,catalogColor;
+ (KSModelCatalogItem *) _createAritcleItem:(NSDictionary *) info catalogId:(NSInteger)catalogId{
    KSModelCatalogItem *result = [[KSModelCatalogItem alloc] init];
    result.title = [info valueForKey:@"title"];
    NSString *strArticleId = [info valueForKey:@"id"];
    result.articleId = [strArticleId intValue];
    result.catalogId = catalogId;
    result.isAritcle = YES;
    result.isFree = [[info valueForKey:@"is_free"] intValue]==1;
    return [result autorelease];
}

+ (KSModelCatalogItem *) _createItem:(NSDictionary *) info dict:(NSDictionary *)dict{
    KSModelCatalogItem *result = [[KSModelCatalogItem alloc] init];
    result.title = [info valueForKey:@"title"];
    NSString *strCatalogId = [info valueForKey:@"id"];
    result.catalogId = [strCatalogId intValue];
    result.isAritcle = NO;
    result.isFree = YES;
    NSDictionary *category = [dict valueForKey:@"category"];
    NSDictionary *article = [dict valueForKey:@"article"];
    NSArray *childs = [category valueForKey:strCatalogId];
    if(childs!=nil){
        for (NSDictionary *item in childs) {
            [result addChild:[KSModelCatalog _createItem:item dict:dict]];
        }
    }
    childs = [article valueForKey:strCatalogId];
    if(childs!=nil){
        for (NSDictionary *item in childs) {
            [result addChild:[KSModelCatalog _createAritcleItem:item catalogId:result.catalogId]];
        }
    }
    return [result autorelease];
}

+ (KSModelCatalog *) catalogWith:(NSDictionary *)dict{
    KSModelCatalog *result = [[KSModelCatalog alloc] init];
    result.dict = dict;
    return [result autorelease];
}
+ (KSModelCatalog *) catalogWithDic:(NSDictionary *)dict
{
    KSModelCatalog *result = [[KSModelCatalog alloc] init];
    result.dict = dict;
    result.magazineId = [[dict objectForKey:@"magzine_id"] intValue];
    result.catalogId = [[dict objectForKey:@"catalog_id"] intValue];
    result.parentId = [[dict objectForKey:@"parent_id"] intValue];
    result.ranking = [[dict objectForKey:@"ranking"] intValue];
    result.title = [dict objectForKey:@"title"];
    result.catalogColor = [dict objectForKey:@"catalogcolor_id"];
    return [result autorelease];
}
+(NSMutableArray*)catalogInMagazineId:(NSInteger)magazineId
{
    NSMutableArray *result = [[NSMutableArray alloc] init];
    FMResultSet *rs = [[KSDB db] executeQuery:@"select * from catalogs where magzine_id=? and parent_id = 0 order by ranking asc", INTEGER(magazineId)];
    while (rs.next) 
    {
        NSDictionary *dict = [rs resultDict];
        [result addObject:[self catalogWithDic:dict]];
    }
    return [result autorelease];

}
+(NSMutableArray*)catalogLeve1InMagazineId:(NSInteger)magazineId inCatalog:(BOOL)inCatalog
{
    NSMutableArray *result = [[NSMutableArray alloc] init];

    
    FMResultSet *rs;
    if (inCatalog)
    {
        rs = [[KSDB db] executeQuery:@"select * from catalogs where magzine_id=? and parent_id = 0 and title not like '%目录%'   order by ranking asc", INTEGER(magazineId)];
 
    }
    else
    {
        rs = [[KSDB db] executeQuery:@"select * from catalogs where magzine_id=? and parent_id = 0   order by ranking asc", INTEGER(magazineId)];

    }
    while (rs.next)
    {
        NSDictionary *dict = [rs resultDict];
        
        [result addObject:[self catalogWithDic:dict]];
    }
    return [result autorelease];
    
}
+(NSMutableArray*)catalogLeve2InMagazineId:(NSInteger)magazineId
{
    NSMutableArray *result = [[NSMutableArray alloc] init];
    FMResultSet *rs = [[KSDB db] executeQuery:@"select * from catalogs where magzine_id=? and parent_id != 0 order by ranking asc", INTEGER(magazineId)];
    while (rs.next) 
    {
        NSDictionary *dict = [rs resultDict];
        [result addObject:[self catalogWithDic:dict]];
    }
    return [result autorelease];
    
}
- (NSArray *) childsInRoot{
    NSArray *childs = [self childsIn:0];
    NSMutableArray *result = [[NSMutableArray alloc] initWithCapacity:[childs count]];
    for (KSModelCatalogItem *item in childs) {
        if([[item childs] count]==1){
            KSModelCatalogItem *childItem = [[item childs] objectAtIndex:0];
            if(childItem.isAritcle){
                [result addObject:childItem];
                continue;
            }
        }
        [result addObject:item];
    }
    return [result autorelease];
}

- (NSArray *) childsIn:(NSInteger)catalogId{
    NSDictionary *info = [NSDictionary dictionaryWithObjectsAndKeys:@"", @"title", [NSString stringWithFormat:@"%d",catalogId], @"id", nil];
    KSModelCatalogItem *item = [KSModelCatalog _createItem:info dict:_dict];
    NSArray *childs = [item childs];
    NSMutableArray *result = [[NSMutableArray alloc] initWithCapacity:[childs count]];
    for (KSModelCatalogItem *item in childs) {
        if([[item childs] count]==0)continue;
        [result addObject:item];
    }
    return [result autorelease];
    
}

- (void) dealloc{
    [_dict release];
    [super dealloc];
}
@end
