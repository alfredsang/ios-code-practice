//
//  KSModelMagzine.h
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-21.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface KSModelMagzine : NSObject
@property(nonatomic, assign) NSInteger magzineId;
@property(nonatomic, assign) NSInteger issueNumber;
@property(nonatomic, assign) NSInteger stageNumber;
@property(nonatomic, assign) BOOL isSpecialIssue;
@property(nonatomic, retain) NSString* customIssueNumber;
@property(nonatomic, assign) NSInteger status;
@property(nonatomic, assign) NSInteger pubDate;
@property(nonatomic, retain) NSString* coverTitle;
@property(nonatomic, retain) NSString* coverSummary;
@property(nonatomic, assign) float priceCn;
@property(nonatomic, assign) float priceUs;
@property(nonatomic, retain) NSString* cover_2;
@property(nonatomic, retain) NSString* cover_3;
@property(nonatomic, assign) BOOL isFree;
@property(nonatomic, assign) BOOL isGiven;
@property(nonatomic, assign) BOOL isPurchased;
@property(nonatomic, assign) BOOL isSubscribed;
@property(nonatomic, assign) BOOL isNew;
@property(nonatomic, assign) BOOL isDownload;
@property(nonatomic, assign) BOOL isDeviceDonate;
@property(nonatomic, assign) NSInteger downloadArticlesNumber;
@property(nonatomic, assign) NSInteger articlesNumber;
@property(nonatomic, retain) NSString* fileSize;
@property(nonatomic, assign) NSInteger isArticlesDownload;
@property(nonatomic, assign) float rateDownload;
@property(nonatomic, retain) NSString* adPic;
@property(nonatomic, retain) NSString* adUrl;


+ (KSModelMagzine *) magzineWith:(NSDictionary *)dict;
+ (NSArray *)magzines;
+ (KSModelMagzine *) loadById:(NSInteger)magzineId;
+ (KSModelMagzine *) loadByIssueNumber:(NSInteger)issueNumber;
+ (KSModelMagzine *) loadByCustomIssueNumber:(NSString*)customIssueNumber;
+ (BOOL) isSubscribed:(KSModelMagzine *)magzine;
+ (BOOL) isGiven:(KSModelMagzine *)magzine;
+ (BOOL)isDeviceDonate:(KSModelMagzine *)magzine;
+ (NSString *)magzineCover:(NSInteger)magzineId index:(NSInteger)index;
+ (BOOL) updateMagzine:(NSInteger)magzineId key:(NSString*)key value:(NSValue *)value;
+ (NSString *)magzinePath:(NSInteger)magzineId;
+ (NSMutableArray *)loadSubscribed;
+ (NSMutableArray *)loadAllFreeLogic;
+ (NSMutableArray *)loadAllDonated:(NSString *)user;
+ (NSInteger) getBookmarkArticleId:(NSInteger)magzineId;
+ (NSInteger)getLastReadArticleId:(NSInteger)magzineId;
- (BOOL) insert;
- (BOOL) update:(NSString*)key value:(NSValue *)value;
- (BOOL) remove:(BOOL)dropMetadata;
- (BOOL) isMybook;
+ (NSMutableArray *)loadAllFree:(NSString *)user ;
- (NSString *) formattedPubDate:(BOOL)fullYear;


@end

@interface KSModelMagzineCoverArticle : NSObject
@property(nonatomic, assign) NSInteger magzineId;
@property(nonatomic, assign) NSInteger articleId;
@property(nonatomic, retain) NSString *articleTitle;
@property(nonatomic, assign) NSInteger ranking;

+ (KSModelMagzineCoverArticle *) magzineCoverArticleWith:(NSDictionary *)dict magzineId:(NSInteger)magzineId;
- (BOOL) insert;
+ (NSArray *) magzineCoverArticles:(NSInteger)magzineId;
@end
