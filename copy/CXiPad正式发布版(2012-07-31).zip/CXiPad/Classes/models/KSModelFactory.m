//
//  KSModelFactory.m
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-21.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSModelFactory.h"

static KSModelFactory *factory;
@implementation KSModelFactory
@synthesize root = _root;
+ (KSModelFactory *) sharedFactory:(NSString *)rootDir{
    if(factory==nil){
        factory = [[KSModelFactory alloc] init];
        factory.root = rootDir;
    }
    return factory;
}

- (NSDictionary *) _dictWithJsonFile:(NSString *)jsonFile{
    NSData *jsonData = [NSData dataWithContentsOfFile:jsonFile];
    if(jsonData==nil)return nil;
    return [[CJSONDeserializer deserializer] deserializeAsDictionary:jsonData error:nil];
}

- (KSModelArticle *) articleById:(NSInteger) articleId magzineId:(NSInteger) magzineId{
    NSString *jsonFile = [_root stringByAppendingFormat:@"/magzineUnpack%d/%d/json.js", magzineId, articleId];
    NSDictionary *dict = [self _dictWithJsonFile:jsonFile];
    KSModelArticle *article = [KSModelArticle articleWith:dict];
    NSString *htmlFile = [_root stringByAppendingFormat:@"/magzineUnpack%d/%d/a.html", magzineId, articleId];
    NSString *html = [NSString stringWithContentsOfFile:htmlFile encoding:NSUTF8StringEncoding error:nil];
    NSRange range = [html rangeOfString:@"<header>"];
    if(range.length>0){
        NSString *header = [html substringFromIndex:range.location+range.length];
        range = [header rangeOfString:@"</header>"];
        header = [header substringToIndex:range.location];
        article.header = header;
    }
    range = [html rangeOfString:@"<article>"];
    if(range.length>0){
        NSString *content = [html substringFromIndex:range.location+range.length];
        range = [content rangeOfString:@"</article>"];
        content = [content substringToIndex:range.location];
        article.content = content;
    }else{
        article.content = html;
    }
    return article;
}

- (KSModelMagzine *) magzineById:(NSInteger) magzineId{
    NSString *jsonFile = [_root stringByAppendingFormat:@"/magzineUnpack%d/json.js", magzineId];
    NSDictionary *dict = [self _dictWithJsonFile:jsonFile];
    KSModelMagzine *magzine = [KSModelMagzine magzineWith:dict];
    magzine.cover_2 = [_root stringByAppendingFormat:@"/magzineUnpack%d/files/cover_2.jpg", magzineId];
    magzine.cover_3 = [_root stringByAppendingFormat:@"/magzineUnpack%d/files/cover_3.jpg", magzineId];
    return magzine;
}

- (KSModelCatalog *) catalogById:(NSInteger) magzineId{
    NSString *jsonFile = [_root stringByAppendingFormat:@"/magzineUnpack%d/catalog.js", magzineId];
    NSDictionary *dict = [self _dictWithJsonFile:jsonFile];
    KSModelCatalog *catalog = [KSModelCatalog catalogWith:dict];
    return catalog;
}

- (void) dealloc{
    [_root release];
    [super dealloc];
}
@end
