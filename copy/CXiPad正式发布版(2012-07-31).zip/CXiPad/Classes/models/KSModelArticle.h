//
//  KSModelArticle.h
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-21.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface KSModelArticle : NSObject

@property(nonatomic, assign) NSInteger articleId;
@property(nonatomic, assign) NSInteger magzineId;
@property(nonatomic, assign) NSInteger catagoryId;
@property(nonatomic, assign) NSInteger vcolumns;
@property(nonatomic, assign) NSInteger hcolumns;
@property(nonatomic, assign) BOOL isFree;
@property(nonatomic, assign) BOOL isHtml;
@property(nonatomic, assign) BOOL isDownload;
@property(nonatomic, assign) BOOL isParsed;
@property(nonatomic, assign) BOOL isBookmark;
@property(nonatomic, retain) NSString* title;
@property(nonatomic, retain) NSString* subtitle;
@property(nonatomic, retain) NSString* summary;
@property(nonatomic, retain) NSString* authors;
@property(nonatomic, retain) NSString* picAuthors;
@property(nonatomic, retain) NSString* header;
@property(nonatomic, retain) NSString* content;
@property(nonatomic, assign) NSInteger contentLength;
@property(nonatomic, assign) NSInteger status;
@property(nonatomic, assign) NSInteger ranking;
@property(nonatomic, assign) NSInteger rankingInMagzine;
@property(nonatomic, retain) NSString* videoSrc;
@property(nonatomic, retain) NSString* video2;
@property(nonatomic, retain) NSString* video3;
@property(nonatomic, retain) NSString* audioSrc;
@property(nonatomic, retain) NSString* filepath;
@property(nonatomic, assign) NSInteger artitype;
@property(nonatomic, assign) NSInteger parentId;
@property(nonatomic, assign) NSInteger sourceId;
@property(nonatomic, retain) NSString* shareUrl;
@property(nonatomic, retain) NSString* coordinates;
@property(nonatomic, assign) BOOL pageable;
@property(nonatomic, assign) BOOL scrollable;
@property(nonatomic, retain) NSString* leve2CatalogName;
@property(nonatomic, retain) NSString* catalogPicPath;
@property(nonatomic, assign) NSInteger catalogPicType;

+ (KSModelArticle *) articleWithDict:(NSDictionary *)dict;
+ (KSModelArticle *) articleWith:(NSDictionary *)dict;
+ (NSMutableArray *) articlesInMagzine:(NSInteger)magzineId;
+ (NSArray *)childArticlesInArtilce:(NSInteger)aId;
+ (KSModelArticle *) loadById:(NSInteger)articleId withContent:(BOOL)withContent;
+ (BOOL) updateArticle:(NSInteger)articleId key:(NSString*)key value:(NSValue *)value;
+ (BOOL) isBookmark:(NSInteger)articleId;
+ (BOOL)articlesInCatalog:(NSInteger)CatalogId;
+ (NSString *) articlePath:(NSInteger)articleId magzineId:(NSInteger)magzineId;
- (void) withContent;
- (BOOL) insert;
- (BOOL) update:(NSString *)key value:(NSValue *)value;
- (NSString *) htmlFile:(NSInteger)oriention;
- (NSString *) articlePath;
- (void) toggleBookmark;
- (void)toggleLastReadArticle;
@end
