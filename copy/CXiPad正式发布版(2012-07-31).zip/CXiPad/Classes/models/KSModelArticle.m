//
//  KSModelArticle.m
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-21.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSModelArticle.h"

#pragma mark KSModelArticle
@implementation KSModelArticle
@synthesize articleId=_articleId,audioSrc=_audioSrc,hcolumns=_hcolumns,
isFree=_isFree, isDownload=_isDownload, vcolumns=_vcolumns,videoSrc=_videoSrc,
magzineId=_magzineId, summary = _summary, title = _title,
header = _header, content = _content, isHtml = _isHtml,
status = _status, authors = _authors,picAuthors =_picAuthors, ranking = _ranking,
isParsed = _isParsed, subtitle = _subtitle, catagoryId = _catagoryId,
contentLength = _contentLength, rankingInMagzine = _rankingInMagzine,
isBookmark = _isBookmark,leve2CatalogName = _leve2CatalogName,catalogPicPath=_catalogPicPath,catalogPicType=_catalogPicType;
@synthesize artitype = _artitype;
@synthesize filepath = _filepath;
@synthesize video2 = _video2;
@synthesize video3 = _video3;
@synthesize parentId = _parentId;
@synthesize sourceId = _sourceId;
@synthesize shareUrl = _shareUrl;
@synthesize coordinates = _coordinates;
@synthesize scrollable = _scrollable;
@synthesize pageable = _pageable;

+ (KSModelArticle *) articleWithDict:(NSDictionary *)dict {
    KSModelArticle *item = [[[KSModelArticle alloc] init] autorelease];
    item.articleId = DICT_INTVAL(dict, @"metadata.id");                             //文章ID
    item.magzineId = DICT_INTVAL(dict, @"metadata.periodicalid");                   //期刊ID
    item.catagoryId = DICT_INTVAL(dict, @"categoryid");                             //栏目ID
    item.ranking = DICT_INTVAL(dict, @"metadata.artiorder");                        //排序
    item.isHtml = ![DICT_VAL(dict, @"metadata.type") isEqualToString:@"cortext"];   //是否为coretext文章
    item.title = DICT_VAL(dict, @"metadata.title");                                 //标题
    item.subtitle = DICT_VAL(dict, @"metadata.subtitle");                           //副标题
    item.authors = DICT_VAL(dict, @"metadata.author");                              //作者
    item.picAuthors = DICT_VAL(dict, @"mulu_pic_author");                           //目录页作者
    item.summary = DICT_VAL(dict, @"metadata.summary");                             //摘要
    item.contentLength = DICT_INTVAL(dict, @"metadata.contentlength");              //长度
    item.videoSrc = DICT_VAL(dict, @"metadata.video");                              //视频
    item.video2 = DICT_VAL(dict, @"metadata.video2");
    item.video3 = DICT_VAL(dict, @"metadata.video3");
    item.audioSrc = DICT_VAL(dict, @"metadata.audio");                              //音频
    item.parentId = DICT_INTVAL(dict, @"metadata.parentid");
    item.sourceId = DICT_INTVAL(dict, @"metadata.sourceid");                        //源ID
    item.isFree = DICT_INTVAL(dict, @"metadata.isfree")==1;                         //是否免费
    item.shareUrl = DICT_VAL(dict, @"metadata.sharesiteurl");                       //分享链接
    item.coordinates = DICT_VAL(dict, @"metadata.coordinates");                     //地图坐标
    item.artitype = DICT_INTVAL(dict, @"metadata.artitype");                        //文章类型
    item.scrollable = DICT_BOOLVAL(dict, @"metadata.scrollable");                   
    item.pageable = DICT_BOOLVAL(dict, @"metadata.pageable");
    return item;
}
+ (KSModelArticle *) articleWith:(NSDictionary *)dict{
    KSModelArticle *item = [[[KSModelArticle alloc] init] autorelease];
    item.articleId = DICT_INTVAL(dict, @"id");
    item.magzineId = DICT_INTVAL(dict, @"periodicalid");
    item.catagoryId = DICT_INTVAL(dict, @"categoryid");
    item.ranking = DICT_INTVAL(dict, @"artiorder");
    item.isHtml = ![DICT_VAL(dict, @"type") isEqualToString:@"cortext"];
    item.title = DICT_VAL(dict, @"title");
    item.subtitle = DICT_VAL(dict, @"subtitle");
    item.authors = DICT_VAL(dict, @"author");
    item.picAuthors = DICT_VAL(dict, @"mulu_pic_author");
    item.summary = DICT_VAL(dict, @"summary");
    item.contentLength = DICT_INTVAL(dict, @"contentlength");
    item.videoSrc = DICT_VAL(dict, @"video");
    item.video2 = DICT_VAL(dict, @"video2");
    item.video3 = DICT_VAL(dict, @"video3");
    item.audioSrc = DICT_VAL(dict, @"audio");
    item.isFree = DICT_BOOLVAL(dict, @"isfree");
    item.parentId = DICT_INTVAL(dict, @"parentid");
    item.sourceId = DICT_INTVAL(dict, @"sourceid");
    item.shareUrl = DICT_VAL(dict, @"sharesiteurl");
    item.coordinates = DICT_VAL(dict, @"coordinates");
    item.artitype = DICT_INTVAL(dict, @"artitype");
    item.pageable = DICT_BOOLVAL(dict, @"pageable");
    item.scrollable = DICT_BOOLVAL(dict, @"scrollable");
    item.catalogPicType = DICT_INTVAL(dict, @"mulu_pic_place");
    item.catalogPicPath = DICT_VAL(dict, @"mulu_url");
    return item;
}

+ (KSModelArticle *) itemByDbDict:(NSDictionary *)dict{
    KSModelArticle *item = [[[KSModelArticle alloc] init] autorelease];
    item.articleId = DICT_INTVAL(dict, @"article_id");
    item.magzineId = DICT_INTVAL(dict, @"magzine_id");
    item.catagoryId = DICT_INTVAL(dict, @"catalog_id");
    item.ranking = DICT_INTVAL(dict, @"ranking");
    item.rankingInMagzine = DICT_INTVAL(dict, @"rankin_in_magzine");
    item.isDownload = DICT_BOOLVAL(dict, @"is_download");
    item.isParsed = DICT_BOOLVAL(dict, @"is_parsed");
    item.isHtml = DICT_BOOLVAL(dict, @"is_html");
    item.artitype = DICT_INTVAL(dict, @"arti_type");
    item.title = DICT_VAL(dict, @"title");
    item.subtitle = DICT_VAL(dict, @"subtitle");
    item.authors = DICT_VAL(dict, @"authors");
    item.picAuthors = DICT_VAL(dict, @"mulu_pic_author");
    item.summary = DICT_VAL(dict, @"summary");
    item.contentLength = DICT_INTVAL(dict, @"content_length");
    item.videoSrc = DICT_VAL(dict, @"video_src");
    item.video2 = DICT_VAL(dict, @"video2");
    item.video3 = DICT_VAL(dict, @"video3");
    item.audioSrc = DICT_VAL(dict, @"audio_src");
    item.isFree = DICT_BOOLVAL(dict, @"is_free");
    item.vcolumns = DICT_INTVAL(dict, @"vcolumns");
    item.hcolumns = DICT_INTVAL(dict, @"hcolumns");
    item.parentId = DICT_INTVAL(dict, @"parent_id");
    item.sourceId = DICT_INTVAL(dict, @"source_id");
    item.shareUrl = DICT_VAL(dict, @"share_url");
    item.coordinates = DICT_VAL(dict, @"coordinates");
    item.pageable = DICT_BOOLVAL(dict, @"pageable");
    item.scrollable = DICT_BOOLVAL(dict, @"scrollable");

    item.isBookmark = [self isBookmark:item.articleId];
    item.filepath = [[KSBootstrap root] stringByAppendingFormat:@"/magzineUnpack%d/%d", item.magzineId, item.articleId];
    item.catalogPicType = DICT_INTVAL(dict, @"catalogpictype");
    item.catalogPicPath = [[KSBootstrap root] stringByAppendingFormat:@"/magzineUnpack%d/%d/%@", item.magzineId, item.articleId,DICT_VAL(dict, @"catalogpicpath")];
    return item;
}

+ (NSMutableArray *) articlesInMagzine:(NSInteger)magzineId{
    NSMutableArray *result = [[NSMutableArray alloc] init];
    FMResultSet *rs = [[KSDB db] executeQuery:@"select * from articles where magzine_id=? AND parent_id=0 order by rankin_in_magzine asc", INTEGER(magzineId)];
    while (rs.next) {
        NSDictionary *dict = [rs resultDict];
        [result addObject:[self itemByDbDict:dict]];
    }
    return [result autorelease];
}
+ (NSArray *)childArticlesInArtilce:(NSInteger)aId {
    NSMutableArray *result = [NSMutableArray arrayWithCapacity:3];
    FMResultSet *rs = [[KSDB db] executeQuery:@"select * from articles where article_id in (select child_id from article_children where article_id=?) order by rankin_in_magzine asc", INTEGER(aId)];
    while (rs.next) {
        NSDictionary *dict = [rs resultDict];
        [result addObject:[self itemByDbDict:dict]];
    }
    return result;
}
+ (BOOL)articlesInCatalog:(NSInteger)CatalogId {
//    NSMutableArray *result = [NSMutableArray arrayWithCapacity:3];
    FMResultSet *rs = [[KSDB db] executeQuery:@"select * from articles where catalog_id = ? order by rankin_in_magzine asc", INTEGER(CatalogId)];
    if (rs.next)
    {
        return YES;
    }
    return NO;
}
+ (KSModelArticle *) loadById:(NSInteger)articleId withContent:(BOOL)withContent{
    FMResultSet *rs = [[KSDB db] executeQuery:@"select * from articles where article_id=?", INTEGER(articleId)];
    if(rs.next){
        KSModelArticle *result = [self itemByDbDict:[rs resultDict]];
        if(withContent){
            [result withContent];
        }
        //add article's leve2CatalogName  //cxy
        NSNumber *catalog_id = [rs objectForColumnName:@"catalog_id"];
        if(catalog_id != nil){
            FMResultSet *catalog_rs = [[KSDB db] executeQuery:@"select * from catalogs where catalog_id=? and parent_id >0",catalog_id]; 
            if(catalog_rs.next){
                result.leve2CatalogName = [catalog_rs objectForColumnName:@"title"];
            }
        }
        return result;
    }
    return nil;
}
+ (BOOL) updateArticle:(NSInteger)articleId key:(NSString *)key value:(NSValue *)value{
    NSString *sql = [NSString stringWithFormat:@"update articles set %@=? where article_id=?", key];
    return [[KSDB db] executeUpdate:sql, value, [NSNumber numberWithInt:articleId]];
}

+ (BOOL)isBookmark:(NSInteger)articleId{
    NSString *user = [KSBootstrap currentUser];
    if(!user){user = @"anonymouse";}
    return[[KSDB db] intForQuery:@"select count(*) from my_bookmarks where article_id=? and user_email=?", INTEGER(articleId), user]>0;
}

+ (NSString *)articlePath:(NSInteger)articleId magzineId:(NSInteger)magzineId{
    if(magzineId<=0){
        KSModelArticle *article = [self loadById:articleId withContent:NO];
        magzineId = article.magzineId;
    }
    return STR_FORMAT(@"%@/%d", [KSModelMagzine magzinePath:magzineId], articleId);
}

- (void) withContent{
    if(_content)return;
    NSString *htmlFile = [[KSBootstrap root] stringByAppendingFormat:@"/magzineUnpack%d/%d/article.html", _magzineId, _articleId];
    NSString *html = [NSString stringWithContentsOfFile:htmlFile encoding:NSUTF8StringEncoding error:nil];
    NSRange range = [html rangeOfString:@"<header>"];
    if(range.length>0){
        NSString *header = [html substringFromIndex:range.location+range.length];
        range = [header rangeOfString:@"</header>"];
        header = [header substringToIndex:range.location];
        _header = [header retain];
    }
    range = [html rangeOfString:@"<article>"];
    if(range.length>0){
        NSString *content = [html substringFromIndex:range.location+range.length];
        range = [content rangeOfString:@"</article>"];
        content = [content substringToIndex:range.location];
        _content = [content retain];
    }else{
        _content = [html retain];
    }
}

- (BOOL) insert{
    NSString *sql = @"insert into articles (catalogPicType,catalogPicPath,article_id, magzine_id, catalog_id, ranking, rankin_in_magzine, is_download, is_parsed, is_html, title, subtitle, authors,mulu_pic_author, summary, content_length, video_src, audio_src, parent_id, source_id, share_url, coordinates, pageable, scrollable, is_free, vcolumns, hcolumns) values(?,?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    return [[KSDB db] executeUpdate:sql, INTEGER(_catalogPicType),_catalogPicPath,INTEGER(_articleId), INTEGER(_magzineId), INTEGER(_catagoryId), INTEGER(_ranking), INTEGER(_rankingInMagzine), INTEGER(_isDownload?1:0), INTEGER(_isParsed?1:0), INTEGER(_isHtml?1:0), _title, _subtitle, _authors,_picAuthors?_picAuthors:@"", _summary, INTEGER(_contentLength), _videoSrc, _audioSrc, INTEGER(_parentId), INTEGER(_sourceId), _shareUrl, _coordinates, INTEGER(_pageable?1:0), INTEGER(_scrollable?1:0), INTEGER(_isFree?1:0), INTEGER(_vcolumns), INTEGER(_hcolumns)];
}

- (BOOL)update:(NSString *)key value:(NSValue *)value{
    return [KSModelArticle updateArticle:_articleId key:key value:value];
}

- (NSString *) htmlFile:(NSInteger)oriention{
    NSString *filename = isPad?(oriention==0?@"ipad_v":@"ipad_h"):(oriention==0?@"iphone_v":@"iphone_h");
    return STR_FORMAT(@"%@/%@.html", [KSModelArticle articlePath:_articleId magzineId:_magzineId], filename);
}

- (NSString *)articlePath{
    return [KSModelArticle articlePath:_articleId magzineId:_magzineId];
}

- (void)toggleBookmark{
    NSString *user = [KSBootstrap currentUser];
    if(!user){user = ANONY_USER;}
    if(self.isBookmark){
        self.isBookmark = NO;
        [[KSDB db] executeUpdate:@"delete from my_bookmarks where magzine_id=? and user_email=?", INTEGER(_magzineId), user];
    }else{
        self.isBookmark = YES;
        [[KSDB db] executeUpdate:@"delete from my_bookmarks where magzine_id=? and user_email=?", INTEGER(_magzineId), user];
        [[KSDB db] executeUpdate:@"insert into my_bookmarks(user_email, magzine_id, article_id) values(?, ?, ?)", user, INTEGER(_magzineId), INTEGER(_articleId)];
    }
}
- (void)toggleLastReadArticle {
    [[KSDB db] executeUpdate:@"INSERT OR REPLACE INTO last_read_article(magzine_id, article_id) VALUES(?, ?)", INTEGER(_magzineId), INTEGER(_articleId)];
}
- (void) dealloc{
    [_title release];
    [_subtitle release];
    [_summary release];
    [_authors release];
    [_picAuthors release];
    [_header release];
    [_content release];
    [_video2 release];
    [_video3 release];
    [_videoSrc release];
    [_audioSrc release];
    [_filepath release];
    [_shareUrl release];
    [_coordinates release];
    [_leve2CatalogName release];
    [_catalogPicPath release];
    [super dealloc];
}
@end

