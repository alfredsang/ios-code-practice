//
//  KSModelCollectionItem.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-20.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSModelCollectionItem.h"

@implementation KSModelCollectionItem
@synthesize articleId = _articleId, cover = _cover,
title = _title, summary = _summary, magzineId = _magzineId, pubDate = _pubDate,
createDate = _createDate, userEmail = _userEmail;
@synthesize magazineTitle = _magzineTitle;
@synthesize stageNumber = _stageNumber;

+ (NSString *) getArticleFirstImage:(NSInteger)articleId{
    KSModelArticle *article = [KSModelArticle loadById:articleId withContent:NO];
    if(article.isHtml){
        NSFileManager *fileManager = [[NSFileManager alloc] autorelease];
        NSString *articlePath = [article articlePath];
        BOOL isDir = NO;
        NSArray *subpaths = nil;
        if ([fileManager fileExistsAtPath:articlePath isDirectory:&isDir] && isDir){
            subpaths = [fileManager subpathsAtPath:articlePath];
        }
        for (NSString *sub in subpaths) {
            NSString *abs = [articlePath stringByAppendingPathComponent:sub];
            if(![fileManager fileExistsAtPath:abs isDirectory:&isDir] || isDir)continue;
            NSString *fileExt = [[[sub componentsSeparatedByString:@"."] lastObject] lowercaseString];
            if([@"jpg" isEqualToString:fileExt] || [@"png" isEqualToString:fileExt] ||
               [@"gif" isEqualToString:fileExt] || [@"bmp" isEqualToString:fileExt]){
                return abs;
            }
        }
        return nil;
    }
    NSString *sql = @"select image from article_images where article_id=? order by page asc, left asc, top asc";
    NSString *relativePath = [[KSDB db] stringForQuery:sql, INTEGER(articleId)];
    if (relativePath && [relativePath length]) {
        return STR_FORMAT(@"%@/%@", [article articlePath], relativePath);
    }
    return nil;
}

+ (KSModelCollectionItem *) itemByDbDict:(NSDictionary *)dict{
    KSModelCollectionItem *item = [[[KSModelCollectionItem alloc] init] autorelease];
    item.title = DICT_VAL(dict, @"title");
    item.magzineId = DICT_INTVAL(dict, @"magzine_id");
    item.articleId = DICT_INTVAL(dict, @"article_id");
    item.pubDate = DICT_INTVAL(dict, @"pub_date");
//    item.cover = [KSModelMagzine magzineCover:item.magzineId index:1];
    item.cover = [self getArticleFirstImage:item.articleId];
    item.summary = DICT_VAL(dict, @"summary");
    item.createDate = DICT_INTVAL(dict, @"create_date");
    item.magazineTitle = DICT_VAL(dict, @"magzine_title");
    item.stageNumber = DICT_VAL(dict, @"stage_number");

    KSModelMagzine *magzine = [KSModelMagzine loadById:item.magzineId];
    //item.stageNumber = magzine.isSpecialIssue==1?STR_FORMAT(@"%d", magzine.stageNumber):magzine.customIssueNumber;
    item.pubDate = magzine.pubDate;
    item.magazineTitle = magzine.coverTitle;
    
    return item;
}

+ (NSArray *) collectionItems{
    NSString *user = [KSBootstrap currentUser];
    if (!user) {
        user = ANONY_USER;
    }
    NSMutableArray *entries = [NSMutableArray arrayWithCapacity:20];
    FMResultSet *rs = [[KSDB db] executeQuery:@"select * from my_collections where user_email=? order by create_date desc", user];
    while (rs.next) {
        NSDictionary *dict = [rs resultDict];
        [entries addObject:[self itemByDbDict:dict]];
    }
    return entries;
}

+ (BOOL) isInCollection:(NSInteger)articleId{
    NSString *user = [KSBootstrap currentUser];
    if (!user) {
        user = ANONY_USER;
    }
    return [[KSDB db] intForQuery:@"select count(*) from my_collections where user_email=? and article_id=?", user, INTEGER(articleId)] > 0;
}

+ (BOOL)unMarkCollection:(NSInteger)articleId {
    NSString *user = [KSBootstrap currentUser];
    if (!user) {
        user = ANONY_USER;
    }
    NSString *sql = @"delete from my_collections where article_id=? and user_email=?";
    return [[KSDB db] executeUpdate:sql,INTEGER(articleId),user];
}
+ (BOOL) markCollection:(NSInteger)articleId{
    NSString *user = [KSBootstrap currentUser];
    if (!user) {
        user = ANONY_USER;
    }
    KSModelCollectionItem *item = [[[KSModelCollectionItem alloc] init] autorelease];
    item.userEmail = user;
    item.articleId = articleId;
    item.createDate = [[NSDate date] timeIntervalSince1970];
    NSString *sql = @"select a.magzine_id, a.title, a.summary, m.pub_date, m.is_special_issue,m.stage_number,m.custom_number from articles a left join magzines m on a.magzine_id=m.magzine_id where a.article_id=?";
    FMResultSet *rs = [[KSDB db] executeQuery:sql, INTEGER(articleId)];
    if(!rs.next)return NO;
    NSDictionary *resultDict = rs.resultDict;
    item.magzineId = DICT_INTVAL(resultDict, @"magzine_id");
    item.title = DICT_VAL(resultDict, @"title");
    item.summary = DICT_VAL(resultDict, @"summary");
    item.pubDate = DICT_INTVAL(resultDict, @"pub_date");
    item.stageNumber = DICT_BOOLVAL(resultDict, @"is_special_issue")?DICT_VAL(resultDict, @"custom_number"):[NSString stringWithFormat:@"%d",DICT_INTVAL(resultDict, @"stage_number")];
    return [item insert];
}

- (BOOL) insert{
    NSString *sql = @"insert into my_collections (article_id, magzine_id, title, summary, pub_date, create_date, user_email,stage_number) values(?, ?, ?, ?, ?, ?, ?, ?)";
    return [[KSDB db] executeUpdate:sql, INTEGER(_articleId), INTEGER(_magzineId), _title, _summary, INTEGER(_pubDate), DOUBLE(_createDate), _userEmail, _stageNumber];
}

- (BOOL) removeFromDb{
    return [[KSDB db] executeUpdate:@"delete from my_collections where article_id=?", INTEGER(_articleId)];
}

- (void) dealloc{
    [_title release];
    [_summary release];
    [_cover release];
    [_userEmail release];
    [_magzineTitle release];
    [_stageNumber release];
    
    [super dealloc];
}
@end
