//
//  KSDownloader.m
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSDownloader.h"

@implementation KSDownloader
@synthesize delegate = _delegate, progressView = _progressView, error = _error, requestUrl = _requestUrl, data = _data;
@synthesize onDownloadCancelled = _onDownloadCancelled, onDownloadCompleted = _onDownloadCompleted, onDownloadFailed = _onDownloadFailed;
#pragma mark RequestDelegate
- (void)requestFinished:(ASIHTTPRequest *)aRequest{
    aRequest.delegate = nil;
	NSFileManager *fileManager = [NSFileManager defaultManager];
	BOOL isFileExist = [fileManager fileExistsAtPath:_saveTo];
    //KSDERROR(@"%d", aRequest.responseStatusCode);
	if((aRequest.responseStatusCode==200 ||
        aRequest.responseStatusCode==416 ||
        aRequest.responseStatusCode==206 ) && isFileExist ){
        if(_onDownloadCompleted){
            _onDownloadCompleted();
        }
        if([_delegate respondsToSelector:@selector(onDownloadSuccess:)]){
            [_delegate onDownloadSuccess:self];
        }
	}else{
        if(_onDownloadFailed){
            _onDownloadFailed(nil);
        }
        if([_delegate respondsToSelector:@selector(onDownloadFail:)]){
            [_delegate onDownloadFail:self];
        }
	}
//真机4.x导致crash,注释掉下两行
//    [_request release];
//    _request = nil;
}
- (void)requestFailed:(ASIHTTPRequest *)aRequest{
	_error = [[aRequest error] retain];
    if(_onDownloadFailed){
        _onDownloadFailed(_error);
    }
    if([_delegate respondsToSelector:@selector(onDownloadFail:)]){
        [_delegate onDownloadFail:self];
    }
//真机4.x导致crash,注释掉下两行
//    [_request release];
//    _request = nil;
}

#pragma mark ASIProgressDelegate
- (void)setProgress:(float)newProgress{
    [_delegate setDownloadProgress:newProgress];
}

#pragma mark Downloader
- (id)init:(NSString *)requestUrl saveTo:(NSString *)saveTo asyn:(BOOL)asyn{
    self = [super init];
    if (self) {
        _requestUrl = [requestUrl retain];
        _saveTo = [saveTo retain];
        _asyn = asyn;
    }
    return self;
}

- (void) start{
    NSString* downloadFile = _saveTo;
	_request = [[ASIHTTPRequest requestWithURL:[NSURL URLWithString:_requestUrl]] retain];
	[_request setDelegate:self];
    [_request setTimeOutSeconds:600];
	[_request setDownloadDestinationPath:downloadFile];
	[_request setAllowResumeForFileDownloads:YES];
	[_request setTemporaryFileDownloadPath:[downloadFile stringByAppendingString:@".tmp"]];
//    _request.shouldRedirect=YES;
    
	if(_progressView){
		_request.showAccurateProgress = YES;
		[_request setDownloadProgressDelegate:_progressView];
	}
    if([_delegate respondsToSelector:@selector(onDownloadStart:)]){
        [_delegate onDownloadStart:self];
    }
    if(_asyn){
        [_request startAsynchronous];
    }else{
        [_request startSynchronous];
    }
    KSDINFO(@"_request start %@", _requestUrl);
}
- (void)setProgressView:(UIProgressView *)progressView {
    _progressView = progressView;
    _request.showAccurateProgress = YES;
    [_request setDownloadProgressDelegate:_progressView];
}
- (void)cancel {
    [_request cancel];
    [_request clearDelegatesAndCancel];
    if(_onDownloadCancelled){
        _onDownloadCancelled();
    }
    if([_delegate respondsToSelector:@selector(onDownloadCancel:)]){
        [_delegate onDownloadCancel:self];
    }
//真机4.x导致crash,注释掉下两行
//    [_request release];
//    _request = nil;
}

- (void)dealloc {
    [_delegate release];
    [_saveTo release];
    [_requestUrl release];
    [_error release];
    [_onDownloadCancelled release];
    [_onDownloadCompleted release];
    [_onDownloadFailed release];
    if(_request){
        [_request release];
        _request = nil;
    }
    [super dealloc];
}
@end
