//
//  KSPageView.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 1/15/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "KSPageView.h"


@implementation KSPageView
@synthesize pageIndex = _pageIndex;
@synthesize dataList = _dataList;
@synthesize cacheViewsList = _cacheViewsList;
- (void)dealloc {
    _scrollView.delegate = nil;
    [_scrollView release];
    [_cacheViewsList release];
    [_dataList release];
    [_freeViewsList release];
    
    [super dealloc];
}
- (void)loadView {
    
    _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, self.width, self.height)];
    
    //_scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    //_scrollView.backgroundColor = [UIColor grayColor];
    
    _scrollView.DelaysContentTouches = NO;
    _scrollView.scrollsToTop = NO;
    _scrollView.showsHorizontalScrollIndicator = NO;
    _scrollView.showsVerticalScrollIndicator = NO;
    _scrollView.scrollEnabled = YES;
    _scrollView.pagingEnabled = YES;
    _scrollView.delegate = self;
    _scrollView.contentSize = CGSizeMake(_pageWidth*_pageCount, _scrollView.height);
    [self addSubview:_scrollView];
    //[self moveToViewAtPage:0 animated:NO];
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        _cacheViewsList = [[NSMutableArray alloc] initWithCapacity:1];
        //_pageCount = [_cacheViewsList count]/_pageSize;
        //_pageCount = _pageCount + ([_cacheViewsList count]%_pageSize == 0?0:1);
        _pageSize = 1;
        _cellWidth = self.width;
        _pageWidth = self.width;
        _formerPageIndex = _pageIndex = 0;
        //[self loadView];
    }
    return self;
}

#pragma mark -
#pragma for subclass
//创建新的详细内容视图
- (UIView *)newCachedView:(NSInteger)index {
    assert(@"subclass should implement this method.");
    return nil;
}
//显示详细某详细内容视图时，可能需要对应的操作，改变父视图状态或
//调用其它代理方法
- (void)setCachedViewState:(NSInteger)index {
    
}

#pragma mark -
- (NSInteger)centerViewIndex {
    CGFloat pageWidth = _scrollView.frame.size.width;
	return floor((_scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
}
- (void)layoutScrollViewSubviewsAnimated:(BOOL)animated{
	NSInteger page = [self centerViewIndex];
    //NSInteger page = _pageIndex;
	//CGRect destFrame = _scrollView.frame;
	if (animated) {
		[UIView beginAnimations:nil context:NULL];
		[UIView setAnimationDuration:.1];
	}
	
    //  layout center
    if (page >= 0 && page < _pageCount){
        for (int i=0; i<_pageSize; i++) {
            NSInteger itemIndex = page*_pageSize+i;
            if ([_cacheViewsList objectAtIndex:itemIndex] != [NSNull null]){
                UIView *v = [_cacheViewsList objectAtIndex:itemIndex];
                v.frame = CGRectMake(_cellWidth * itemIndex, 0.0f, _cellWidth, v.height);
            }
        }
    }
	
    //  layout left
    if (page-1 >= 0){
        for (int i=0; i<_pageSize; i++) {
            NSInteger itemIndex = (page-1)*_pageSize+i;
            if ([_cacheViewsList objectAtIndex:itemIndex] != [NSNull null]){
                UIView *v = [_cacheViewsList objectAtIndex:itemIndex];
                v.frame = CGRectMake(_cellWidth * itemIndex, 0.0f, _cellWidth, v.height);
            }
        }
    }
    
    //  layout right
    if (page+1 < _pageCount) {
        for (int i=0; i<_pageSize; i++) {
            NSInteger itemIndex = (page+1)*_pageSize+i;
            UIView *v = [_cacheViewsList objectAtIndex:itemIndex];
            if ((NSNull *)v != [NSNull null]){
                v.frame = CGRectMake(_cellWidth * itemIndex, 0.0f, _cellWidth, v.height);
            }
        }
    }
	
	if (animated) {
		[UIView commitAnimations];
	}
}
- (void)loadScrollViewWithPage:(NSInteger)page {
	if (page < 0) return;
    if (page >= _pageCount) return;

    // replace the placeholder if necessary 
	for (int i=0; i<_pageSize; i++) {
        NSInteger itemIndex = _pageSize*page + i;
        UIView *cachedView = [_cacheViewsList objectAtIndex:itemIndex];
        if (cachedView == nil || (NSNull*)cachedView == [NSNull null]) {
            NSLog(@"begin newCachedView itemIndex=%d",itemIndex);
            cachedView = [self newCachedView:itemIndex];
            [_cacheViewsList replaceObjectAtIndex:itemIndex withObject:cachedView];
            if (cachedView.superview == nil) {
                [_scrollView addSubview:cachedView];
            }
            [cachedView release];
            NSLog(@"end newCachedView itemIndex=%d",itemIndex);
        }
    }
}
- (void)unLoadScrollViewWithPage:(NSInteger)page {
    if (page < 0) return;
    if (page >= _pageCount) return;
   // NSLog(@"begin unLoadScrollViewWithPage page=%d",page);
    for (int i = 0; i < [_cacheViewsList count]; i++) {
        if (i<(page-1)*_pageSize || i>(page+2)*_pageSize) {
            UIView *view = [_cacheViewsList objectAtIndex:i];
            if ((NSNull *)view != [NSNull null]) {
          //      NSLog(@"begin unLoadScrollViewWithPage valid i=%d",i);
                [view removeFromSuperview];
                [_cacheViewsList replaceObjectAtIndex:i withObject:[NSNull null]];
          //      NSLog(@"end unLoadScrollViewWithPage valid i=%d",i);
            }
        }
    }
    NSLog(@"end unLoadScrollViewWithPage page=%d",page);
}
- (void)moveToViewAtPage:(NSInteger)page animated:(BOOL)animated{
    _pageIndex = page;
	if (!_cacheViewsList || ![_cacheViewsList count]) {
        return;
    }
    if (_pageIndex >= _pageCount) {
        _pageIndex = _pageCount-1;
    }
    [self unLoadScrollViewWithPage:_pageIndex];
    
    [self loadScrollViewWithPage:_pageIndex-1];
    [self loadScrollViewWithPage:_pageIndex+1];
    [self loadScrollViewWithPage:_pageIndex];
    
	//[_scrollView scrollRectToVisible:((UIView *)[_cacheViewsList objectAtIndex:page*_pageSize]).frame animated:animated];
    [_scrollView setContentOffset:CGPointMake(_pageIndex*_pageWidth, 0) animated:animated];
   // [self layoutScrollViewSubviewsAnimated:NO];
    [self setCachedViewState:_pageIndex];
    
}
#pragma mark -
#pragma mark UIScrollViewDelegate

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    if (scrollView == _scrollView) {
        _scrolling = YES;
    }
}


- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    if (scrollView == _scrollView && !_rotating) {
        //NSLog(@"begin DidEndDecelerating");
        NSInteger newIndex = [self centerViewIndex];
        [self moveToViewAtPage:newIndex animated:YES];
        _pageIndex = newIndex;
       // NSLog(@"end DidEndDecelerating");
       // [self layoutScrollViewSubviewsAnimated:NO];
    }
	_scrolling = NO;
}

- (void)unloadAllPages {
    NSInteger count = 0;
    for (count=0; count < _pageCount; count++) {
        for (int i = 0; i < _pageSize; i++) {
            UIView *view = [_cacheViewsList objectAtIndex:(count*_pageSize+i)];
            if ((NSNull *)view != [NSNull null] && count!=_pageIndex) {
                [view removeFromSuperview];
                [_cacheViewsList replaceObjectAtIndex:(count*_pageSize+i) withObject:[NSNull null]];
            }
        }
	}
}

@end
