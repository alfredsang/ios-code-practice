//
//  KSPageView.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 1/15/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSTrackScrollView.h"


@protocol KSPageItemViewProtocol <NSObject>
- (void)identifier;
- (void)setItem:(id)obj;
@end

@interface KSPageView : UIView<UIScrollViewDelegate> {
    //KSTrackScrollView *_scrollView;
    UIScrollView *_scrollView;
    //NSArray *_dataList;
    NSMutableArray *_dataList;
    NSMutableArray *_cacheViewsList;
    NSMutableArray *_freeViewsList;
    
    NSInteger _pageCount;
    NSInteger _pageIndex;
    NSInteger _itemIndex;
    NSInteger _formerPageIndex;
    NSInteger _pageSize;
    CGFloat _cellWidth;
    CGFloat _pageWidth;
    
    BOOL _rotating;
    BOOL _scrolling;
    BOOL _loaded;
}
@property(nonatomic, readonly)NSInteger pageIndex;
@property(nonatomic, retain)NSMutableArray *dataList;
@property(nonatomic, retain)NSMutableArray *cacheViewsList;
- (void)loadView;
- (NSInteger)centerViewIndex;
- (void)moveToViewAtPage:(NSInteger)page animated:(BOOL)animated;
- (void)layoutScrollViewSubviewsAnimated:(BOOL)animated;
- (UIView *)newCachedView:(NSInteger)index;
- (void)setCachedViewState:(NSInteger)index;
- (void)unloadAllPages;
- (void)loadScrollViewWithPage:(NSInteger)page;
@end
