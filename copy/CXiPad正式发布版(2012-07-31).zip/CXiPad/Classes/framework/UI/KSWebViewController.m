//
//  KSWebViewController.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 12/26/11.
//  Copyright (c) 2011 KSMobile. All rights reserved.
//

#import "KSWebViewController.h"

@implementation KSWebViewController
@synthesize webViewURL = _webViewURL;

- (void)dealloc {
    _webView.delegate = nil, [_webView stopLoading],[_webView release];
    [_webViewToolbar release];
    [_activityIndicator stopAnimating], [_activityIndicator release];
    [_actionButton release];
    [_refreshButton release];
    [_backButton release];
    [_forwardButton release];
    
    [_webViewURL release];
    
    [super dealloc];
}
- (id)initWithRequestURL:(NSString *)url{
    self = [self initWithRequestURL:url ScalesPageToFit:NO];
	if( self ){
		
	}
	return self;
}
- (id)initWithRequestURL:(NSString *)url ScalesPageToFit:(BOOL)fit{
    self = [self initWithNibName:nil bundle:nil];
	if( self ){
		_webViewURL = [[NSURL URLWithString:url] retain];
		_scalesPageToFit = fit;
	}
	return self;
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        //_scalesPageToFit = YES;
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle


// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
    [super loadView];
    _webView = [[UIWebView alloc] initWithFrame:self.view.bounds];
    _webView.delegate = self;
	_webView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
	((UIScrollView*)[_webView.subviews objectAtIndex:0]).showsHorizontalScrollIndicator = NO;
	((UIScrollView*)[_webView.subviews objectAtIndex:0]).showsVerticalScrollIndicator = NO;
	//((UIScrollView*)[webView.subviews objectAtIndex:0]).backgroundColor = [UIColor blackColor];
	//((UIScrollView*)[webView.subviews objectAtIndex:0]).bounces = NO;
	_webView.scalesPageToFit = _scalesPageToFit;
	_webView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
	[self.view addSubview:_webView];
    
    [_webView loadRequest:[NSURLRequest requestWithURL:_webViewURL]];
}


/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return YES;//(interfaceOrientation == UIInterfaceOrientationPortrait);
}


#pragma mark Web View methods

- (void)webViewDidStartLoad:(UIWebView *)wv {
}

- (void)webViewDidFinishLoad:(UIWebView *)wv {
	self.title = [_webView stringByEvaluatingJavaScriptFromString:@"document.title"];
}

//- (void)webView:(UIWebView *)wv didFailLoadWithError:(NSError *)error {
//	if (error != NULL && ([error code] != NSURLErrorCancelled)) {
//		// NSLog(@"Error: %@", error);
//		
//		if ([error code] != NSURLErrorCancelled) {
//			//show error alert, etc.
//		}
//        UIAlertView *errorAlert = [[UIAlertView alloc]
//								   initWithTitle:@"Error Loading Page"
//								   message: [error localizedFailureReason]
//								   delegate:nil
//								   cancelButtonTitle:@"OK"
//								   otherButtonTitles:nil];
//        [errorAlert show];
//        [errorAlert release];
//    }
//}

- (void)dismiss {
    if ([self respondsToSelector:@selector(presentingViewController)]) {
        
        [self.navigationController.presentingViewController dismissModalViewControllerAnimated:YES];
    }else {
        KSDINFO(@"%@",self.navigationController.parentViewController);
        [self.navigationController.parentViewController dismissModalViewControllerAnimated:YES];
    }
}
#pragma mark - static method
//- (void)openExternalWebView:(NSString *)url{
//	
//	KSWebViewController *webViewController = [[KSWebViewController alloc] initWithRequestURL:url ScalesPageToFit:YES];
//	UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:webViewController];
//	navigationController.modalPresentationStyle = UIModalPresentationPageSheet;
//	UIBarButtonItem *doneItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:[DataEnv sharedDataEnv].menuViewController action:@selector(closeExternalWebView)];
//	navigationController.topViewController.navigationItem.rightBarButtonItem = doneItem;
//	[doneItem release];
//	
//	[[DataEnv sharedDataEnv].menuViewController presentModalViewController:navigationController animated:YES];
//	
//	[webViewController release];
//	[navigationController release];	
//}
+ (void)presentWithURL:(NSString *)url inController:(UIViewController *)controller {
    KSWebViewController *webViewController = [[KSWebViewController alloc] initWithRequestURL:url ScalesPageToFit:YES];
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:webViewController];
    [webViewController release];
    navigationController.modalPresentationStyle = UIModalPresentationPageSheet;
    UIBarButtonItem *doneItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:webViewController action:@selector(dismiss)];
    navigationController.topViewController.navigationItem.rightBarButtonItem = doneItem;
    [doneItem release];
    [controller presentModalViewController:navigationController animated:YES];
    
    [navigationController release];
}

@end


