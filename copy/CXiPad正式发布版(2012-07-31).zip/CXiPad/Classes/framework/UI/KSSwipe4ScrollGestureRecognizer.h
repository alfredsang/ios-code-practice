//
//  KSSwipe4ScrollGestureRecognizer.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 1/1/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>
#ifndef __KSSWIPE4SCROLLGESTURERECOGNIZER_H__
#define __KSSWIPE4SCROLLGESTURERECOGNIZER_H__   YES


@interface KSSwipe4ScrollGestureRecognizer : UIPanGestureRecognizer<UIGestureRecognizerDelegate> {
#define SWIPE_THRESHOLD     3000
#define NO_DIR              -1
    BOOL _panning;
    
    CGFloat _maxTouchSpeed;
    CGFloat _minTouchSpeed;
    
    UISwipeGestureRecognizerDirection _direccion;
    UISwipeGestureRecognizerDirection _direccionDelegate;
    id<UIGestureRecognizerDelegate> m_delegate;
    
    id m_target;
    SEL m_callback;

}
@property(nonatomic,assign) id<UIGestureRecognizerDelegate> delegate;
@property(nonatomic,assign) id target;
@property(nonatomic,assign) SEL callback;
@property(nonatomic,readonly) UISwipeGestureRecognizerDirection direction;
@property(nonatomic, assign)CGFloat maxTouchSpeed;
@property(nonatomic, assign)CGFloat minTouchSpeed;
//@property(nonatomic) CGFloat swipeVelocityInView;

- (id)initWithTarget:(id)target action:(SEL)action;


- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer;
- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer;
-(void)setDirection:(UISwipeGestureRecognizerDirection)direction;
-(void)callback:(UIGestureRecognizer*)recognizer;

@end

#endif  // end of __KSSWIPE4SCROLLGESTURERECOGNIZER_H__
