//
//  KSNavigationSegBtnView.m
//  CenturyWeeklyV2
//
//  Created by 广亮 高 on 12-6-11.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import "KSNavigationSegBtnView.h"
#import "KSMagzineMainView.h"

@implementation KSNavigationSegBtnView
@synthesize currentYear;
@synthesize titleArray = _titleArray;

- (id)initWithFrame:(CGRect)frame titles:(NSMutableArray*)titles delegate:(id)delegate
{
    self = [super initWithFrame:frame];
    if (self) 
    {
        _delegate = [delegate retain];
        _titleArray = [titles retain];
        self.userInteractionEnabled = YES;
        self.image = [[UIImage imageNamed:@"year_nav_bg.png"] stretchableImageWithLeftCapWidth:0 topCapHeight:10];
        _selectImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"year_nav_high_light.png"]];
        _selectImageView.frame = CGRectMake(2, 2, 51, 22);
        [self addSubview:_selectImageView];
        
        for (int i = 0; i<[titles count]; i++)
        {
            NSString *year = [titles objectAtIndex:i];
            UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
            btn.userInteractionEnabled = YES;
            btn.tag = 10+i;
            [btn setFrame:CGRectMake(55*i, 0, 55, frame.size.height)];
            [btn setTitle:year forState:UIControlStateNormal];
            [btn.titleLabel setFont:[UIFont boldSystemFontOfSize:16]];
            [btn setTitleColor:BTN_NORMAL_COLOR forState:UIControlStateNormal];
//            [btn setTitleColor:BTN_HIGHT_COLOR forState:UIControlStateHighlighted];
            [btn setTitleColor:BTN_HIGHT_COLOR forState:UIControlStateSelected];
            [btn addTarget:self action:@selector(pressBtn:) forControlEvents:UIControlEventTouchUpInside];
            [self addSubview:btn];
            if (i==0)
            {
                btn.selected = YES;
            }

        }
        if ([titles count]>0)
        {
            currentYear = [[titles objectAtIndex:0] retain];
        }

    }
    return self;
}
-(void)changeBtnWithAnimation:(UIButton*)btn
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDuration:0.25];
    _selectImageView.left = btn.left+2;
    if (currentYear)
    {
        RELEASE_SAFELY(currentYear)
    }
    currentYear = [btn.titleLabel.text retain];
    for ( int i = 0; i<[_titleArray count]; i++)
    {
        UIButton *bt = (UIButton*)[self viewWithTag:10+i];
        if (bt == btn)
        {
            btn.selected = YES;
        }
        else 
        {
            bt.selected = NO;
            
        }
    }

    [UIView commitAnimations];
}
-(void)pressBtn:(UIButton*)btn
{

    if (btn.selected)
    {
        return;
    }


    //    [UIView commitAnimations];
    if ([btn.titleLabel.text isEqualToString:@"最新"]||[btn.titleLabel.text isEqualToString:@"全部"]) 
    {
        if ([_delegate respondsToSelector:@selector(showBookStoreView)] && [btn.titleLabel.text isEqualToString:@"全部"]) 
        {
            [_delegate showBookStoreView];
        }
        if ([_delegate respondsToSelector:@selector(hiddenStoreView)] && [_delegate respondsToSelector:@selector(showBookStoreView)]) 
        {
            [_delegate hiddenStoreView];
        }
    }

    else 
    {
        if ([_delegate respondsToSelector:@selector(reloadDataWithYear:)]) 
        {
            [_delegate  reloadDataWithYear:[btn.titleLabel.text intValue]];
        }

    }
    [self changeBtnWithAnimation:btn];

}


-(void)dealloc
{
    RELEASE_SAFELY(_delegate);
    RELEASE_SAFELY(_selectImageView);
    RELEASE_SAFELY(_titleArray);
    RELEASE_SAFELY(currentYear);
    [super dealloc];
}

@end
