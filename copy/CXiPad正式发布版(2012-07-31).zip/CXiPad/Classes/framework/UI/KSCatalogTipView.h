//
//  KSCatalogTipView.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 1/11/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KSCatalogTipView : UIView {
    CGFloat _pointerX;              //指针指向点X坐标
    CGFloat _pointerY;              //指针指向点Y坐标
    CGSize _pointerSize;            //指针大小
    CGFloat _cornerRadius;          //圆角
    
    UILabel *_titleLabel;
    UILabel *_summaryLabel;
    UIImageView *_lockView;
}
@property(nonatomic, assign)CGFloat pointerX;
@property(nonatomic, retain)UILabel *titleLabel;
@property(nonatomic, retain)UILabel *summaryLabel;
@property(nonatomic, retain)UIImageView *lockView;

@end
