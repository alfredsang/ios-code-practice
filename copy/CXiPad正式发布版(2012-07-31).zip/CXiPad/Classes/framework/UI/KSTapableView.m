//
//  KSTapableView.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 1/6/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KSTapableView.h"

@implementation KSTapableView
@synthesize tapDelegate = _tapDelegate;

- (id)init {
	if (self = [super init]) {
		self.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
		_tapDelegate = nil;
	}
	return self;
}
- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
		self.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
        self.userInteractionEnabled = YES;
        _tapDelegate = nil;
    }
    return self;
}
- (void) touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {	
	// If not dragging, send event to next responder
	if (_tapDelegate && [_tapDelegate respondsToSelector:@selector(didTapped)])
    {
		[_tapDelegate didTapped];

    }
	else
		[super touchesEnded: touches withEvent: event];
}
/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code.
 }
 */
//
//- (void)dealloc {
//    [super dealloc];
//}

@end
