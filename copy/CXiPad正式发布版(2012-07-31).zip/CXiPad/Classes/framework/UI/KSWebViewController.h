//
//  KSWebViewController.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 12/26/11.
//  Copyright (c) 2011 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KSWebViewController : UIViewController<UIWebViewDelegate> {
    UIToolbar *_webViewToolbar;
    UIWebView *_webView;
    UIActivityIndicatorView *_activityIndicator;
    UIBarButtonItem *_actionButton;
    UIBarButtonItem *_refreshButton;
    UIBarButtonItem *_backButton;
    UIBarButtonItem *_forwardButton;
    
    NSURL *_webViewURL;
    BOOL _scalesPageToFit;
}
@property(nonatomic, retain)NSURL *webViewURL;


- (id)initWithRequestURL:(NSString *)url;
- (id)initWithRequestURL:(NSString *)url ScalesPageToFit:(BOOL)fit;

+ (void)presentWithURL:(NSString *)url inController:(UIViewController *)controller;
@end
