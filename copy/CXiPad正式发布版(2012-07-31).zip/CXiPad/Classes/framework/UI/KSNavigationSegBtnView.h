//
//  KSNavigationSegBtnView.h
//  CenturyWeeklyV2
//
//  Created by 广亮 高 on 12-6-11.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
@class KSMagzineMainView;

@interface KSNavigationSegBtnView : UIImageView

{
    UIImageView *_selectImageView;
    KSMagzineMainView *_delegate;
    NSArray *_titleArray;
    
}
@property(nonatomic,retain) NSString *currentYear;
@property(nonatomic,retain) NSArray *titleArray;

- (id)initWithFrame:(CGRect)frame titles:(NSMutableArray*)titles delegate:(id)delegate;
-(void)changeBtnWithAnimation:(UIButton*)btn;

@end
