//
//  KSSwipe4ScrollGestureRecognizer.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 1/1/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KSSwipe4ScrollGestureRecognizer.h"

@implementation KSSwipe4ScrollGestureRecognizer
@synthesize direction = _direccion;
@synthesize maxTouchSpeed = _maxTouchSpeed;
@synthesize minTouchSpeed = _minTouchSpeed;
//@synthesize swipeVelocityInView = _touchSpeed;

-(void)dealloc {
    [m_delegate release];
    [super dealloc];
}

#pragma mark - properties
- (id<UIGestureRecognizerDelegate>)delegate {
    return m_delegate;
}

- (void) setDelegate:(id<UIGestureRecognizerDelegate>)delegate {
    [m_delegate release];
    m_delegate = delegate;
    [m_delegate retain];
}

- (id)target {
    return m_target;
}

- (void)setTarget:(id)target {
    [m_target release];
    m_target = target;
    [m_target retain];
}

- (SEL)callback {
    return m_callback;
}

- (void)setCallback:(SEL)callback {
    m_callback = callback;
}

#pragma mark - 
- (id)initWithTarget:(id)target action:(SEL)action {
    self = [super initWithTarget:self action:@selector(callback:)];
    if (self) {
        m_delegate = super.delegate;
        [super setDelegate:self];
        [self setTarget:target];
        [self setCallback:action];
        _direccionDelegate = NO_DIR;
        _panning = NO;        
        _maxTouchSpeed = SWIPE_THRESHOLD;
        _minTouchSpeed = 0.0f;
    }
    return self;
}


- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    if( !m_delegate )
        return YES;
    
    if ([m_delegate respondsToSelector:@selector(gestureRecognizer: shouldRecognizeSimultaneouslyWithGestureRecognizer:)]) 
        return [m_delegate gestureRecognizer:gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:otherGestureRecognizer];
    else return YES;
}

- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer {
    if( !m_delegate )
        return YES;
    
    if ([m_delegate respondsToSelector:@selector(gestureRecognizerShouldBegin:)])
        return [m_delegate gestureRecognizerShouldBegin:gestureRecognizer];
    else return YES;
}


- (void)callback:(KSSwipe4ScrollGestureRecognizer*)recognizer {
    if(recognizer.state == UIGestureRecognizerStateBegan) {
        _panning = NO;
    } else {
        //return;
    }
    CGPoint v =[recognizer velocityInView:recognizer.view];
    if ((recognizer.direction & UISwipeGestureRecognizerDirectionUp) == UISwipeGestureRecognizerDirectionUp || (recognizer.direction&UISwipeGestureRecognizerDirectionDown) == UISwipeGestureRecognizerDirectionDown) {
        if( (abs(v.y) > _minTouchSpeed) && (abs(v.y) <= _maxTouchSpeed) && !_panning) {
            _panning = YES;
            
            [recognizer cancelsTouchesInView];
            
            if(v.y > 0) _direccion = UISwipeGestureRecognizerDirectionDown;
            else _direccion = UISwipeGestureRecognizerDirectionUp;
            
            if (((_direccionDelegate & _direccion) == _direccion) || (_direccionDelegate == NO_DIR)) {
                if( m_target )
                    [m_target performSelector:m_callback withObject:recognizer];
            }
        }
    } else {
        if( (abs(v.x) > _minTouchSpeed) && (abs(v.x) <= _maxTouchSpeed) && !_panning) {
            _panning = YES;
            
            [recognizer cancelsTouchesInView];
            
            if(v.x>0) _direccion = UISwipeGestureRecognizerDirectionRight;
            else _direccion = UISwipeGestureRecognizerDirectionLeft;
            
            if (((_direccionDelegate & _direccion) == _direccion) || (_direccionDelegate == NO_DIR)) {
                if( m_target )
                    [m_target performSelector:m_callback withObject:recognizer];
            }
        }
    }
}

-(void)setDirection:(UISwipeGestureRecognizerDirection)direction {
    _direccionDelegate = direction;
}



@end


