//
//  KSPageViewController.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 1/19/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KSPageViewController.h"

@implementation KSPageViewController
@synthesize numberOfPages = _numberOfPages;
@synthesize currentPage = _currentPage;
@synthesize spacing = _spacing;
@synthesize selectedColor = _selectedColor;
@synthesize deselectedColor = _deselectedColor;
@synthesize delegate = _delegate;


- (void)dealloc {
    [_selectedColor release];
    [_deselectedColor release];
    
    [super dealloc];
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self ) {
        self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, KSPAGECONTROL_HEIGHT);
        self.backgroundColor = [UIColor clearColor];
        self.deselectedColor = [UIColor grayColor];
        self.selectedColor = [UIColor blackColor];
        self.spacing = 10;
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, KSPAGECONTROL_HEIGHT);
        self.backgroundColor = [UIColor clearColor];
        self.deselectedColor = [UIColor grayColor];
        self.selectedColor = [UIColor blackColor];
        self.spacing = 10;
    }
    return self;
}

- (void)setNumberOfPages:(NSInteger) number {
    _numberOfPages = MAX(number, 0);
    _currentPage = 0;
    
    CGPoint tempCenter = self.center;
    self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, 4 + _numberOfPages * DOT_WIDTH + MAX(_numberOfPages - 1, 0) * _spacing, self.frame.size.height);
    self.center = tempCenter;
    [self setNeedsDisplay];
}

- (void)setCurrentPage:(NSInteger)index {
    if (index >= _numberOfPages)
        _currentPage = 0;
    else
        _currentPage = MAX(0, index);
    
    [self setNeedsDisplay];
}

- (NSInteger)currentPage {
    return _currentPage;
}

- (void)setSelectedColor:(UIColor*) color {
    [_selectedColor release];
    _selectedColor = [color retain];
    [self setNeedsDisplay];
}

- (UIColor*)selectedColor {
    return _selectedColor;
}

-(void) setDeselectedColor: (UIColor*) color {
    [_deselectedColor release];
    _deselectedColor = [color retain];
    [self setNeedsDisplay];
}

- (void)drawRect:(CGRect)rect {
    
    for (int i = 0; i < _numberOfPages; i++) {
        
        CGContextRef contextRef = UIGraphicsGetCurrentContext();
        
        if (i == _currentPage)
            CGContextSetFillColorWithColor(contextRef, _selectedColor.CGColor);
        else
            CGContextSetFillColorWithColor(contextRef, _deselectedColor.CGColor);
        
        CGContextFillEllipseInRect(contextRef, CGRectMake(2 + DOT_WIDTH * i + _spacing * i,
                                                          (KSPAGECONTROL_HEIGHT - DOT_WIDTH) / 2, DOT_WIDTH, DOT_WIDTH));
    }
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    if (!self.delegate) return;
    
    CGPoint touchPoint = [[[event touchesForView:self] anyObject] locationInView:self];
    
    CGFloat dotSpanX = self.numberOfPages*(DOT_WIDTH + _spacing);
    CGFloat dotSpanY = KSPAGECONTROL_HEIGHT;
    
    CGRect currentBounds = self.bounds;
    CGFloat x = touchPoint.x + dotSpanX/2 - CGRectGetMidX(currentBounds);
    CGFloat y = touchPoint.y + dotSpanY/2 - CGRectGetMidY(currentBounds);
    
    if ((x<0) || (x>dotSpanX) || (y<0) || (y>dotSpanY)) return;
    
    self.currentPage = floor(x/(DOT_WIDTH + _spacing));
    if ([self.delegate respondsToSelector:@selector(pageControlPageDidChange:)]) {
        [self.delegate pageControlPageDidChange:self];
    }
}

@end
