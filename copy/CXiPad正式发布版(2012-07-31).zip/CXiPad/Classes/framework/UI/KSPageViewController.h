//
//  KSPageViewController.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 1/19/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>

#define KSPAGECONTROL_HEIGHT 20
#define DOT_WIDTH 6
#define DOT_SPACING 10

@class KSPageViewController;
@protocol KSPageViewControllerDelegate<NSObject>
@optional
- (void)pageControlPageDidChange:(KSPageViewController *)pageControl;
@end

@interface KSPageViewController : UIView {
    NSInteger _numberOfPages;
    NSInteger _currentPage;
    UIColor *_selectedColor;
    UIColor *_deselectedColor;
    NSInteger _spacing;
    id<KSPageViewControllerDelegate> _delegate;
}
@property(nonatomic, assign)NSInteger numberOfPages;
@property(nonatomic, assign)NSInteger currentPage;
@property(nonatomic, assign)NSInteger spacing;
@property(nonatomic, retain)UIColor *selectedColor;
@property(nonatomic, retain)UIColor *deselectedColor;
@property(nonatomic, assign)id<KSPageViewControllerDelegate> delegate;

@end
