//
//  KSTapableView.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 1/6/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol KSTapableDelegate <NSObject>

- (void)didTapped;

@end

@interface KSTapableView : UIView {
    id<KSTapableDelegate> _tapDelegate;
}
@property(nonatomic,assign) id tapDelegate;

- (id)init;
- (id)initWithFrame:(CGRect)frame;

@end
