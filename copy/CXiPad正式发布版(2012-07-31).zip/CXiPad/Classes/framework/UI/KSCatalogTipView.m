//
//  KSCatalogTipView.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 1/11/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KSCatalogTipView.h"

@implementation KSCatalogTipView
@synthesize pointerX = _pointerX;
@synthesize titleLabel = _titleLabel;
@synthesize summaryLabel = _summaryLabel;
@synthesize lockView = _lockView;

- (void)dealloc {
    [_titleLabel release];
    [_summaryLabel release];
    [_lockView release];
    [super dealloc];
}
- (void)loadSubviews {
    self.backgroundColor = [UIColor clearColor];//[UIColor colorWithRed:62.0/255.0 green:60.0/255.0 blue:154.0/255.0 alpha:1.0];
    
    _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 5, self.width-30, 40)];
    _titleLabel.backgroundColor = [UIColor clearColor];
    _titleLabel.font = [UIFont boldSystemFontOfSize:14.0f];
    _titleLabel.numberOfLines = 2;
    [self addSubview:_titleLabel];
    
    _summaryLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 40, self.width-20, 60)];
    _summaryLabel.backgroundColor = [UIColor clearColor];
    _summaryLabel.font = [UIFont systemFontOfSize:12.0f];
    _summaryLabel.numberOfLines = 4;
    _summaryLabel.textColor = [UIColor colorWithWhite:0.2 alpha:1];
    [self addSubview:_summaryLabel];
    
    _lockView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"lbl_item_locked.png"]];
    _lockView.frame = CGRectMake(self.width-20, 10, 12, 22);
    _lockView.hidden = YES;
    [self addSubview:_lockView];
}
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        _pointerSize = CGSizeMake(16, 16);
        _cornerRadius = 8.0f;
        _pointerX = roundf(self.width/2);
        _pointerY = self.height;
        [self loadSubviews];
    }
    return self;
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    CGRect bubbleRect;
    bubbleRect = CGRectMake(2.0, 0, self.width-4, self.height-_pointerSize.height);
    CGContextRef c = UIGraphicsGetCurrentContext(); 
	CGContextSetRGBStrokeColor(c, 0, 0, 0, 1);
	CGContextSetLineWidth(c, 1.0);
	CGMutablePathRef bubblePath = CGPathCreateMutable();
    
    CGPathMoveToPoint(bubblePath, NULL, _pointerX, _pointerY);//指针指向的点
    CGPathAddLineToPoint(bubblePath, NULL, _pointerX - _pointerSize.width, _pointerY -_pointerSize.width);
    
    CGPathAddArcToPoint(bubblePath, NULL,
                        bubbleRect.origin.x, bubbleRect.origin.y+bubbleRect.size.height,
                        bubbleRect.origin.x, bubbleRect.origin.y+bubbleRect.size.height-_cornerRadius,
                        _cornerRadius);
    CGPathAddArcToPoint(bubblePath, NULL,
                        bubbleRect.origin.x, bubbleRect.origin.y,
                        bubbleRect.origin.x+_cornerRadius, bubbleRect.origin.y,
                        _cornerRadius);
    CGPathAddArcToPoint(bubblePath, NULL,
                        bubbleRect.origin.x+bubbleRect.size.width, bubbleRect.origin.y,
                        bubbleRect.origin.x+bubbleRect.size.width, bubbleRect.origin.y+_cornerRadius,
                        _cornerRadius);
    CGPathAddArcToPoint(bubblePath, NULL,
                        bubbleRect.origin.x+bubbleRect.size.width, bubbleRect.origin.y+bubbleRect.size.height,
                        bubbleRect.origin.x+bubbleRect.size.width-_cornerRadius, bubbleRect.origin.y+bubbleRect.size.height,
                        _cornerRadius);
    CGPathAddLineToPoint(bubblePath, NULL, _pointerX+_pointerSize.width, _pointerY-_pointerSize.height);

    CGPathCloseSubpath(bubblePath);
    
    CGContextAddPath(c, bubblePath);
    if (bubblePath != NULL) {
        CGPathRelease(bubblePath);
    }
    CGContextSaveGState(c);
	CGContextSetShadow(c, CGSizeMake(0, 3), 5);
	CGContextSetRGBFillColor(c, 0.9, 0.9, 0.9, 0.9);
	CGContextFillPath(c);
    CGContextRestoreGState(c);
}

- (void)setPointerX:(CGFloat)pointerX {
    CGFloat maxWidth = [UIUtil currentOrientation]==0?768:1024;
    
    if (pointerX < round(self.width/2)) {
        self.centerX = round(self.width/2);
        _pointerX = pointerX;
    } else if(pointerX > roundf(maxWidth- self.width/2)) {
        _pointerX = self.width-roundf(maxWidth-pointerX);
        self.centerX = roundf(maxWidth- self.width/2);
    } else {
        _pointerX = roundf(self.width/2);
        self.centerX = pointerX;
    }
    
    [self setNeedsDisplay];
}

- (void)setPointerX:(CGFloat)pointerX screenWith:(CGFloat)screenWith {
    
}
@end
