//
//  KSGetAllMagzinesDownloader.h
//  CenturyWeeklyV2
//
//  Created by liuyou on 12-1-11.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KSDownloader.h"

#define GET_ALL_URL SURL_PREFIX(@"article", @"%d/%d")

@interface KSGetAllMagzinesDownloader : KSDownloader<KSDownloaderDelegate>{
    NSString *_zipFile;
    NSString *_unpackDir;
    NSInteger _articleId;
    NSInteger _magzineId;
}

- (id)init:(NSInteger)articleId magzineId:(NSInteger)magzineId;


@end
