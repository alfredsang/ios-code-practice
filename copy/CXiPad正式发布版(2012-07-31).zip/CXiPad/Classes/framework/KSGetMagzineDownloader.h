//
//  KSGetMagzineDownloader.h
//  CenturyWeeklyV2
//
//  Created by liuyou on 12-1-2.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import "KSDownloader.h"
#import "KSDownloadManager.h"

#define GET_MAGZINE_URL SURL_PREFIX(@"magazine", @"%d")

@interface KSGetMagzineDownloader : KSDownloader<KSDownloaderDelegate>{
    NSString *_zipFile;
    NSString *_unpackDir;
    NSInteger _magzineId;
}
- (id) init:(NSInteger)magzineId;
+ (BOOL) isDownloading:(NSInteger)magzineId;
@end
