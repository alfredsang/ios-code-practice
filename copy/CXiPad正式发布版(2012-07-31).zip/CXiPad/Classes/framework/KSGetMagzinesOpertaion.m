//
//  KSGetMagzinesOpertaion.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 12-1-4.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import "KSGetMagzinesOpertaion.h"
#import "KSDownloadManager.h"
#import "KSGetMagzineDownloader.h"

@implementation KSGetMagzinesOpertaion
- (id)init:(NSArray *)magzineIds{
    if(self = [super init]){
        _magzineIds = [magzineIds retain];
    }
    return self;
}

- (void)dealloc{
    [_magzineIds release];
    [super dealloc];
}

- (void) main{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
	if (![self isCancelled])
	{
        for (NSNumber *magzineId in _magzineIds) {
            KSDownloadManager *dm = [KSDownloadManager sharedManager];
            if(![KSGetMagzineDownloader isDownloading:[magzineId intValue]]){
                KSGetMagzineDownloader *dl = [[KSGetMagzineDownloader alloc] init:[magzineId intValue]];
                [dm addDownloader:dl];
                [dl release];
            }
        }
	}
	
	[pool release];
}
@end
