//
//  KSGetMagzineCoverDownloader.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 12-1-11.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import "KSGetMagzineCoverDownloader.h"

@implementation KSGetMagzineCoverDownloader
- (id) init:(NSInteger)magzineId coverIndex:(NSInteger)cover{
    _magzineId = magzineId;
    _cover = cover;
    _path = [[[KSModelMagzine magzinePath:magzineId] stringByAppendingPathComponent:@"files"] retain];
    _saveFile = [STR_FORMAT(@"%@/cover%d.jpg", _path, cover) retain];
    NSString *requestUrl = STR_FORMAT(GET_MAGZINE_COVER_URL, magzineId, cover);
    if(self = [super init:requestUrl saveTo:_saveFile asyn:YES]){
        self.onDownloadCompleted = ^(){
            [self onDownloadSuccess:self];
        };
        self.onDownloadFailed = ^(NSError *error){
            [self onDownloadFail:self];
        };
    }
    return self;
}

- (void) dealloc{
    [_path release];
    [_saveFile release];
    [super dealloc];
}

+ (BOOL)isDownloading:(NSInteger)magzineId{
    return [[KSBootstrap dataCenter] valueForKey:STR_FORMAT(@"d_m_c_%d", magzineId)]!=nil;
}

- (void) onDownloadSuccess:(KSDownloader *)downloader{
    if (!isRetina)
    {
        UIImage *img = [UIImage imageWithContentsOfFile:_saveFile];
        if (img)
        {
            UIImage *newImag = [img imageByScalingToSize:CGSizeMake(img.size.width/2, img.size.height/2)];
            NSData *imgData = UIImageJPEGRepresentation(newImag,1.0);
            [imgData writeToFile:_saveFile atomically:NO];
        }
    }

    [KSBootstrap notify:NOTIFY_MAGZINE_COVER_DOWNLOADED data:[NSDictionary dictionaryWithObjectsAndKeys: INTEGER(_magzineId), @"magzine_id", INTEGER(_cover), @"cover", nil]];
    [[KSBootstrap dataCenter] removeObjectForKey:STR_FORMAT(@"d_m_c_%d_%d", _magzineId, _cover)];
    self.onDownloadFailed = self.onDownloadCompleted = self.onDownloadCancelled = nil;
}

- (void) onDownloadFail:(KSDownloader *)downloader{
    NSLog(@"%@", downloader.error);
    [[KSBootstrap dataCenter] removeObjectForKey:STR_FORMAT(@"d_m_c_%d_%d", _magzineId, _cover)];
    self.onDownloadFailed = self.onDownloadCompleted = self.onDownloadCancelled = nil;
}

- (void) onDownloadCancel:(KSDownloader *)downloader{
    [[KSBootstrap dataCenter] removeObjectForKey:STR_FORMAT(@"d_m_c_%d_%d", _magzineId, _cover)];
    self.onDownloadFailed = self.onDownloadCompleted = self.onDownloadCancelled = nil;
}

- (void)start{
    NSFileManager *fileManager = [[NSFileManager alloc] init];
	if ([fileManager fileExistsAtPath:_saveFile] || [[self class] isDownloading:_magzineId]) {
        self.onDownloadFailed = self.onDownloadCompleted = self.onDownloadCancelled = nil;
        [fileManager release];
        return;
    }
	if (![fileManager fileExistsAtPath:_path]) {
        [fileManager createDirectoryAtPath:_path withIntermediateDirectories:YES attributes:nil error:nil];
	}
    [fileManager release];
    [[KSBootstrap dataCenter] setValue:INTEGER(1) forKey:STR_FORMAT(@"d_m_c_%d_%d", _magzineId, _cover)];
    [super start];
}
@end
