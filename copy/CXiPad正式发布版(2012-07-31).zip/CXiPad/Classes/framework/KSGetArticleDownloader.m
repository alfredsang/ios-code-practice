//
//  KSGetArticleDownloader.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 12-1-2.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import "KSGetArticleDownloader.h"

@implementation KSGetArticleDownloader

- (id)init:(NSInteger)articleId magzineId:(NSInteger)magzineId{
    _articleId = articleId;
    _magzineId = magzineId;
    _zipFile = [[NSString stringWithFormat:@"%@/magzineUnpack%d/%d.zip", [KSBootstrap root], magzineId, articleId] retain];
    _unpackDir = [[NSString stringWithFormat:@"%@/magzineUnpack%d/", [KSBootstrap root], magzineId] retain];
    NSString *requestUrl = [NSString stringWithFormat:GET_ARTICLE_URL, articleId, magzineId];
    if(self = [super init:requestUrl saveTo:_zipFile asyn:YES]){
        self.onDownloadCompleted = ^(){
            [self onDownloadSuccess:self];
        };
        self.onDownloadFailed = ^(NSError *error){
            [self onDownloadFail:self];
        };
    }
    return self;
}

- (void) dealloc{
    [_zipFile release];
    [_unpackDir release];
    [super dealloc];
}

- (void) onDownloadSuccess:(KSDownloader *)downloader{
    ZipArchive* za = [[ZipArchive alloc] init];
    if( [za UnzipOpenFile:_zipFile] ){
        BOOL ret = [za UnzipFileTo:_unpackDir overWrite:YES];
        if( NO==ret ){
			KSDERROR(@"unzip error.");
        }else{
			KSDINFO(@"unzip successfully.");
		}
        [za UnzipCloseFile];
    }
    [za release];
    NSFileManager *fileManager = [[NSFileManager alloc] init];
	if ([fileManager fileExistsAtPath:_zipFile]) {
		[fileManager removeItemAtPath:_zipFile error:nil];
	}
    [fileManager release];
    // article
    KSModelArticle *oldArticle = [KSModelArticle loadById:_articleId withContent:NO];
    if(oldArticle.isDownload)return;
    NSString *jsonFile = STR_FORMAT(@"%@/magzineUnpack%d/%d/article.json", [KSBootstrap root], _magzineId, _articleId);
    NSData *jsonData = [NSData dataWithContentsOfFile:jsonFile];
    NSDictionary *dict = [[CJSONDeserializer deserializer] deserializeAsDictionary:jsonData error:nil];
    if(dict){
        NSString *sql = @"delete from article_header_blocks where article_id=?";
        [[KSDB db] executeUpdate:sql, INTEGER(_articleId)];
        sql = @"delete from article_images where article_id=?";
        [[KSDB db] executeUpdate:sql, INTEGER(_articleId)];
        NSDictionary *vblocks = [dict objectForKey:@"vblocks"];
        for (NSString *page in vblocks.keyEnumerator) {
            NSArray *blocks = [vblocks objectForKey:page];
            for (NSDictionary *block in blocks) {
                if(DICT_INTVAL(block, @"blocktype")==0){
                    //header
                    NSString *sql = @"insert into article_header_blocks(article_id, page, is_v, left, top, width, height, content, left_image, right_image) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    [[KSDB db] executeUpdate:sql, INTEGER(_articleId), page, INTEGER(1), DICT_VAL(block, @"left"), DICT_VAL(block, @"top"), DICT_VAL(block, @"width"), DICT_VAL(block, @"height"), DICT_VAL(block, @"content"), DICT_VAL(block, @"leftimage"), DICT_VAL(block, @"rightimage")];
                }else if(DICT_INTVAL(block, @"blocktype")==1){
                    NSString *sql = @"insert into article_images(article_id, page, is_v, left, top, width, height, image, title, link, controltype) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    [[KSDB db] executeUpdate:sql, INTEGER(_articleId), page, INTEGER(1), DICT_VAL(block, @"left"), DICT_VAL(block, @"top"), DICT_VAL(block, @"width"), DICT_VAL(block, @"height"), DICT_VAL(block, @"url"), DICT_VAL(block, @"title"), DICT_VAL(block, @"link"), DICT_VAL(block, @"controltype")];
                }
            }
        }
        NSDictionary *hblocks = [dict objectForKey:@"hblocks"];
        for (NSString *page in hblocks.keyEnumerator) {
            NSArray *blocks = [hblocks objectForKey:page];
            for (NSDictionary *block in blocks) {
                if(DICT_INTVAL(block, @"blocktype")==0){
                    //header
                    NSString *sql = @"insert into article_header_blocks(article_id, page, is_v, left, top, width, height, content, left_image, right_image) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    [[KSDB db] executeUpdate:sql, INTEGER(_articleId), page, INTEGER(0), DICT_VAL(block, @"left"), DICT_VAL(block, @"top"), DICT_VAL(block, @"width"), DICT_VAL(block, @"height"), DICT_VAL(block, @"content"), DICT_VAL(block, @"leftimage"), DICT_VAL(block, @"rightimage")];
                }else if(DICT_INTVAL(block, @"blocktype")==1){
                    NSString *sql = @"insert into article_images(article_id, page, is_v, left, top, width, height, image, title, link, controltype) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    [[KSDB db] executeUpdate:sql, INTEGER(_articleId), page, INTEGER(0), DICT_VAL(block, @"left"), DICT_VAL(block, @"top"), DICT_VAL(block, @"width"), DICT_VAL(block, @"height"), DICT_VAL(block, @"url"), DICT_VAL(block, @"title"), DICT_VAL(block, @"link"), DICT_VAL(block, @"controltype")];
                }
            }
        }
        //article_templates
        sql = @"delete from article_templates where article_id=?";
        [[KSDB db] executeUpdate:sql, INTEGER(_articleId)];
        NSArray * templates = [dict objectForKey:@"templates"];
        for (NSDictionary *template in templates) {
            NSString *sql = @"insert into article_templates(article_id, type, background, content) values(?, ?, ?, ?)";
            [[KSDB db] executeUpdate:sql, INTEGER(_articleId), DICT_VAL(template, @"type"), DICT_VAL(template, @"background"), DICT_VAL(template, @"content")];
        }
        // slideshow
        sql = @"delete from article_slideshow where article_id=?";
        [[KSDB db] executeUpdate:sql, INTEGER(_articleId)];
        NSArray * slideshows = [dict objectForKey:@"slideshow"];
        int iter = 0;
        for (NSDictionary *image in slideshows) {
            NSString *sql = @"insert into article_slideshow(article_id, hsrc, vsrc, title, link, ranking) values(?, ?, ?, ?, ?, ?)";
            iter++;
            [[KSDB db] executeUpdate:sql, INTEGER(_articleId), DICT_VAL(image, @"hsrc"), DICT_VAL(image, @"vsrc"), DICT_VAL(image, @"title"), DICT_VAL(image, @"link"), INTEGER(iter)];
        }
        //relations
        //childrens
        sql = @"delete from article_children where article_id=?";
        [[KSDB db] executeUpdate:sql, INTEGER(_articleId)];
        NSArray *childrens = [dict objectForKey:@"children"];
        iter = 0;
        for (NSDictionary *child in childrens) {
            NSString *sql = @"insert into article_children(article_id, child_id,ranking) values(?,?,?)";
            iter++;
            [[KSDB db] executeUpdate:sql, INTEGER(_articleId),child, INTEGER(iter)];
        }
        
        //

        [[KSDB db] executeUpdate:@"update articles set is_download=?, vcolumns=?, hcolumns=?, content_length=?, authors=?,mulu_pic_author=?, subtitle=?, summary=?, title=?, video_src=?,video2=?,video3=?, audio_src=?, is_html=?,arti_type=?, is_free=?, catalog_id=?, ranking=? where article_id=?", INTEGER(1), INTEGER(DICT_INTVAL(dict, @"vcolumns")), INTEGER(DICT_INTVAL(dict, @"hcolumns")), DICT_VAL(dict, @"contentlength"), DICT_VAL(dict, @"metadata.author"),DICT_VAL(dict, @"metadata.mulu_pic_author"), DICT_VAL(dict, @"metadata.subtitle"), DICT_VAL(dict, @"metadata.summary"), DICT_VAL(dict, @"metadata.title"), DICT_VAL(dict, @"metadata.video"),DICT_VAL(dict, @"metadata.video2"),DICT_VAL(dict, @"metadata.video3"), DICT_VAL(dict, @"metadata.audio"), [DICT_VAL(dict, @"metadata.type") isEqualToString:@"cortext"]?INTEGER(0):INTEGER(1),INTEGER(DICT_INTVAL(dict, @"metadata.artitype")), DICT_VAL(dict, @"metadata.isfree"), DICT_VAL(dict, @"metadata.categoryid"), DICT_VAL(dict, @"metadata.artiorder"), INTEGER(_articleId)];
        [[KSDB db] executeUpdate:@"update magzines set download_articles_num=download_articles_num+1 where magzine_id=?", INTEGER(_magzineId)];
    }
    [KSBootstrap notify:NOTIFY_ARTICLE_DOWNLOADED data:[NSDictionary dictionaryWithObjectsAndKeys:INTEGER(_articleId), @"article_id", INTEGER(_magzineId), @"magzine_id", nil]];
    self.onDownloadFailed = self.onDownloadCompleted = self.onDownloadCancelled = nil;
}

- (void) onDownloadFail:(KSDownloader *)downloader{
    //
    NSLog(@"%@", downloader.error);
    self.onDownloadFailed = self.onDownloadCompleted = self.onDownloadCancelled = nil;
}

- (void) onDownloadCancel:(KSDownloader *)downloader{
    self.onDownloadFailed = self.onDownloadCompleted = self.onDownloadCancelled = nil;
}

@end
