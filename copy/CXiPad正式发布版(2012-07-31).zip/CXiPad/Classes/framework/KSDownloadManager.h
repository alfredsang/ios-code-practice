//
//  KSDownloadManager.h
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KSDownloader.h"
    
@interface KSDownloadManager : NSObject<KSDownloaderDelegate>{
    NSMutableArray *queue;
    NSMutableArray *runningQueue;
    NSMutableArray *suspendQueue;
    NSInteger _maxConcurrentCount;
    NSInteger _runningNumber;
    BOOL _isSuspend;
}
+ (KSDownloadManager *)sharedManager;
- (id)init:(NSInteger)maxConcurrentCount;
- (void) addDownloader:(KSDownloader *)downloader;
- (void) addDownloader:(KSDownloader *)downloader atIndex:(NSInteger)index;
- (void) start;
- (void) suspend;
- (void) resume;
- (void) cancelWaiting;
@end
