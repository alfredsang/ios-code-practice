//
//  KSGetMagzineDownloader.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 12-1-2.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import "KSGetMagzineDownloader.h"
@implementation KSGetMagzineDownloader
- (id) init:(NSInteger)magzineId{
    _zipFile = [[NSString stringWithFormat:@"%@/%d.zip", [KSBootstrap root], magzineId] retain];
    _unpackDir = [[NSString stringWithFormat:@"%@", [KSBootstrap root]] retain];
    NSString *requestUrl = [NSString stringWithFormat:GET_MAGZINE_URL, magzineId];
    if(self = [super init:requestUrl saveTo:_zipFile asyn:YES]){
        _magzineId = magzineId;
        self.onDownloadCompleted = ^(){
            [self onDownloadSuccess:self];
        };
        self.onDownloadFailed = ^(NSError *error){
            [self onDownloadFail:self];
        };
    }
    [[KSBootstrap dataCenter] setValue:INTEGER(1) forKey:STR_FORMAT(@"d_m_%d", magzineId)];
    return self;
}

- (void) dealloc{
    [_zipFile release];
    [_unpackDir release];
    [super dealloc];
}

+ (BOOL)isDownloading:(NSInteger)magzineId{
    return [[KSBootstrap dataCenter] valueForKey:STR_FORMAT(@"d_m_%d", magzineId)]!=nil;
}

- (void) onDownloadSuccess:(KSDownloader *)downloader{
    ZipArchive* za = [[ZipArchive alloc] init];
    if( [za UnzipOpenFile:_zipFile] ){
        BOOL ret = [za UnzipFileTo:_unpackDir overWrite:YES];
        if( NO==ret ){
			NSLog(@"unzip error.");
        }else{
			NSLog(@"unzip successfully.");
		}
        [za UnzipCloseFile];
    }
    [za release];
    NSFileManager *fileManager = [[NSFileManager alloc] init];
	if ([fileManager fileExistsAtPath:_zipFile]) {
		[fileManager removeItemAtPath:_zipFile error:nil];
	}
    NSString *renameToDir = [NSString stringWithFormat:@"%@/magzineUnpack%d", [KSBootstrap root], _magzineId];
	if ([fileManager fileExistsAtPath:renameToDir]) {
		[fileManager removeItemAtPath:renameToDir error:nil];
	}
    
    [fileManager moveItemAtPath:[_unpackDir stringByAppendingFormat:@"/%d", _magzineId] toPath:renameToDir error:nil];
    [fileManager release];
    
    NSString *jsonFile = STR_FORMAT(@"%@/magzineUnpack%d/magazine.json", [KSBootstrap root], _magzineId);
    NSData *jsonData = [NSData dataWithContentsOfFile:jsonFile];
    NSDictionary *dict = [[CJSONDeserializer deserializer] deserializeAsDictionary:jsonData error:nil];
    if(dict){
        NSInteger articlesNum = DICT_INTVAL(dict, @"article_num");
        [[KSDB db] executeUpdate:@"update magzines set articles_num=? where magzine_id=?", INTEGER(articlesNum), INTEGER(_magzineId)];
        NSArray *articles = [dict objectForKey:@"articles"];
        int iteration = 0;
        for (NSDictionary *articleDict in articles) {
            KSModelArticle *article = [KSModelArticle articleWith:articleDict];
            article.rankingInMagzine = iteration++;
            if(![article insert])continue; //将文章写入DB
        }
    }
    self.onDownloadFailed = self.onDownloadCompleted = self.onDownloadCancelled = nil;
    [[KSBootstrap dataCenter] removeObjectForKey:STR_FORMAT(@"d_m_%d", _magzineId)];
    [[KSDB db] executeUpdate:@"update magzines set is_download=1,is_articles_download=1,rate_download=1 where magzine_id=?", INTEGER(_magzineId)];
    [KSBootstrap notify:NOTIFY_MAGZINE_DOWNLOADED data:[NSDictionary dictionaryWithObjectsAndKeys: INTEGER(_magzineId), @"magzine_id", nil]];
}

- (void) onDownloadFail:(KSDownloader *)downloader{
    //
    NSLog(@"%@", downloader.error);
    self.onDownloadFailed = self.onDownloadCompleted = self.onDownloadCancelled = nil;
    [[KSBootstrap dataCenter] removeObjectForKey:STR_FORMAT(@"d_m_%d", _magzineId)];
}

- (void) onDownloadCancel:(KSDownloader *)downloader{
    self.onDownloadFailed = self.onDownloadCompleted = self.onDownloadCancelled = nil;
    [[KSBootstrap dataCenter] removeObjectForKey:STR_FORMAT(@"d_m_%d", _magzineId)];
}

@end
