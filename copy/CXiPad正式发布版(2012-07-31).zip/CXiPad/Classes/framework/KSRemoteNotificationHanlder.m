//
//  KSPushNotificationDetector.m
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSRemoteNotificationHanlder.h"
#import "KSGetMagzineListOperation.h"
#import "CXDataRequest.h"

@implementation KSRemoteNotificationHanlder
+ (void) whenNewMagzine{
    KSGetMagzineListOperation *operGetMagzineList = [[KSGetMagzineListOperation alloc] init];
    [[KSBootstrap operationQueue] addOperation:operGetMagzineList];
    [operGetMagzineList release];
}

+ (void) whenMangzineUpdate:(NSInteger)magzineId{
    KSModelMagzine *magzine = [KSModelMagzine loadById:magzineId];
    if(magzine==nil)return;
    [magzine remove:YES];
    KSGetMagzineListOperation *operGetMagzineList = [[KSGetMagzineListOperation alloc] init];
    [[KSBootstrap operationQueue] addOperation:operGetMagzineList];
    [operGetMagzineList release];
}

+ (void) handle:(NSDictionary *)acmMsg{
    NSString *pushtype = DICT_VAL(acmMsg, @"pushtype");//8. 更新新刊,2.新增期刊,4.重要新闻
    NSString *shorttype = DICT_VAL(acmMsg, @"t");
    if (pushtype||shorttype) {
        NSInteger type = [pushtype intValue];
        if (type == 2) 
        {
            [self whenNewMagzine];
        } 
        else if(type ==8)
        {
            NSInteger periodicalid = DICT_INTVAL(acmMsg, @"periodicalid");
            if (periodicalid > 0)
            {
                [self whenMangzineUpdate:periodicalid];
            }
            periodicalid = DICT_INTVAL(acmMsg, @"p");
            if (periodicalid > 0) 
            {
                [self whenMangzineUpdate:periodicalid];
            }
        }
    }
}


+ (void)savePushSettingToServer {
    NSString *deviceToken = [KSDB stringForKey:PUSH_DEVICE_TOKEN];
    if (deviceToken == nil || ![deviceToken length]) {
        deviceToken = [[NSUserDefaults standardUserDefaults] objectForKey:PUSH_DEVICE_TOKEN];
    }
    if (deviceToken == nil || ![deviceToken length]) {
        return;
    }
    NSString *starthour = [KSDB stringForKey:PUSH_START_HOUR];
    if (starthour == nil || [starthour length] == 0) {
        starthour = @"0";
    }
    
    NSString *endhour = [KSDB stringForKey:PUSH_END_HOUR];
    if (endhour == nil || [endhour length] == 0) {
        endhour = @"24";
    }
    
    NSString *email = [KSDB stringForKey:@"login_name"];
    if (email == nil) {
        email = @"";
    }
    
    NSString *pushtype = [KSDB stringForKey:PUSH_TYPE];
    if (pushtype == nil || [pushtype length] == 0) {
        pushtype = [NSString stringWithFormat:@"%d", cXPushTypeNone|cxPushTypeUpMagazine|cXPushTypeNews|cXPushTypeMagazine];
    }
    
    [CXPushSetDataRequest requestWithDelegate:nil 
                               withParameters:[NSDictionary dictionaryWithObjectsAndKeys: 
                                               email, @"email",
                                               deviceToken, @"devicetoken",
                                               pushtype, @"pushtype",
                                               @"", @"pushtime",
                                               PUSH_APP_NAME, @"appname",
                                               starthour, @"starthour",
                                               endhour, @"endhour",
                                               MAGZINE_TYPE, @"magazineid",
                                               nil]];
}
@end
