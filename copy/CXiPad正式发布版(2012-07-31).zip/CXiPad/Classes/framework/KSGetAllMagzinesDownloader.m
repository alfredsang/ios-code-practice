//
//  KSGetAllMagzinesDownloader.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 12-1-11.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import "KSGetAllMagzinesDownloader.h"

@implementation KSGetAllMagzinesDownloader

@end
