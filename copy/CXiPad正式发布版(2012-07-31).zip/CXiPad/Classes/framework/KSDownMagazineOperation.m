//
//  KSDownMagazineOperation.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 2/1/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KSDownMagazineOperation.h"
#import "KSGetAllArticlesDownloader.h"
#import "KSDownloadManager.h"
#import "KSShelfProgressView.h"

@implementation KSDownMagazineOperation
@synthesize progressView = _progressView;
@synthesize magazinId = _magazineId;

- (id)initWithMagazineId:(NSInteger)magzineId {
    if(self = [super init]){
        _magazineId = magzineId;
    }
    return self;
}
- (void)dealloc{
    RELEASE_SAFELY(_getAllArticlesDownloader);
    RELEASE_SAFELY(_progressView);
    
    [super dealloc];
}

- (void) main{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
	if (![self isCancelled]) {
        
        KSDownloadManager *dm = [KSDownloadManager sharedManager];
        if(![KSGetAllArticlesDownloader isDownloading:_magazineId]){
            _getAllArticlesDownloader = [[KSGetAllArticlesDownloader alloc] init:_magazineId];
            _getAllArticlesDownloader.progressView = _progressView;
            [dm addDownloader:_getAllArticlesDownloader];
        }

	}
	
	[pool release];
}
- (void)cancel {
    [_getAllArticlesDownloader cancel];
    _getAllArticlesDownloader.progressView = nil;
    if ([_progressView respondsToSelector:@selector(setOriginProgress:)]) {
        [(KSShelfProgressView*)_progressView setOriginProgress:_progressView.progress];
    }
    //[[KSDownloadManager sharedManager] cancelWaiting];
    RELEASE_SAFELY(_getAllArticlesDownloader);
    
    [super cancel];
}

- (void)setProgressView:(UIProgressView *)progressView {
    RELEASE_SAFELY(_progressView);
    _progressView = [progressView retain];
    _getAllArticlesDownloader.progressView = progressView;
}
@end
