//
//  KSBootstrap.m
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-24.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSBootstrap.h"
#import "KSGetMagzineListOperation.h"
#import "KSDownloadManager.h"
#import "CXDataRequest.h"
#import "SHKSina.h"
#import "SHKTencent.h"
#import "KStoreManager.h"

static KSDataCenter * _dataCenter;
@implementation KSDataCenter
- (id) init{
    if(self=[super init]){
        _data = [[NSMutableDictionary alloc] initWithCapacity:10];
    }
    return self;
}
- (NSDictionary *) data{
    return [[_data copy] autorelease];
}
- (void) setValue:(id)value forKey:(NSString *)key{
    if(value==nil){
        [self removeObjectForKey:key];
    }
    [_data setValue:value forKey:key];
}

- (void) removeObjectForKey:(id)aKey{
    [_data removeObjectForKey:aKey];
}

- (id) valueForKey:(NSString *)key{
    return [_data valueForKey:key];
}

- (void) dealloc{
    [_data release];
    [super dealloc];
}
@end

static NSOperationQueue *_threadedQueue;
#pragma mark -
#pragma mark KSBootstrap
@implementation KSBootstrap

+ (NSOperationQueue *) operationQueue{
    if(_threadedQueue==nil){
        _threadedQueue = [[NSOperationQueue alloc] init];
        _threadedQueue.maxConcurrentOperationCount = 1;
    }
    return _threadedQueue;
}

+ (NSString *) root{
//    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
//    NSString *rootDir = [[paths objectAtIndex:0] stringByAppendingPathComponent:@"notbackupdata"];
//    
//    return rootDir;
    return [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"/Documents/notbackupdata/"]];
}

+ (KSDataCenter *) dataCenter{
    if(_dataCenter==nil){
        _dataCenter = [[KSDataCenter alloc] init];
    }
    return _dataCenter;
}

#define KEY_LOGIN_USER  @"login_user"
+ (void) setCurrentUser:(NSString *)user{
    [[KSDB db] executeUpdate:@"delete from key_value where keyname=?", KEY_LOGIN_USER];
    [[self dataCenter] setValue:[user lowercaseString] forKey:KEY_LOGIN_USER];
    if(user!=nil){
        [[KSDB db] executeUpdate:@"insert into key_value values(?, ?)", KEY_LOGIN_USER, [user lowercaseString]];
    }
}

+ (NSString *)currentUser{
    //return @"123@gmail.com";
    NSString *user = [[self dataCenter] valueForKey:KEY_LOGIN_USER];
//    if(!user){
//        user = [[KSDB db] stringForQuery:@"select keyvalue from key_value where keyname=?", KEY_LOGIN_USER];
//    }
//    if(!user){
//        [[self dataCenter] setValue:user forKey:KEY_LOGIN_USER];
//    }
    return user;
}

+ (void)autoLogin {
    NSString *user = [[KSDB db] stringForQuery:@"select keyvalue from key_value where keyname=?", KEY_LOGIN_USER];
    if(user){
        [[self dataCenter] setValue:user forKey:KEY_LOGIN_USER];
    }
}
+ (void) _initData{
//    NSArray *familyNames = [UIFont familyNames];
//    for (NSString *familyName in familyNames) {
//        NSArray *fontNames = [UIFont fontNamesForFamilyName:familyName];
//        NSLog(@"%@: %@", familyName, fontNames);
//    }
    //KSModelGiven
    //Magzine List
    //Download magzine.zip 's
    //test datas
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    NSString *bundleDb = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"sqlite.db"];
    NSString *dbFile = [KSDB dbFile];
    if (![fileManager fileExistsAtPath:dbFile]) {
        NSError *error = [[NSError alloc] init];
        [fileManager copyItemAtPath:bundleDb toPath:dbFile error:&error];
        [error release];
    }
    
    if (![[KSDB db] open]) {
        KSDINFO(@"Cant not open sqlite db file!");
        return;
    }
    KSDINFO(@"open dbfile succeed!");
//网速太快导致notification没有完成
//    KSGetMagzineListOperation *operGetMagzineList = [[KSGetMagzineListOperation alloc] init];
//    [[KSBootstrap operationQueue] addOperation:operGetMagzineList];
//    [operGetMagzineList release];
    
    
    //增加第一次安装默认值设置
    if ([[KSDB stringForKey:UD_KEY_INSTALLED] intValue] < 1) {
        //注册设备UDID
        [CXRegDeviceUDIDRequest requestWithDelegate:nil];
        
        [KSDB saveString:@"1" forKey:UD_KEY_INSTALLED];
        [KSDB saveString:@"0" forKey:PUSH_START_HOUR];
        [KSDB saveString:@"24" forKey:PUSH_END_HOUR];
        [KSDB saveString:STR_FORMAT(@"%d", cXPushTypeNone|cXPushTypeNews|cXPushTypeMagazine|cxPushTypeUpMagazine) forKey:PUSH_TYPE];
        //设置记住密码
        [KSDB saveString:@"0" forKey:UD_KEY_AUTOLOGIN];
        //默认字号
        [KSDB saveString:@"18" forKey:KEY_DEFAULT_FONT_SIZE];
        //显示首次安装帮助
        //[KSDB saveString:@"1" forKey:@"SHOW_FIRST_HELP"];
        [[KSBootstrap dataCenter] setValue:@"1" forKey:KEY_SHOW_FIRST_HELP];
        
//        //copy 默认广告图片
//        [[NSFileManager defaultManager] copyItemAtPath:KSPathForBundleResource(@"ad.png") toPath:KSPathForDocumentsResource(KEY_STORAGE_DIR@"/ad.png") error:nil];
        [KSDB saveString:[[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"] forKey:KEY_CURRENT_VERSION];
        //cache UDID
        [KSDB saveString:KEY_DEVICE_UDID forKey:KEY_DEVICE_UDID_STR];
        //分享缓存清理
        [SHKSina logout];
        [SHKTencent logout];
    } else {//检查是否需要升级
//        NSString *currentVersion = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
//        NSString *oldVersion = [KSDB stringForKey:KEY_CURRENT_VERSION];
//        if ([currentVersion versionStringCompare:oldVersion]==NSOrderedDescending) {
//            
//        }
    }
    
    //自动登录
    if ([[KSDB stringForKey:UD_KEY_AUTOLOGIN] intValue] > 0) {
        [self autoLogin];
    }
}

+ (void) start{
    //make root dir
    NSString *rootDir = [KSBootstrap root];
    NSFileManager *fileMan = [NSFileManager defaultManager];
    BOOL isDir = NO, isExist = [fileMan fileExistsAtPath:rootDir isDirectory:&isDir];
    if(isExist && !isDir){
        [fileMan removeItemAtPath:rootDir error:nil];
        isExist = NO;
    }
    if(!isExist){
        [fileMan createDirectoryAtPath:rootDir withIntermediateDirectories:YES attributes:nil error:nil];
    }
    u_int8_t b = 1;           
    setxattr([rootDir cStringUsingEncoding:NSUTF8StringEncoding], "com.apple.MobileBackup", &b, 1, 0, 0);
    //instance dataCenter
    [KSBootstrap dataCenter];
    [KSBootstrap operationQueue];
    //instance modeFactory
    [KSModelFactory sharedFactory:rootDir];
    //init data
    [KSBootstrap _initData];
    [KSDownloadManager sharedManager];
    
    [KStoreManager sharedManager];
}

+ (void) end{
    [_dataCenter release];
    [_threadedQueue release];
    [[KSDB db] close];
}

+ (void)notify:(NSString *)name data:(NSDictionary *)data{
    [[NSNotificationCenter defaultCenter] postNotificationName:name object:nil userInfo:data];
}

+ (void)listen:(NSString *)name target:(id)target selector:(SEL)selector{
    [[NSNotificationCenter defaultCenter] addObserver:target selector:selector name:name object:nil];
}

+ (void)unlisten:(id)target{
    [[NSNotificationCenter defaultCenter] removeObserver:target];
}

+ (void)unlisten:(NSString *)name target:(id)target{
    [[NSNotificationCenter defaultCenter] removeObserver:target name:name object:nil];
}
@end
