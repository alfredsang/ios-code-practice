//
//  KSDB.h
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-23.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDatabase.h"
#import "FMDatabaseAdditions.h"

@interface KSDB : NSObject
+ (FMDatabase *)db;
+ (NSString *)dbFile;
+ (NSString *)stringForKey:(NSString *)key;
+ (void)saveString:(NSString *)str forKey:(NSString *)key;
@end
