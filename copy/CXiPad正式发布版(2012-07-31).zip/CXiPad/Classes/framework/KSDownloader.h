//
//  KSDownloader.h
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ASIHTTPRequest.h"

@class KSDownloader;

@protocol KSDownloaderDelegate <NSObject>
@optional
- (void) onDownloadStart:(KSDownloader *)downloader;
- (void) onDownloadSuccess:(KSDownloader *)downloader;
- (void) onDownloadFail:(KSDownloader *)downloader;
- (void) setDownloadProgress:(float)newProgress;
- (void) onDownloadCancel:(KSDownloader *)downloader;
@end

@interface KSDownloader : NSObject<ASIHTTPRequestDelegate, ASIProgressDelegate>{
    ASIHTTPRequest *_request;
    NSString *_saveTo;
    NSString *_requestUrl;
    BOOL _asyn;
}
@property(nonatomic, retain) id<KSDownloaderDelegate> delegate;
@property(nonatomic, assign) UIProgressView *progressView;
@property(nonatomic, readonly) NSError* error;
@property(nonatomic, readonly) NSString* requestUrl;
@property(nonatomic, retain) NSDictionary* data;
@property (nonatomic, copy) void (^onDownloadCancelled)();
@property (nonatomic, copy) void (^onDownloadCompleted)();
@property (nonatomic, copy) void (^onDownloadFailed)(NSError *error);
- (id) init:(NSString *)requestUrl saveTo:(NSString *)saveTo asyn:(BOOL)asyn;
- (void) start;
- (void) cancel;
@end
