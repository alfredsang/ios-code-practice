//
//  KSGetRequest.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSUrlRequest.h"

@interface KSUrlRequest()
- (void)generateRequestWithUrl:(NSString*)url withParameters:(NSDictionary*)params;
@end

@implementation KSUrlRequest
@synthesize delegate = _delegate, error = _error, asyn = _asyn, content = _content;

+ (NSString *) encodeURL:(NSString *)str{
    return [str stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]; 
}

- (void)generateRequestWithUrl:(NSString*)url withParameters:(NSDictionary*)params {
	if (_method == kKSUrlRequestGet){
        NSString *urlStr = url;
        NSMutableArray *paramParts = [NSMutableArray arrayWithCapacity:1];
		if (params) {
			NSArray *allKeys = [params allKeys];
			NSInteger count = [allKeys count];
			NSString *value = nil;
			for (NSUInteger i=0; i<count; i++) {
				id key = [allKeys objectAtIndex:i];
				value = (NSString *)[params objectForKey:key];
				value = [KSUrlRequest encodeURL:value];
				[paramParts addObject:STR_FORMAT(@"%@=%@", key, value)];
			}
            if([url rangeOfString:@"?"].length>0){
                urlStr = STR_FORMAT(@"%@&%@", url, [paramParts componentsJoinedByString:@"&"]);
            }else{
                urlStr = STR_FORMAT(@"%@?%@", url, [paramParts componentsJoinedByString:@"&"]);
            }
		}
        NSURL *nsUrl = [NSURL URLWithString:urlStr];
        _request = [ASIHTTPRequest requestWithURL:nsUrl];
        [_request setRequestMethod:@"GET"];
    }else{
        NSURL *nsUrl = [NSURL URLWithString:url];
        _request = [ASIFormDataRequest requestWithURL:nsUrl];
        ASIFormDataRequest *request = (ASIFormDataRequest *)_request;
        [request setRequestMethod:@"POST"];
        ASIPostFormat postFormat = ASIURLEncodedPostFormat;
        for (NSString *key in [params allKeys]) {
            [request addPostValue:[params objectForKey:key] forKey:key];
        }
        request.postFormat = postFormat;
    }
    _request.delegate = self;
    _request.defaultResponseEncoding = NSUTF8StringEncoding;
    _request.timeOutSeconds = 600;
    _request.allowCompressedResponse = YES;
    _request.shouldCompressRequestBody = NO;
    _request.shouldRedirect = YES;
    [_request retain];
}

+ (NSString *)networkErrorMessage:(NSError *)error{
    switch ([error code]) {
        case ASIConnectionFailureErrorType:
            return @"无法连接到网络";
        case ASIRequestTimedOutErrorType:
            return @"访问超时";
        case ASIAuthenticationErrorType:
            return @"服务器身份验证失败";
        case ASIRequestCancelledErrorType:
            return @"服务器请求已取消";
        case ASIUnableToCreateRequestErrorType:
            return @"无法创建服务器请求";
        case ASIInternalErrorWhileBuildingRequestType:
            return @"服务器请求创建异常";
        case ASIInternalErrorWhileApplyingCredentialsType:
            return @"服务器请求异常";
        case ASIFileManagementError:
            return @"服务器请求异常";
        case ASIUnhandledExceptionError:
            return @"未知请求异常异常";
        default:
            return @"服务器故障或网络链接失败！";
    }
    return nil;
}

- (void)requestStarted:(ASIHTTPRequest*)request {
	if(_delegate && [_delegate respondsToSelector:@selector(onRequestStart:)]){
		[_delegate onRequestStart:self];
	}
}

- (void)requestFinished:(ASIHTTPRequest*)request {
    RELEASE_SAFELY(_content);
    if (request.allowCompressedResponse) {
        _content = [[NSString alloc] initWithData:[request responseData] encoding:NSUTF8StringEncoding];
    }else{
        _content = [[NSString alloc] initWithData:[request rawResponseData] encoding:NSUTF8StringEncoding];
    }
    NSString *trimmedString = [_content stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    RELEASE_SAFELY(_content);
	_content = [trimmedString retain];
	if(_delegate && [_delegate respondsToSelector:@selector(onRequestSuccess:)]){
        [_delegate onRequestSuccess:self];
    }
    RELEASE_SAFELY(_request);
}

- (void)requestFailed:(ASIHTTPRequest*)request {
	_error = [[request error] retain];
	if(_delegate && [_delegate respondsToSelector:@selector(onRequestFail:)]){
        [_delegate onRequestFail:self];
    }
    RELEASE_SAFELY(_request);
}

- (NSDictionary *)resultDict{
	if (!_content || [_content length] == 0) {
		return nil;
	}
	NSData *jsonData;
	if ([[_content  substringWithRange:NSMakeRange(0,1)] isEqualToString: @"["] ) {
		jsonData = [[[@"{\"data\":" stringByAppendingString:_content ] stringByAppendingString:@"}"] dataUsingEncoding:NSUTF8StringEncoding];
	}else {
		jsonData = [_content dataUsingEncoding:NSUTF8StringEncoding];
	}
    NSError *error;
    NSDictionary *resultDic = [[CJSONDeserializer deserializer] deserializeAsDictionary:jsonData error:&error];
    
	if(!resultDic) { 
        _error = [[_request error] retain];
        return nil;
	}
    return resultDic;
}

#pragma mark KSUrlRequest
- (id) initWithUrl:(NSString *)requestUrl{
    return [self initWithUrl:requestUrl params:nil method:kKSUrlRequestGet];
}
- (id) initWithUrl:(NSString *)requestUrl params:(NSDictionary *)params{
    return [self initWithUrl:requestUrl params:params method:kKSUrlRequestGet];
}
- (id) initWithUrl:(NSString *)requestUrl params:(NSDictionary *)params method:(KSUrlRequestMethod)method{
    if(self = [super init]){
        _requestUrl = [requestUrl retain];
        _params = [params retain];
        _method = method;
    }
    return self;
}

- (void) start{
	[self generateRequestWithUrl:_requestUrl withParameters:_params];
    KSDINFO(@"_request start %@", _request.url);
    if(_asyn){
        [_request startAsynchronous];
    }else{
        [_request startSynchronous];
    }
}

- (void)cancel {
    [_request cancel];
    [_request clearDelegatesAndCancel];
    RELEASE_SAFELY(_request);
    RELEASE_SAFELY(_error);
    RELEASE_SAFELY(_content);
}

- (void)dealloc {
    //[_delegate release];
    [_content release];
    [_requestUrl release];
    [_error release];
    [_params release];
    RELEASE_SAFELY(_request);
    [super dealloc];
}
@end
