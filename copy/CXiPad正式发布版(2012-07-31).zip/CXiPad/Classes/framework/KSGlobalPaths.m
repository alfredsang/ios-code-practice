//
//  KSGlobalPaths.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 12/22/11.
//  Copyright (c) 2011 KSMobile. All rights reserved.
//

#import "KSGlobalPaths.h"


static NSBundle* globalBundle = nil;


///////////////////////////////////////////////////////////////////////////////////////////////////
BOOL KSIsBundleURL(NSString* URL) {
    return [URL hasPrefix:@"bundle://"];
}


///////////////////////////////////////////////////////////////////////////////////////////////////
BOOL KSIsDocumentsURL(NSString* URL) {
    return [URL hasPrefix:@"documents://"];
}


///////////////////////////////////////////////////////////////////////////////////////////////////
void KSSetDefaultBundle(NSBundle* bundle) {
    [bundle retain];
    [globalBundle release];
    globalBundle = bundle;
}


///////////////////////////////////////////////////////////////////////////////////////////////////
static NSBundle* KSGetDefaultBundle() {
    return (nil != globalBundle) ? globalBundle : [NSBundle mainBundle];
}


///////////////////////////////////////////////////////////////////////////////////////////////////
NSString* KSPathForBundleResource(NSString* relativePath) {
    NSString* resourcePath = [KSGetDefaultBundle() resourcePath];
    return [resourcePath stringByAppendingPathComponent:relativePath];
}


///////////////////////////////////////////////////////////////////////////////////////////////////
NSString* KSPathForDocumentsResource(NSString* relativePath) {
    static NSString* documentsPath = nil;
    if (nil == documentsPath) {
        NSArray* dirs = NSSearchPathForDirectoriesInDomains(
                                                            NSDocumentDirectory, NSUserDomainMask, YES);
        documentsPath = [[dirs objectAtIndex:0] retain];
    }
    return [documentsPath stringByAppendingPathComponent:relativePath];
}

///////////////////////////////////////////////////////////////////////////////////////////////////
NSString* KSPathForCachesResource(NSString* relativePath) {
    static NSString* cachesPath = nil;
    if (nil == cachesPath) {
        cachesPath = [[NSString stringWithFormat:@"%@/Library/Caches/", NSHomeDirectory()] retain];
    }
    return [cachesPath stringByAppendingPathComponent:relativePath];
}


