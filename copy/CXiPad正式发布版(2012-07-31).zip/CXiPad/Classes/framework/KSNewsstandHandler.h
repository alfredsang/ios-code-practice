//
//  KSNewsstandHandler.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 2/5/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <NewsstandKit/NewsstandKit.h>
#import "KSGetMagzineListOperation.h"
@interface KSNewsstandHandler : NSObject<NSURLConnectionDownloadDelegate>
{
    
}
@property(nonatomic,retain) NSDictionary *info;
+ (void)handle:(NSDictionary *)userInfo;
+(KSNewsstandHandler*)shareKSNewsstandHandler;
@end
