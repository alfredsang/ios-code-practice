//
//  KSDownMagazineOperation.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 2/1/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KSGetAllArticlesDownloader.h"

@interface KSDownMagazineOperation : NSOperation{
    NSInteger _magazineId;
    KSGetAllArticlesDownloader *_getAllArticlesDownloader;
    UIProgressView *_progressView;
}
@property(nonatomic, retain)UIProgressView *progressView;
@property(nonatomic, assign)NSInteger magazinId;

- (id)initWithMagazineId:(NSInteger)magzineId;

@end
