//
//  KSGetRequest.h
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ASIHTTPRequest.h"
#import "ASIFormDataRequest.h"

typedef enum _KSUrlRequestMethod{
    kKSUrlRequestGet = 0,
    lKSUrlRequestPost = 1
} KSUrlRequestMethod;

@class KSUrlRequest;

@protocol KSUrlRequestDelegate <NSObject>
@optional
- (void) onRequestStart:(KSUrlRequest *)request;
- (void) onRequestSuccess:(KSUrlRequest *)request;
- (void) onRequestFail:(KSUrlRequest *)request;
@end

@interface KSUrlRequest : NSObject<ASIHTTPRequestDelegate>{
    ASIHTTPRequest *_request;
    NSString *_requestUrl;
    NSDictionary *_params;
    KSUrlRequestMethod _method;
}
@property(nonatomic, assign) id<KSUrlRequestDelegate> delegate;
@property(nonatomic, assign) BOOL asyn;
@property(nonatomic, retain, readonly) NSString* content;
@property(nonatomic, retain, readonly) NSError* error;
+ (NSString *) networkErrorMessage:(NSError *)error;
+ (NSString*) encodeURL:(NSString *)str;
- (id) initWithUrl:(NSString *)requestUrl;
- (id) initWithUrl:(NSString *)requestUrl params:(NSDictionary *)params;
- (id) initWithUrl:(NSString *)requestUrl params:(NSDictionary *)params method:(KSUrlRequestMethod)method;
- (void) start;
- (void) cancel;
- (NSDictionary *) resultDict;
@end
