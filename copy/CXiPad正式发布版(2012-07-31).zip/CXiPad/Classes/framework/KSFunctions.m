//
//  KSFunctions.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-27.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSFunctions.h"


UIColor* str2rgb(NSString* rgb){
    if ([rgb isKindOfClass:[NSNull class]]||rgb == nil)
    {
        return nil;
    }
    unsigned int r, g, b;
    [[NSScanner scannerWithString:[rgb substringWithRange:NSMakeRange(1, 2)]]scanHexInt:&r];
    [[NSScanner scannerWithString:[rgb substringWithRange:NSMakeRange(3, 2)]]scanHexInt:&g];
    [[NSScanner scannerWithString:[rgb substringWithRange:NSMakeRange(5, 2)]]scanHexInt:&b];
    return [UIColor colorWithRed:r/255.0f green:g/255.0f blue:b/255.0f alpha:1]; 
}
//@"Microsoft YaHei"
//@"STSong"
//@"SimSun"
//@"Helvetica"
//@"LiSong Pro" 
//@"Helvetica-Light" 
//@"STHeitiSC-Light"
UIFont* yahei(float size){
    //return [UIFont fontWithName:@"Microsoft YaHei" size:size];
    return [UIFont systemFontOfSize:size];
}