//
//  KSNewsstandHandler.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 2/5/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KSNewsstandHandler.h"
#import "KSRemoteNotificationHanlder.h"
#import "KSModelMagzine.h"
#import "KSGetAllArticlesDownloader.h"

@interface KSNewsstandHandler()

-(void)addIssuesInNewsstand:(NSDictionary*)issues;
-(void)downloadIssue:(NKIssue *)nkIssue url:(NSString*)url;
@end



static KSNewsstandHandler *handler;
static NSInteger magazineId;

@implementation KSNewsstandHandler
@synthesize info;
+(KSNewsstandHandler*)shareKSNewsstandHandler
{
    if (handler==nil)
    {
        handler = [[KSNewsstandHandler alloc] init];
        [KSBootstrap listen:NOTIFY_MAGZINE_LIST_UPDATED target:handler selector:@selector(whenMagzineListUpdated:)];

    }
    return handler;
}
-(void)startBackgroundDownload
{
    if ([[[UIDevice currentDevice] systemVersion] floatValue]>=5.0)
    {
        NSString *magazineId = [handler.info objectForKey:@"periodicalid"];
        KSModelMagzine *magazine = [KSModelMagzine loadById:[magazineId intValue]];
        
        if (magazineId&&![[magazineId stringByReplacingOccurrencesOfString:@" " withString:@""] isEqualToString:@""]&&[magazine isMybook]&&![USER_DEFAULT boolForKey:BACKGROUND_DOWNLOAD])
        {
//            NSLog(@"bg==========bg=============bg");
            
            [handler addIssuesInNewsstand:[NSDictionary dictionaryWithObjectsAndKeys:[handler.info objectForKey:@"periodicalid"],@"Name",[NSDate dateWithTimeIntervalSince1970:magazine.pubDate],@"Date",magazineId,@"id", nil]];
//            NSLog(@"newsstand push success``````````%d",magazine.magzineId);
//            NSString *str = [[NSString alloc] initWithFormat:@"该本杂志%d有权限,可以下载",magazine.magzineId];
//            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:str delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
//            [alert show];
//            [alert release];
        }
        else
        {
//            NSString *str = [[NSString alloc] initWithFormat:@"该本杂志%d没有权限",magazine.magzineId];
//            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:str delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
//            [alert show];
//            [alert release];
//            NSLog(@"newsstand push failed``````````%d",magazine.magzineId);
        }

    }
    else
    {
//        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"系统版本小于5.0" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
//        [alert show];
//        [alert release];
    }
                                              

}
+ (void)handle:(NSDictionary *)userInfo
{

    [KSNewsstandHandler shareKSNewsstandHandler];
    handler.info = userInfo;
    NSString *magazineId = [[handler.info objectForKey:@"periodicalid"] retain];
    NSArray *magazins = [[NSArray alloc] initWithArray:[KSModelMagzine magzines]];
    BOOL exist = NO;
    for (int i = 0;i<[magazins count];i++)
    {
        KSModelMagzine *magaz = [magazins objectAtIndex:i];
        if ([magazineId intValue]==magaz.magzineId)
        {
            exist = YES;
            break;
        }
    }
    if (exist)
    {
        [handler startBackgroundDownload];

    }
    else
    {
        [KSRemoteNotificationHanlder whenNewMagzine];

    }
    [magazineId release];
    [magazins release];
}
-(void)whenMagzineListUpdated:(NSNotification*)notification
{
    [self startBackgroundDownload];
//    KSModelMagzine *magazine = [KSModelMagzine loadById:[[handler.info objectForKey:@"periodicalid"] intValue]];
//    if ([magazine isMybook])
//    {
        
        
//    }
//    else
//    {
//        KSDINFO(@"newsstand push failed``````````%d",magazine.magzineId);
//
//    }
}
-(void)addIssuesInNewsstand:(NSDictionary*)issues
{
    // shared NKLibrary instance
    NKLibrary *nkLib = [NKLibrary sharedLibrary];
//    [issues enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) 
//    {
        NSString *name = [issues objectForKey:@"Name"];
        NKIssue *nkIssue = [nkLib issueWithName:name];
        if(!nkIssue) 
        {
            NKIssue *nkIssue = [nkLib addIssueWithName:name date:[issues objectForKey:@"Date"]];
            magazineId = [[issues objectForKey:@"id"] intValue];
            NSString *url = [[NSString alloc] initWithFormat:GET_AMAGZINE_URL,magazineId];
            [self downloadIssue:nkIssue url:url];
        }
//    }];
}
-(NSString *)downloadPathForIssue:(NKIssue *)nkIssue 
{
    NSString *_zipFile = [NSString stringWithFormat:@"%@/%@.zip", [KSBootstrap root], [handler.info objectForKey:@"periodicalid"]];
    return _zipFile;
}
-(void)downloadIssue:(NKIssue *)nkIssue url:(NSString*)url
{
//    NKLibrary *nkLib = [NKLibrary sharedLibrary];
    NSURL *downloadURL = [NSURL URLWithString:url];
    if(!downloadURL) 
        return ;
    NSURLRequest *request = [NSURLRequest requestWithURL:downloadURL];
    NKAssetDownload *assetDownload = [nkIssue addAssetWithRequest:request];
//    [assetDownload setUserInfo:[NSDictionary dictionaryWithObjectsAndKeys:
//                                [NSNumber numberWithInt:1],@"Index",
//                                nkIssue.name,@"issueName",
//                                nil]];
    [assetDownload downloadWithDelegate:self];
}

//-(void)updateProgressOfConnection:(NSURLConnection *)connection withTotalBytesWritten:(long long)totalBytesWritten expectedTotalBytes:(long long)expectedTotalBytes {
//    // get asset
//    NKAssetDownload *dnl = connection.newsstandAssetDownload;
//    UITableViewCell *cell = [table_ cellForRowAtIndexPath:[NSIndexPath indexPathForRow:[[dnl.userInfo objectForKey:@"Index"] intValue] inSection:0]];
//    UIProgressView *progressView = (UIProgressView *)[cell viewWithTag:102];
//    progressView.alpha=1.0;
//    [[cell viewWithTag:103] setAlpha:0.0];
//    progressView.progress=1.f*totalBytesWritten/expectedTotalBytes;
//}

-(void)downloadSuccess
{
    
}

- (void)saveArticleToDB:(NSInteger)articleId {
    NSInteger _articleId = articleId;
    KSModelArticle *oldArticle = [KSModelArticle loadById:_articleId withContent:NO];
    if(oldArticle.isDownload)return;
    NSString *jsonFile = STR_FORMAT(@"%@/magzineUnpack%d/%d/article.json", [KSBootstrap root], magazineId, _articleId);
    NSData *jsonData = [NSData dataWithContentsOfFile:jsonFile];
    NSDictionary *dict = [[CJSONDeserializer deserializer] deserializeAsDictionary:jsonData error:nil];
    if(dict){
        NSString *sql = @"delete from article_header_blocks where article_id=?";
        [[KSDB db] executeUpdate:sql, INTEGER(_articleId)];
        sql = @"delete from article_images where article_id=?";
        [[KSDB db] executeUpdate:sql, INTEGER(_articleId)];
        NSDictionary *vblocks = [dict objectForKey:@"vblocks"];
        for (NSString *page in vblocks.keyEnumerator) {
            NSArray *blocks = [vblocks objectForKey:page];
            for (NSDictionary *block in blocks) {
                if(DICT_INTVAL(block, @"blocktype")==0){
                    //header
                    NSString *sql = @"insert into article_header_blocks(article_id, page, is_v, left, top, width, height, content, left_image, right_image) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    [[KSDB db] executeUpdate:sql, INTEGER(_articleId), page, INTEGER(1), DICT_VAL(block, @"left"), DICT_VAL(block, @"top"), DICT_VAL(block, @"width"), DICT_VAL(block, @"height"), DICT_VAL(block, @"content"), DICT_VAL(block, @"leftimage"), DICT_VAL(block, @"rightimage")];
                }else if(DICT_INTVAL(block, @"blocktype")==1){
                    NSString *sql = @"insert into article_images(article_id, page, is_v, left, top, width, height, image, title, link, controltype) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    [[KSDB db] executeUpdate:sql, INTEGER(_articleId), page, INTEGER(1), DICT_VAL(block, @"left"), DICT_VAL(block, @"top"), DICT_VAL(block, @"width"), DICT_VAL(block, @"height"), DICT_VAL(block, @"url"), DICT_VAL(block, @"title"), DICT_VAL(block, @"link"), DICT_VAL(block, @"controltype")];
                }
            }
        }
        NSDictionary *hblocks = [dict objectForKey:@"hblocks"];
        for (NSString *page in hblocks.keyEnumerator) {
            NSArray *blocks = [hblocks objectForKey:page];
            for (NSDictionary *block in blocks) {
                if(DICT_INTVAL(block, @"blocktype")==0){
                    //header
                    NSString *sql = @"insert into article_header_blocks(article_id, page, is_v, left, top, width, height, content, left_image, right_image) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    [[KSDB db] executeUpdate:sql, INTEGER(_articleId), page, INTEGER(0), DICT_VAL(block, @"left"), DICT_VAL(block, @"top"), DICT_VAL(block, @"width"), DICT_VAL(block, @"height"), DICT_VAL(block, @"content"), DICT_VAL(block, @"leftimage"), DICT_VAL(block, @"rightimage")];
                }else if(DICT_INTVAL(block, @"blocktype")==1){
                    NSString *sql = @"insert into article_images(article_id, page, is_v, left, top, width, height, image, title, link, controltype) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    [[KSDB db] executeUpdate:sql, INTEGER(_articleId), page, INTEGER(0), DICT_VAL(block, @"left"), DICT_VAL(block, @"top"), DICT_VAL(block, @"width"), DICT_VAL(block, @"height"), DICT_VAL(block, @"url"), DICT_VAL(block, @"title"), DICT_VAL(block, @"link"), DICT_VAL(block, @"controltype")];
                }
            }
        }
        //article_templates
        sql = @"delete from article_templates where article_id=?";
        [[KSDB db] executeUpdate:sql, INTEGER(_articleId)];
        NSArray * templates = [dict objectForKey:@"templates"];
        for (NSDictionary *template in templates) {
            NSString *sql = @"insert into article_templates(article_id, type, background, content) values(?, ?, ?, ?)";
            [[KSDB db] executeUpdate:sql, INTEGER(_articleId), DICT_VAL(template, @"type"), DICT_VAL(template, @"background"), DICT_VAL(template, @"content")];
        }
        // slideshow
        sql = @"delete from article_slideshow where article_id=?";
        [[KSDB db] executeUpdate:sql, INTEGER(_articleId)];
        NSArray * slideshows = [dict objectForKey:@"slideshow"];
        int iter = 0;
        for (NSDictionary *image in slideshows) {
            NSString *sql = @"insert into article_slideshow(article_id, hsrc, vsrc, title, link, ranking) values(?, ?, ?, ?, ?, ?)";
            iter++;
            [[KSDB db] executeUpdate:sql, INTEGER(_articleId), DICT_VAL(image, @"hsrc"), DICT_VAL(image, @"vsrc"), DICT_VAL(image, @"title"), DICT_VAL(image, @"link"), INTEGER(iter)];
        }
        //relations
        sql = @"delete from article_relations where id=?";
        [[KSDB db] executeUpdate:sql, INTEGER(_articleId)];
        NSArray * relations = [dict objectForKey:@"relations"];
        iter = 0;
        for (NSDictionary *dic in relations) {
            NSString *sql = @"insert into article_relations(id, relation_article_id, relation_article_resource, title, url, relation_article_type,relation_article_pubtime,relation_article_cover_title,stage_number,publish_time) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            iter++;
            [[KSDB db] executeUpdate:sql, INTEGER(_articleId), INTEGER([[dic objectForKey:@"relarticleid"] intValue]),[dic objectForKey:@"relartisource"],[dic objectForKey:@"relartititle"],[dic objectForKey:@"relartipuburl"],[dic objectForKey:@"relartitype"],[dic objectForKey:@"relartipubtime"],[dic objectForKey:@"covertitle"],[dic objectForKey:@"stagenumber"],[dic objectForKey:@"publishtime"]];
        }
        
        //childrens
        sql = @"delete from article_children where article_id=?";
        [[KSDB db] executeUpdate:sql, INTEGER(_articleId)];
        NSArray *childrens = [dict objectForKey:@"children"];
        iter = 0;
        for (NSDictionary *child in childrens) {
            NSString *sql = @"insert into article_children(article_id, child_id,ranking) values(?,?,?)";
            iter++;
            [[KSDB db] executeUpdate:sql, INTEGER(_articleId),child, INTEGER(iter)];
        }
        
        //
        
        [[KSDB db] executeUpdate:@"update articles set is_download=?, vcolumns=?, hcolumns=?, content_length=?, authors=?,mulu_pic_author=? ,subtitle=?, summary=?, title=?, video_src=?,video2=?,video3=?, audio_src=?, is_html=?,arti_type=?, is_free=?, catalog_id=?, ranking=? where article_id=?", INTEGER(1), INTEGER(DICT_INTVAL(dict, @"vcolumns")), INTEGER(DICT_INTVAL(dict, @"hcolumns")), DICT_VAL(dict, @"contentlength"), DICT_VAL(dict, @"metadata.author"),DICT_VAL(dict, @"metadata.mulu_pic_author")?DICT_VAL(dict, @"metadata.mulu_pic_author"):@"", DICT_VAL(dict, @"metadata.subtitle"), DICT_VAL(dict, @"metadata.summary"), DICT_VAL(dict, @"metadata.title"), DICT_VAL(dict, @"metadata.video"),DICT_VAL(dict, @"metadata.video2"),DICT_VAL(dict, @"metadata.video3"), DICT_VAL(dict, @"metadata.audio"), [DICT_VAL(dict, @"metadata.type") isEqualToString:@"cortext"]?INTEGER(0):INTEGER(1),INTEGER(DICT_INTVAL(dict, @"metadata.artitype")), DICT_VAL(dict, @"metadata.isfree"), DICT_VAL(dict, @"metadata.categoryid"), DICT_VAL(dict, @"metadata.artiorder"), INTEGER(_articleId)];
        [[KSDB db] executeUpdate:@"update magzines set download_articles_num=download_articles_num+1 where magzine_id=?", INTEGER(magazineId)];
    }
    //[KSBootstrap notify:NOTIFY_ARTICLE_DOWNLOADED data:[NSDictionary dictionaryWithObjectsAndKeys:INTEGER(_articleId), @"article_id", INTEGER(_magzineId), @"magzine_id", nil]];
    
}


- (void)saveCatalogToDB
{
    [[KSDB db] executeUpdate:@"delete from catalogs where magzine_id=?", INTEGER(magazineId)]; //默认先删除老数据，防止重复调用引起的问题
    
    NSString *jsonFile = STR_FORMAT(@"%@/magzineUnpack%d/catalog.json", [KSBootstrap root], magazineId);
    NSData *jsonData = [NSData dataWithContentsOfFile:jsonFile];
    NSDictionary *dict = [[CJSONDeserializer deserializer] deserializeAsDictionary:jsonData error:nil];
    if(dict)
    {
        NSDictionary *categoryDic = [dict objectForKey:@"category"];
        if ([categoryDic isKindOfClass:[NSDictionary class]])
        {
            NSArray *keys = [categoryDic allKeys];
            for (int j = 0; j<[keys count]; j++)
            {
                NSString *key = [keys objectAtIndex:j];
                
                NSArray *catalogsArray = [categoryDic objectForKey:key];
                
                for (int i = 0; i<[catalogsArray count]; i++)
                {
                    NSDictionary *catalog = [catalogsArray objectAtIndex:i];
                    [[KSDB db] executeUpdate:@"insert into catalogs(magzine_id, catalog_id,catalogcolor_id, title, parent_id, ranking) values(?, ?, ?,?, ?, ?)",
                     INTEGER(magazineId),
                     INTEGER(DICT_INTVAL(catalog, @"id")),
                     [catalog  objectForKey:@"catecolor"],
                     [catalog objectForKey:@"title"],
                     INTEGER([key intValue]),
                     INTEGER([[catalog objectForKey:@"cateorder"] intValue])
                     ];
                    
                }
                
            }
            
        }
        else
        {
            NSArray *categoryArray = [dict objectForKey:@"category"];
            for (int j = 0; j<[categoryArray count]; j++)
            {
                NSArray *array = [categoryArray objectAtIndex:j];
                
                
                for (int i = 0; i<[array count]; i++)
                {
                    NSDictionary *catalog = [array objectAtIndex:i];
                    [[KSDB db] executeUpdate:@"insert into catalogs(magzine_id, catalog_id,catalogcolor_id, title, parent_id, ranking) values(?, ?, ?,?, ?, ?)",
                     INTEGER(magazineId),
                     INTEGER(DICT_INTVAL(catalog, @"id")),
                     [catalog  objectForKey:@"catecolor"],
                     [catalog objectForKey:@"title"],
                     INTEGER(0),
                     INTEGER(DICT_INTVAL(catalog, @"0"))
                     ];
                    
                }
                
            }
            
        }
    }
}

- (void)saveMagazineToDB
{
    
    NSString *jsonFile = STR_FORMAT(@"%@/magzineUnpack%d/magazine.json", [KSBootstrap root], magazineId);
    NSData *jsonData = [NSData dataWithContentsOfFile:jsonFile];
    NSDictionary *dict = [[CJSONDeserializer deserializer] deserializeAsDictionary:jsonData error:nil];
    if(dict)
    {
        NSInteger articlesNum = DICT_INTVAL(dict, @"article_num");
        NSString *adPic = [[dict objectForKey:@"ad"] objectForKey:@"ad_pic"];
        NSString *adUrl = [[dict objectForKey:@"ad"] objectForKey:@"ad_url"];
        [[KSDB db] executeUpdate:@"update magzines set download_articles_num =?, articles_num=?,is_articles_download=1,rate_download='1', issue_number=?, stage_number=?, is_special_issue=?, custom_number=?, pub_date=?, cover_title=?, cover_summary=?, is_free=?, file_size=?,ad_pic=?,ad_url=? where magzine_id=?",
         INTEGER(articlesNum),
         INTEGER(articlesNum),
         INTEGER(DICT_INTVAL(dict, @"issue_number")),
         INTEGER(DICT_INTVAL(dict, @"stage_number")),
         INTEGER(DICT_INTVAL(dict, @"is_special_issue")),
         DICT_VAL(dict, @"custom_issue_number"),
         INTEGER(DICT_INTVAL(dict, @"publication_time")),
         DICT_VAL(dict, @"cover_title"),
         DICT_VAL(dict, @"cover_description"),
         INTEGER(DICT_INTVAL(dict, @"isfree")),
         DICT_VAL(dict, @"file_size"),
         adPic,
         adUrl,
         INTEGER(magazineId)];
        NSArray *articles = [dict objectForKey:@"articles"];
        NSString *sql = @"DELETE FROM articles WHERE magzine_id=?";
        [[KSDB db] executeUpdate:sql,INTEGER(DICT_INTVAL(dict, @"id"))];
        int iteration = 0;
        for (NSDictionary *articleDict in articles) {
            KSModelArticle *article = [KSModelArticle articleWith:articleDict];
            article.rankingInMagzine = iteration++;
            //if(![article insert])continue;
            [article insert];
            [self saveArticleToDB:article.articleId];
        }
    }
    
    [self saveCatalogToDB];
}

-(void)connection:(NSURLConnection *)connection didWriteData:(long long)bytesWritten totalBytesWritten:(long long)totalBytesWritten expectedTotalBytes:(long long)expectedTotalBytes
{
    NSLog(@"didWriteData   %lld  %lld  %lld  %f",bytesWritten,totalBytesWritten,expectedTotalBytes,(CGFloat)totalBytesWritten/(CGFloat)expectedTotalBytes);
}

-(void)connectionDidResumeDownloading:(NSURLConnection *)connection totalBytesWritten:(long long)totalBytesWritten expectedTotalBytes:(long long)expectedTotalBytes
{
    NSLog(@"connectionDidResumeDownloading  %lld  %lld   %lld",totalBytesWritten,expectedTotalBytes,totalBytesWritten/expectedTotalBytes);
}

-(void)connectionDidFinishDownloading:(NSURLConnection *)connection destinationURL:(NSURL *)destinationURL
{
    NKAssetDownload *dnl = connection.newsstandAssetDownload;
    NKIssue *nkIssue = dnl.issue;
    NSString *_zipFile = [self downloadPathForIssue:nkIssue];
    NSLog(@"newsstand path==========================:%@",_zipFile);
    NSError *moveError=nil;
    if([[NSFileManager defaultManager] moveItemAtPath:[destinationURL path] toPath:_zipFile error:&moveError]==NO) 
    {
        NSLog(@"Error copying file from %@ to %@",destinationURL,_zipFile);
    }
    [[NKLibrary sharedLibrary] removeIssue:nkIssue];
    NSString* _unpackDir = [[NSString stringWithFormat:@"%@/%d/", [KSBootstrap root],magazineId] retain];
    ZipArchive* za = [[ZipArchive alloc] init];
    if( [za UnzipOpenFile:_zipFile] )
    {
        BOOL ret = [za UnzipFileTo:_unpackDir overWrite:YES];
        if( NO==ret ){
			NSLog(@"unzip error.");
        }else{
			NSLog(@"unzip successfully.");
		}
        [za UnzipCloseFile];
    }
    [za release];
    NSLog(@"%@",_unpackDir);

    NSFileManager *fileManager = [[NSFileManager alloc] init];
	if ([fileManager fileExistsAtPath:_zipFile]) {
		[fileManager removeItemAtPath:_zipFile error:nil];
	}
    NSString *renameToDir = [NSString stringWithFormat:@"%@/magzineUnpack%d", [KSBootstrap root], magazineId];
	if ([fileManager fileExistsAtPath:renameToDir]) {
		[fileManager removeItemAtPath:renameToDir error:nil];
	}
    

    [fileManager moveItemAtPath:_unpackDir toPath:renameToDir error:nil];
    [fileManager release];

    [self saveMagazineToDB];
    [[KSDB db] executeUpdate:@"update magzines set is_download=1,is_articles_download=1,rate_download=1 where magzine_id=?", INTEGER(magazineId)];

    [self performSelector:@selector(magazineDownload) withObject:nil afterDelay:1.0];

    
    



}

-(void)magazineDownload
{
    [KSBootstrap notify:NOTIFY_MAGZINE_DOWNLOADED data:[NSDictionary dictionaryWithObjectsAndKeys: INTEGER(magazineId), @"magzine_id", nil]];

}
@end
