//
//  KSGetMyFreeOperation.h
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-25.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface KSGetMyFreeOperation : NSOperation

@end
