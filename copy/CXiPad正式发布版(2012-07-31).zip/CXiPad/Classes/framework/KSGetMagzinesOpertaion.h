//
//  KSGetMagzinesOpertaion.h
//  CenturyWeeklyV2
//
//  Created by liuyou on 12-1-4.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface KSGetMagzinesOpertaion : NSOperation{
    NSArray *_magzineIds;
}
- (id)init:(NSArray *)magzineIds;
@end
