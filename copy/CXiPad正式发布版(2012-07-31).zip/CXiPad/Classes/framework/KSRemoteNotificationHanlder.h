//
//  KSPushNotificationDetector.h
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface KSRemoteNotificationHanlder : NSObject
+ (void) whenNewMagzine;
+ (void) whenMangzineUpdate:(NSInteger)magzineId;
+ (void) handle:(NSDictionary *)acmMsg;

+ (void)savePushSettingToServer;
@end
