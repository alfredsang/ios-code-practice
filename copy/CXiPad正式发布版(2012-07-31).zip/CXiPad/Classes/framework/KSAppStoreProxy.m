//
//  KSAppStoreProxy.m
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSAppStoreProxy.h"
static KSAppStoreProxy *_appStoreProxy;
@implementation KSAppStoreProxy
@synthesize productIdentifer = _productIdentifer;
+ (KSAppStoreProxy *)shareProxy{
    if(_appStoreProxy==nil){
        _appStoreProxy = [[KSAppStoreProxy alloc] init];
    }
    return _appStoreProxy;
}
- (void)dealloc {
    [_productIdentifer release];
    [super dealloc];
}
- (void)purchase:(NSString *)goodId prefix:(NSString *)prefix fromView:(UIView *)view onComplete:(void (^)(NSString*))complete{
    if ([SKPaymentQueue canMakePayments]) {
        if (_productIdentifer) {
            [_productIdentifer release];
            _productIdentifer = nil;
        }
        _productIdentifer = [[NSString stringWithFormat:@"%@%@",prefix, goodId] retain];
        
		[UIUtil showProcessIndicatorWithView:view atPoint:([UIUtil currentOrientation]==0)?CGPointMake(384, 512):CGPointMake(512, 384) hasMask:YES];
        
        KStoreManager *mkstore = [KStoreManager sharedManager];
        //mkstore.delegate = self;
        
        [mkstore buyFeature:_productIdentifer onComplete:^(NSString *productIdentifier_) {
            if(!_productIdentifer || ![_productIdentifer isEqualToString:productIdentifier_] || _productIdentifer.length<=prefix.length)return;
            NSString *goodId = [_productIdentifer substringFromIndex:prefix.length];
            complete(goodId);
            self.productIdentifer = nil;
            
        } onCancelled:^{
            [UIUtil hideProcessIndicatorWithView:view];
        }];
	} else {
		[UIUtil showMsgAlertWithTitle:@"购买受限提示" message:@"您的设备没有权限使用苹果的购买服务或没有网络连接，请使用系统设置或itunes进行相关设置。"];
        [UIUtil hideProcessIndicatorWithView:view];
	}
}
- (void)caixinSavePurchased:(NSString*)productIdentifier {
    [KSAppStoreProxy caixinSavePurchased:productIdentifier];
}
- (void)caixinSaveSubscription:(NSDictionary *)receipt verifiedReceiptDictionary:(NSDictionary *)verifiedReceiptDictionary {
    [KSAppStoreProxy caixinSaveSubscription:receipt verifiedReceiptDictionary:verifiedReceiptDictionary];
}


//实现逻辑以统一保存购买数据，兼容恢复购买
+ (void)caixinSavePurchased:(NSString*)productIdentifier {
    if ([productIdentifier length]>[STORE_PRODUCT_PREFIX length]) {
        NSString *idenTifierId = [productIdentifier substringFromIndex:[STORE_PRODUCT_PREFIX length]];
        [[KSDB db] executeUpdate:@"update magzines set is_purchased=1 where issue_number=?",INTEGER([idenTifierId intValue])];
        [[KSDB db] executeUpdate:@"update magzines set is_purchased=1 where custom_number=? and is_special_issue=1",idenTifierId];
    }
}

+ (void)caixinSaveSubscription:(NSDictionary *)receipt verifiedReceiptDictionary:(NSDictionary *)verifiedReceiptDictionary {
    NSDate *begindate;//purchase_date
    
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    NSString *purchasedDateString = [receipt objectForKey:@"original_purchase_date"];
    if (!purchasedDateString) {
        purchasedDateString = [receipt objectForKey:@"purchase_date"];
    }
    purchasedDateString = [purchasedDateString substringToIndex:10];    
    NSLocale *POSIXLocale = [[[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"] autorelease];
    [df setLocale:POSIXLocale];
    [df setTimeZone:[NSTimeZone timeZoneForSecondsFromGMT:0]];    
    [df setDateFormat:@"yyyy-MM-dd"];
    
    begindate = [df dateFromString: purchasedDateString];
    [df release];
    
    NSString *tranId = [receipt objectForKey:@"original_transaction_id"];
    if (tranId == nil) {
        tranId = [receipt objectForKey:@"transaction_id"];
    }
    
    NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *components = [[NSDateComponents alloc] init];
    
    NSString *productIdentifier = [receipt objectForKey:@"product_id"];
    NSInteger months = [[productIdentifier substringFromIndex:STORE_SUBSCRIPTION_PREFIX.length] intValue];
    components.month = months;
    
    NSDate *endDate = [gregorian dateByAddingComponents:components toDate:begindate options:0];
    NSString *lastExpireDateStr = nil;
    if ([verifiedReceiptDictionary objectForKey:@"latest_receipt_info"]) {
        lastExpireDateStr = [[verifiedReceiptDictionary objectForKey:@"latest_receipt_info"] objectForKey:@"expires_date"];
    }else if([verifiedReceiptDictionary objectForKey:@"latest_expired_receipt_info"]) {
        lastExpireDateStr = [[verifiedReceiptDictionary objectForKey:@"latest_expired_receipt_info"] objectForKey:@"expires_date"];
    }
    
    if (lastExpireDateStr == nil) {
        lastExpireDateStr = [receipt objectForKey:@"expires_date"];
    }
    NSInteger endIssueDate = 0;
    if (lastExpireDateStr == nil) {
        endIssueDate = [endDate timeIntervalSince1970];
    }else {
        endIssueDate = [lastExpireDateStr floatValue]/1000;//expires_date
    }
    [components release];
    [gregorian release];
    
    //保存订阅信息
    [[KSDB db] executeUpdate:@"delete from subscribed where order_no=?", tranId];
    [[KSDB db] executeUpdate:@"insert into subscribed(order_no, start, end,subsribe_type) values(?, ?, ?,?)", tranId, INTEGER([begindate timeIntervalSince1970]), INTEGER(endIssueDate),productIdentifier];
    
    
    //[[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_PURCHASE_COMPLETED object:nil userInfo:[NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithInt:endIssueDate], @"end", [NSNumber numberWithInt:[begindate timeIntervalSince1970]], @"start", tranId, @"tran_id",productIdentifier,@"identifier", @"subscribe", @"type", nil]];
}

+ (void) buy:(KSModelMagzine *)magzine fromView:(UIView *)view{
    if (![UIUtil checkInternetConnection])
    {
        return;
    }
    NSString *productId = [NSString stringWithFormat:@"%@%@",STORE_PRODUCT_PREFIX,magzine.isSpecialIssue?magzine.customIssueNumber:[NSString stringWithFormat:@"%d", magzine.issueNumber]];
    [UIUtil showProcessIndicatorWithView:view atPoint:([UIUtil currentOrientation]==0)?CGPointMake(384, 512):CGPointMake(512, 384) hasMask:YES];
    [[KStoreManager sharedManager] buyFeature:productId onComplete:^(NSString *productIdentifier_) {
        if ([productIdentifier_ isEqualToString:productId]) {
            magzine.isPurchased = YES;
            [UIUtil hideProcessIndicatorWithView:view];
            [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_PURCHASE_COMPLETED object:nil userInfo:[NSDictionary dictionaryWithObjectsAndKeys:productIdentifier_, magzine.isSpecialIssue?@"custom_issue_number":@"issue_number", @"buy", @"type", nil]];
        }
    } onCancelled:^{
        [UIUtil hideProcessIndicatorWithView:view];
    }];
    
    return;
                           
    [[KSAppStoreProxy shareProxy] purchase:magzine.isSpecialIssue?magzine.customIssueNumber:[NSString stringWithFormat:@"%d", magzine.issueNumber] prefix:STORE_PRODUCT_PREFIX fromView:view onComplete:^(NSString *goodId){
        //save data to db
        magzine.isPurchased = YES;
        //
        [UIUtil hideProcessIndicatorWithView:view];
        // notify
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_PURCHASE_COMPLETED object:nil userInfo:[NSDictionary dictionaryWithObjectsAndKeys:goodId, magzine.isSpecialIssue?@"custom_issue_number":@"issue_number", @"buy", @"type", nil]];
    }];
}

+ (void) subscribe:(NSInteger)months fromView:(UIView *)view{
    if (![UIUtil checkInternetConnection])
    {
        return;
    }
    NSString *_productId = [[NSString stringWithFormat:@"%@%@",STORE_SUBSCRIPTION_PREFIX, [NSString stringWithFormat:@"%d", months]] retain];
    
    [UIUtil showProcessIndicatorWithView:view atPoint:([UIUtil currentOrientation]==0)?CGPointMake(384, 512):CGPointMake(512, 384) hasMask:YES];
    
    [[KStoreManager sharedManager] buyFeature:_productId onComplete:^(NSString *productIdentifier_) {
        if(!_productId || ![_productId isEqualToString:productIdentifier_] || _productId.length<=STORE_SUBSCRIPTION_PREFIX.length)return;
        //NSString *goodId = [_productId substringFromIndex:STORE_SUBSCRIPTION_PREFIX.length];
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_PURCHASE_COMPLETED object:nil userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"subscribe", @"type",nil]];
    } onCancelled:^{
        [UIUtil hideProcessIndicatorWithView:view];
    }];
    
    return;
    
    [[KSAppStoreProxy shareProxy] purchase:[NSString stringWithFormat:@"%d", months] prefix:STORE_SUBSCRIPTION_PREFIX fromView:view onComplete:^(NSString *goodId){
        //[UIUtil hideProcessIndicatorWithView:view];
        //
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_PURCHASE_COMPLETED object:nil userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"subscribe", @"type",nil]];
    }];
}

+ (void)restorefromView:(UIView *)view {
    CGPoint centerPoint = view.center;
    if (view.width == 1024 && view.height==768)
        centerPoint = CGPointMake(512, 384);
    else if(view.height == 1024 && view.width==768)
        centerPoint = CGPointMake(384, 512);
    [UIUtil showProcessIndicatorWithView:view atPoint:centerPoint hasMask:YES];
    
    [[KStoreManager sharedManager] restorePreviousTransactionsOnComplete:^{
        [UIUtil showMsgAlertWithTitle:@"提示" message:@"成功恢复购买。"];
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_RESTORE_COMPLETED object:nil];
        [UIUtil hideProcessIndicatorWithView:view];
    } onError:^(NSError *err) {
        [UIUtil hideProcessIndicatorWithView:view];
        if (err.code != SKErrorPaymentCancelled) {
            [UIUtil showMsgAlertWithTitle:@"提示" message:[NSString stringWithFormat:@"恢复未成功:%@",err.localizedDescription] ];
        }
    }];
}
@end
