//
//  KSGetAllArticlesDownloader.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 2/1/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KSGetAllArticlesDownloader.h"

@implementation KSGetAllArticlesDownloader
@synthesize magzineId = _magzineId;


- (id) init:(NSInteger)magzineId{
    _zipFile = [[NSString stringWithFormat:@"%@/%d.zip", [KSBootstrap root], magzineId] retain];
//    if ([[NSFileManager defaultManager] fileExistsAtPath:_zipFile]) {
//        [[NSFileManager defaultManager] removeItemAtPath:_zipFile error:nil];
//    }
    _unpackDir = [[NSString stringWithFormat:@"%@/%d/", [KSBootstrap root],magzineId] retain];
    NSString *requestUrl = [NSString stringWithFormat:GET_AMAGZINE_URL, magzineId];
    if(self = [super init:requestUrl saveTo:_zipFile asyn:YES]){
        _magzineId = magzineId;
        self.onDownloadCompleted = ^(){
            [self onDownloadSuccess:self];
        };
        self.onDownloadFailed = ^(NSError *error){
            [self onDownloadFail:self];
        };
    }
    [[KSBootstrap dataCenter] setValue:INTEGER(1) forKey:STR_FORMAT(@"d_ma_%d", magzineId)];
    return self;
}

- (void) dealloc{
    [_zipFile release];
    [_unpackDir release];
    KSDINFO(@"%@", @"dealloc!");
    
    [super dealloc];
}

+ (BOOL)isDownloading:(NSInteger)magzineId{
    return [[KSBootstrap dataCenter] valueForKey:STR_FORMAT(@"d_ma_%d", magzineId)]!=nil;
}

- (void)saveArticleToDB:(NSInteger)articleId {
    NSInteger _articleId = articleId;
    KSModelArticle *oldArticle = [KSModelArticle loadById:_articleId withContent:NO];
    if(oldArticle.isDownload)return;
    NSString *jsonFile = STR_FORMAT(@"%@/magzineUnpack%d/%d/article.json", [KSBootstrap root], _magzineId, _articleId);
    NSData *jsonData = [NSData dataWithContentsOfFile:jsonFile];
    NSDictionary *dict = [[CJSONDeserializer deserializer] deserializeAsDictionary:jsonData error:nil];
    if(dict){
        NSString *sql = @"delete from article_header_blocks where article_id=?";
        [[KSDB db] executeUpdate:sql, INTEGER(_articleId)];
        sql = @"delete from article_images where article_id=?";
        [[KSDB db] executeUpdate:sql, INTEGER(_articleId)];
        NSDictionary *vblocks = [dict objectForKey:@"vblocks"];
        for (NSString *page in vblocks.keyEnumerator) {
            NSArray *blocks = [vblocks objectForKey:page];
            for (NSDictionary *block in blocks) {
                if(DICT_INTVAL(block, @"blocktype")==0){
                    //header
                    NSString *sql = @"insert into article_header_blocks(article_id, page, is_v, left, top, width, height, content, left_image, right_image) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    [[KSDB db] executeUpdate:sql, INTEGER(_articleId), page, INTEGER(1), DICT_VAL(block, @"left"), DICT_VAL(block, @"top"), DICT_VAL(block, @"width"), DICT_VAL(block, @"height"), DICT_VAL(block, @"content"), DICT_VAL(block, @"leftimage"), DICT_VAL(block, @"rightimage")];
                }else if(DICT_INTVAL(block, @"blocktype")==1){
                    NSString *sql = @"insert into article_images(article_id, page, is_v, left, top, width, height, image, title, link, controltype) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    [[KSDB db] executeUpdate:sql, INTEGER(_articleId), page, INTEGER(1), DICT_VAL(block, @"left"), DICT_VAL(block, @"top"), DICT_VAL(block, @"width"), DICT_VAL(block, @"height"), DICT_VAL(block, @"url"), DICT_VAL(block, @"title"), DICT_VAL(block, @"link"), DICT_VAL(block, @"controltype")];
                }
            }
        }
        NSDictionary *hblocks = [dict objectForKey:@"hblocks"];
        for (NSString *page in hblocks.keyEnumerator) {
            NSArray *blocks = [hblocks objectForKey:page];
            for (NSDictionary *block in blocks) {
                if(DICT_INTVAL(block, @"blocktype")==0){
                    //header
                    NSString *sql = @"insert into article_header_blocks(article_id, page, is_v, left, top, width, height, content, left_image, right_image) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    [[KSDB db] executeUpdate:sql, INTEGER(_articleId), page, INTEGER(0), DICT_VAL(block, @"left"), DICT_VAL(block, @"top"), DICT_VAL(block, @"width"), DICT_VAL(block, @"height"), DICT_VAL(block, @"content"), DICT_VAL(block, @"leftimage"), DICT_VAL(block, @"rightimage")];
                }else if(DICT_INTVAL(block, @"blocktype")==1){
                    NSString *sql = @"insert into article_images(article_id, page, is_v, left, top, width, height, image, title, link, controltype) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    [[KSDB db] executeUpdate:sql, INTEGER(_articleId), page, INTEGER(0), DICT_VAL(block, @"left"), DICT_VAL(block, @"top"), DICT_VAL(block, @"width"), DICT_VAL(block, @"height"), DICT_VAL(block, @"url"), DICT_VAL(block, @"title"), DICT_VAL(block, @"link"), DICT_VAL(block, @"controltype")];
                }
            }
        }
        //article_templates
        sql = @"delete from article_templates where article_id=?";
        [[KSDB db] executeUpdate:sql, INTEGER(_articleId)];
        NSArray * templates = [dict objectForKey:@"templates"];
        for (NSDictionary *template in templates) {
            NSString *sql = @"insert into article_templates(article_id, type, background, content) values(?, ?, ?, ?)";
            [[KSDB db] executeUpdate:sql, INTEGER(_articleId), DICT_VAL(template, @"type"), DICT_VAL(template, @"background"), DICT_VAL(template, @"content")];
        }
        // slideshow
        sql = @"delete from article_slideshow where article_id=?";
        [[KSDB db] executeUpdate:sql, INTEGER(_articleId)];
        NSArray * slideshows = [dict objectForKey:@"slideshow"];
        int iter = 0;
        for (NSDictionary *image in slideshows) {
            NSString *sql = @"insert into article_slideshow(article_id, hsrc, vsrc, title, link, ranking) values(?, ?, ?, ?, ?, ?)";
            iter++;
            [[KSDB db] executeUpdate:sql, INTEGER(_articleId), DICT_VAL(image, @"hsrc"), DICT_VAL(image, @"vsrc"), DICT_VAL(image, @"title"), DICT_VAL(image, @"link"), INTEGER(iter)];
        }
        //relations
        sql = @"delete from article_relations where id=?";
        [[KSDB db] executeUpdate:sql, INTEGER(_articleId)];
        NSArray * relations = [dict objectForKey:@"relations"];
        iter = 0;
        for (NSDictionary *dic in relations) {
            NSString *sql = @"insert into article_relations(id, relation_article_id, relation_article_resource, title, url, relation_article_type,relation_article_pubtime,relation_article_cover_title,stage_number,publish_time) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            iter++;
            [[KSDB db] executeUpdate:sql, INTEGER(_articleId), INTEGER([[dic objectForKey:@"relarticleid"] intValue]),[dic objectForKey:@"relartisource"],[dic objectForKey:@"relartititle"],[dic objectForKey:@"relartipuburl"],[dic objectForKey:@"relartitype"],[dic objectForKey:@"relartipubtime"],[dic objectForKey:@"covertitle"],[dic objectForKey:@"stagenumber"],[dic objectForKey:@"publishtime"]];
        }

        //childrens
        sql = @"delete from article_children where article_id=?";
        [[KSDB db] executeUpdate:sql, INTEGER(_articleId)];
        NSArray *childrens = [dict objectForKey:@"children"];
        iter = 0;
        for (NSDictionary *child in childrens) {
            NSString *sql = @"insert into article_children(article_id, child_id,ranking) values(?,?,?)";
            iter++;
            [[KSDB db] executeUpdate:sql, INTEGER(_articleId),child, INTEGER(iter)];
        }
        
        //
        
        [[KSDB db] executeUpdate:@"update articles set is_download=?, vcolumns=?, hcolumns=?, content_length=?, authors=?,mulu_pic_author=?, subtitle=?, summary=?, title=?, video_src=?,video2=?,video3=?, audio_src=?, is_html=?,arti_type=?, is_free=?, catalog_id=?, ranking=? where article_id=?", INTEGER(1), INTEGER(DICT_INTVAL(dict, @"vcolumns")), INTEGER(DICT_INTVAL(dict, @"hcolumns")), DICT_VAL(dict, @"contentlength"), DICT_VAL(dict, @"metadata.author"),DICT_VAL(dict, @"metadata.mulu_pic_author"), DICT_VAL(dict, @"metadata.subtitle"), DICT_VAL(dict, @"metadata.summary"), DICT_VAL(dict, @"metadata.title"), DICT_VAL(dict, @"metadata.video"),DICT_VAL(dict, @"metadata.video2"),DICT_VAL(dict, @"metadata.video3"), DICT_VAL(dict, @"metadata.audio"), [DICT_VAL(dict, @"metadata.type") isEqualToString:@"cortext"]?INTEGER(0):INTEGER(1),INTEGER(DICT_INTVAL(dict, @"metadata.artitype")), DICT_VAL(dict, @"metadata.isfree"), DICT_VAL(dict, @"metadata.categoryid"), DICT_VAL(dict, @"metadata.artiorder"), INTEGER(_articleId)];
        [[KSDB db] executeUpdate:@"update magzines set download_articles_num=download_articles_num+1 where magzine_id=?", INTEGER(_magzineId)];
    }
    //[KSBootstrap notify:NOTIFY_ARTICLE_DOWNLOADED data:[NSDictionary dictionaryWithObjectsAndKeys:INTEGER(_articleId), @"article_id", INTEGER(_magzineId), @"magzine_id", nil]];
    
}


- (void)saveCatalogToDB 
{
    [[KSDB db] executeUpdate:@"delete from catalogs where magzine_id=?", INTEGER(_magzineId)]; //默认先删除老数据，防止重复调用引起的问题

    NSString *jsonFile = STR_FORMAT(@"%@/magzineUnpack%d/catalog.json", [KSBootstrap root], _magzineId);
    NSData *jsonData = [NSData dataWithContentsOfFile:jsonFile];
    NSDictionary *dict = [[CJSONDeserializer deserializer] deserializeAsDictionary:jsonData error:nil];
    if(dict)
    {
        NSDictionary *categoryDic = [dict objectForKey:@"category"];
        if ([categoryDic isKindOfClass:[NSDictionary class]])
        {
            NSArray *keys = [categoryDic allKeys];
            for (int j = 0; j<[keys count]; j++)
            {
                NSString *key = [keys objectAtIndex:j];
                
                NSArray *catalogsArray = [categoryDic objectForKey:key];
                
                for (int i = 0; i<[catalogsArray count]; i++)
                {
                    NSDictionary *catalog = [catalogsArray objectAtIndex:i];
                    [[KSDB db] executeUpdate:@"insert into catalogs(magzine_id, catalog_id,catalogcolor_id, title, parent_id, ranking) values(?, ?, ?,?, ?, ?)", 
                     INTEGER(_magzineId),
                     INTEGER(DICT_INTVAL(catalog, @"id")),
                     [catalog  objectForKey:@"catecolor"],
                     [catalog objectForKey:@"title"],
                     INTEGER([key intValue]), 
                     INTEGER([[catalog objectForKey:@"cateorder"] intValue])
                     ];
                    
                }
                
            }

        }
        else 
        {
            NSArray *categoryArray = [dict objectForKey:@"category"];
            for (int j = 0; j<[categoryArray count]; j++)
            {
                NSArray *array = [categoryArray objectAtIndex:j];
                for (int i = 0; i<[array count]; i++)
                {
                    NSDictionary *catalog = [array objectAtIndex:i];
                    [[KSDB db] executeUpdate:@"insert into catalogs(magzine_id, catalog_id,catalogcolor_id, title, parent_id, ranking) values(?, ?, ?,?, ?, ?)", 
                     INTEGER(_magzineId),
                     INTEGER(DICT_INTVAL(catalog, @"id")),
                     [catalog  objectForKey:@"catecolor"],
                     [catalog objectForKey:@"title"],
                     INTEGER(0), 
                     INTEGER(DICT_INTVAL(catalog, @"0"))
                     ];
                    
                }
                
            }

        }
    }
}

- (void)saveMagazineToDB 
{
    
    NSString *jsonFile = STR_FORMAT(@"%@/magzineUnpack%d/magazine.json", [KSBootstrap root], _magzineId);
    NSData *jsonData = [NSData dataWithContentsOfFile:jsonFile];
    NSDictionary *dict = [[CJSONDeserializer deserializer] deserializeAsDictionary:jsonData error:nil];
    if(dict)
    {
        NSInteger articlesNum = DICT_INTVAL(dict, @"article_num");
        NSString *adPic = [[dict objectForKey:@"ad"] objectForKey:@"ad_pic"];
        NSString *adUrl = [[dict objectForKey:@"ad"] objectForKey:@"ad_url"];
        [[KSDB db] executeUpdate:@"update magzines set download_articles_num =?, articles_num=?,is_articles_download=1,rate_download='1', issue_number=?, stage_number=?, is_special_issue=?, custom_number=?, pub_date=?, cover_title=?, cover_summary=?, is_free=?, file_size=?,ad_pic=?,ad_url=? where magzine_id=?", 
         INTEGER(articlesNum),
         INTEGER(articlesNum),
         INTEGER(DICT_INTVAL(dict, @"issue_number")),
         INTEGER(DICT_INTVAL(dict, @"stage_number")), 
         INTEGER(DICT_INTVAL(dict, @"is_special_issue")),
         DICT_VAL(dict, @"custom_issue_number"),
         INTEGER(DICT_INTVAL(dict, @"publication_time")),
         DICT_VAL(dict, @"cover_title"),
         DICT_VAL(dict, @"cover_description"),
         INTEGER(DICT_INTVAL(dict, @"isfree")),
         DICT_VAL(dict, @"file_size"), 
         adPic,
         adUrl,
         INTEGER(_magzineId)];
        NSArray *articles = [dict objectForKey:@"articles"];
        NSString *sql = @"DELETE FROM articles WHERE magzine_id=?";
        [[KSDB db] executeUpdate:sql,INTEGER(DICT_INTVAL(dict, @"id"))];
        int iteration = 0;
        for (NSDictionary *articleDict in articles) {
            KSModelArticle *article = [KSModelArticle articleWith:articleDict];
            article.rankingInMagzine = iteration++;
            //if(![article insert])continue;
            [article insert];
            [self saveArticleToDB:article.articleId];
        }
    }
    [self saveCatalogToDB];
}

- (void)upgradeDB
{
    //更新数据库结构（每一份已下载杂志更新一下）
    //1.更新相关表结构
    NSString *sql = @"ALTER TABLE catalogs add column catalogcolor_id varchar(255) DEFAULT ''";
    [[KSDB db] executeUpdate:sql];
    sql = @"ALTER TABLE magzines add column ad_url varchar(255) DEFAULT ''";
    [[KSDB db] executeUpdate:sql];
    sql = @"ALTER TABLE magzines add column ad_pic varchar(255) DEFAULT ''";
    [[KSDB db] executeUpdate:sql];
    sql = @"ALTER TABLE subscribed add column  email varchar(255) DEFAULT ''";
    [[KSDB db] executeUpdate:sql];
    sql = @"ALTER TABLE articles add column catalogPicType NUMERIC";
    [[KSDB db] executeUpdate:sql];
    sql = @"ALTER TABLE articles add column catalogPicPath TEXT DEFAULT ''";
    [[KSDB db] executeUpdate:sql];
    sql = @"ALTER TABLE articles add column mulu_pic_author varchar(255) DEFAULT ''";
    [[KSDB db] executeUpdate:sql];            
    sql = @"select magzine_id from magzines where is_download=1";
    FMResultSet *rs = [[KSDB db] executeQuery:sql];
    while (rs.next) {
        NSDictionary *dict = rs.resultDict;
        _magzineId = DICT_INTVAL(dict, @"magzine_id");
        [self saveCatalogToDB]; //老版数据没有添加到catalogs表，重新添加数据
    }
    [rs close];   
}

- (void) onDownloadSuccess:(KSDownloader *)downloader{
    ZipArchive* za = [[ZipArchive alloc] init];
    if( [za UnzipOpenFile:_zipFile] ){
        BOOL ret = [za UnzipFileTo:_unpackDir overWrite:YES];
        if( NO==ret ){
			KSDERROR(@"unzip error.");
        }else{
			KSDINFO(@"unzip successfully.");
		}
        [za UnzipCloseFile];
    }
    [za release];
    NSFileManager *fileManager = [[NSFileManager alloc] init];
	if ([fileManager fileExistsAtPath:_zipFile]) {
		[fileManager removeItemAtPath:_zipFile error:nil];
	}
    NSString *renameToDir = [NSString stringWithFormat:@"%@/magzineUnpack%d", [KSBootstrap root], _magzineId];
	if ([fileManager fileExistsAtPath:renameToDir]) {
		[fileManager removeItemAtPath:renameToDir error:nil];
	}
    
    //[fileManager moveItemAtPath:[_unpackDir stringByAppendingFormat:@"/%d", _magzineId] toPath:renameToDir error:nil];
    [fileManager moveItemAtPath:_unpackDir toPath:renameToDir error:nil];
    [fileManager release];
    
    [self saveMagazineToDB];
    
    self.onDownloadFailed = self.onDownloadCompleted = self.onDownloadCancelled = nil;
    [[KSBootstrap dataCenter] removeObjectForKey:STR_FORMAT(@"d_ma_%d", _magzineId)];
    [[KSDB db] executeUpdate:@"update magzines set is_download=1,is_articles_download=1,rate_download=1 where magzine_id=?", INTEGER(_magzineId)];
    [KSBootstrap notify:NOTIFY_MAGZINE_DOWNLOADED data:[NSDictionary dictionaryWithObjectsAndKeys: INTEGER(_magzineId), @"magzine_id", nil]];
}

- (void) onDownloadFail:(KSDownloader *)downloader{
    //
    NSError *err = downloader.error;
    KSDERROR(@"%@", err);
    NSLog(@"%@", downloader.error);
    self.onDownloadFailed = self.onDownloadCompleted = self.onDownloadCancelled = nil;
    [[KSBootstrap dataCenter] removeObjectForKey:STR_FORMAT(@"d_ma_%d", _magzineId)];
}
- (void) start {
    if ([[NSFileManager defaultManager] fileExistsAtPath:_zipFile]) {
        [[NSFileManager defaultManager] moveItemAtPath:_zipFile toPath:[_zipFile stringByAppendingString:@".tmp"] error:nil];
    }
    [super start];
}
- (void)cancel {
    [super cancel];
    [self onDownloadCancel:self];
}

- (void) onDownloadCancel:(KSDownloader *)downloader{
    KSDINFO(@"%f",super.progressView.progress);
    [[KSDB db] executeUpdate:@"UPDATE magzines set rate_download=? where magzine_id=?",STR_FORMAT(@"%f",super.progressView.progress),INTEGER(_magzineId)];
    self.onDownloadFailed = self.onDownloadCompleted = self.onDownloadCancelled = nil;
    [[KSBootstrap dataCenter] removeObjectForKey:STR_FORMAT(@"d_ma_%d", _magzineId)];
}


@end
