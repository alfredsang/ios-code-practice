//
//  KSGetMagzineCoverDownloader.h
//  CenturyWeeklyV2
//
//  Created by liuyou on 12-1-11.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KSDownloader.h"

#define GET_MAGZINE_COVER_URL SERVER_URL_HOST@"/application/sysdata/ipadpic/%d/cover%d.jpg"

@interface KSGetMagzineCoverDownloader : KSDownloader<KSDownloaderDelegate>{
    NSString *_path;
    NSString *_saveFile;
    NSInteger _magzineId;
    NSInteger _cover;
}
- (id)init:(NSInteger)magzineId coverIndex:(NSInteger)cover;
+ (BOOL) isDownloading:(NSInteger)magzineId;
@end
