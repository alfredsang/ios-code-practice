//
//  KSDB.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-23.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSDB.h"


static FMDatabase *fmdb = nil;

@implementation KSDB


+ (id)db
{
    if (!fmdb) {
        fmdb = [[FMDatabase databaseWithPath:[KSDB dbFile]] retain];
        fmdb.logsErrors = YES;
    }
    if( fmdb.inUse){
        while (fmdb.inUse) {
            usleep(20);
        }
    }
    return fmdb;
}

+ (NSString *)dbFile{
    NSString *databaseFilepath = [[KSBootstrap root] stringByAppendingPathComponent:@"sqlite.db"];
    return databaseFilepath;
}

+ (NSString *)stringForKey:(NSString *)key {
    return [[KSDB db] stringForQuery:@"select keyvalue from key_value where keyname=?",key];
}
+ (void)saveString:(NSString *)str forKey:(NSString *)key {
    [[KSDB db] executeUpdate:@"delete from key_value where keyname=?", key];
    [[KSDB db] executeUpdate:@"insert into key_value values(?, ?)", key, str];
}


@end


