//
//  KSGlobalPaths.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 12/22/11.
//  Copyright (c) 2011 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 * @return YES if the URL begins with "bundle://"
 */
BOOL KSIsBundleURL(NSString* URL);

/**
 * @return YES if the URL begins with "documents://"
 */
BOOL KSIsDocumentsURL(NSString* URL);

/**
 * Used by KSPathForBundleResource to construct the bundle path.
 *
 * Retains the given bundle.
 *
 * @default nil (See KSGetDefaultBundle for what this means)
 */
void KSSetDefaultBundle(NSBundle* bundle);

/**
 * Retrieves the default bundle.
 *
 * If the default bundle is nil, returns [NSBundle mainBundle].
 *
 * @see KSSetDefaultBundle
 */
static NSBundle* KSGetDefaultBundle();

/**
 * @return The main bundle path concatenated with the given relative path.
 */
NSString* KSPathForBundleResource(NSString* relativePath);

/**
 * @return The documents path concatenated with the given relative path.
 */
NSString* KSPathForDocumentsResource(NSString* relativePath);


NSString* KSPathForCachesResource(NSString* relativePath);


