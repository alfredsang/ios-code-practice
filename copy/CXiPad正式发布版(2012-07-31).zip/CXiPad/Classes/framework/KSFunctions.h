//
//  KSFunctions.h
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-27.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>

UIColor* str2rgb(NSString *rgb);
UIFont* yahei(float size);
