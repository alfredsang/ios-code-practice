//
//  KSAppStoreProxy.h
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KStoreManager.h"

@interface KSAppStoreProxy : NSObject {
    NSString *_productIdentifer;
}
@property(nonatomic,retain)NSString *productIdentifer;

- (void)purchase:(NSString *)goodId prefix:(NSString *)prefix fromView:(UIView*)view onComplete:(void (^) (NSString*))complete;
- (void)caixinSavePurchased:(NSString*)productIdentifier;
- (void)caixinSaveSubscription:(NSDictionary *)receipt verifiedReceiptDictionary:(NSDictionary *)verifiedReceiptDictionary;
+ (KSAppStoreProxy *)shareProxy;
+ (void) buy:(KSModelMagzine *)magzine fromView:(UIView*)view;
+ (void) subscribe:(NSInteger)months fromView:(UIView*)view;

+ (void)caixinSavePurchased:(NSString*)productIdentifier;
+ (void)caixinSaveSubscription:(NSDictionary *)receipt verifiedReceiptDictionary:(NSDictionary *)verifiedReceiptDictionary;
+ (void)restorefromView:(UIView *)view;
@end
