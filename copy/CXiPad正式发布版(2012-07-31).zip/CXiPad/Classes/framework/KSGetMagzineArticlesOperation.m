//
//  KSGetMagzineArticlesOperation.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 12-1-1.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import "KSGetMagzineArticlesOperation.h"
#import "KSDownloadManager.h"
#import "KSGetArticleDownloader.h"

@implementation KSGetMagzineArticlesOperation
- (id) init:(NSInteger)magzineId{
    if(self = [super init]){
        _magzineId = magzineId;
    }
    return self;
}
- (void)dealloc{
    [super dealloc];
}
- (void)main{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
	if (![self isCancelled])
	{
        KSDownloadManager *dm = [KSDownloadManager sharedManager];
        [dm cancelWaiting];
        NSString *sql = @"select * from articles where is_download=0 and magzine_id=? order by rankin_in_magzine asc";
        FMResultSet *rs = [[KSDB db] executeQuery:sql, INTEGER(_magzineId)];
        while (rs.next) {
            NSDictionary *dict = rs.resultDict;
            KSGetArticleDownloader *dl = [[KSGetArticleDownloader alloc] init:DICT_INTVAL(dict, @"article_id") magzineId:_magzineId];
            [dm addDownloader:dl];
            [dl release];
        }
        [rs close];
	}
	
	[pool release];
    
}
@end
