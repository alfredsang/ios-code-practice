//
//  KSGetAllArticlesDownloader.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 2/1/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KSDownloader.h"
#import "KSDownloadManager.h"

#define GET_AMAGZINE_URL SURL_PREFIX(@"magazine", @"%d/true")
@interface KSGetAllArticlesDownloader : KSDownloader<KSDownloaderDelegate>{
    NSString *_zipFile;
    NSString *_unpackDir;
    NSInteger _magzineId;
}
@property(nonatomic,assign) NSInteger magzineId;
- (id)init:(NSInteger)magzineId;
+ (BOOL)isDownloading:(NSInteger)magzineId;
- (void)saveMagazineToDB;
- (void)upgradeDB; //for old version update
@end
