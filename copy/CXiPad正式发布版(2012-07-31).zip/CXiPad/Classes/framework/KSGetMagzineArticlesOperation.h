//
//  KSGetMagzineArticlesOperation.h
//  CenturyWeeklyV2
//
//  Created by liuyou on 12-1-1.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface KSGetMagzineArticlesOperation : NSOperation{
    NSInteger _magzineId;
}
- (id)init:(NSInteger)magzineId;
@end
