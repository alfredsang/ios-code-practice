//
//  KSDownloadManager.m
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSDownloadManager.h"

static KSDownloadManager *_singleton;
@implementation KSDownloadManager
- (id)init:(NSInteger)maxConcurrentCount{
    if(self = [super init]){
        _maxConcurrentCount = maxConcurrentCount;
        queue = [[NSMutableArray alloc] initWithCapacity:10];
        runningQueue = [[NSMutableArray alloc] initWithCapacity:_maxConcurrentCount];
    }
    return self;
}
- (void)dealloc{
    for (KSDownloader *item in queue) {
        [item cancel];
    }
    RELEASE_SAFELY(queue);
    RELEASE_SAFELY(runningQueue);
    [super dealloc];
}
+ (KSDownloadManager *)sharedManager{
    if(!_singleton){
        _singleton = [[KSDownloadManager alloc] init:1000];
    }
    return _singleton;
}
- (void) clearRunningDownloader:(KSDownloader *)downloader{
    [runningQueue removeObject:downloader];
//    downloader.delegate = nil;
    @synchronized(queue){
        _runningNumber--;
    }
    [self start];

}
-(void)onDownloadSuccess:(KSDownloader *)downloader{
    [self clearRunningDownloader:downloader];
}

- (void)onDownloadFail:(KSDownloader *)downloader{
    [self clearRunningDownloader:downloader];
}

- (void)onDownloadCancel:(KSDownloader *)downloader{
    [self clearRunningDownloader:downloader];
}

- (void)onDownloadStart:(KSDownloader *)downloader{
    @synchronized(queue){
        _runningNumber++;
    }
}

- (void)addDownloader:(KSDownloader *)downloader{
    @synchronized(queue){
        NSInteger count = [queue count];
        downloader.delegate = self;
        [queue insertObject:downloader atIndex:count];
    }
    [self start];
}

- (void) addDownloader:(KSDownloader *)downloader atIndex:(NSInteger)index{
    @synchronized(queue){
        downloader.delegate = self;
        [queue insertObject:downloader atIndex:index];
    }
    [self start];
}

- (void)start{
    if(_isSuspend)return;
    if(_runningNumber>=_maxConcurrentCount)return;
    if([queue count]==0)return;
    @synchronized(queue){
        if(_isSuspend)return;
        if(_runningNumber>=_maxConcurrentCount)return;
        if([queue count]==0)return;
        KSDownloader *downloader = [queue objectAtIndex:0];
        [runningQueue insertObject:downloader atIndex:0];
        [queue removeObjectAtIndex:0];
        [downloader start];
    }
    
}
- (void)suspend{
    _isSuspend = YES;
    @synchronized(queue){
        RELEASE_SAFELY(suspendQueue);
        suspendQueue = [runningQueue copy];
        for (KSDownloader *item in suspendQueue) {
            [item cancel];
        }
    }
}
- (void)resume{
    @synchronized(queue){
        [runningQueue removeAllObjects];
        runningQueue = [suspendQueue copy];
        for (KSDownloader *item in runningQueue) {
            [item start];
        }
        RELEASE_SAFELY(suspendQueue);
        _isSuspend = NO;
    }
    [self start];
}
- (void) cancelWaiting{
    _isSuspend = YES;
    @synchronized(queue){
        for (KSDownloader *item in queue) {
            [item cancel];
        }
        [queue removeAllObjects];
        _isSuspend = NO;
    }
}
@end
