//
//  KSGetMagzineListOperation.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-25.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSGetMagzineListOperation.h"

@implementation KSGetMagzineListDataRequest

- (NSString*)getRequestUrl{
    return GET_MAGZINE_LIST_URL;
}

- (void)processResult{
}

@end

@implementation KSGetMagzineListOperation
- (id)init{
    if(self = [super init]){
        self.queuePriority = NSOperationQueuePriorityHigh;
    }
    return self;
}
- (void) dealloc{
    //RELEASE_SAFELY(_request);
    [super dealloc];
}
- (void)requestDidFinished:(KSBaseDataRequest *)request{
    NSArray *magzines = [request.resultDict valueForKey:@"data"];
    BOOL hasNewMagzine = NO;
    FMResultSet *rs = [[KSDB db] executeQuery:@"select magzine_id, is_download from magzines"];
    NSMutableDictionary *magzineDownStatus = [NSMutableDictionary dictionaryWithCapacity:10];
    while (rs.next) {
        NSDictionary *row = rs.resultDict;
        [magzineDownStatus setValue:INTEGER(DICT_INTVAL(row, @"is_download")) forKey:DICT_VAL(row, @"magzine_id")];
    }
    if (magzines && [magzines isKindOfClass:[NSArray class]])
    for (NSDictionary *magzine in magzines) {
        NSString *strMagzineId = DICT_VAL(magzine, @"id");
        NSNumber *downStatus = [magzineDownStatus valueForKey:strMagzineId];
        if(downStatus!=nil)continue;
        NSInteger magzineId = [strMagzineId intValue];
        KSModelMagzine *modelMagzine = [KSModelMagzine magzineWith:magzine];
        if (modelMagzine.status==1)
        {
            if(![modelMagzine insert])
                continue;
        }
        else {
            continue;
        }

        hasNewMagzine = YES;
        NSArray *coverArticles = [magzine valueForKey:@"coverarticles"];
        for (int i=0, n=[coverArticles count]; i<n; i++) {
            NSDictionary *coverArticle = [coverArticles objectAtIndex:i];
            KSModelMagzineCoverArticle *modelCoverArticle = [KSModelMagzineCoverArticle magzineCoverArticleWith:coverArticle magzineId:magzineId];
            modelCoverArticle.ranking = i;
            [modelCoverArticle insert];
        }
    }
    NSArray *array = [[KSBootstrap dataCenter] valueForKey:@"KEY_PURCHASED_MAGAZINES"];
    if (array) {
        for (NSNumber *n in array) {
            [[KSDB db] executeUpdate:@"update magzines set is_purchased=1 where magzine_id=?", n];
        }
        [[KSBootstrap dataCenter] removeObjectForKey:@"KEY_PURCHASED_MAGAZINES"];
        [KSBootstrap notify:NOTIFY_MAGZINE_LIST_UPDATED data:nil];
        hasNewMagzine = NO;
    }
    if(hasNewMagzine){
        [KSBootstrap notify:NOTIFY_MAGZINE_LIST_UPDATED data:nil];
    }

}
- (void)requestDidFailed:(KSBaseDataRequest *)request withError:(NSError*)error{
    NSLog(@"%@", error);
}
- (void)main{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
	if (![self isCancelled])
	{
        _request = [KSGetMagzineListDataRequest requestWithDelegate:self];
	}
	
	[pool release];

}
@end
