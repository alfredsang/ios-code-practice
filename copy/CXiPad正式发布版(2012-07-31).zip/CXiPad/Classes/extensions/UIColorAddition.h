//
//  UIColorAddition.h
//  CenturyWeeklyV2
//
//  Created by 广亮 高 on 12-7-2.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>

#define COLOR_1    str2rgb(@"#396C9F")
#define COLOR_2    str2rgb(@"#8957A1")
#define COLOR_3    str2rgb(@"#C4DC00")
#define COLOR_4    str2rgb(@"#638C0B")
#define COLOR_5    str2rgb(@"#6A3906")
#define COLOR_6    str2rgb(@"#CFF0FF")
#define COLOR_7    str2rgb(@"#F49800")
#define COLOR_8    str2rgb(@"#0075A9")
#define COLOR_9    str2rgb(@"#FCB217")
#define COLOR_10    str2rgb(@"#7ECEF4")
#define COLOR_11    str2rgb(@"#B38850")
#define COLOR_12    str2rgb(@"#ED6941")
#define COLOR_13    str2rgb(@"#100964")
#define COLOR_14    str2rgb(@"#A40000")
#define COLOR_15    str2rgb(@"#000000")
#define COLOR_16    str2rgb(@"#EC6877")
#define COLOR_17    str2rgb(@"#601986")
#define COLOR_18    str2rgb(@"#005752")
#define COLOR_19    str2rgb(@"#B7AB00")
#define COLOR_20    str2rgb(@"#FFF100")

#define COLOR_BACKGROUND    str2rgb(@"#eeeeee")

@interface UIColor(UIColorAddition)

+(UIColor*)leftColor:(NSInteger)colorType;
@end
