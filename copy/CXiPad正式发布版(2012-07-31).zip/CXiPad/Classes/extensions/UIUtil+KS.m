//
//  UIUtil+KS.m
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-27.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import <QuartzCore/QuartzCore.h>
#import "UIUtil+KS.h"

typedef enum{
	kTagImageMaskView = 10000,
	kTagCommonMaskView,
	kTagCommonIndicatorView,
	kTagCommonMaskView2,
} MaskViewTag;

@implementation UIUtil
@end

@implementation UIUtil (KS)
+ (NSInteger) currentOrientation{
//    NSInteger val = [[UIApplication sharedApplication] statusBarOrientation];
//    return (val==UIInterfaceOrientationPortrait || val==UIInterfaceOrientationPortraitUpsideDown)?0:1;
    KSDataCenter *dataCenter = [KSBootstrap dataCenter];
    return [[dataCenter valueForKey:@"orientation"] intValue];
}
+ (void)setOrientation:(UIInterfaceOrientation)orientation {
    NSInteger o = UIInterfaceOrientationIsPortrait(orientation)?0:1;
    [[KSBootstrap dataCenter] setValue:[NSNumber numberWithInt:o] forKey:@"orientation"];
}
+ (void)animatedShakeView:(UIView *)view repeat:(NSInteger)count duration:(NSTimeInterval)duration {
    [UIView beginAnimations:@"rotate" context:nil];
    [UIView setAnimationRepeatAutoreverses:YES];
    [UIView setAnimationRepeatCount:count];
    [UIView setAnimationDuration:duration];
    
    view.transform = CGAffineTransformMakeRotation(2 * M_PI / 180);
    view.transform = CGAffineTransformMakeRotation(-2 * M_PI / 180);
    //self.transform = CGAffineTransformMakeRotation(0 * M_PI / 180);
    [UIView commitAnimations];
}

+ (void)animatedShowView:(UIView *)view duration:(NSTimeInterval)duration {
    [self animatedShowView:view duration:duration alpha:1];
}
+ (void)animatedShowView:(UIView *)view duration:(NSTimeInterval)duration alpha:(CGFloat)alpha {
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:duration];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    view.alpha = alpha;
    [UIView commitAnimations];
}
+ (void)animatedShowAndHideView:(UIView *)view duration:(NSTimeInterval)duration waitDuration:(NSTimeInterval)waitDuration {
    [self animatedShowView:view duration:duration];
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:duration];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDelay:waitDuration];
    view.alpha = 0;
    [UIView commitAnimations];
}
+ (void)animatedHideView:(UIView *)view duration:(NSTimeInterval)duration {
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:duration];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    view.alpha = 0;
    [UIView commitAnimations];
}
+ (void)animatedHideAndShowView:(UIView *)view duration:(NSTimeInterval)duration waitDuration:(NSTimeInterval)waitDuration {
    [self animatedHideView:view duration:duration];
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:duration];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDelay:waitDuration];
    view.alpha = 1;
    [UIView commitAnimations];
}
+ (void)animatedMoveView:(UIView *)view duration:(NSTimeInterval)duration newFrame:(CGRect)newFrame {
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:duration];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    view.frame = newFrame;
    [UIView commitAnimations];
}
+ (void)animatedWinkView:(UIView *)view duration:(NSTimeInterval)duration {
    view.alpha = 0;    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:duration];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationRepeatCount:1000];
    [UIView setAnimationRepeatAutoreverses:YES];
    view.alpha = 1;
    [UIView commitAnimations];
}
+ (void)addAnimationPop:(UIView *)viewToAddAnimation {
    [viewToAddAnimation setTransform:CGAffineTransformMakeScale(0.1,0.1)];
    [UIView animateWithDuration:0.5 animations:^{
        [viewToAddAnimation setTransform:CGAffineTransformMakeScale(1,1)];
    }];
}


+ (void)addAnimationShow:(UIView *)viewToAddAnimation{
	viewToAddAnimation.alpha = 0;
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.5];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
	viewToAddAnimation.alpha = 1;
	[UIView commitAnimations];
}

+ (void)addAnimationFade:(UIView *)viewToAddAnimation{
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.5];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
	viewToAddAnimation.alpha = 0;
	[UIView commitAnimations];
}

+ (void)addAnimationClick:(UIView *)viewToAddAnimation{
	viewToAddAnimation.alpha = 0;
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.2];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
	viewToAddAnimation.alpha = 1;
	[UIView commitAnimations];
}

+ (void)addAnimationSlideUp2:(UIView *)viewToAddAnimation{
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.5];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
	viewToAddAnimation.center = CGPointMake(viewToAddAnimation.center.x, viewToAddAnimation.center.y-viewToAddAnimation.frame.size.height*2);
	[UIView commitAnimations];
}

+ (void)addAnimationSlideDown2:(UIView *)viewToAddAnimation{
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.5];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
	viewToAddAnimation.center = CGPointMake(viewToAddAnimation.center.x, viewToAddAnimation.center.y+viewToAddAnimation.frame.size.height*2);
	[UIView commitAnimations];
}

+ (void)addAnimationSlideUp:(UIView *)viewToAddAnimation{
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.5];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
	viewToAddAnimation.center = CGPointMake(viewToAddAnimation.center.x, viewToAddAnimation.center.y-viewToAddAnimation.frame.size.height);
	[UIView commitAnimations];
}

+ (void)addAnimationSlideDown:(UIView *)viewToAddAnimation{
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.5];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
	viewToAddAnimation.center = CGPointMake(viewToAddAnimation.center.x, viewToAddAnimation.center.y+viewToAddAnimation.frame.size.height);
	[UIView commitAnimations];
}

+ (void)addAnimationSlideLeft:(UIView *)viewToAddAnimation{
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.5];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
	viewToAddAnimation.center = CGPointMake(viewToAddAnimation.center.x-viewToAddAnimation.frame.size.width, viewToAddAnimation.center.y);
	[UIView commitAnimations];
}

+ (void)addAnimationSlideRight:(UIView *)viewToAddAnimation{
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.5];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
	viewToAddAnimation.center = CGPointMake(viewToAddAnimation.center.x+viewToAddAnimation.frame.size.width, viewToAddAnimation.center.y);
	[UIView commitAnimations];
}

+ (void)addAnimationWaveShake:(UIView *)viewToAddAnimation {
    CAKeyframeAnimation *animation = [CAKeyframeAnimation
                                      animationWithKeyPath:@"transform"];
    
    CATransform3D scale1 = CATransform3DMakeScale(0.5, 0.5, 1);
    CATransform3D scale2 = CATransform3DMakeScale(1.2, 1.2, 1);
    CATransform3D scale3 = CATransform3DMakeScale(0.9, 0.9, 1);
    CATransform3D scale4 = CATransform3DMakeScale(1.0, 1.0, 1);
    
    NSArray *frameValues = [NSArray arrayWithObjects:
                            [NSValue valueWithCATransform3D:scale1],
                            [NSValue valueWithCATransform3D:scale2],
                            [NSValue valueWithCATransform3D:scale3],
                            [NSValue valueWithCATransform3D:scale4],
                            nil];
    [animation setValues:frameValues];
    
    NSArray *frameTimes = [NSArray arrayWithObjects:
                           [NSNumber numberWithFloat:0.0],
                           [NSNumber numberWithFloat:0.5],
                           [NSNumber numberWithFloat:0.9],
                           [NSNumber numberWithFloat:1.0],
                           nil];    
    [animation setKeyTimes:frameTimes];
    
    animation.fillMode = kCAFillModeForwards;
    animation.removedOnCompletion = NO;
    animation.duration = .2;
    
    [viewToAddAnimation.layer addAnimation:animation forKey:@"popup"];
}

+ (UIImage *)snapshotScreen {
    // Create a graphics context with the target size
    // On iOS 4 and later, use UIGraphicsBeginImageContextWithOptions to take the scale into consideration
    // On iOS prior to 4, fall back to use UIGraphicsBeginImageContext
    CGSize imageSize = [[UIScreen mainScreen] bounds].size;
    if (NULL != UIGraphicsBeginImageContextWithOptions)
        UIGraphicsBeginImageContextWithOptions(imageSize, YES, 0);
    else
        UIGraphicsBeginImageContext(imageSize);
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    // Iterate over every window from back to front
    for (UIWindow *window in [[UIApplication sharedApplication] windows]) 
    {
        if (![window respondsToSelector:@selector(screen)] || [window screen] == [UIScreen mainScreen])
        {
            // -renderInContext: renders in the coordinate space of the layer,
            // so we must first apply the layer's geometry to the graphics context
            CGContextSaveGState(context);
            // Center the context around the window's anchor point
            CGContextTranslateCTM(context, [window center].x, [window center].y);
            // Apply the window's transform about the anchor point
            CGContextConcatCTM(context, [window transform]);
            // Offset by the portion of the bounds left of and above the anchor point
            CGContextTranslateCTM(context,
                                  -[window bounds].size.width * [[window layer] anchorPoint].x,
                                  -[window bounds].size.height * [[window layer] anchorPoint].y);
            
            // Render the layer hierarchy to the current context
            [[window layer] renderInContext:context];
            
            // Restore the context
            CGContextRestoreGState(context);
        }
    }
    
    // Retrieve the screenshot image
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    return image;
}

+ (UIImage *)snapshotView:(UIView *)shotView {
    UIGraphicsBeginImageContext(shotView.bounds.size);
    [shotView.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}


+ (void)saveImageToPhotoAlbum:(UIImage *)image {
    UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil);
}
+(BOOL)checkInternetConnection
{
    if (([Reachability reachabilityForInternetConnection].currentReachabilityStatus == NotReachable) &&
        ([Reachability reachabilityForLocalWiFi].currentReachabilityStatus == NotReachable))
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"无法连接到网络" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alert show];
        [alert release];
        return NO;
    }
    return YES;
}

#pragma mark - UI Elements/Components Factory
+ (UIButton *)newTextButtonWithFrame:(CGRect)frame
                               title:(NSString *)title 
                          titleColor:(UIColor *)titleColor
                         tappedColor:(UIColor *)tappedColor
                                font:(UIFont *)font
                              target:(id)target 
                              action:(SEL)selector{
	UIButton *button = [[UIButton alloc] initWithFrame:frame];
	button.backgroundColor = [UIColor clearColor];
	[button setTitle:title forState:UIControlStateNormal];
	[button setTitleColor:titleColor forState:UIControlStateNormal];
	[button setTitleColor:tappedColor forState:UIControlStateHighlighted];
	button.titleLabel.font = font;
	[button addTarget:target action:selector forControlEvents:UIControlEventTouchUpInside];
	return button;
}
+ (UIButton *)createImageButtonWithFrame:(CGRect)frame 
                                   image:(UIImage *)image 
                                  target:(id)target 
                                  action:(SEL)selector{
    UIButton *button = [[UIButton alloc] initWithFrame:frame];
	button.backgroundColor = [UIColor clearColor];
	[button setImage:image forState:UIControlStateNormal];
	[button setImage:image forState:UIControlStateHighlighted];
	[button addTarget:target action:selector forControlEvents:UIControlEventTouchUpInside];
//    button.layer.borderColor = [UIColor redColor].CGColor;
//    button.layer.borderWidth = 1;
	return button;
}
+ (UIButton *)newImageButtonWithFrame:(CGRect)frame
								image:(UIImage *)image{
	UIButton *button = [[UIButton alloc] initWithFrame:frame];
	button.backgroundColor = [UIColor clearColor];
	[button setBackgroundImage:image forState:UIControlStateNormal];
	return button;
}

+ (UIButton *)newImageButtonWithFrame:(CGRect)frame
								image:(UIImage *)image
							   target:(id)target 
							   action:(SEL)selector{
    return [UIUtil newImageButtonWithFrame:frame image:image tappedImage:image target:target action:selector];
}

+ (UIButton *)newImageSwitchButtonWithFrame:(CGRect)frame
								image:(UIImage *)image
						  tappedImage:(UIImage *)tappedImage
							   target:(id)target 
							   action:(SEL)selector{
	UIButton *button = [[UIButton alloc] initWithFrame:frame];
	button.backgroundColor = [UIColor clearColor];
	[button setBackgroundImage:image forState:UIControlStateNormal];
	[button setBackgroundImage:tappedImage forState:UIControlStateHighlighted];
	[button addTarget:target action:selector forControlEvents:UIControlEventTouchUpInside];
    
	return button;
}

+ (UIButton *)newImageButtonWithFrame:(CGRect)frame
								image:(UIImage *)image
						  tappedImage:(UIImage *)tappedImage
							   target:(id)target 
							   action:(SEL)selector{
	UIButton *button = [[UIButton alloc] initWithFrame:frame];
	button.backgroundColor = [UIColor clearColor];
	[button setBackgroundImage:image forState:UIControlStateNormal];
	[button setBackgroundImage:tappedImage forState:UIControlStateHighlighted];
	[button addTarget:target action:selector forControlEvents:UIControlEventTouchUpInside];
	return button;
}

+ (UIButton *)newActionButtonWithFrame:(CGRect)frame
                                 title:(NSString *)title 
                            titleColor:(UIColor *)titleColor
                           tappedColor:(UIColor *)tappedColor
                                  font:(UIFont *)font
                                target:(id)target 
                                action:(SEL)selector{
	UIButton *button = [[UIButton alloc] initWithFrame:frame];
	button.backgroundColor = [UIColor clearColor];
	[button setTitle:title forState:UIControlStateNormal];
	[button setTitleColor:titleColor forState:UIControlStateNormal];
	[button setTitleColor:tappedColor forState:UIControlStateHighlighted];
	button.titleLabel.font = font;
	[button addTarget:target action:selector forControlEvents:UIControlEventTouchUpInside];
	[button setBackgroundImage:[[UIImage imageNamed:@"btnLogin.png"] stretchableImageWithLeftCapWidth:10 topCapHeight:0] forState:UIControlStateNormal];
	[button setBackgroundImage:[[UIImage imageNamed:@"btnLogin.png"] stretchableImageWithLeftCapWidth:10 topCapHeight:0] forState:UIControlStateHighlighted];
	
	return button;
}

+ (UILabel *)newLabelWithFrame:(CGRect)frame
                          text:(NSString *)text
                     textColor:(UIColor *)textColor
                          font:(UIFont *)font{
    UILabel *label = [[UILabel alloc] initWithFrame:frame];
	label.text = text;
	label.textColor = textColor;
	label.backgroundColor = [UIColor clearColor];
	label.textAlignment = UITextAlignmentLeft;
	label.font = font;
    return label;
}

+ (UITextField *)newTextFieldWithFrame:(CGRect)frame
                           borderStyle:(UITextBorderStyle)borderStyle
                             textColor:(UIColor *)textColor
                       backgroundColor:(UIColor *)backgroundColor
                                  font:(UIFont *)font
                          keyboardType:(UIKeyboardType)keyboardType{
	UITextField *textField = [[UITextField alloc] initWithFrame:frame];
	textField.borderStyle = borderStyle;
	textField.textColor = textColor;
	textField.font = font;
	textField.backgroundColor = backgroundColor;
	textField.keyboardType = keyboardType;
	
	textField.returnKeyType = UIReturnKeyDefault;
	textField.clearButtonMode = UITextFieldViewModeWhileEditing;
	textField.leftViewMode = UITextFieldViewModeNever;
	textField.autocorrectionType = UITextAutocorrectionTypeNo;
	textField.autocapitalizationType = UITextAutocapitalizationTypeNone;
	
	UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"icon_textField_red.png"]];
	textField.leftView = imageView;
	[imageView release];
	
	return textField;
}

+ (void)showMsgAlertWithTitle:(NSString *)title message:(NSString *)msg{
	UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title message:msg delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
	[alertView show];
	[alertView release];
}

+ (void)showProcessIndicator:(UIView *)imgView{
	UIView *maskView = [[UIView alloc] initWithFrame:imgView.bounds];
    maskView.tag = kTagCommonMaskView;
	maskView.backgroundColor = [UIColor clearColor];  //[UIColor colorWithWhite:0 alpha:0.7];
	//maskView.tag = kTagImageMaskView;
	[imgView addSubview:maskView];
	[maskView release];
	UIActivityIndicatorView *indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
	indicator.center = maskView.center;
	[maskView addSubview:indicator];
	[indicator release];
	[indicator startAnimating];
}
+ (void)showFadeInAnimation:(UIView*)view endAlpha:(CGFloat)alpha
{
    view.alpha = 0;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3f];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    view.alpha = alpha;
    [UIView commitAnimations];
}
+ (void)showProcessIndicatorWithView:(UIView *)view atPoint:(CGPoint)point hasMask:(BOOL)hasMask{
	if( hasMask ){
		UIView *maskView = [[UIView alloc] initWithFrame:view.bounds];
		maskView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
		maskView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
		maskView.tag = kTagCommonMaskView;
		[view addSubview:maskView];
		[maskView release];
	}
	UIActivityIndicatorView *indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
	indicator.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin|UIViewAutoresizingFlexibleRightMargin|UIViewAutoresizingFlexibleTopMargin|UIViewAutoresizingFlexibleBottomMargin;
	indicator.center = point;
	indicator.tag = kTagCommonIndicatorView;
	[view addSubview:indicator];
	[indicator release];
	[indicator startAnimating];
}

+ (void)hideProcessIndicatorWithView:(UIView *)view{
	UIView *maskView = [view viewWithTag:kTagCommonMaskView];
	if( maskView != nil ){
		[maskView removeFromSuperview];
	}
	UIView *indicator = [view viewWithTag:kTagCommonIndicatorView];
	if( indicator != nil ){
		[indicator removeFromSuperview];
	}
}

+ (void)showGlobalMask{
	UIWindow *window = [UIApplication sharedApplication].keyWindow;
	UIView *maskView = [[UIView alloc] initWithFrame:window.bounds];
	maskView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
	maskView.tag = kTagCommonMaskView2;
	[window addSubview:maskView];
	[maskView release];
}

+ (void)hideGlobalMask{
	UIWindow *window = [UIApplication sharedApplication].keyWindow;
	UIView *maskView = [window viewWithTag:kTagCommonMaskView2];
	if( maskView != nil ){
		[maskView removeFromSuperview];
	}
}

+ (void)roundCenter:(UIView *)view{
	view.center = CGPointMake(round(view.center.x), round(view.center.y));
}

#pragma mark - image downloader
+ (void)imageWithUrl:(NSString *)imgUrl toView:(UIView *)view {
    [self imageWithUrl:imgUrl toView:view shouldResize:NO];
}
+ (void)imageWithUrl:(NSString *)imgUrl toView:(UIView *)view resize:(CGSize)size {
    if (imgUrl == nil || view == nil) {
        return;
    }
    NSOperationQueue *operationQueue = [[[NSOperationQueue alloc] init] autorelease];
    ImageDataOperation *imgDataOperation = [[ImageDataOperation alloc] initWithURL:imgUrl view:view resize:size];
    [operationQueue addOperation:imgDataOperation];
    [imgDataOperation release];
}
+ (void)imageWithUrl:(NSString *)imgUrl toView:(UIView *)view shouldResize:(BOOL)shouldResize {
    if (imgUrl == nil || view == nil) {
        return;
    }
    NSOperationQueue *operationQueue = [[[NSOperationQueue alloc] init] autorelease];
    ImageDataOperation *imgDataOperation = [[ImageDataOperation alloc] initWithURL:imgUrl view:view shouldResize:shouldResize];
    [operationQueue addOperation:imgDataOperation];
    [imgDataOperation release];
}


@end



///////////////////////////////////////////////////////////////////////
// 远程异步下载图片
//
///////////////////////////////////////////////////////////////////////
@implementation ImageDataOperation                                                                                            

- (id)initWithURL:(NSString *)url view:(UIView *)view{
    self = [super init];
	if (self) {
		imageUrl = [url retain];
		imgView = [view retain];
        shouldResize = NO;
	}
	return self;
}
- (id)initWithURL:(NSString *)url view:(UIView *)view resize:(CGSize)size{
    self = [super init];
	if (self) {
		imageUrl = [url retain];
		imgView = [view retain];
        newSize = size;
        shouldResize = YES;
	}
	return self;
}
- (id)initWithURL:(NSString *)url view:(UIView *)view shouldResize:(BOOL)resize{
    self = [self initWithURL:url view:view];
    if (self) {
        shouldResize = resize;
        if (shouldResize) {
            newSize = CGSizeMake(view.frame.size.width, view.frame.size.height);
            IF_IOS4_OR_GREATER( newSize = CGSizeMake(view.frame.size.width*2, view.frame.size.height*2););
        }
    }
    return self;
}
- (void)main {
	NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
	[(NSObject *)[UIUtil class] performSelectorOnMainThread:@selector(showProcessIndicator:) withObject:imgView waitUntilDone:YES];	
    
	//UIImage *image = (UIImage *)[[DataEnv sharedDataEnv].imageCacheDict objectForKey:imageUrl];
    UIImage *image = [UIImage imageWithContentsOfFile:[DataUtil urlToPah:imageUrl]];
	if( !image ){
        NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:imageUrl]];
        image = [UIImage imageWithData:data];
		if (image) {
			//[[DataEnv sharedDataEnv].imageCacheDict setObject:image forKey:imageUrl];
            //[DataUtil saveImageToDisk:image fullPath:[DataUtil urlToPah:imageUrl]];
            //创建目录
            NSString *fullpath = [DataUtil urlToPah:imageUrl];
            NSString *directory = [fullpath substringToIndex:(int)([fullpath rangeOfString:@"/" options:NSBackwardsSearch].location) ];
            NSFileManager *fileManager = [NSFileManager defaultManager];
            if (![fileManager fileExistsAtPath:directory]) {
                [fileManager createDirectoryAtPath:directory withIntermediateDirectories:YES attributes:nil error:nil];
            }
            //保存数据
            [data writeToFile:fullpath atomically:YES];
		}
	}
    if (shouldResize) {
        NSString *thumbPath = [DataUtil urlToPah:imageUrl size:newSize];
        UIImage *thumb = [UIImage imageWithContentsOfFile:thumbPath];
        if (!thumb) {
            thumb = [image cropCenterAndScaleToSize:newSize];
            [DataUtil saveImageToDisk:thumb fullPath:thumbPath];
        }
        image = thumb;
    }
	if( [imgView isKindOfClass:[UIButton class]] ){
		UIButton *imgBtn = (UIButton *)imgView;
		if (image) {
			[imgBtn setBackgroundImage:image forState:UIControlStateNormal];
			[imgBtn setBackgroundImage:image forState:UIControlStateHighlighted];
		}
	}else if ([imgView isKindOfClass:[UIImageView class]]) {
		UIImageView *iView = (UIImageView *)imgView;
		iView.image = image;
	}
	[(NSObject *)[UIUtil class] performSelectorOnMainThread:@selector(hideProcessIndicatorWithView:) withObject:imgView waitUntilDone:YES];
	[pool release];
}
- (void)dealloc {
	[imgView release];
	[imageUrl release];
	[super dealloc];
}

@end


