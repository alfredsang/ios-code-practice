//
//  NSObjectAdditons.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 12/30/11.
//  Copyright (c) 2011 KSMobile. All rights reserved.
//

#import "NSObjectAdditons.h"

@implementation NSObjectAdditons

@end

@implementation NSNull (KS)
- (int)intValue {
    return 0;
}
- (int)length {
    return 0;
}
- (NSString *)stringValue {
    return nil;
}
- (void)removeFromSuperview {
    
}
@end