//
//  UIColorAddition.m
//  CenturyWeeklyV2
//
//  Created by 广亮 高 on 12-7-2.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import "UIColorAddition.h"

@implementation UIColor(UIColorAddition)
+(UIColor*)leftColor:(NSInteger)colorType
{
    switch (colorType)
    {
        case 1:
            return COLOR_1;
            break;
        case 2:
            return COLOR_2;
            break;
        case 3:
            return COLOR_3;
            break;
        case 4:
            return COLOR_4;
            break;
        case 5:
            return COLOR_5;
            break;
        case 6:
            return COLOR_6;
            break;
        case 7:
            return COLOR_7;
            break;
        case 8:
            return COLOR_8;
            break;
        case 9:
            return COLOR_9;
            break;
        case 10:
            return COLOR_10;
            break;
        case 11:
            return COLOR_11;
            break;
        case 12:
            return COLOR_12;
            break;
        case 13:
            return COLOR_13;
            break;
        case 14:
            return COLOR_14;
            break;
        case 15:
            return COLOR_15;
            break;
        case 16:
            return COLOR_16;
            break;
        case 17:
            return COLOR_17;
            break;
        case 18:
            return COLOR_18;
            break;
        case 19:
            return COLOR_19;
            break;
        case 20:
            return COLOR_20;
            break;
        default:
            return nil;
            break;
    }
}

@end
