//
//  UIUtil+KS.h
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-27.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//
#import <Foundation/Foundation.h>

@interface UIUtil : NSObject
@end

@interface UIUtil (KS)
+ (NSInteger) currentOrientation;
+ (void)setOrientation:(UIInterfaceOrientation)orientation;

+ (void)animatedShakeView:(UIView *)view repeat:(NSInteger)count duration:(NSTimeInterval)duration;
+ (void)animatedShowView:(UIView *)view duration:(NSTimeInterval)duration;
+ (void)animatedShowView:(UIView *)view duration:(NSTimeInterval)duration alpha:(CGFloat)alpha;
+ (void)animatedShowAndHideView:(UIView *)view duration:(NSTimeInterval)duration waitDuration:(NSTimeInterval)waitDuration;
+ (void)animatedHideView:(UIView *)view duration:(NSTimeInterval)duration;
+ (void)animatedHideAndShowView:(UIView *)view duration:(NSTimeInterval)duration waitDuration:(NSTimeInterval)waitDuration;
+ (void)animatedMoveView:(UIView *)view duration:(NSTimeInterval)duration newFrame:(CGRect)newFrame;
+ (void)animatedWinkView:(UIView *)view duration:(NSTimeInterval)duration;
+ (void)addAnimationPop:(UIView *)viewToAddAnimation;

+ (void)addAnimationShow:(UIView *)viewToAddAnimation;
+ (void)addAnimationFade:(UIView *)viewToAddAnimation;
+ (void)addAnimationClick:(UIView *)viewToAddAnimation;
+ (void)addAnimationSlideUp2:(UIView *)viewToAddAnimation;   //上移高度两倍
+ (void)addAnimationSlideDown2:(UIView *)viewToAddAnimation; //下移高度两倍
+ (void)addAnimationSlideUp:(UIView *)viewToAddAnimation;
+ (void)addAnimationSlideDown:(UIView *)viewToAddAnimation;
+ (void)addAnimationSlideLeft:(UIView *)viewToAddAnimation;
+ (void)addAnimationSlideRight:(UIView *)viewToAddAnimation;

+ (void)addAnimationWaveShake:(UIView *)viewToAddAnimation;
+ (UIImage *)snapshotScreen;
+(BOOL)checkInternetConnection;
+ (UIImage *)snapshotView:(UIView *)shotView;
+ (void)saveImageToPhotoAlbum:(UIImage *)image;
+ (UIButton *)newTextButtonWithFrame:(CGRect)frame
                               title:(NSString *)title 
                          titleColor:(UIColor *)titleColor
                         tappedColor:(UIColor *)tappedColor
                                font:(UIFont *)font
                              target:(id)target 
                              action:(SEL)selector;

+ (UIButton *)newImageButtonWithFrame:(CGRect)frame
								image:(UIImage *)image;
+ (UIButton *)createImageButtonWithFrame:(CGRect)frame 
                                   image:(UIImage *)image 
                                  target:(id)target 
                                  action:(SEL)selector;

+ (UIButton *)newImageButtonWithFrame:(CGRect)frame
								image:(UIImage *)image
							   target:(id)target 
							   action:(SEL)selector;

+ (UIButton *)newImageButtonWithFrame:(CGRect)frame
								image:(UIImage *)image
						  tappedImage:(UIImage *)tappedImage
							   target:(id)target 
							   action:(SEL)selector;

+ (UIButton *)newActionButtonWithFrame:(CGRect)frame
                                 title:(NSString *)title 
                            titleColor:(UIColor *)titleColor
                           tappedColor:(UIColor *)tappedColor
                                  font:(UIFont *)font
                                target:(id)target 
                                action:(SEL)selector;

+ (UILabel *)newLabelWithFrame:(CGRect)frame
                          text:(NSString *)text
                     textColor:(UIColor *)textColor
                          font:(UIFont *)font;

+ (UITextField *)newTextFieldWithFrame:(CGRect)frame
                           borderStyle:(UITextBorderStyle)borderStyle
                             textColor:(UIColor *)textColor
                       backgroundColor:(UIColor *)backgroundColor
                                  font:(UIFont *)font
                          keyboardType:(UIKeyboardType)keyboardType;

+ (void)showMsgAlertWithTitle:(NSString *)title message:(NSString *)msg;

+ (void)showProcessIndicator:(UIView *)imgView;
+ (void)showProcessIndicatorWithView:(UIView *)view atPoint:(CGPoint)point hasMask:(BOOL)hasMask;
+ (void)hideProcessIndicatorWithView:(UIView *)view;
+ (void)showGlobalMask;
+ (void)hideGlobalMask;
+ (void)roundCenter:(UIView *)view;

+ (void)imageWithUrl:(NSString *)imgUrl toView:(UIView *)view;
+ (void)imageWithUrl:(NSString *)imgUrl toView:(UIView *)view resize:(CGSize)size;
+ (void)imageWithUrl:(NSString *)imgUrl toView:(UIView *)view shouldResize:(BOOL)shouldResize;
+ (void)showFadeInAnimation:(UIView*)view endAlpha:(CGFloat)alpha;
@end


@interface ImageDataOperation : NSOperation {
	NSString *imageUrl;
	UIView *imgView;
    CGSize newSize;
    BOOL shouldResize;
}
- (id)initWithURL:(NSString *)url view:(UIView *)view;
- (id)initWithURL:(NSString *)url view:(UIView *)view resize:(CGSize)size;
- (id)initWithURL:(NSString *)url view:(UIView *)view shouldResize:(BOOL)resize;

@end
