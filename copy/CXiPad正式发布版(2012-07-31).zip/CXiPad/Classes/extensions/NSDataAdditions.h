//
//  NSDataAdditions.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 12/22/11.
//  Copyright (c) 2011 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSData+Base64.h"

@interface NSData (KS)

@end