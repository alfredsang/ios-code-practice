//
//  KSStatedIconButton.h
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-20.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KSStatedIconButton : UIButton{
    UIImage *_img1;
    UIImage *_img2;
    BOOL _selected;
}
@property(nonatomic, assign) BOOL selected;
- (id) initWithFrame:(CGRect)frame image:(UIImage *)img1 selectedImage:(UIImage *)img2;
- (id) initWithFrame:(CGRect)frame image:(UIImage *)img1 selectedImage:(UIImage *)img2 target:(id)target action:(SEL)action;
- (id) initWithFrame:(CGRect)frame title:(NSString*)title image:(UIImage *)img1 selectedImage:(UIImage *)img2 target:(id)target action:(SEL)action;
- (void) stateChange;
@end
