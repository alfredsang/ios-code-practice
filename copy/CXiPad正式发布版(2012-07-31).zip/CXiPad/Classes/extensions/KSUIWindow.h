//
//  KSUIWindow.h
//  CenturyWeeklyV2
//
//  Created by liuyou on 12-1-3.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol KSUIWindowDelegate
- (void)touchesEnded:(UIEvent *)event;
@end

@interface KSUIWindow : UIWindow {
    id <KSUIWindowDelegate> _tapDelegate;
}
@property(nonatomic, assign) id tapDelegate;

@end
