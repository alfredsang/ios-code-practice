//
//  NSObjectAdditons.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 12/30/11.
//  Copyright (c) 2011 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObjectAdditons : NSObject

@end

@interface NSNull (KS)
- (int)intValue;
- (int)length;
- (NSString *)stringValue;
- (void)removeFromSuperview;
@end