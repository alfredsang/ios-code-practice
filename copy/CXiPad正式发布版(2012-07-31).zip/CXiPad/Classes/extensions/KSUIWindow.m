//
//  KSUIWindow.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 12-1-3.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import "KSUIWindow.h"
#import "KSDirectoryMainView.h"

@implementation KSUIWindow
@synthesize tapDelegate = _tapDelegate;

- (void)sendEvent:(UIEvent *)event
{
    if(event.type==UIEventTypeTouches)
    {
        UITouch *touch = [[event allTouches] anyObject];
        if(touch.phase==UITouchPhaseEnded && touch.tapCount>=2)
        {
            [KSBootstrap notify:NOTIFY_WINDOW_TOUCH_END data:[NSDictionary dictionaryWithObjectsAndKeys:event, @"event", touch, @"touch", nil]];
        }


    }
    [super sendEvent:event];
}

//- (void)sendEvent:(UIEvent *)event {
//    [super sendEvent:event];
//	if (_tapDelegate != nil)
//        [_tapDelegate touchesEnded:event];
//}

@end
