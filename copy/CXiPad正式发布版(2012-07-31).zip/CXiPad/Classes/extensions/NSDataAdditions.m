//
//  NSDataAdditions.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 12/22/11.
//  Copyright (c) 2011 KSMobile. All rights reserved.
//

#import "NSDataAdditions.h"
@implementation NSData (KS)

@end

