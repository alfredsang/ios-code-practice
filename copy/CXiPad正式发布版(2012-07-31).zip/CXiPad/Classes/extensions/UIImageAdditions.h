//
//  UIImageAdditions.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 12/22/11.
//  Copyright (c) 2011 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface UIImage(UIImageAdditions)

- (UIImage *)rescaleToSize:(CGSize)size;
- (UIImage *)cropToRect:(CGRect)cropRect;
- (CGSize)calculateNewSizeForCropBox:(CGSize)croppingBox;
- (UIImage *)cropCenterAndScaleToSize:(CGSize)cropSize;

- (UIImage *)imageAtRect:(CGRect)rect;
- (UIImage *)imageByScalingProportionallyToMinimumSize:(CGSize)targetSize;
- (UIImage *)imageByScalingProportionallyToSize:(CGSize)targetSize;
- (UIImage *)imageByScalingToSize:(CGSize)targetSize;
- (UIImage *)imageRotatedByRadians:(CGFloat)radians;
- (UIImage *)imageRotatedByDegrees:(CGFloat)degrees;


@end

@interface UIImage (Alpha)
- (BOOL)hasAlpha;
- (UIImage *)imageWithAlpha;
- (UIImage *)transparentBorderImage:(NSUInteger)borderSize;
- (UIImage *)transparentBorderImage:(NSUInteger)borderSize size:(CGSize)sz;
@end

@interface UIImage(KS)

+ (UIImage *)imageNamedNocache:(NSString *)name;
- (id)initWithContentsOfResolutionIndependentFile:(NSString *)path;
+ (UIImage*)imageWithContentsOfResolutionIndependentFile:(NSString *)path;
@end
