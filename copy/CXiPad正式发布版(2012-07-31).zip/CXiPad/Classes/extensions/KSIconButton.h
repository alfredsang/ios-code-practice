//
//  KSIconButton.h
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-11-27.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KSIconButton : UIButton {
	id delegate;
	UIImage *image;
	UIImage *tapImage;
	UIImage *tappedImage;
	UIColor *selBgColor;
	UIColor *normalBgColor;
	UIButton *button;
    UILabel *textLabel;
	BOOL isSelected;
}

- (id)initWithFrame:(CGRect)frame image:(UIImage *)image tappedImage:(UIImage *)tappedImage;
- (id)initWithFrame:(CGRect)frame image:(UIImage *)image tapImage:(UIImage *)tapImage tappedImage:(UIImage *)tappedImage;
- (id)initWithFrame:(CGRect)frame image:(UIImage *)image tapImage:(UIImage *)tapImage tappedImage:(UIImage *)tappedImage group:(NSInteger) group index:(NSInteger)index;
- (void)unHighlight;
- (void)highlight;

@property(nonatomic,retain) UIColor *selBgColor;
@property(nonatomic,assign) BOOL isSelected;
@property(nonatomic,retain) NSString *text;
@property(nonatomic,retain) UIColor *textColor;
@property(nonatomic,retain) UIColor *highlightTextColor;
@property(nonatomic,assign) NSInteger group;
@end
