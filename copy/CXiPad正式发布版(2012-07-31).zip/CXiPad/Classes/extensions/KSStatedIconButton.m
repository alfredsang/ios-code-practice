//
//  KSStatedIconButton.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-20.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSStatedIconButton.h"

@implementation KSStatedIconButton
@synthesize selected = _selected;
- (void) stateChange{
    _selected = !_selected;
    [self setImage:_selected?_img2:_img1 forState:UIControlStateNormal];
}

- (void) setSelected:(BOOL)selected{
    _selected = selected;
    [self setImage:_selected?_img2:_img1 forState:UIControlStateNormal];
}

- (id) initWithFrame:(CGRect)frame image:(UIImage *)img1 selectedImage:(UIImage *)img2{
    if(self = [super initWithFrame:frame]){
        _img1 = [img1 retain];
        _img2 = [img2 retain];
        _selected = NO;
        [self setImage:_img1 forState:UIControlStateNormal];
        [self setImage:_img2 forState:UIControlStateHighlighted];
        [self addTarget:self action:@selector(stateChange) forControlEvents:UIControlEventTouchUpInside];
    }
    return self;
}
- (id) initWithFrame:(CGRect)frame image:(UIImage *)img1 selectedImage:(UIImage *)img2 target:(id)target action:(SEL)action{
    self = [self initWithFrame:frame image:img1 selectedImage:img2];
    if(self){
        [self addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    }
    return self;
}
- (id) initWithFrame:(CGRect)frame title:(NSString*)title image:(UIImage *)img1 selectedImage:(UIImage *)img2 target:(id)target action:(SEL)action{
    self = [self initWithFrame:frame image:img1 selectedImage:img2];
    if(self)
    {
        [self setTitle:title forState:UIControlStateNormal];
        [self setTitleEdgeInsets:UIEdgeInsetsMake(self.imageView.height, 0, 0, 0)];
        [self addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    }
    return self;
}
- (void) dealloc{
    [_img1 release];
    [_img2 release];
    [super dealloc];
}
@end
