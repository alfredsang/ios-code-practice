//
//  UILabel+VerticalAlign.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 12/28/11.
//  Copyright (c) 2011 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UILabel (VerticalAlign)

- (void)alignTop;
- (void)alignBottom;

@end
