//
//  KSIconButton.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-11-27.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSIconButton.h"

@implementation KSIconButton
@synthesize isSelected, selBgColor, text = _text, textColor = _textColor, highlightTextColor = _highlightTextColor,
group = _group;


#pragma mark -
#pragma mark PUBLIC
- (void)highlight {
	isSelected = YES;
	[button setImage:tappedImage forState:UIControlStateNormal];//选择后的按钮图片
    [textLabel setTextColor:_highlightTextColor];
}
- (void)unHighlight {
	isSelected = NO;
	[button setImage:image forState:UIControlStateNormal];
    [textLabel setTextColor:_textColor];
}
- (void)buttonTouchDown {
	self.backgroundColor = selBgColor;
	[self highlight];
}
- (void)buttonTouchUp {
	self.backgroundColor = normalBgColor;
    if(!self.group){
        [self unHighlight];
        return;
    }
    NSInteger start = 10000 + self.group * 100;
    for (NSInteger i = start; i<start+10; i++) {
        UIView *view = [self.viewController.view viewWithTag:i];
        if(view == nil || ![view isKindOfClass:[KSIconButton class]])continue;
        KSIconButton *btn = (KSIconButton *)view;
        if(btn==self)continue;
        [btn unHighlight];
    }
}
- (void)setSubviews {
	button = [[UIButton alloc] initWithFrame:CGRectMake(5, 5, 30, 30)];
	button.backgroundColor = [UIColor clearColor];
	[button setImage:image forState:UIControlStateNormal];
	[button setImage:tapImage forState:UIControlStateHighlighted];//选择中的按钮图片
	button.userInteractionEnabled = NO;
	[self addSubview:button];
    textLabel = [[UILabel alloc] initWithFrame:CGRectMake(40, 10, self.frame.size.width-40, 20)];
    textLabel.backgroundColor = [UIColor clearColor];
    textLabel.textColor = _textColor;
    textLabel.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    [self addSubview:textLabel];
    textLabel.hidden = YES;
}

- (void)initData {
    self.backgroundColor = [UIColor clearColor];
	_textColor = [UIColor whiteColor];
	_highlightTextColor = [UIColor yellowColor];
    selBgColor = [UIColor clearColor];//[UIColor grayColor];
    normalBgColor = [UIColor clearColor];
    isSelected = NO;
}

- (id)initWithFrame:(CGRect)frame image:(UIImage *)img tapImage:(UIImage *)tapImg tappedImage:(UIImage *)tappedImg{
	if (self = [super initWithFrame:frame]) {
		image = [img retain];
		tapImage = [tapImg retain];
		tappedImage = [tappedImg retain];
		
		[self initData];
		[self setSubviews];
	}
	[self addTarget:self action:@selector(buttonTouchDown) forControlEvents:UIControlEventTouchDown];
	[self addTarget:self action:@selector(buttonTouchUp) forControlEvents:UIControlEventTouchUpInside|UIControlEventTouchDragExit];
	return self;
}

- (id)initWithFrame:(CGRect)frame image:(UIImage *)img tappedImage:(UIImage *)tappedImg{
    return [self initWithFrame:frame image:img tapImage:tappedImg tappedImage:tappedImg];
}

- (id)initWithFrame:(CGRect)frame image:(UIImage *)img tapImage:(UIImage *)tapImg tappedImage:(UIImage *)tappedImg group:(NSInteger)group index : (NSInteger) index{
    self = [self initWithFrame:frame image:img tapImage:tapImg tappedImage:tappedImg];
    self.group = group;
    self.tag = 10000 + self.group * 100 + index;
    return self;
}

- (void) setText:(NSString *)text{
    if (!text) {
        return;
    }
    [_text release];
    _text = [text retain];
    textLabel.text = _text;
    textLabel.hidden = NO;
}

- (void)dealloc {
	[image release];
	[tapImage release];
	[tappedImage release];
	[button release];
    [textLabel release];
    [_text release];
    [_textColor release];
    [_highlightTextColor release];
	[super dealloc];
}

@end
