//
//  ASIBaseDataRequest.h
//  JHcaifu
//
//  Created by jian jin on 9/14/11.
//  Copyright 2011 caixin. All rights reserved.
//

#import "KSBaseDataRequest.h"
#import "ASIFormDataRequest.h"

@interface ASIBaseDataRequest : KSBaseDataRequest {
    ASIFormDataRequest *_request;
}

@end
