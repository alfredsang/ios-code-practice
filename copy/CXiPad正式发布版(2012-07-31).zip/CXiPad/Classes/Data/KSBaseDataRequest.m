//
//  KSBaseDataRequest.m
//  JHcaifu
//
//  Created by jian jin on 9/14/11.
//  Copyright 2011 caixin. All rights reserved.
//

#import "KSBaseDataRequest.h"
#import "CJSONDeserializer.h"

@implementation KSBaseDataRequest
@synthesize delegate = _delegate;
@synthesize isLoading = _isLoading;
@synthesize indicatorView = _indicatorView;
@synthesize resultDict = _resultDict;
@synthesize resultString = _resultString;
@synthesize requestResult = _requestResult;
@synthesize requestStartTime = _requestStartTime;
@synthesize timeout = _timeout;
@synthesize useSilentAlert = _useSilentAlert;
@synthesize requestUrl = _innerUrl;

+ (id)silentRequestWithDelegate:(id<KSDataRequestDelegate>)delegate {
    return [[[self class] alloc] initWithDelegate:delegate
                                   withParameters:nil
                                withIndicatorView:nil
                                withCancelSubject:nil
                                  withSilentAlert:YES];
}
+ (id)requestWithDelegate:(id<KSDataRequestDelegate>)delegate {
    return [[[self class] alloc] initWithDelegate:delegate 
                                   withParameters:nil 
                                withIndicatorView:nil
                                withCancelSubject:nil
                                  withSilentAlert:NO];
}
+ (id)requestWithDelegate:(id<KSDataRequestDelegate>)delegate
        withCancelSubject:(NSString*)cancelSubject {
    return [[[self class] alloc] initWithDelegate:delegate 
                                   withParameters:nil 
                                withIndicatorView:nil 
                                withCancelSubject:cancelSubject 
                                  withSilentAlert:NO];
}
+ (id)silentRequestWithDelegate:(id<KSDataRequestDelegate>)delegate 
                 withParameters:(NSDictionary*)params {
    return [[[self class] alloc] initWithDelegate:delegate
                                   withParameters:params
                                withIndicatorView:nil
                                withCancelSubject:nil
                                  withSilentAlert:YES];
}
+ (id)requestWithDelegate:(id<KSDataRequestDelegate>)delegate 
           withParameters:(NSDictionary*)params {
    return [[[self class] alloc] initWithDelegate:delegate 
                                   withParameters:params 
                                withIndicatorView:nil 
                                withCancelSubject:nil
                                  withSilentAlert:NO];
}

+ (id)requestWithDelegate:(id<KSDataRequestDelegate>)delegate 
           withParameters:(NSDictionary*)params
        withCancelSubject:(NSString*)cancelSubject {
    return [[[self class] alloc] initWithDelegate:delegate 
                                   withParameters:params 
                                withIndicatorView:nil 
                                withCancelSubject:cancelSubject 
                                  withSilentAlert:NO];
}
+ (id)requestWithDelegate:(id<KSDataRequestDelegate>)delegate
        withIndicatorView:(UIView*)indiView
        withCancelSubject:(NSString*)cancelSubject{
    return [[[self class] alloc] initWithDelegate:delegate 
                                   withParameters:nil 
                                withIndicatorView:indiView 
                                withCancelSubject:cancelSubject 
                                  withSilentAlert:NO];
}
+ (id)requestWithDelegate:(id<KSDataRequestDelegate>)delegate
        withIndicatorView:(UIView*)indiView{
	return [[[self class] alloc] initWithDelegate:delegate 
                                   withParameters:nil 
                                withIndicatorView:indiView
                                withCancelSubject:nil
                                  withSilentAlert:NO];
}
+ (id)requestWithDelegate:(id<KSDataRequestDelegate>)delegate 
           withParameters:(NSDictionary*)params
        withIndicatorView:(UIView*)indiView{
	return [[[self class] alloc] initWithDelegate:delegate 
                                   withParameters:params 
                                withIndicatorView:indiView
                                withCancelSubject:nil
                                  withSilentAlert:NO];
}
+ (id)requestWithDelegate:(id<KSDataRequestDelegate>)delegate 
           withParameters:(NSDictionary*)params
        withIndicatorView:(UIView*)indiView
        withCancelSubject:(NSString*)cancelSubject{
	return [[[self class] alloc] initWithDelegate:delegate 
                                   withParameters:params 
                                withIndicatorView:indiView 
                                withCancelSubject:cancelSubject 
                                  withSilentAlert:NO];
}

+ (id)requestWithDelegate:(id<KSDataRequestDelegate>)delegate 
                      url:(NSString *)url
           withParameters:(NSDictionary*)params
        withIndicatorView:(UIView*)indiView
        withCancelSubject:(NSString*)cancelSubject{
	return [[[self class] alloc] initWithDelegate:delegate 
                                              url:(NSString *)url
                                   withParameters:params 
                                withIndicatorView:indiView 
                                withCancelSubject:cancelSubject 
                                  withSilentAlert:NO];
}

- (id)initWithDelegate:(id<KSDataRequestDelegate>)delegate 
                   url:(NSString *)url
        withParameters:(NSDictionary*)params
     withIndicatorView:(UIView*)indiView
     withCancelSubject:(NSString*)cancelSubject
       withSilentAlert:(BOOL)silent {
    self = [super init];
	if(self) {
		_indicatorView = [indiView retain];
        _innerUrl = [url retain];
		_isLoading = NO;
		_delegate = [delegate retain];
		_resultDict = nil;
        _requestResult = nil;
        _useSilentAlert = silent;
        _timeout = 120;
        if (cancelSubject && cancelSubject.length > 0) {
            _requestUniqueName = [cancelSubject retain];
        }
        
        if (_requestUniqueName && _requestUniqueName.length) {
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(cancelRequest) name:_requestUniqueName object:nil];
        }
        
        _requestStartTime = [[NSDate date] retain];
        [self doRequestWithParams:params];
        KSDINFO(@"request %@ is created", [self class]);
	}
	return self;
}
- (id)initWithDelegate:(id<KSDataRequestDelegate>)delegate
        withParameters:(NSDictionary*)params
     withIndicatorView:(UIView*)indiView
     withCancelSubject:(NSString*)cancelSubject
       withSilentAlert:(BOOL)silent {
    self = [self initWithDelegate:delegate url:nil withParameters:params withIndicatorView:indiView withCancelSubject:cancelSubject withSilentAlert:silent];
	if(self) {
		
	}
	return self;
}

- (void)dealloc {	
    if (_indicatorView) {
        //make sure indicator is closed
        [self showIndicator:NO];
    }
    if (_requestUniqueName && _requestUniqueName.length) {
        [[NSNotificationCenter defaultCenter] removeObserver:self
                                                        name:_requestUniqueName
                                                      object:nil];
    }
    KSDINFO(@"request %@ is released,time spend on this request:%f seconds", [self class],[[NSDate date] timeIntervalSinceDate:_requestStartTime]);
    RELEASE_SAFELY(_delegate);
    RELEASE_SAFELY(_requestResult);
    RELEASE_SAFELY(_requestUniqueName);
    RELEASE_SAFELY(_resultDict);
    RELEASE_SAFELY(_resultString);
    RELEASE_SAFELY(_indicatorView);
    RELEASE_SAFELY(_requestStartTime);
	[super dealloc];
}

#pragma mark - PUBLIC
+ (void)cancelRequest:(NSString *)subject {
    [[NSNotificationCenter defaultCenter] postNotificationName:subject object:nil];
}

#pragma mark -

+ (NSDictionary*)getDictFromString:(NSString*)cachedResponse {
    NSData *jsonData = [cachedResponse dataUsingEncoding:NSUTF8StringEncoding];
	return [[CJSONDeserializer deserializer] deserializeAsDictionary:jsonData error:nil];
}

- (void)processResult{
    NSDictionary *resultData = [self.resultDict objectForKey:@"result"];
    if (resultData) {
        _requestResult = [[KSRequestResult alloc] initWithCode:[resultData objectForKey:@"code"] 
                                             withMessage:[resultData objectForKey:@"msg"]];
        if (![_requestResult isSuccess]) {
            KSDERROR(@"request[%@] failed with message %@",self,_requestResult.code);
        }else {
            KSDINFO(@"request[%@] :%@" ,self ,@"success");
        }
    }
}

- (BOOL)isSuccess{
    if (_requestResult && [_requestResult isSuccess]) {
        return YES;
    }
    return NO;
}

- (NSString*)encodeURL:(NSString *)string{
    //NSString *newString = [(NSString *)CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault, (CFStringRef)string, NULL, CFSTR(":/?#[]@!$ &'()*+,;=\"<>%{}|\\^~`"), CFStringConvertNSStringEncodingToEncoding(NSUTF8StringEncoding)) autorelease];
	NSString *newString = (NSString *)CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault, (CFStringRef)string, NULL, CFSTR(":/?#[]@!$ &'()*+,;=\"<>%{}|\\^~`"), kCFStringEncodingGB_18030_2000);
	if (newString) {
		return [newString autorelease];
	}
	return @"";
}

- (void)showIndicator:(BOOL)bshow{
	_isLoading = bshow;
	if (_indicatorView) {
        UIView *indicatorView = (UIView *)[_indicatorView viewWithTag:kTagWindowIndicatorView];
        UIActivityIndicatorView *indicator = (UIActivityIndicatorView *)[_indicatorView viewWithTag:kTagWindowIndicator];
        if (indicatorView == nil) {
            indicatorView = [[UIView alloc] initWithFrame:[_indicatorView bounds]];
            indicatorView.contentMode = UIViewContentModeCenter;
            indicatorView.autoresizingMask = _indicatorView.autoresizingMask;
            indicatorView.backgroundColor = [UIColor colorWithWhite:0.2 alpha:0.8];//RGBACOLOR(100,100,100,0.7);
            indicatorView.tag = kTagWindowIndicatorView;
            [_indicatorView addSubview:indicatorView];
            indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
            //indicator.frame = CGRectMake(_indicatorView.bounds.size.width/2 -15, _indicatorView.bounds.size.height/2-15, 30, 30);
            indicator.tag = kTagWindowIndicator;
            [indicatorView addSubview:indicator];
            indicator.center = indicatorView.center;
            indicator.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin|UIViewAutoresizingFlexibleRightMargin|UIViewAutoresizingFlexibleTopMargin|UIViewAutoresizingFlexibleBottomMargin;
            
            [indicator release];
            [indicatorView release];
        }
        if (bshow) {
            [indicatorView setHidden:NO];
            [indicator startAnimating];
            [_indicatorView bringSubviewToFront:indicatorView];
        }else {
            [indicatorView setHidden:YES];
            [indicator stopAnimating];
            [_indicatorView sendSubviewToBack:indicatorView];
        }
	}
}

- (BOOL)handleResultString:(NSString*)resultString{
    NSString *trimmedString = [resultString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    RELEASE_SAFELY(_resultString)
	_resultString = [trimmedString retain];
	if (!_resultString || [_resultString length] == 0) {
		KSDERROR(@"!empty response error with Request:%@",[self class]);
        RELEASE_SAFELY(_resultString)
        _resultString = [[NSString alloc] initWithString:@"{\"data\":\"\"}"];
		//return NO;
	}
	//KSDINFO(@"raw response:%@",_resultString);
    
	NSData *jsonData;
    NSString *first = [_resultString  substringWithRange:NSMakeRange(0,1)];
    if (![first isEqualToString:@"{"] && ![first isEqualToString:@"["]) {
        //jsonData = [NSDictionary dictionaryWithObject:[[self.resultString stringByReplacingOccurrencesOfString:@"\n" withString:@""] stringByReplacingOccurrencesOfString:@"\r" withString:@""] forKey:@"string"];
        jsonData = [[NSString stringWithFormat:@"{\"data\":\"%@\"}",[[self.resultString stringByReplacingOccurrencesOfString:@"\n" withString:@""] stringByReplacingOccurrencesOfString:@"\r" withString:@""]] dataUsingEncoding:NSUTF8StringEncoding];
        
    } else if ([first isEqualToString: @"["] ) {
		jsonData = [[[@"{\"data\":" stringByAppendingString:self.resultString ] stringByAppendingString:@"}"] dataUsingEncoding:NSUTF8StringEncoding];
	}else {
		jsonData = [self.resultString  dataUsingEncoding:NSUTF8StringEncoding];
	}
    NSError *error;
    NSDictionary *resultDic = [[CJSONDeserializer deserializer] deserializeAsDictionary:jsonData error:&error];
    
	if(!resultDic) { 
		if( _delegate && [_delegate respondsToSelector:@selector(requestDidFailed:withError:)]){
			[_delegate requestDidFailed:self withError:[NSError errorWithDomain:NSURLErrorDomain code:0 userInfo:nil]];
		}
        KSDERROR(@"http request:%@\n with error:%@\n raw result:%@",[self class],error,_resultString);
        return NO;
	}else{
        RELEASE_SAFELY(_resultDict);
        _resultDict = [[NSMutableDictionary alloc] initWithDictionary:resultDic];
        [self processResult];
        if(_delegate && [_delegate respondsToSelector:@selector(requestDidFinished:)]){
            [_delegate requestDidFinished:self];
        }
        return YES;
    }
}
#pragma mark - hook methods
- (void)doRequestWithParams:(NSDictionary*)params{
    KSDERROR(@"should implement request logic here!");
}
- (NSStringEncoding)getResponseEncoding{
    return CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
}

- (NSDictionary*)getStaticParams{
	//return [NSDictionary dictionaryWithObjectsAndKeys:[DATA_ENV getToken], @"token",[DATA_ENV getUID], @"userId",nil];
    return nil;
}

- (KSRequestMethod)getRequestMethod{
	return KSRequestMethodGet;
}

- (NSString*)getRequestUrl{
	return _innerUrl;
}

- (NSString*)getRequestHost{
	//return DATA_ENV.urlRequestHost;
    return nil;
}

@end
