//
//  KSRequestResult.m
//  JHcaifu
//
//  Created by jian jin on 9/14/11.
//  Copyright 2011 caixin. All rights reserved.
//

#import "KSRequestResult.h"

@implementation KSRequestResult
@synthesize code = _code;
@synthesize message = _message;

- (id)initWithCode:(NSNumber *)code withMessage:(NSString *)msg {
    self = [super init];
    if (self) {
        _code = [code retain];
        _message = [msg retain];
    }
    return self;
}

- (BOOL)isSuccess {
    return (_code && [_code intValue] == 200);
}
- (void)showMessageAlert {
    if (_message && _message.length) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" 
                                                            message:_message
                                                           delegate:nil 
                                                  cancelButtonTitle:@"确定" 
                                                  otherButtonTitles:nil];
        [alertView show];
        [alertView release]; 
    }
}

- (void)dealloc {
	[_code release];
    [_message release];
    [super dealloc];
}

@end
