//
//  KSRequestResult.h
//  JHcaifu
//
//  Created by jian jin on 9/14/11.
//  Copyright 2011 caixin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface KSRequestResult : NSObject {
    NSNumber *_code;
    NSString *_message;
}
@property(nonatomic, retain)NSNumber *code;
@property(nonatomic, retain)NSString *message;

- (id)initWithCode:(NSNumber *)code withMessage:(NSString *)msg;
- (BOOL)isSuccess;
- (void)showMessageAlert;

@end
