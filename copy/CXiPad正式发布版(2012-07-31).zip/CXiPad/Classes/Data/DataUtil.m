//
//  DataUtil.m
//  CaixiniPad
//
//  Created by Kevin Huang on 6/6/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#include <sys/xattr.h>

#import "DataUtil.h"
#import "ASIFormDataRequest.h"
#import "KSBootstrap.h"

static char encodingTable[64] = {
	'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P',
	'Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f',
	'g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v',
	'w','x','y','z','0','1','2','3','4','5','6','7','8','9','+','/' };

@implementation DataUtil

+ (NSString *)getPathByFileName:(NSString *)fileName{
	return [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"/Documents/%@",fileName]];
}
+ (NSString *)getCachePathByFileName:(NSString *)fileName {
    return [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"/Library/Caches/%@",fileName]];
}
+ (BOOL)addSkipBackupAttributeToItemAtFilePath:(NSString *)filePath {
    NSURL *url = [NSURL URLWithString:filePath];
    return [self addSkipBackupAttributeToItemAtURL:url];
}
+ (BOOL)addSkipBackupAttributeToItemAtURL:(NSURL *)URL{
    const char* filePath = [[URL path] fileSystemRepresentation];
    const char* attrName = "com.apple.MobileBackup";
    u_int8_t attrValue = 1;
    int result = setxattr(filePath, attrName, &attrValue, sizeof(attrValue), 0, 0);
    return result == 0;
}

+ (NSString *)getPathByFileNameInBundle:(NSString *)fileName{
	return [NSString stringWithFormat:@"%@/%@",[[NSBundle mainBundle] bundlePath],fileName];
}

+ (NSString *)convertURL2CachefilePath:(NSString *)imageurl {
    return  [self urlToPah:imageurl];
    
    NSArray *URLParts = [imageurl componentsSeparatedByString:@"/"];
	NSString *fileName = (NSString *)[URLParts lastObject];
	if(fileName && fileName.length) {
		NSError *error = nil;
		[[NSFileManager defaultManager] createDirectoryAtPath:KSPathForCachesResource(@"index_covers")
								  withIntermediateDirectories:YES
												   attributes:nil
														error:&error];
		return KSPathForCachesResource([NSString stringWithFormat:@"index_covers/%@", fileName]);
	}
    
	return @"";
}
+ (NSString *)urlToPah:(NSString *)url {
    if (url && url.length) {
        return [NSString stringWithFormat:@"%@/Library/Caches/ImagesCache/%@",NSHomeDirectory(),[url substringFromIndex:7]];
    }else
        return @"";
    
}
+ (NSString *)urlToPah:(NSString *)url size:(CGSize)newSize {
    if (url && url.length) {
        NSString *path = [NSString stringWithFormat:@"%@/Library/Caches/ImagesCache/%@",NSHomeDirectory(),[url substringFromIndex:7]];
        NSString *extension = [path substringFromIndex:(int)([path rangeOfString:@"." options:NSBackwardsSearch].location)+1];
        return [NSString stringWithFormat:@"%@_%dx%d.%@", [path substringToIndex:(int)([path rangeOfString:@"." options:NSBackwardsSearch].location)-1],(int)newSize.width,(int)newSize.height,extension];
        
        
    }else
        return @"";
}
+ (BOOL)saveNSDataToDisk:(NSData *)data fullPath:(NSString *)path {
    NSString *directory = [path substringToIndex:(int)([path rangeOfString:@"/" options:NSBackwardsSearch].location) ];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if (![fileManager fileExistsAtPath:directory]) {
        [fileManager createDirectoryAtPath:directory withIntermediateDirectories:YES attributes:nil error:nil];
    }
    if (![fileManager fileExistsAtPath:path]) {
        return [fileManager createFileAtPath:path contents:data attributes:nil];
        //[data writeToFile:path atomically:YES];
    }
    return YES;
}
+ (BOOL)saveImageToDisk:(UIImage *)img fullPath:(NSString *)path {
    NSString *extension = [path substringFromIndex:(int)([path rangeOfString:@"." options:NSBackwardsSearch].location)+1];
    NSData *data;
    if ([[extension lowercaseString] isEqualToString:@"png"]) {
        data = UIImagePNGRepresentation(img);
    }else {
        data = UIImageJPEGRepresentation(img, 1.0);
    }
    return [DataUtil saveNSDataToDisk:data fullPath:path];
    
    
}

+ (BOOL)validateEmail:(NSString *)candidate{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"; 
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex]; 
    return [emailTest evaluateWithObject:candidate];
}

#pragma mark -
+ (unsigned long long int)folderSize:(NSString *)folderPath {
    NSArray *filesArray = [[NSFileManager defaultManager] subpathsOfDirectoryAtPath:folderPath error:nil];
    NSEnumerator *filesEnumerator = [filesArray objectEnumerator];
    NSString *fileName;
    unsigned long long int fileSize = 0;
    
    while (fileName = [filesEnumerator nextObject]) {
        NSDictionary *fileDictionary = [[NSFileManager defaultManager] attributesOfItemAtPath:KSPathForDocumentsResource(fileName) error:nil];
        fileSize += [fileDictionary fileSize];
    } 
    
    return fileSize;
}

//Human-Readable
+ (NSString *)getHRFolderSize:(NSString *)folderPath {
    NSString *sizeTypeW = @" B";
    NSInteger fileSize = [self folderSize:folderPath];
    if (fileSize > 1024) {
        fileSize = fileSize / 1024;
        sizeTypeW = @" KB";
    }
    if (fileSize > 1024) {
        fileSize = fileSize / 1024;
        sizeTypeW = @" MB";
    }
    if (fileSize > 1024) {
        fileSize = fileSize / 1024;
        sizeTypeW = @" GB";
    }
    return [NSString stringWithFormat:@"%i%@",fileSize, sizeTypeW];
}

#pragma mark -
+ (NSString *)convertArrayToString:(NSArray *)array{
	NSMutableString *string = [NSMutableString stringWithCapacity:0];
	for( NSInteger i=0;i<[array count];i++ ){
		[string appendFormat:@"%@%@",(NSString *)[array objectAtIndex:i], (i<([array count]-1))?@",":@""];
	}
	return string;
}

+ (NSArray *)convertStringToArray:(NSString *)string{
	return [string componentsSeparatedByString:@","];
}

+ (void)saveLoginData{
	KSDataCenter *dataCenter = [KSBootstrap dataCenter];
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
	[userDefaults setObject:[dataCenter valueForKey:UD_KEY_USERNAME] forKey:UD_KEY_USERNAME];
	[userDefaults setObject:[dataCenter valueForKey:UD_KEY_PASSWORD] forKey:UD_KEY_PASSWORD];
	[userDefaults setObject:[dataCenter valueForKey:UD_KEY_NICKNAME] forKey:UD_KEY_NICKNAME];
	[userDefaults synchronize];
}

+ (void)deleteLoginData{
	KSDataCenter *dataCenter = [KSBootstrap dataCenter];
    [dataCenter removeObjectForKey:UD_KEY_USERNAME];
    [dataCenter removeObjectForKey:UD_KEY_PASSWORD];
    [dataCenter removeObjectForKey:UD_KEY_NICKNAME];
    
	NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
	[userDefaults setObject:nil forKey:UD_KEY_USERNAME];
	[userDefaults setObject:nil forKey:UD_KEY_PASSWORD];
	[userDefaults setObject:nil forKey:UD_KEY_NICKNAME];
	[userDefaults synchronize];
}

+ (void)savePurchaseData{
	
}
+ (void)saveCurrnetPurchaseData {
	
}

+ (void)saveDownloadData{
	
}

+ (NSString *)encodeURL:(NSString *)url{
	NSURL *tmpUrl = [[NSURL alloc] initWithString:@"http://www.apple.com"];
	ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:tmpUrl];
	[tmpUrl release];
	
	return [request encodeURL:url];
}

+ (NSString *)base64EncodingStringWithData:(NSData *)data lineLength:(unsigned int)lineLength{
	const unsigned char *bytes = [data bytes];
	NSMutableString *result = [NSMutableString stringWithCapacity:[data length]];
	unsigned long ixtext = 0;
	unsigned long lentext = [data length];
	long ctremaining = 0;
	unsigned char inbuf[3], outbuf[4];
	short i = 0;
	short charsonline = 0, ctcopy = 0;
	unsigned long ix = 0;
	
	while( YES ) {
		ctremaining = lentext - ixtext;
		if( ctremaining <= 0 ) break;
		
		for( i = 0; i < 3; i++ ) {
			ix = ixtext + i;
			if( ix < lentext ) inbuf[i] = bytes[ix];
			else inbuf [i] = 0;
		}
		
		outbuf [0] = (inbuf [0] & 0xFC) >> 2;
		outbuf [1] = ((inbuf [0] & 0x03) << 4) | ((inbuf [1] & 0xF0) >> 4);
		outbuf [2] = ((inbuf [1] & 0x0F) << 2) | ((inbuf [2] & 0xC0) >> 6);
		outbuf [3] = inbuf [2] & 0x3F;
		ctcopy = 4;
		
		switch( ctremaining ) {
			case 1:
				ctcopy = 2;
				break;
			case 2:
				ctcopy = 3;
				break;
		}
		
		for( i = 0; i < ctcopy; i++ )
			[result appendFormat:@"%c", encodingTable[outbuf[i]]];
		
		for( i = ctcopy; i < 4; i++ )
			[result appendString:@"="];
		
		ixtext += 3;
		charsonline += 4;
		
		if( lineLength > 0 ) {
			if (charsonline >= lineLength) {
				charsonline = 0;
				[result appendString:@"\n"];
			}
		}
	}
	return [NSString stringWithString:result];
}





@end
