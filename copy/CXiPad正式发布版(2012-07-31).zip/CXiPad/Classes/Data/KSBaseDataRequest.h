//
//  KSBaseDataRequest.h
//  JHcaifu
//
//  Created by jian jin on 9/14/11.
//  Copyright 2011 caixin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KSRequestResult.h"

typedef enum {
    KSRequestMethodGet = 0,
    KSRequestMethodPost = 1,            //application/x-www-form-urlencoded
    KSRequestMethodMultipartPost = 2,   //multipart/form-data
} KSRequestMethod;

@class KSBaseDataRequest;
@protocol KSDataRequestDelegate <NSObject>
@optional
//#pragma mark - KSDataRequestDelegate
- (void)requestDidStarted:(KSBaseDataRequest *)request;
- (void)requestDidFinished:(KSBaseDataRequest *)request;
- (void)requestDidCanceled:(KSBaseDataRequest *)request;
- (void)requestDidFailed:(KSBaseDataRequest *)request withError:(NSError*)error;

@end


@interface KSBaseDataRequest : NSObject {
    id<KSDataRequestDelegate> _delegate;
    NSMutableDictionary *_resultDict;
    NSString *_resultString;
    NSString *_requestUniqueName;
    BOOL _isLoading;
    UIView *_indicatorView;
    BOOL _useSilentAlert;
    NSDate *_requestStartTime;
    KSRequestResult *_requestResult;
    NSInteger _timeout;
    NSString *_innerUrl;
}
@property(nonatomic, retain)id<KSDataRequestDelegate> delegate;
@property(nonatomic, assign)BOOL isLoading;
@property(nonatomic, retain)UIView *indicatorView;
@property(nonatomic, retain)NSMutableDictionary *resultDict;
@property(nonatomic, retain)NSString *resultString;
@property(nonatomic, retain)NSDate *requestStartTime;
@property(nonatomic, retain)KSRequestResult *requestResult;
@property(nonatomic, assign)NSInteger timeout;
@property(nonatomic, assign)BOOL useSilentAlert;
@property(nonatomic, assign)NSString *requestUrl;

+ (id)silentRequestWithDelegate:(id<KSDataRequestDelegate>)delegate;
+ (id)silentRequestWithDelegate:(id<KSDataRequestDelegate>)delegate 
                 withParameters:(NSDictionary*)params;

+ (id)requestWithDelegate:(id<KSDataRequestDelegate>)delegate;

+ (id)requestWithDelegate:(id<KSDataRequestDelegate>)delegate
        withCancelSubject:(NSString*)cancelSubject;

+ (id)requestWithDelegate:(id<KSDataRequestDelegate>)delegate 
           withParameters:(NSDictionary*)params;

+ (id)requestWithDelegate:(id<KSDataRequestDelegate>)delegate 
           withParameters:(NSDictionary*)params
        withCancelSubject:(NSString*)cancelSubject;

+ (id)requestWithDelegate:(id<KSDataRequestDelegate>)delegate
        withIndicatorView:(UIView*)indiView;

+ (id)requestWithDelegate:(id<KSDataRequestDelegate>)delegate
        withIndicatorView:(UIView*)indiView
        withCancelSubject:(NSString*)cancelSubject;

+ (id)requestWithDelegate:(id<KSDataRequestDelegate>)delegate 
           withParameters:(NSDictionary*)params
        withIndicatorView:(UIView*)indiView;

+ (id)requestWithDelegate:(id<KSDataRequestDelegate>)delegate 
           withParameters:(NSDictionary*)params
        withIndicatorView:(UIView*)indiView
        withCancelSubject:(NSString*)cancelSubject;

+ (id)requestWithDelegate:(id<KSDataRequestDelegate>)delegate 
                      url:(NSString *)url
           withParameters:(NSDictionary*)params
        withIndicatorView:(UIView*)indiView
        withCancelSubject:(NSString*)cancelSubject;


- (id)initWithDelegate:(id<KSDataRequestDelegate>)delegate
        withParameters:(NSDictionary*)params
     withIndicatorView:(UIView*)indiView
     withCancelSubject:(NSString*)cancelSubject
       withSilentAlert:(BOOL)silent;

- (id)initWithDelegate:(id<KSDataRequestDelegate>)delegate 
                   url:(NSString *)url
        withParameters:(NSDictionary*)params
     withIndicatorView:(UIView*)indiView
     withCancelSubject:(NSString*)cancelSubject
       withSilentAlert:(BOOL)silent;



+ (NSDictionary*)getDictFromString:(NSString*)cachedResponse;
- (void)doRequestWithParams:(NSDictionary*)params;
- (NSStringEncoding)getResponseEncoding;
- (NSDictionary*)getStaticParams;
- (KSRequestMethod)getRequestMethod;
- (NSString*)getRequestUrl;
- (NSString*)getRequestHost;
- (void)processResult;
- (BOOL)isSuccess;
- (NSString*)encodeURL:(NSString *)string;
- (void)showIndicator:(BOOL)bshow;
- (BOOL)handleResultString:(NSString*)resultString;


+ (void)cancelRequest:(NSString *)subject;

@end
