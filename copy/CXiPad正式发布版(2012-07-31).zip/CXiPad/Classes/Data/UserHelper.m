//
//  UserHelper.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 1/11/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "UserHelper.h"

@implementation UserHelper

+ (void)saveMyFreeToDB:(NSDictionary *)dict {
    //处理my_free
    //将free数据写入数据库
    //NSDictionary *dict = request.resultDict;
    NSString *udid = KEY_DEVICE_UDID;
    [[KSDB db] executeUpdate:@"delete from my_free where user_email=?",[KSBootstrap currentUser]];
    NSArray *periodicalidsArr = [dict objectForKey:@"periodicalids"];
    if (periodicalidsArr && [KSBootstrap currentUser]) {
        for (NSString *issue in periodicalidsArr) {
            [[KSDB db] executeUpdate:@"insert into my_free(user_email,issue_number)values(?,?)",[KSBootstrap currentUser],INTEGER([issue intValue])];
        }
    }
    [[KSDB db] executeUpdate:@"delete from my_device_free where device_udid=?",udid];
    periodicalidsArr = [dict objectForKey:@"device_periodicalids"];
    if (periodicalidsArr) {
        for (NSString *issue in periodicalidsArr) {
            [[KSDB db] executeUpdate:@"insert into my_device_free(device_udid,issue_number)values(?,?)",udid,INTEGER([issue intValue])];
        }
    }
    [[KSDB db] executeUpdate:@"delete from my_free_logic where user_email=? or user_email=?",[KSBootstrap currentUser],udid];
    NSArray *infoArray = [dict objectForKey:@"info"];
    //"info":[{"magazine_type":"1","starttime":"1320595200","endtime":"0","free_count":"2"}]
    if (infoArray) {
        for (NSDictionary *d in infoArray) {
            NSInteger donateType = DICT_INTVAL(d, @"type");
            [[KSDB db] executeUpdate:@"insert into my_free_logic(user_email,start_time,end_time,free_count,free_type) values(?,?,?,?,?)",[DICT_VAL(d, @"email") lowercaseString], INTEGER(DICT_INTVAL(d, @"starttime")),INTEGER(DICT_INTVAL(d, @"endtime")),INTEGER(DICT_INTVAL(d, @"free_count")),INTEGER(donateType)];
        }
    }
    
    //删除所有网站订阅记录
    [[KSDB db] executeUpdate:@"delete from subscribed where order_no='0'"];
    NSArray *webSubArray = [dict objectForKey:@"buy_info"];
    //"buy_info":[{"magazine_type":"1","starttime":"1320595200","endtime":"0","free_count":"2"}]
    if (webSubArray) {
        for (NSDictionary *d in webSubArray) {
            [[KSDB db] executeUpdate:@"insert into subscribed (email,start,end,subsribe_type,order_no) values(?,?,?,?,'0')",[DICT_VAL(d, @"email") lowercaseString], INTEGER(DICT_INTVAL(d, @"starttime")),INTEGER(DICT_INTVAL(d, @"endtime")),INTEGER(DICT_INTVAL(d, @"type"))];
        }
    }
}
+ (void)saveUserCardToDB:(NSDictionary *)dict {
    
}

+ (void)convFreeLogic2MagId {
    if ([KSBootstrap currentUser]) {
        FMResultSet *rs = [[KSDB db] executeQuery:@"SELECT * FROM my_free_logic WHERE user_email=?",[KSBootstrap currentUser]];
        NSMutableArray *arr = [NSMutableArray arrayWithCapacity:4];
        while (rs.next) {
            [arr addObject:rs.resultDict];
        }
        [rs close];
        NSMutableArray *allfree = [NSMutableArray arrayWithCapacity:10];
        for (NSDictionary *d in arr) {
            NSInteger free_count = DICT_INTVAL(d, @"free_count");
            if (free_count == 0) {
                rs = [[KSDB db] executeQuery:@"select magzine_id from magzines where pub_date>=? and pub_date<=?",DICT_VAL(d, @"start_time"),DICT_VAL(d, @"end_time")];
            } else {
                rs = [[KSDB db] executeQuery:@"select magzine_id from magzines where pub_date >= ?  order by pub_date asc limit ?",DICT_VAL(d, @"start_time"), DICT_VAL(d, @"free_count")];
            }
            while (rs.next) {
                [allfree addObject:DICT_VAL(rs.resultDict, @"magzine_id")];
            }
            [rs close];
        }
        NSString *user = [KSBootstrap currentUser];
        [[KSDB db] executeUpdate:@"delete from my_free where user_email=?",user];
        for (NSNumber *magid in allfree) {
            [[KSDB db] executeUpdate:@"insert into my_free(user_email,issue_number)values(?,?)",user,magid];
        }
    }
}
@end
