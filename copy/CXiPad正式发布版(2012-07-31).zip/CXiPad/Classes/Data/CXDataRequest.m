//
//  CXDataRequest.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 12/24/11.
//  Copyright (c) 2011 KSMobile. All rights reserved.
//

#import "CXDataRequest.h"
#import "KSDB.h"
#import "UIDeviceAdditions.h"
#import "UserHelper.h"

@implementation CXDataRequest

@end

@implementation CXLoginDataRequest

- (KSRequestMethod)getRequestMethod{
	return KSRequestMethodPost;
}

- (NSDictionary*)getStaticParams{
    return nil;
}

- (NSString*)getRequestUrl{
    return @"http://user.caixin.com/auth/login_ipad";
}
- (void)processResult{
    NSInteger result = [[self.resultDict objectForKey:@"result"] intValue];
    if (result == 0) {
        _requestResult = [[KSRequestResult alloc] initWithCode:0 withMessage:@"用户无效"];
        if (![_requestResult isSuccess]) {
            KSDERROR(@"request[%@] failed with message %@",self,_requestResult.code);
        }else {
            KSDINFO(@"request[%@] :%@" ,self ,@"success");
        }
    }
}

@end

@implementation CXRegDataRequest
- (KSRequestMethod)getRequestMethod{
	return KSRequestMethodPost;
}
- (NSString*)getRequestUrl{
    return @"http://user.caixin.com/auth/register_ipad";
}
- (NSStringEncoding)getResponseEncoding{
    //return CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingUTF8);
    return NSUTF8StringEncoding;
}
- (void)requestFinished:(ASIFormDataRequest*)request {
    [self showIndicator:NO];
	NSString *responseString;
    if (request.allowCompressedResponse) {
        responseString = [[NSString alloc] initWithData:[request responseData] encoding:[self getResponseEncoding]];
    }else{
        responseString = [[NSString alloc] initWithData:[request rawResponseData] encoding:[self getResponseEncoding]];
    }
    
	[self handleResultString:responseString];
    RELEASE_SAFELY(responseString);
    
	[self release];
}

@end

@implementation CXRetrievePassDataRequest
//- (KSRequestMethod)getRequestMethod {
//    return KSRequestMethodPost;
//}
- (NSString *)getRequestUrl {
    return @"http://user.caixin.com/usermanage/iphonepwd/?";
}

@end

/////////////////////////////////////////////////////////////////////
//激活用户
@implementation CXActiveUserDataRequest

- (KSRequestMethod)getRequestMethod {
    return KSRequestMethodGet;
}
- (NSString *)getRequestUrl {
    return @"http://user.caixin.com/auth/iphonesend/?";
}


@end


//推送消息设置
@implementation CXPushSetDataRequest

- (KSRequestMethod)getRequestMethod {
    return KSRequestMethodPost;
}
- (NSString *)getRequestUrl {
    return SERVER_URL(@"/pushset/");
}

@end


/////////////////////////////////////////////////////////////////////
//加载赠送的杂志
@implementation CXLoadFreeMagazineDataRequest 
- (KSRequestMethod)getRequestMethod {
    return KSRequestMethodGet;
}
//- (NSString *)getRequestUrl {
//    return SERVER_URL(@"fireEvent/");
//}

@end

/////////////////////////////////////////////////////////////////////
//触发赠送事件
@implementation CXFireDonateEventDataRequest

@end

/////////////////////////////////////////////////////////////////////
//触发赠送事件
@implementation CXFireSubscriptionEventDataRequest

@end

/////////////////////////////////////////////////////////////////////
//消费订阅卡
@implementation CXGiftCardDataRequest


@end



/////////////////////////////////////////////////////////////////////
//获取评论列表
@implementation CXListCommentDataRequest


@end


/////////////////////////////////////////////////////////////////////
//发表评论列表
@implementation CXPostCommentDataRequest
- (KSRequestMethod)getRequestMethod {
    return KSRequestMethodPost;
}
- (NSString *)getRequestUrl {
    return SERVER_URL(@"/comment/0");
}

@end

////////////////////////////////////////////////////////////////////
//获取财新网评论列表
@implementation CXListCaixinCommentDataRequest 
- (KSRequestMethod)getRequestMethod {
    return KSRequestMethodGet;
}    
- (NSString *)getRequestUrl {
    return @"http://comment.caixin.com/interface/ipad/getCommentsListByTargetd.php?";
}


@end

/////////////////////////////////////////////////////////////////////
//发表财新评论列表
@implementation CXPostCaixinCommentDataRequest
- (KSRequestMethod)getRequestMethod {
    return KSRequestMethodPost;
}

- (NSString *)getRequestUrl {
    return @"http://comment.caixin.com/interface/ipad/addComment.php?";
}


@end

/////////////////////////////////////////////////////////////////////
//注册设备UDID赠送杂志
@implementation CXRegDeviceUDIDRequest
- (NSString *)getRequestUrl {
    NSString *udid = [[KSBootstrap dataCenter] valueForKey:@"udid"];
    if (udid == nil) {
        udid = [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier];
        [[KSBootstrap dataCenter] setValue:@"udid" forKey:udid];
    }
    return SERVER_URL(@"/regDeviceUDID/%@/%@",MAGZINE_TYPE,udid);
}
- (void)processResult{
    NSDictionary *resultData = self.resultDict;//[self.resultDict objectForKey:@"result"];
//    if (resultData) {
//        _requestResult = [[KSRequestResult alloc] initWithCode:[resultData objectForKey:@"code"] 
//                                                   withMessage:[resultData objectForKey:@"msg"]];
//        if (![_requestResult isSuccess]) {
//            KSDERROR(@"request[%@] failed with message %@",self,_requestResult.code);
//        }else {
//            KSDINFO(@"request[%@] :%@" ,self ,@"success");
//        }
//    }
//    NSString *udid = [[KSBootstrap dataCenter] valueForKey:@"udid"];
//    if (udid == nil) {
//        udid = [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier];
//        [[KSBootstrap dataCenter] setValue:@"udid" forKey:udid];
//    }
//    if ([[_resultDict objectForKey:@"error"] intValue] == 0) {
//        //NSString *ids = [_resultDict objectForKey:@"periodical_ids"];
//        [[KSDB db] executeUpdate:@"delete from device_udid where device_udid=?",udid];
//        [[KSDB db] executeUpdate:@"insert into device_udid(device_udid,periodical_ids,create_time)values(?,?,?)",udid, [_resultDict objectForKey:@"periodical_ids"],INTEGER([[NSDate date] timeIntervalSince1970])];
//    }
    [UserHelper saveMyFreeToDB:resultData];
}

@end


/////////////////////////////////////////////////////////////////////
//注册设备UDID赠送杂志
@implementation CXGetFullContentRequest
- (NSString *)getRequestUrl {
    KSDINFO(@"%@", SERVER_URL(@"/shareContent/%d",_articleId));
    return SERVER_URL(@"/shareContent/%d",_articleId);
}
- (void)doRequestWithParams:(NSDictionary*)params{	
    _articleId = [[params objectForKey:@"articleId"] intValue];
    [super doRequestWithParams:nil];
}

- (NSStringEncoding)getResponseEncoding{
    //return CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingUTF8);
    return NSUTF8StringEncoding;
}

- (BOOL)handleResultString:(NSString*)resultString{
    NSString *trimmedString = [resultString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    RELEASE_SAFELY(_resultString)
	_resultString = [trimmedString retain];
	if (!_resultString || [_resultString length] == 0) {
		KSDERROR(@"!empty response error with Request:%@",[self class]);
        RELEASE_SAFELY(_resultString)
        _resultString = [[NSString alloc] initWithString:@"{\"data\":\"\"}"];
		//return NO;
	}
    RELEASE_SAFELY(_resultDict);
    if(_delegate && [_delegate respondsToSelector:@selector(requestDidFinished:)]){
        [_delegate requestDidFinished:self];
    }
    return YES;
}

@end

/////////////////////////////////////////////////////////////////////
//检查是否为订阅卡用户
@implementation CXCheckGiftcardUserRequest
- (KSRequestMethod)getRequestMethod {
    return KSRequestMethodGet;
}

@end

/////////////////////////////////////////////////////////////////////
//应用推荐
@implementation CXAppRecommendRequest
- (KSRequestMethod)getRequestMethod {
    return KSRequestMethodPost;
}

- (NSString *)getRequestUrl {
    return SERVER_RECOMMEND_URL;
}
@end
/////////////////////////////////////////////////////////////////////
//公告
@implementation CXNoticeRequest
- (KSRequestMethod)getRequestMethod {
    return KSRequestMethodPost;
}

- (NSString *)getRequestUrl {
    return SERVER_NOTICE_URL;
}
@end