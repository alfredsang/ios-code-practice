//
//  UserHelper.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 1/11/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserHelper : NSObject

+ (void)saveMyFreeToDB:(NSDictionary *)dict;
+ (void)saveUserCardToDB:(NSDictionary *)dict;
+ (void)convFreeLogic2MagId;
@end
