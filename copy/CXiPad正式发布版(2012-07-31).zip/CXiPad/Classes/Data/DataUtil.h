//
//
//
//  KSMobile.
//  

#import <Foundation/Foundation.h>
#import "CJSONDeserializer.h"

@interface DataUtil : NSObject {

}
+ (BOOL)addSkipBackupAttributeToItemAtURL:(NSURL *)URL;
+ (BOOL)addSkipBackupAttributeToItemAtFilePath:(NSString *)filePath;

+ (NSString *)getPathByFileName:(NSString *)fileName;
+ (NSString *)getCachePathByFileName:(NSString *)fileName;
+ (NSString *)getPathByFileNameInBundle:(NSString *)fileName;

//
// 缓存图片，存储图片
//
+ (NSString *)convertURL2CachefilePath:(NSString *)imageurl;
+ (NSString *)urlToPah:(NSString *)url;
+ (NSString *)urlToPah:(NSString *)url size:(CGSize)newSize;
+ (BOOL)saveNSDataToDisk:(NSData *)data fullPath:(NSString *)path;
+ (BOOL)saveImageToDisk:(UIImage *)img fullPath:(NSString *)path;

//
// 验证邮箱合法性
//
+ (BOOL)validateEmail:(NSString *)candidate;

//计算文件夹大小
+ (unsigned long long int)folderSize:(NSString *)folderPath;
+ (NSString *)getHRFolderSize:(NSString *)folderPath;

+ (NSString *)convertArrayToString:(NSArray *)array;
+ (NSArray *)convertStringToArray:(NSString *)string;

+ (NSString *)encodeURL:(NSString *)url;
+ (NSString *)base64EncodingStringWithData:(NSData *)data lineLength:(unsigned int)lineLength;


//=================================================
//+ (NSInteger)getCurrentMagazineNumber;

//+ (NSInteger)getCurrentPurchasedMagazineNumber;

//+ (BOOL)processMagazineListFromServer:(NSDictionary *)dataDict;
//+ (BOOL)processBoughtData:(NSDictionary *)dataDict;

//+ (NSDictionary *)getCurrentMagazineDict;
//+ (Magazine *)getCurrentMagazine;


+ (void)saveLoginData;
+ (void)deleteLoginData;

+ (void)savePurchaseData;
+ (void)saveCurrnetPurchaseData;
+ (void)saveDownloadData;

//硬编码生成样刊，已使用magazineFromLocal方法代替
//+ (NSDictionary *)getSwatch;
//从本地文件系统json.js生成杂志对象
//+ (NSDictionary *)magazineFromLocal:(NSString *)magIdStr;
//返回当前购买杂志的app store ID
//+ (NSString *)getCurrentSKIdentifier;
//返回当前杂志对应的PopAd

/*!
    @function
    @abstract   
    @discussion 设置当前阅读的数据，从本地文件系统Document读出JSON对象分别设到DataEnv中去
    @param      
    @result     
*/
//+ (void)setReadableJournal;
//+ (void)releaseReadableJournal;

//+ (UIImage *)thumbnailWithArticleId:(NSString *)articleId;
//+ (NSString *)titleWithArticleId:(NSString *)articleId;

//+ (NSInteger)articleIndexWithId:(NSInteger)articleId;
//+ (NSInteger)freeArticleIndexWithId:(NSInteger)articleId;
//+ (NSInteger)articleIndexWithCatalogId:(NSInteger)catalogId;


//删除杂志数据 (下载的文件，记录的已购买数据、记录的已下载数据)
//+ (void)deleteDownloadedMagazine:(NSInteger)magId;



//+ (void)savePurchasedMagazine:(NSInteger)magazineId;
//+ (void)saveSubscribe;

//获取文章信息
//+ (NSDictionary *)loadLocalArticleMeta:(NSInteger)articleId;
//+ (BOOL)isAd:(NSInteger)articleId;
@end
