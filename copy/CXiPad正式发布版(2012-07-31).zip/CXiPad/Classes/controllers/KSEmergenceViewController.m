//
//  KSEmergenceViewController.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 1/4/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KSEmergenceViewController.h"

@implementation KSEmergenceViewController

//- (void)dealloc {
//    
//    [super dealloc];
//}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle


// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
    [super loadView];
    UIImageView *background = [[UIImageView alloc] initWithImage:[UIImage imageNamedNocache:@"welcome_bg.png"]];
    //UIImageView *background = [[UIImageView alloc] initWithImage:[UIImage imageNamedNocache:@"Default-Portrait.png"]];
    background.tag = 1010;
    background.frame = CGRectMake(0, 0, 768, 1024);
    [self.view addSubview:background];
    [background release];
    UIImageView *logo = [[UIImageView alloc] initWithImage:[UIImage imageNamedNocache:@"welcome_logo.png"]];
    logo.tag = 1011;
    //logo.frame = CGRectMake(279, 1024-507-222, 210, 222);
    logo.frame = CGRectMake(279, 190, 210, 222);
    [self.view addSubview:logo];
    [logo release];
}



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
    [UIView animateWithDuration:3 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [[self.view viewWithTag:1010] setTransform:CGAffineTransformMakeScale(1.8,1.8)];
        [self.view viewWithTag:1011].frame = CGRectMake(279, 100, 210, 222);
    } completion:^(BOOL finished) {
        [self.view removeFromSuperview];
        [[KSMainController mainController] presentMagzineViewController];
    }];
}


- (void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration{
    NSDictionary *userInfo = [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithInt:toInterfaceOrientation], @"to",
                              [NSNumber numberWithInt:[[UIApplication sharedApplication] statusBarOrientation]], @"from",
                              nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"ROTATION_OCCURS" object:self userInfo:userInfo];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    //return (interfaceOrientation == UIInterfaceOrientationPortrait);
    return (interfaceOrientation==UIDeviceOrientationPortrait || interfaceOrientation==UIDeviceOrientationPortraitUpsideDown);
}

@end
