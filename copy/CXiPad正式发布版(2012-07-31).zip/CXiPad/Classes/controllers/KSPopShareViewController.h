//
//  KSPopShareViewController.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 1/4/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SHK.h"

@interface KSPopShareViewController : UIViewController{
    SHKShareType type;
    NSMutableArray *_sharers;
    SHKItem *_item;
}
@property(nonatomic,retain)SHKItem *item;
@property(nonatomic, assign)SHKShareType type;

- (id)initWithShareType:(SHKShareType)shareType;
- (id)initWithSHKItem:(SHKItem *)i;
@end
