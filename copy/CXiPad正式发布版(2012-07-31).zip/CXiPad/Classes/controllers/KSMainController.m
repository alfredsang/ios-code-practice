//
//  KSMainController.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 1/4/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KSMainController.h"

#import "KSArticleViewController.h"
#import "KSMagzineViewController.h"
#import "KSEmergenceViewController.h"
#import "KSAppDelegate.h"
#import "KSUIWindow.h"

@implementation KSMainController
@synthesize viewControllers = _viewControllers;

+ (KSMainController *)mainController {
    return (KSMainController *)(((KSAppDelegate *)[UIApplication sharedApplication].delegate).mainController);
}
- (void)dealloc {
    [_viewControllers dealloc];
    [super dealloc];
}

- (id)init
{
    self = [super init];
    if (self) {
        _controllerIndex = 0;
        _viewControllers = [[NSMutableArray alloc] initWithCapacity:2];
        for (int i = 0; i<3; i++) {
            [_viewControllers addObject:[NSNull null]];
        }
    }
    
    return self;
}

//移除view
- (void)removeView:(NSNumber *)index {
    //NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    UIViewController *controller = [_viewControllers objectAtIndex:[index intValue]]; 
    if (controller && (NSNull *)controller != [NSNull null] ) {
        if (controller.view.superview) {
            [controller.view removeFromSuperview];
        }
    }
    //[pool release];
}
//移除view,清除controller
- (void)removeViewController:(NSInteger)index {
    UIViewController *controller = [_viewControllers objectAtIndex:index];
    if (controller && (NSNull *)controller != [NSNull null] ) {
        if (controller.view.superview) {
            [controller.view removeFromSuperview];
        }
        [_viewControllers replaceObjectAtIndex:index withObject:[NSNull null]];
    }
}
#pragma mark -
- (UIViewController *)activeController {
    UIViewController *v = [_viewControllers objectAtIndex:_controllerIndex];
    if ((NSNull *)v == [NSNull null]) {
        return nil;
    }
    return v;
}

//开机动画
- (void)presentEmergenceViewController {
    ((KSUIWindow *)[UIApplication sharedApplication].keyWindow).tapDelegate = nil;
    _controllerIndex = 0;
    UIWindow *window = [[[UIApplication sharedApplication] windows] objectAtIndex:0];
    KSEmergenceViewController *c = [_viewControllers objectAtIndex:_controllerIndex];
    
    if ((NSNull *)c == [NSNull null]) {
        c = [[KSEmergenceViewController alloc] initWithNibName:nil bundle:nil];
        [_viewControllers replaceObjectAtIndex:_controllerIndex withObject:c];
        [c release];
    }
    window.rootViewController = c;
    
}

//杂志列表界面
- (void)presentMagzineViewController {
    ((KSUIWindow *)[UIApplication sharedApplication].keyWindow).tapDelegate = nil;
    //开机动画的controller已没用，释放掉
    [self removeViewController:0];
    //阅读viewcontroller释放掉
    [self removeViewController:2];
    //
    _controllerIndex = 1;
    UIWindow *window = [[[UIApplication sharedApplication] windows] objectAtIndex:0];
    KSMagzineViewController *c = [_viewControllers objectAtIndex:_controllerIndex];
    if ((NSNull *)c == [NSNull null])
    {
        c = [[KSMagzineViewController alloc] init];
        [_viewControllers replaceObjectAtIndex:_controllerIndex withObject:c];
        [c release];
    }
    window.rootViewController = c;
}

//阅读界面
- (void)presentArticleViewController {
    [[self activeController].view removeFromSuperview];
    
    _controllerIndex = 2;
    UIWindow *window = [[[UIApplication sharedApplication] windows] objectAtIndex:0];
    KSArticleViewController *c = [_viewControllers objectAtIndex:_controllerIndex];
    if ((NSNull *)c == [NSNull null]) {
        c = [[KSArticleViewController alloc] init];
        [_viewControllers replaceObjectAtIndex:_controllerIndex withObject:c];
        [c release];
    }
    window.rootViewController = c;
    
    ((KSUIWindow *)[UIApplication sharedApplication].keyWindow).tapDelegate = c;
}
- (void)presentArticleViewControllerWithMagId:(NSInteger)magId ArticleId:(NSInteger)aId from:(NSString *)from{
//    UIImage *img = [UIUtil snapshotScreen];
//    if ([[NSFileManager defaultManager] fileExistsAtPath:KSPathForCachesResource(@"main.png")]) {
//        [[NSFileManager defaultManager] removeItemAtPath:KSPathForCachesResource(@"main.png") error:nil];
//    }
//    if ([self activeController].interfaceOrientation == UIInterfaceOrientationLandscapeLeft||[self activeController].interfaceOrientation == UIInterfaceOrientationPortraitUpsideDown) {
//        
//        [[KSBootstrap dataCenter] setValue:@"1" forKey:@"KEY_MAIN_IMG_SHOULD_PI"];
//    }else {
//        [[KSBootstrap dataCenter] removeObjectForKey:@"KEY_MAIN_IMG_SHOULD_PI"];
//    }
//    [UIImagePNGRepresentation(img) writeToFile: KSPathForCachesResource(@"main.png") atomically:YES];

//    [[self activeController].view removeFromSuperview];
    
    [_viewControllers replaceObjectAtIndex:2 withObject:[NSNull null]];
    
    _controllerIndex = 2;
    UIWindow *window = [[[UIApplication sharedApplication] windows] objectAtIndex:0];
    KSArticleViewController *c = [_viewControllers objectAtIndex:_controllerIndex];
    
    if ((NSNull *)c == [NSNull null]) 
    {
        c = [[KSArticleViewController alloc] init:magId articleId:aId];
        if (from == nil)
        {
            c.launchFrom = 0;
        }
        else if ([from isEqualToString:@"collection"]) 
        {
            c.launchFrom = 1;
        }
        else if([from isEqualToString:@"search"])
        {
            c.launchFrom = 2;
        }
        else if([from isEqualToString:@"bookShelf"])
        {
            c.launchFrom = 3;
        }
        [_viewControllers replaceObjectAtIndex:_controllerIndex withObject:c];
        [c release];
    }
    window.rootViewController = c;
//    [UIUtil addAnimationShow:c.view];
}
- (KSModelMagzine *)nextMagzine:(NSInteger)magId {
    NSArray *array = ((KSMagzineViewController *)[_viewControllers objectAtIndex:1]).magzines;
    if ([array count] && ((KSModelMagzine *)[array lastObject]).magzineId == magId) {
        return nil;
    }
    int i = 0;
    for (KSModelMagzine * mag in array ) {
        i++;
        if (mag.magzineId == magId) {
            return [array objectAtIndex:i+1];
        }
        
    }
    return nil;
}
- (KSModelMagzine *)prevMagzine:(NSInteger)magId {
    NSArray *array = ((KSMagzineViewController *)[_viewControllers objectAtIndex:1]).magzines;
    if ([array count] && ((KSModelMagzine *)[array objectAtIndex:0]).magzineId == magId) {
        return nil;
    }
    int i = 0;
    for (KSModelMagzine * mag in array ) {
        i++;
        if (mag.magzineId == magId) {
            return [array objectAtIndex:i-1];
        }
        
    }
    return nil;
}
@end
