//
//  KSArticleChildViewController.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 2/9/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSModelArticle.h"

@interface KSArticleChildViewController : UIViewController {
    UIScrollView *_scrollView;
    
    NSMutableArray *_dataList;
    NSMutableArray *_cacheViewsList;
    
    NSInteger _pageCount;
    NSInteger _pageIndex;
    CGFloat _pagewidth;
    
    
    BOOL _rotating;
    BOOL _scrolling;

}

@end
