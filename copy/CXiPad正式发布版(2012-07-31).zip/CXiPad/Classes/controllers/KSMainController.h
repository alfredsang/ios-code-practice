//
//  KSMainController.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 1/4/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KSModelMagzine.h"
#import "KSModelCatalog.h"


@interface KSMainController : NSObject {
    NSMutableArray *_viewControllers;
    NSInteger _controllerIndex;
    
}

@property(nonatomic, retain)NSMutableArray *viewControllers;

+ (KSMainController *)mainController;

//开机动画
- (void)presentEmergenceViewController;
//杂志列表界面
- (void)presentMagzineViewController;
//阅读界面
- (void)presentArticleViewController;
- (void)presentArticleViewControllerWithMagId:(NSInteger)magId ArticleId:(NSInteger)aId from:(NSString *)from;

- (KSModelMagzine *)nextMagzine:(NSInteger)magId;
- (KSModelMagzine *)prevMagzine:(NSInteger)magId;

//分享popover界面
//- (void)dismissPopShareAnimated:(BOOL)anim;

//当前顶层ViewController
- (UIViewController *)activeController;
@end
