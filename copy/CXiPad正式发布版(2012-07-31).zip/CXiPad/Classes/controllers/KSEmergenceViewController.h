//
//  KSEmergenceViewController.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 1/4/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KSEmergenceViewController : UIViewController

@end
