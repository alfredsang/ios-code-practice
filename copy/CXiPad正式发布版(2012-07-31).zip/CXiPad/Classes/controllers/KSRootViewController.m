//
//  KSRootViewController.m
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-27.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSRootViewController.h"

@implementation KSRootViewController
- (id) init{
    if(self = [super init]){
        
    }
    return self;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

//*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
    [super loadView];
    UIImageView *background = [[UIImageView alloc] initWithImage:[UIImage imageNamedNocache:@"welcome_bg.png"]];
    //UIImageView *background = [[UIImageView alloc] initWithImage:[UIImage imageNamedNocache:@"Default-Portrait.png"]];
    background.tag = 1010;
    background.frame = CGRectMake(0, 0, 768, 1024);
    [self.view addSubview:background];
    [background release];
    UIImageView *logo = [[UIImageView alloc] initWithImage:[UIImage imageNamedNocache:@"welcome_logo.png"]];
    logo.tag = 1011;
    //logo.frame = CGRectMake(279, 1024-507-222, 210, 222);
    logo.frame = CGRectMake(279, 197, 210, 222);
    [self.view addSubview:logo];
    [logo release];
    //[self performSelector:@selector(presentMagzineViewController) withObject:self afterDelay:3];
}

- (void) presentMagzineViewController{
    UIWindow *window = [[[UIApplication sharedApplication] windows] objectAtIndex:0];
    KSMagzineViewController *c = [[KSMagzineViewController alloc] init];
    window.rootViewController = c;
    [c release];
}

- (void) presentArticleViewController{
    UIWindow *window = [[[UIApplication sharedApplication] windows] objectAtIndex:0];
    KSArticleViewController *c = [[KSArticleViewController alloc] init];
    window.rootViewController = c;
    [c release];
}

//*/

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
//    [self presentArticleViewController];
//    return;
    [UIView animateWithDuration:3 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [[self.view viewWithTag:1010] setTransform:CGAffineTransformMakeScale(1.8,1.8)];
        [self.view viewWithTag:1011].frame = CGRectMake(279, 100, 210, 222);
    } completion:^(BOOL finished) {
        [self.view removeFromSuperview];
        [self presentMagzineViewController];
    }];
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration{
    NSDictionary *userInfo = [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithInt:toInterfaceOrientation], @"to",
    [NSNumber numberWithInt:[[UIApplication sharedApplication] statusBarOrientation]], @"from",
                              nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"ROTATION_OCCURS" object:self userInfo:userInfo];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    if(interfaceOrientation==UIInterfaceOrientationLandscapeLeft || interfaceOrientation==UIInterfaceOrientationLandscapeRight)
    return NO;
    return YES;
}

@end
