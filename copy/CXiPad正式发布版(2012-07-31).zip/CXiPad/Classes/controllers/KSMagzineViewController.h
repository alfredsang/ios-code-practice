//
//  KSMagzineViewController.h
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSArticleViewController.h"
#import "KSMagzineBackgroundView.h"
#import "KSMagzineFooterBarView.h"
#import "KSMagzineMainView.h"
#import "KSMagzineDatasource.h"
#import "KSModelFactory.h"
#import "KSAppStoreProxy.h"
#import "KSLoginView.h"
#import "KSCollectionView.h"
#import "KSSearchView.h"
#import "KSSettingView.h"
#import "CXAccountView.h"
#import "CXDataRequest.h"
#import "KSNoPermissionAlertView.h"
#import "KSHelpView.h"
#import "KSMagazineBookShelfView.h"

@interface KSMagzineViewController : UIViewController<KSMagzineDatasource,KSDataRequestDelegate>{
    KSMagzineBackgroundView *background;
    KSMagzineFooterBarView *footer;
    KSMagzineMainView *main;
    KSLoginView *_loginView;
    KSCollectionView *collection;
    KSSearchView *search;
    KSSettingView *_settingView;
    CXAccountView *_accountView;
    KSHelpView  *_helpView;
    KSMagazineBookShelfView *_bookShelfView;
    KSMagazineBookShelfView *_bookStoreView;
    NSArray *_magzines;
    
    KSNoPermissionAlertView *_noPermissionAlertView;
    
    BOOL _purchasing;
    BOOL _viewLoaded;
    
    BOOL _hasSubscription;

    

}
@property(nonatomic, assign)BOOL purchaseing;
@property(nonatomic, retain)KSMagzineFooterBarView *footer;
@property(nonatomic, retain)KSMagzineMainView *main;

- (void) showView:(NSString *)type;
- (CGRect) CGRectFull;

- (void) registerUser:(NSString *)email name:(NSString *)name pwd:(NSString *) pwd pwd_repeat:(NSString *) pwd_repeat verify_code:(NSString *) code;
- (void) gotoArticle:(NSInteger)articleId magzineId:(NSInteger)magzineId from:(NSString *)from;

- (KSModelMagzine *) currentMagzine;
- (void) setCurrentMagzine:(KSModelMagzine *)magzine;

- (void) buy:(UIButton*)btn;
- (void) try_read;

- (void)showRegSuccessViewWithMail:(NSString *)email password:(NSString *)pwd;
- (void)dismissRegSuccView;
- (void)showRegView;
- (void)showTrievePassView;

- (void)loginUser:(NSString *)user;
- (void)loginUserQuiet:(NSString *)user;
- (void)logout;
- (void) showLogin;
- (void)showSetting;
- (void)showAccountView;
- (void)showAccountViewFromSetting;
- (void)showAccountViewFromLogin;
- (void)showSubscriptionView;
- (void) showHelpViews:(id)sender;
- (NSObject *) getUser;

-(void)showBookShelf; //cxy

- (void)savePushSettingToServer;
- (void)storageCleaned;
- (void)openMail:(NSString *)url;

//无权限提示
- (void)showNoPermissionView:(KSModelMagzine *)mag delegate:(id<KSNoPermissionAlertViewDelegate>)delegate;
- (void)dismissNoPermissionView;
//下载杂志
/**
 *	@brief	从搜索页下载杂志
 *
 *	@param 	magazineId 	要下载的杂志ID
 */
-(void)downloadTheMagazineWithId:(NSInteger)magazineId;
/**
 *	@brief	按年份筛选
 *
 *	@param 	year 	年份
 *
 *	@return	数组
 */
-(NSMutableArray*)loadMagazineByYear:(NSInteger)year;
/**
 *	@brief	获取年份数组
 *
 *	@return	年份数组
 */
-(NSMutableArray*)getMagazinesYear;
-(void)selectCoverMagazineAtIndex:(NSInteger)index  magazine:(KSModelMagzine*)magazine;
-(void)selectBookShelfMagazineAtIndex:(NSInteger)index  magazine:(KSModelMagzine*)magazine;
- (void) s_1y;
- (void)whenMagzineDeleted:(KSModelMagzine *)magazine;
-(void)startDownLoadCoverImage;
@end
