//
//  KSArticleViewController.m
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSArticleViewController.h"
#import "KSModelCollectionItem.h"
#import "KSDownloadManager.h"
#import "KSPopShareViewController.h"
#import "KSGetMagzinesOpertaion.h"
#import "KSMainController.h"
#import "KSArticleHelpView.h"
#import "KSArticleChildrenView.h"
#import "KSArticleMapView.h"
#import "KSMagzineViewController.h"

#define TAG_DOWNLOAD_VIEW 9000

#define AUTO_HIDEREADBAR_TIME 10

@interface  KSArticleViewController()
- (void) showHeaderAndFooter;
- (void) hideHeaderAndFooter;

- (NSInteger)currentCatalogIndex;
- (void)articleLoaded;
- (void)layoutFooter;
@end


@implementation KSArticleViewController
@synthesize magzineId = _magzineId;
@synthesize currentPageIndex = _currentPageIndex;
@synthesize contentLengthOffsetArr;
@synthesize forceHideHeader = _forceHideHeader;
@synthesize launchFrom = _launchFrom;
@synthesize articlePageView = _articlePageView;
@synthesize readableArticlesArray = _readableArticlesArray;
@synthesize articles = _articles;
@synthesize headerHide = _headerHide;

-(id)init:(NSInteger)magzineId articleId:(NSInteger)articleId
{
    if(self = [super init]){
        _articleId = articleId;
        _magzineId = magzineId;
        _currentMagazine = [[KSModelMagzine loadById:_magzineId] retain];
        [self articles];
        [self currentArticle];
    }
    return self;
}

- (void)dealloc{
    [KSBootstrap unlisten:NOTIFY_WINDOW_TOUCH_END target:self];
    if (_directoryListView)
    {
        RELEASE_SAFELY(_directoryListView);
    }
    footer.handler = nil;
    _commentView.controller = nil;
    _articleSearchView.controller = nil;
    
    RELEASE_SAFELY(_articlePageView);
    
    RELEASE_SAFELY(_tmpMainImageView);
    RELEASE_SAFELY(_currentMagazine);
    RELEASE_SAFELY(_commentView);
    RELEASE_SAFELY(_noPermissionAlertView);
    RELEASE_SAFELY(_articleHelpView);
    RELEASE_SAFELY(_readableArticlesArray);
    RELEASE_SAFELY(_articleSearchView);
    RELEASE_SAFELY(_sharePopController);
    RELEASE_SAFELY(background);
    RELEASE_SAFELY(header);
    RELEASE_SAFELY(footer);
//    RELEASE_SAFELY(pagesScrollView);
    RELEASE_SAFELY(_articles);
    RELEASE_SAFELY(contentLengthOffsetArr);
    [super dealloc];
}


- (void)whenArticleDownload:(NSNotification *)notification{
    NSDictionary *data = notification.userInfo;
    RELEASE_SAFELY(_articles);
    _articles = [[KSModelArticle articlesInMagzine:_magzineId] retain];
    //KSModelMagzine *magzine = [KSModelMagzine loadById:_magzineId];
    //[progressView setProgress:magzine.downloadArticlesNumber allNums:magzine.articlesNumber];
    if (_articleId != [[data objectForKey:@"article_id"] intValue]) return;
    KSArticleDownloadingView *downView = (KSArticleDownloadingView *)[pagesScrollView viewWithTag:TAG_DOWNLOAD_VIEW];
    if(downView){
        [self loadPages];
    }
}
- (NSArray *)articles{

    if(!_articles)
    {
        _articles = [[KSModelArticle articlesInMagzine:_magzineId] retain];
    }
    if (!_readableArticlesArray)
    {
        _readableArticlesArray = [[NSMutableArray alloc] init];
    }
    else 
    {
        [_readableArticlesArray removeAllObjects];
    }
    RELEASE_SAFELY(contentLengthOffsetArr);
    contentLengthOffsetArr = [[NSMutableArray arrayWithCapacity:[_articles count]+1] retain];
    int iter = 0, contentLen = 0;
    for (KSModelArticle *item in _articles) 
    {
        //计算contentLengthOffset
        //[contentLengthOffsetArr insertObject:INTEGER(contentLen) atIndex:iter];
        [contentLengthOffsetArr addObject:INTEGER(contentLen)];
        contentLen += MAX(ceil(item.contentLength/PAGE_CHAR_COUNT),1);
        iter++;
        if ([self currentMagzine].isMybook || item.isFree) 
        {
            [_readableArticlesArray addObject:item];
        }
    }
    //[contentLengthOffsetArr insertObject:INTEGER(contentLen) atIndex:iter];
    [contentLengthOffsetArr addObject:INTEGER(contentLen)];

    return _articles;
}

- (void)loadPages{
    int currentPage = pageControl.currentPage;
    //[pagesScrollView loadPages:[self articles] current:currentPage];
    [_articlePageView moveToViewAtPage:pageControl.currentPage animated:NO];
//    [pagesScrollView loadPages:_readableArticlesArray current:currentPage];
    [self changeFooterState];

    [self.view bringSubviewToFront:header];
    [header refresh];
    [self articleLoaded];
    [self.view bringSubviewToFront:footer];
    [self.view bringSubviewToFront:progressView];
}
- (void)loadPagesFromCatalog{
    [self loadPages];
}
#pragma mark - View lifecycle

- (void)loadView {
    [super loadView];
    background = [[KSArticleBackgroundView alloc] initWithFrame:self.view.bounds];
	[self.view addSubview:background];
	self.view.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    //header = [[KSArticleHeaderBarView alloc] initWithFrame:CGRectMake(0, 0, self.view.width, 74) handler:self];
    header = [[KSArticleHeaderBarView alloc] initWithFrame:CGRectMake(0, 0, self.view.width, 34) handler:self]; //防止遮挡二级目录的点击响应
    [self.view addSubview:header];
    //footer = [[KSArticleFooterBarView alloc] initWithFrame:CGRectMake(0, self.view.height-51, self.view.width, 51)  handler:self];
    footer = [[KSArticleFooterBarView alloc] initWithFrame:CGRectMake(0, ([UIUtil currentOrientation]==0?1024:768)-50, self.view.width, 50)  handler:self];
    [self.view addSubview:footer];
    
    _articlePageView = [[KSArticlePagesView alloc] initWithFrame:self.view.bounds articles:_readableArticlesArray];
    _articlePageView.handler = self;
    _articlePageView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self.view addSubview:_articlePageView];
    
//    pagesScrollView = [[KSArticlePagesScrollView alloc] initWithFrame:self.view.bounds handler:self];
//    pagesScrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
//    [self.view addSubview:pagesScrollView];
    
//    progressView = [[KSArticleProgressView alloc] initWithFrame:CGRectMake(803-1024+768, 184, 186, 48)];
//    progressView.autoresizingMask = UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleLeftMargin;
//    [self.view addSubview:progressView];
//    [progressView setProgress:0 allNums:0];
    
    pageControl = [[UIPageControl alloc] initWithFrame:CGRectZero];
    pageControl.hidden = YES;
    pageControl.numberOfPages = _readableArticlesArray.count;
    pageControl.currentPage = [_readableArticlesArray indexOfObject:[self currentArticle]];
    [self.view addSubview:pageControl];
    [self hideHeaderAndFooter];
    [self loadPages];
    
    [KSBootstrap listen:NOTIFY_WINDOW_TOUCH_END target:self selector:@selector(mainViewWasTapped:)];
    
    //UIGestureRecognizer
    UIPanGestureRecognizer *tripleSwipGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(tripleSwipped:)];
    tripleSwipGesture.delegate = self;
    tripleSwipGesture.minimumNumberOfTouches = 3;
    [self.view addGestureRecognizer:tripleSwipGesture];
    [tripleSwipGesture release];
    
    
}
- (void)tripleSwipped:(UIPanGestureRecognizer *)gesture {
    KSDINFO(@"....triple...");
    CGFloat rate = 0.1;
    if (gesture.state == UIGestureRecognizerStateBegan) {
        _articlePageView.userInteractionEnabled = NO;
        _panning = YES;
        if (!_tmpMainImageView) {
            //_tmpMainImageView = [[UIImageView alloc] initWithImage:[UIImage imageWithContentsOfFile:KSPathForCachesResource(@"1main.png")]];
            //_tmpMainImageView = [[UIImageView alloc] initWithImage:[UIImage imageWithContentsOfFile:KSPathForBundleResource(@"main.png")]];
            _tmpMainImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 768, 1024)];
            _tmpMainImageView.backgroundColor = [UIColor blackColor];
            [self.view addSubview:_tmpMainImageView];
            _tmpMainImageView.top = 0;
            _tmpMainImageView.right = 0;

        }
//        if ([[KSBootstrap dataCenter] valueForKey:@"KEY_MAIN_IMG_SHOULD_PI"] != nil) {
//            CGAffineTransform transform = CGAffineTransformMakeRotation(M_PI);
//            [_tmpMainImageView setTransform:transform];
//        }
        if (_tmpMainImageView.width != ([UIUtil currentOrientation]==0?768:1024)) {
//            if ([[KSBootstrap dataCenter] valueForKey:@"KEY_MAIN_IMG_SHOULD_PI"] != nil) {
//                CGAffineTransform at =CGAffineTransformMakeRotation(M_PI/2);
//                [_tmpMainImageView setTransform:at];
//            } else {
//                CGAffineTransform at =CGAffineTransformMakeRotation(-M_PI/2);
//                [_tmpMainImageView setTransform:at];
//            }
            _tmpMainImageView.width = [UIUtil currentOrientation]==0?768:1024;
            _tmpMainImageView.height = [UIUtil currentOrientation]==0?1024:768;
            _tmpMainImageView.top = 0;
            _tmpMainImageView.right = 0;
        }
    } else if(gesture.state == UIGestureRecognizerStateChanged){
        CGPoint p = [gesture translationInView:gesture.view];
        [self.view bringSubviewToFront:_tmpMainImageView];
        //if (_tmpMainImageView.left <=0 || _tmpMainImageView.left >= [UIUtil currentOrientation]==0?1024:768) {
        CGFloat w =  [UIUtil currentOrientation]==0?768:1024;
        if (_articlePageView.left>= (-w) && _articlePageView.left<=w) {
            _articlePageView.left += p.x * rate;
            if (_articlePageView.left < 0) {
                _tmpMainImageView.left = _articlePageView.right;
            } else {
                _tmpMainImageView.right = _articlePageView.left;
            }
        }
        if (_articlePageView.left > w) {
            _articlePageView.left = w;
            _tmpMainImageView.left = 0;
        }
        if (_articlePageView.left < -w) {
            _articlePageView.left = -w;
            _tmpMainImageView.left = 0;
        }
    } else if(gesture.state == UIGestureRecognizerStateEnded) {
        _panning = NO;
        if (abs(_tmpMainImageView.left)<200.0f) {
            [[KSMainController mainController] presentMagzineViewController];
        } else {
            _articlePageView.left = 0;
            _articlePageView.userInteractionEnabled = YES;
            [_tmpMainImageView removeFromSuperview];
            RELEASE_SAFELY(_tmpMainImageView);
        }
    }
}
- (void)viewDidLoad {
    [super viewDidLoad];
    if(_articles.count==0){
        [KSBootstrap listen:NOTIFY_MAGZINE_DOWNLOADED target:self selector:@selector(whenMagzineDownloaded:)];
        KSGetMagzinesOpertaion *oper = [[KSGetMagzinesOpertaion alloc] init:[NSArray arrayWithObject:INTEGER(_magzineId)]];
        [[KSBootstrap operationQueue] addOperation:oper];
        [oper release];
    }else{
        NSInteger needDownNum = [[KSDB db] intForQuery:@"select count(*) from articles where magzine_id=? and is_download=0", INTEGER(_magzineId)];
        if(needDownNum<=0)return;
        [KSBootstrap listen:NOTIFY_ARTICLE_DOWNLOADED target:self selector:@selector(whenArticleDownload:)];
        KSGetMagzineArticlesOperation *oper = [[KSGetMagzineArticlesOperation alloc] init:_magzineId];
        [[KSBootstrap operationQueue] addOperation:oper];
        [oper release];    
    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

- (void)viewWillUnload{
    [super viewWillUnload];
    
}

- (void)viewWillAppear:(BOOL)animated
{   
    [self layoutFooter];
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    
    [super viewDidAppear:animated];
    _isDidAppear = YES;
}

- (void)viewWillDisappear:(BOOL)animated {
    [KSBootstrap unlisten:NOTIFY_ARTICLE_DOWNLOADED target:self];
    [KSBootstrap unlisten:NOTIFY_MAGZINE_DOWNLOADED target:self];
    
    _isDidAppear = NO;
	[super viewWillDisappear:animated];
    if (hideTimer) {
        [hideTimer invalidate];
        hideTimer = nil;
    }
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation{
}

- (void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration{
//    NSDictionary *userInfo = [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithInt:toInterfaceOrientation], @"to",
//                              [NSNumber numberWithInt:[[UIApplication sharedApplication] statusBarOrientation]], @"from",
//                              nil];
//    [[NSNotificationCenter defaultCenter] postNotificationName:@"ROTATION_OCCURS" object:self userInfo:userInfo];
    [UIUtil setOrientation:toInterfaceOrientation];
    [self layoutFooter];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return YES;
}

- (void)didReceiveMemoryWarning {
    RELEASE_SAFELY(_sharePopController);
    [_articlePageView didReceiveMemoryWarning];
    
    [super didReceiveMemoryWarning];
}
#pragma mark -
- (void)removeAllArticleViews {
    [_articlePageView removeAllPages];
}
#pragma mark - ChangeStage 
- (void)changeCollectState {
    [header changeCollectState:[KSModelCollectionItem isInCollection:_articleId]];
}
- (void)changeFooterState {
    NSInteger currentPage = pageControl.currentPage;
    if(currentPage > -1 && _readableArticlesArray.count > currentPage ) {
        //NSInteger offset = [[contentLengthOffsetArr objectAtIndex:currentPage] intValue];
        NSInteger offset = [[contentLengthOffsetArr objectAtIndex:[self currentCatalogIndex]] intValue];
        NSInteger allLen = MAX([[contentLengthOffsetArr lastObject] intValue], 1);
        //KSModelArticle *article = [articles objectAtIndex:currentPage];
        KSModelArticle *article = [_readableArticlesArray objectAtIndex:currentPage];
        footer.allLen = allLen;
        //定位当前目录条的位置及长度比例
        [footer lightRuler:1.0*offset/allLen width:1.0*MAX(ceil(article.contentLength/PAGE_CHAR_COUNT),1.0)/allLen];
    }
}
- (void)articleLoaded {
    //设置导航状态
//    if (pageControl.currentPage == 0) {//广告 or 封面 //[self currentArticle].articleId == 1||
//        _forceHideHeader = YES;
//        if (!_headerHide) {
//            [self hideHeaderAndFooter];
//        }
//    } else {
//        _forceHideHeader = NO;
//    }
    _forceHideHeader = NO;
    if( _articlePageView.pageIndex == pageControl.currentPage || _articlePageView.pageIndex < 0 || _articlePageView.pageIndex >= [_readableArticlesArray count])
		return;
	pageControl.currentPage = _articlePageView.pageIndex;
    //KSModelArticle *current = [[self articles] objectAtIndex:index]
    KSModelArticle *current = [_readableArticlesArray objectAtIndex:_articlePageView.pageIndex];
    _articleId = current.articleId;
    [header refresh];
    //[self performSelector:@selector(changeCollectState) withObject:nil afterDelay:0.1];
}

- (void)articleDidLoad:(NSInteger)index_ {
    //if( index_ == pageControl.currentPage || index_ < 0 || index_ >= [_readableArticlesArray count])
    if( index_ < 0 || index_ >= [_readableArticlesArray count])
		return;
    pageControl.currentPage = index_;
    KSModelArticle *current = [_readableArticlesArray objectAtIndex:_articlePageView.pageIndex];
    _articleId = current.articleId;
    //设置导航隐藏状态
//    if (pageControl.currentPage == 0) {//广告 or 封面 //[self currentArticle].articleId == 1||
//        _forceHideHeader = YES;
//        if (!_headerHide) [self hideHeaderAndFooter];
//    } else {
//        _forceHideHeader = NO;
//    }
    _forceHideHeader = NO;
    //设置底部目录状态
    [self changeFooterState];
    //设置收藏状态
    [header performSelector:@selector(refresh) withObject:nil afterDelay:0.1];
//    [header refresh];
    //分享状态
    header.btnShare.userInteractionEnabled = (current.artitype != 2);
    //目录页，自动隐藏header,Footer
    
//动画化隐藏header,Footer   
    if(current.artitype != 2){
     if (!_headerHide) footer.hidden = NO;
    }else {
        footer.hidden = YES;
    }
}

#pragma mark -
- (void) backToMagzineView{
    //artitype为2的文章为目录，需要返回目录，当lanchfrom为收藏即从收藏进来阅读，则需要立即退出
    [[KSDownloadManager sharedManager] cancelWaiting];
    [[KSMainController mainController] presentMagzineViewController];
    KSMagzineViewController * MagzineViewController = (KSMagzineViewController *)[[KSMainController mainController] activeController];
    [MagzineViewController showBookShelf];
//    if ([self currentArticle].artitype == 2 || _launchFrom != 0) { 
//        [[KSDownloadManager sharedManager] cancelWaiting];
//        [[KSMainController mainController] presentMagzineViewController];
//    } else {
//        NSInteger aId = -1;
//        NSInteger i = 0;
//        for (i =0; i<[_readableArticlesArray count]; i++) {
//            KSModelArticle *a = [_readableArticlesArray objectAtIndex:i];
//            if (a.artitype == 2) {
//                aId = a.articleId;
//                break;
//            }
//        }
//        if (aId == -1) {
//            [[KSDownloadManager sharedManager] cancelWaiting];
//            [[KSMainController mainController] presentMagzineViewController];
//        } else {
//            [self gotoPageWithIndex:i];
//        }
//    }
//    //[self dismissModalViewControllerAnimated:YES];
    
}
- (void)backToCatalog{
    //artitype为2的文章为目录，需要返回目录，当lanchfrom为收藏即从收藏进来阅读，则需要立即退出
//    if ([self currentArticle].artitype == 2 || _launchFrom != 0) {
//    if ([self currentArticle].artitype == 2) 
//    {
////        [[KSDownloadManager sharedManager] cancelWaiting];
////        [[KSMainController mainController] presentMagzineViewController];
//    } 
//    else 
//    {
        NSInteger aId = -1;
        NSInteger i = 0;
        for (i =0; i<[_articles count]; i++) {
            KSModelArticle *a = [_articles objectAtIndex:i];
            if (a.artitype == 2) {
                aId = a.articleId;
                break;
            }
        }
        if (aId == -1) {
//            [[KSDownloadManager sharedManager] cancelWaiting];
//            [[KSMainController mainController] presentMagzineViewController];
        } 
        else 
        {
            [self gotoPageWithIndex:i];
        }
        
       // [self hideHeaderAndFooter];
//    }
    //[self dismissModalViewControllerAnimated:YES];
    
}
-(void)showCatalogListView
{
    if (_directoryListView==nil) 
    {
        _directoryListView = [[KSDirectoryListView alloc] initWithFrame:CGRectMake(0, 0, self.view.width, self.view.height) magazineId:_magzineId hander:self];
        _directoryListView.autoresizingMask = UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleWidth;
        [self.view addSubview:_directoryListView];
    }
    else 
    {
        _directoryListView.ToolBarStatus = self.headerHide;
        [self hideHeaderAndFooter];
        self.forceHideHeader = YES;
        [self.view bringSubviewToFront:_directoryListView];
    }

    _directoryListView.alpha = 0;

    [UIView animateWithDuration:0.25 animations:
     ^{
         _directoryListView.alpha = 1;
     } completion:^(BOOL finished)
     {
         [_directoryListView showTableViewWithArticleId:[self currentArticle].articleId];
     }];
    
}

- (KSModelArticle *) currentArticle{
    KSModelArticle *current = nil;
    //加载书签数据
    if(_articleId<=0){
        _articleId = [KSModelMagzine getBookmarkArticleId:_magzineId];
    }
    //加载最后阅读数据
    if(_articleId<=0){
        _articleId = [KSModelMagzine getLastReadArticleId:_magzineId];
    }
    if(_articleId<=0){//取第一篇文章
        if(_articles.count>0){
            current = [_articles objectAtIndex:0];
            _articleId = current.articleId;
        }
    } else {//取需要显示的文章
        //for (KSModelArticle *item in articles) {
        for (KSModelArticle *item in _readableArticlesArray) {
            if(item.articleId==_articleId){
                current = item;
                break;
            }
        }
    }
    //需要显示的文章不存在或不可阅读 则显示第一篇文章（封面）
    if (current == nil && _articles.count>0) {
        current = [_articles objectAtIndex:0];
    }
    return current;
}
- (KSModelArticle *)articleById:(NSInteger)articleId {
    for (KSModelArticle *a in _readableArticlesArray) {
        if (a.articleId == articleId) {
            return a;
        }
    }
    return nil;
}
- (void) gotoArticleId:(NSInteger) articleId{
    [self articles];
    //NSArray *arr = [self articles];
    KSModelArticle *currentArticle = nil;
    NSInteger iteration = 0;
    //for (KSModelArticle *item in arr) {
    for (KSModelArticle *item in _readableArticlesArray) {
        if(item.articleId==articleId){
            currentArticle = item;
            break;
        }
        iteration++;
    }
    _articleId = articleId;
    if(currentArticle==nil)return;
	if( iteration==pageControl.currentPage )
		return;
	pageControl.currentPage = iteration;
	[self performSelector:@selector(loadPages) withObject:nil afterDelay:0.1];
}
- (void) gotoArticleFromCatalog:(NSString *) articleId{
    if (self.currentArticle.artitype != 2) {
        return;
    }
    //_oldPageIndex = _currentPageIndex;
    //_oldArticle = [_readableArticlesArray objectAtIndex:pageControl.currentPage];
    [self articles];
    //NSArray *arr = [self articles];
    KSModelArticle *currentArticle = nil;
    int iteration = 0;
    //for (KSModelArticle *item in arr) {
    NSInteger aaId = [articleId intValue];
    for (KSModelArticle *item in _readableArticlesArray) {
        if(item.articleId==aaId){
            currentArticle = item;
            break;
        }
        iteration++;
    }
    _articleId = aaId;
    if(currentArticle==nil)return;
	if( iteration==pageControl.currentPage )
		return;
    
	pageControl.currentPage = iteration;
    KSDINFO(@"%d  %d",pageControl.numberOfPages,pageControl.currentPage);
    [self loadPagesFromCatalog];
	//[self performSelector:@selector(loadPagesFromCatalog) withObject:nil afterDelay:0.1];
}
- (void)reloadData{
    if (_articles)
    {
        RELEASE_SAFELY(_articles);

    }
    [self articles];
    [_articlePageView setDataList:_readableArticlesArray];
    pageControl.numberOfPages = [_readableArticlesArray count];
    [self gotoArticleId:_articleId];
}
- (void) showArticleSlide:(NSInteger) articleId{
    NSString *sql = @"select * from article_slideshow where article_id=? order by ranking asc";
    FMResultSet *rs = [[KSDB db] executeQuery:sql, INTEGER(articleId)];
    NSMutableArray *arr = [NSMutableArray arrayWithCapacity:4];
    while (rs.next) {
        NSDictionary *dict = rs.resultDict;
        NSString *imagePath = STR_FORMAT(@"%@/%@", [KSModelArticle articlePath:articleId magzineId:_magzineId], DICT_VAL(dict, @"vsrc"));
        //NSDictionary *imageDict = [NSDictionary dictionaryWithObjectsAndKeys:[UIImage imageWithContentsOfFile:imagePath], @"image", DICT_VAL(dict, @"title"), @"title", nil];
        NSDictionary *imageDict = [NSDictionary dictionaryWithObjectsAndKeys:imagePath, @"image", DICT_VAL(dict, @"title"), @"title", nil];
        [arr addObject:imageDict];
    }
    if(arr.count<=0)return;
    [self showSlide:arr];
}

- (void)showSlide:(NSArray *)images{
    
    KSArticleSlideShowView *slideshow = [[KSArticleSlideShowView alloc] initWithFrame:CGFULL images:images];
    slideshow.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self.view addSubview:slideshow];
    [slideshow release];
}
- (void) showArticleVideo:(NSInteger)articleId full:(BOOL)full{
    KSModelArticle *article = [KSModelArticle loadById:_articleId withContent:NO];
	NSURL *nsURL;
    NSString *url = article.videoSrc;
    if ([url rangeOfString:@"http:"].length<=0) {
        url = STR_FORMAT(@"%@/%@", [KSModelArticle articlePath:articleId magzineId:article.magzineId], url);
        nsURL = [NSURL fileURLWithPath:url];
    }else {
        nsURL = [NSURL URLWithString:url];
    }
    [self showVideo:nsURL full:full];
}
- (void) showArticleVideo:(NSInteger) articleId vIndex:(NSInteger)index full:(BOOL)full {
    KSModelArticle *article = [KSModelArticle loadById:articleId withContent:NO];
	NSURL *nsURL;
    NSString *url = article.videoSrc;
    if (index == 2) {
        url = article.video2;
    } else if (index == 3) {
        url = article.video3;
    }
    if ([url rangeOfString:@"http:"].length<=0) {
        url = STR_FORMAT(@"%@/%@", [KSModelArticle articlePath:articleId magzineId:article.magzineId], url);
        nsURL = [NSURL fileURLWithPath:url];
    }else {
        nsURL = [NSURL URLWithString:url];
    }
    [self showVideo:nsURL full:full];
    KSArticleWebView *webView = (KSArticleWebView*)[_articlePageView.cacheViewsList objectAtIndex:pageControl.currentPage];
    if ([webView isKindOfClass:[KSArticleWebView class]])
    {
        [webView setNeedsLayout];
    }


}
- (void)showVideo:(NSURL *)url full:(BOOL)full{
	KSArticleVideoView *videoView= [[KSArticleVideoView alloc] initWithFrame:CGFULL url:url full:full];
    videoView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self.view addSubview:videoView];
    [videoView release];
}

- (void)showChildren:(NSArray *)articles{
    _forceHideHeader = YES;
    if (!_headerHide) {
        [self hideHeaderAndFooter];
    }
    KSArticleChildrenView *articleChildrenView = [[KSArticleChildrenView alloc] initWithFrame:CGFULL];
    [self.view addSubview:articleChildrenView];
    [articleChildrenView release];
}
- (void) showChildArticles:(KSModelArticle *)articl {
    _forceHideHeader = YES;
    if (!_headerHide) {
        [self hideHeaderAndFooter];
    }

    //fix webview click twice bug,we found articleChildrenView then return   http://stackoverflow.com/questions/1840355/uiwebview-shouldstartloadwithrequest-only-called-once
    UIView * childView = [self.view viewWithTag:1840355];
    if (childView == nil || (NSNull*)childView == [NSNull null]){
        KSArticleChildrenView *articleChildrenView = [[KSArticleChildrenView alloc] initWithFrame:CGFULL article:articl];
        articleChildrenView.tag = 1840355;
        articleChildrenView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        [self.view addSubview:articleChildrenView];
        [articleChildrenView release];
    }    
}
- (void)showArticleMapView:(KSModelArticle *)articl {
    _forceHideHeader = YES;
    if (!_headerHide) {
        [self hideHeaderAndFooter];
    }
    KSArticleMapView *articleMapView = [[KSArticleMapView alloc] initWithFrame:CGFULL article:articl];
    articleMapView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self.view addSubview:articleMapView];
    [articleMapView release];
}
#pragma mark - show/hide header or footer
- (void)mainViewWasTapped:(NSNotification *)notification{
    
    
    KSDINFO(@"%d  ",_articleId);
    
    /*
    if ([[self currentArticle] artitype]==2)
    {
        for (int i = 0; i<[_articlePageView.cacheViewsList count]; i++)
        {
            if ([[_articlePageView.cacheViewsList objectAtIndex:i] isKindOfClass:[KSDirectoryMainView class]])
            {
                KSDirectoryMainView *directoryMainView = (KSDirectoryMainView*)[_articlePageView.cacheViewsList objectAtIndex:i];
                if (directoryMainView.headerBarBgView.bottom == 0)
                {
                    [directoryMainView showHeaderBar];
                }
                else
                {
                    [directoryMainView hiddenHeaderBar];
                }
            }
        }
//        if (_headerHide) {
//            [_directoryListView sho];
//        }else
//            [self hideHeaderAndFooter];
        return;
    }
    */
    
    if (!_forceHideHeader)
    {
        NSDictionary *data = notification.userInfo;
        UITouch *touch = [data objectForKey:@"touch"];
        if(touch.tapCount<2)return;
        
        if([[self currentArticle] artitype]==2){
            footer.hidden=YES;
        }else {
            footer.hidden = NO;
        }        
        if (_headerHide) 
            [self showHeaderAndFooter];
        else
            [self hideHeaderAndFooter];
    }

    //[self showHeaderAndFooter];
}

- (void)resetHideTimer:(BOOL)need{
    if (hideTimer) {
        [hideTimer invalidate];
        hideTimer = nil;
    }
    if(need && self){
        hideTimer = [NSTimer scheduledTimerWithTimeInterval:AUTO_HIDEREADBAR_TIME target:self selector:@selector(hideHeaderAndFooter) userInfo:nil repeats:NO];
    }
}

- (void)showHeaderAndFooter{
    [self.view bringSubviewToFront:header];
    _headerHide = NO;
    if(header.top<0){
        [UIUtil addAnimationSlideDown2:header];
    }
    if(footer.bottom>([UIUtil currentOrientation]==0?1024:768)){
        [UIUtil addAnimationSlideUp:footer];
    }
    //[self resetHideTimer:YES];
}

- (void)hideHeaderAndFooter{
    _headerHide = YES;
    if(header.bottom>0){
        [UIUtil addAnimationSlideUp2:header];
    }
    if(footer.top<([UIUtil currentOrientation]==0?1024:768)){
        [UIUtil addAnimationSlideDown:footer];
    }
    //[self resetHideTimer:NO];
}

//通过代理方式实现单击出现导航菜单
- (void)touchesEnded:(UIEvent *)event{
    //if(!_isDidAppear)return;
    
    if (!_forceHideHeader) {
        NSSet *touches = [event allTouches];
        if (touches.count==1) {
            UITouch *touch = [touches anyObject];
            if(touch.tapCount==2 && touch.phase==UITouchPhaseEnded && !CGRectContainsPoint(header.frame, [touch locationInView:self.view]) &&
               !CGRectContainsPoint(footer.frame, [touch locationInView:self.view]))return;
            if (_headerHide) {
                [self showHeaderAndFooter];
            }else
                [self hideHeaderAndFooter];
        }
    }
    
    return;
    
	NSSet *touches = [event allTouches];
	NSArray *touchesAry = [touches allObjects];
	if (touches.count==1) {
		UITouch *touch = [touchesAry objectAtIndex:0];
		
		if (touch.tapCount==1 && touch.phase==UITouchPhaseEnded && !CGRectContainsPoint(header.frame, [touch locationInView:self.view]) &&
			!CGRectContainsPoint(footer.frame, [touch locationInView:self.view])) {
			[self showHeaderAndFooter];
		}
	}
    //双指点击同样触发
	if( touches.count ==2 ) {
        UITouch *touch1 = [touchesAry objectAtIndex:0];
        UITouch *touch2 = [touchesAry objectAtIndex:1];
        if( touch1.tapCount==1 && touch2.tapCount==1 && (touch1.phase == UITouchPhaseEnded || touch2.phase == UITouchPhaseEnded) ){
            [self showHeaderAndFooter];
        }
    }
}


#pragma mark - share help comment notes
- (void)showShareMenu {
    
    KSModelArticle *modelArticle = [self currentArticle];//[KSModelArticle loadById:_articleId withContent:YES];
    //KSDINFO(@"%@,%d,%@", modelArticle.title, modelArticle.articleId,modelArticle.summary);
    if (!modelArticle) {
        return;
    }
//    if (modelArticle.isHtml) {
//        NSString *htmlFile = [modelArticle htmlFile:0];
//        NSString *str = [NSString stringWithContentsOfFile:htmlFile encoding:NSUTF8StringEncoding error:nil];
//        modelArticle.content = str;
//    }
    [[SHK currentHelper] setRootViewController:self];
    SHKItem *item = [SHKItem text:modelArticle.summary];
    [item setCustomValue:modelArticle.authors forKey:@"author"];
    [item setCustomValue:[NSString stringWithFormat:@"%d", modelArticle.articleId] forKey:@"articleid"];
    item.title = modelArticle.title;//[NSString stringWithFormat:@"财新网（caixin.com）：【%@】\n%@\n（来自新世纪iPad客户端）",modelArticle.title,modelArticle.shareUrl];
    if (modelArticle.shareUrl && [modelArticle.shareUrl length]) {
        item.shareUrl = modelArticle.shareUrl;
    } else {
        item.shareUrl = @"";
    }
    
    NSString *sql = @"select * from article_images where article_id=? order by page asc, left asc, top asc limit 1";
    FMResultSet *rs = [[KSDB db] executeQuery:sql, INTEGER(modelArticle.articleId)];
    if (rs.next) {
        NSDictionary *dict = rs.resultDict;
        NSString *imagePath = STR_FORMAT(@"%@/%@", [modelArticle articlePath], DICT_VAL(dict, @"image"));
        if (imagePath) {
            item.image = [UIImage imageWithContentsOfFile:imagePath];
            item.shareType = SHKShareTypeImage;
        } else {
            item.shareType = SHKShareTypeText;
        }
    }
    [rs close];
    
    
    if (!_sharePopController) {
        KSPopShareViewController *controller = [[KSPopShareViewController alloc] initWithSHKItem:item];
        controller.contentSizeForViewInPopover = CGSizeMake(248, controller.view.height);
        _sharePopController = [[UIPopoverController alloc] initWithContentViewController:controller];
        _sharePopController.delegate = self;
        [controller release];
    } else {
        [(KSPopShareViewController *)_sharePopController.contentViewController setItem:item];
    }
    
    [_sharePopController presentPopoverFromRect:CGRectMake(220, 0, 68, 40) inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
    
}
- (void)dismissShareMenuAnimated:(BOOL)animat {
    [_sharePopController dismissPopoverAnimated:NO];
    RELEASE_SAFELY(_sharePopController);
}
- (void)dismissCommentView {
    [_commentView removeFromSuperview];
    RELEASE_SAFELY(_commentView);
}
- (void)dismissArticleSearchView {
    [_articleSearchView removeFromSuperview];
    RELEASE_SAFELY(_articleSearchView);
}
- (void)showHelp:(id)target{
    [self showHelpView];
}
- (void)showHelpView {
    _articleHelpView = [[KSArticleHelpView alloc] initWithFrame:self.view.bounds];
    _articleHelpView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    [self.view addSubview:_articleHelpView];
}
- (void)dismissHelpview {
    [_articleHelpView removeFromSuperview];
    RELEASE_SAFELY(_articleHelpView);
}
- (void) collectThis{
    if([KSModelCollectionItem isInCollection:_articleId]){
        [KSModelCollectionItem unMarkCollection:_articleId];
        [header changeCollectState:NO];
        return;
    }
    [KSModelCollectionItem markCollection:_articleId];
    [header changeCollectState:YES];
}
- (void) searchThis{
    if (!_articleSearchView) {
        _articleSearchView = [[KSArticleSearchView alloc] initWithFrame:CGFULL];
        _articleSearchView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    }
    [self.view addSubview:_articleSearchView];
    [UIUtil addAnimationShow:_articleSearchView];
}
- (void) shareToWeibo{
    [self showShareMenu];
}
- (void) openCommentView{
    if (!_commentView) {
        KSModelArticle *a = [KSModelArticle loadById:_articleId withContent:NO];
        _commentView = [[KSCaixinCommentView alloc] initWithFrame:CGFULL article:a];
    }
    [self.view addSubview:_commentView];
    [UIUtil addAnimationShow:_commentView];
    //    
    //    _commentView.transform = CGAffineTransformMakeScale(0.1, 0.1);
    //    [UIView animateWithDuration:0.3 delay:0 options:UIViewAnimationOptionCurveLinear animations:^{
    //        _commentView.transform = CGAffineTransformMakeScale(1, 1);
    //        _commentView.frame = CGFULL;
    //    } completion:^(BOOL finished) {
    //        
    //    }];
}
- (void)showNoPermissionView:(KSModelMagzine *)mag delegate:(id<KSNoPermissionAlertViewDelegate>)delegate {
    if (!_noPermissionAlertView) {
        _noPermissionAlertView = [[KSNoPermissionAlertView alloc] initWithFrame:CGFULL magazine:mag];
        _noPermissionAlertView.delegate = delegate;
    }
    [self.view addSubview:_noPermissionAlertView];
    [UIUtil addAnimationPop:_noPermissionAlertView];
}
- (void)dismissNoPermissionView {
    [_noPermissionAlertView removeFromSuperview];
    RELEASE_SAFELY(_noPermissionAlertView);
}
- (void)decreaseFont {
    //[[pagesScrollView articleCoreTextView] decreaseFont];
    if (isRetina) {
        [_articlePageView didReceiveMemoryWarning];
    }
    [_articlePageView decreaseFont];
}
- (void)resetFont {
    if (isRetina) {
        [_articlePageView didReceiveMemoryWarning];
    }
    //[[pagesScrollView articleCoreTextView] resetFont];
    [_articlePageView resetFont];
}
- (void)increaseFont {
    if (isRetina) {
        [_articlePageView didReceiveMemoryWarning];
    }
    //[[pagesScrollView articleCoreTextView] increaseFont];
    [_articlePageView increaseFont];
}
- (void) pizhuThis{
    
}
- (void) bluePenPizhu{
    
}
- (void) redPenPizhu{
    
}
- (void) markPenPizhu{
    
}
- (void) erasePizhu{
    
}


#pragma mark -

- (void)whenMagzineDownloaded:(NSNotification *)notification{
    NSDictionary *data = notification.userInfo;
    NSInteger magzineId = DICT_INTVAL(data, @"magzine_id");
    if(magzineId!=_magzineId)return;
    RELEASE_SAFELY(_articles);
    [self articles];
    [self currentArticle];
    pageControl.numberOfPages = _articles.count;
    [KSBootstrap unlisten:NOTIFY_MAGZINE_DOWNLOADED target:self];
    [KSBootstrap listen:NOTIFY_ARTICLE_DOWNLOADED target:self selector:@selector(whenArticleDownload:)];
    KSGetMagzineArticlesOperation *oper = [[KSGetMagzineArticlesOperation alloc] init:_magzineId];
    [[KSBootstrap operationQueue] addOperation:oper];
    [oper release];    
    [self loadPages];
}

#pragma mark -

- (void)gotoPageWithIndex:(NSInteger)index{
	//if( index==pageControl.currentPage || index<0 || index>=[self articles].count)
    if( index==pageControl.currentPage || index<0 || index>=[_readableArticlesArray count])
		return;
	pageControl.currentPage = index;
    //KSModelArticle *current = [[self articles] objectAtIndex:index]
    KSModelArticle *current = [_readableArticlesArray objectAtIndex:index];
    _articleId = current.articleId;
    [self loadPages];
    [self performSelector:@selector(changeCollectState) withObject:nil afterDelay:0.1];
}
- (void)gotoNextPage{
	[self gotoPageWithIndex:pageControl.currentPage+1];
}
- (void)gotoPrevPage{
	[self gotoPageWithIndex:pageControl.currentPage-1];
}
- (NSInteger)currentCatalogIndex {
    //NSInteger index = pageControl.currentPage;
    //KSModelArticle *a = [_readableArticlesArray objectAtIndex:index];
    for (int i=0; i< [_articles count];i++) {
        KSModelArticle *aa = [_articles objectAtIndex:i];
        if (aa.articleId == _articleId) {
            _currentCatalogIndex = i;
            break;
        }
    }
    return _currentCatalogIndex;
}
- (NSInteger)currentPageIndex {
    return pageControl.currentPage;
}
- (KSModelMagzine *)currentMagzine{
    if (!_currentMagazine) {
        _currentMagazine = [KSModelMagzine loadById:_magzineId];
    }
    return _currentMagazine;//[KSModelMagzine loadById:_magzineId];
}

#pragma mark - UIPopoverControllerDelegate
- (void)popoverControllerDidDismissPopover:(UIPopoverController *)popoverController {
    RELEASE_SAFELY(_sharePopController);
}

#pragma mark - UIGestureRecognizerDelegate
// called when a gesture recognizer attempts to transition out of UIGestureRecognizerStatePossible. returning NO causes it to transition to UIGestureRecognizerStateFailed
- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer {
    return YES;
}

// called when the recognition of one of gestureRecognizer or otherGestureRecognizer would be blocked by the other
// return YES to allow both to recognize simultaneously. the default implementation returns NO (by default no two gestures can be recognized simultaneously)
//
// note: returning YES is guaranteed to allow simultaneous recognition. returning NO is not guaranteed to prevent simultaneous recognition, as the other gesture's delegate may return YES
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer{
    return YES;
}

// called before touchesBegan:withEvent: is called on the gesture recognizer for a new touch. return NO to prevent the gesture recognizer from seeing this touch
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch{
    return YES;
}

#pragma mark -
- (void)layoutFooter {
    if([UIUtil currentOrientation] == 0) {
        footer.top = 1024-(_headerHide?0:footer.height);
    } else {
        footer.top = 768-(_headerHide?0:footer.height);
    }
}
- (void)resetTripstate {
    if (_tmpMainImageView) {//修复三指事件非正常中止的清理
        [_tmpMainImageView removeFromSuperview];
        RELEASE_SAFELY(_tmpMainImageView);
        _articlePageView.left = 0;
        _articlePageView.userInteractionEnabled = YES;
    }
}
#pragma mark - KSNoPermissionAlertViewDelegate
- (void)afterDoBuy:(KSNoPermissionAlertView *)alertView {
    [UIUtil showMsgAlertWithTitle:@"购买成功" message:@"现在可以阅读全部文章"];
    self.currentMagzine.isPurchased = YES;
    [self reloadData];
    [self dismissNoPermissionView];
}

@end
