
//
//  KSMagzineViewController.m
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSMagzineViewController.h"
#import "KSWebViewController.h"
#import "KSViewInitor.h"
#import "UserHelper.h"
#import "KSRemoteNotificationHanlder.h"
#import "KSDownloadManager.h"
#import "KSGetMagzineCoverDownloader.h"
#import "KSFirstHelpView.h"
#import "KSGetMagzineListOperation.h"
#import "KStoreManager.h"
#import "KSMagazinMainBottomShelfView.h"

@implementation KSMagzineViewController
@synthesize purchaseing = _purchasing;
@synthesize main,footer;

- (id) init{
    return [self initWithNibName:nil bundle:nil];
}

- (id) initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    if(self=[super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]){
        //
        _purchasing = NO;
        
        [KSBootstrap listen:NOTIFY_PURCHASE_COMPLETED target:self selector:@selector(purchaseOccurs:)];
        [KSBootstrap listen:NOTIFY_RESTORE_COMPLETED target:self selector:@selector(restoreOccurs:)];
        
        [KSBootstrap listen:NOTIFY_MAGZINE_LIST_UPDATED target:self selector:@selector(whenMagzineListUpdated:)];
        [KSBootstrap listen:NOTIFY_MAGZINE_DOWNLOADED target:self selector:@selector(whenMagzineDownloaded:)];
        [KSBootstrap listen:NOTIFY_ARTICLE_DOWNLOADED target:self selector:@selector(whenArticleDownload:)];
        [KSBootstrap listen:NOTIFY_MAGZINE_COVER_DOWNLOADED target:self selector:@selector(whenMagzineCoverDownloaded:)];
//        [KSBootstrap listen:NOTIFY_MAGAZINE_PURCHASED target:self selector:@selector(whenMagzinePurchased:)];

        
    }
    return self;
}

- (void)dealloc {
    [KSBootstrap unlisten:self];
    
    [_noPermissionAlertView release];
    
    [background release];
    [footer release];
    RELEASE_SAFELY(main);
    [_loginView release];
    [collection release];
    [search release];
    [_settingView release];
    [_accountView release];
    [_magzines release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    if (![_settingView superview]) {
        [_settingView release],_settingView = nil;
        
    }
    // Release any cached data, images, etc that aren't in use.
}

- (CGRect) CGRectFull{
    return CGRectMake(0, 0, 768, 1024);
}

-(void)refreshData
{
    [main.bottomShelfView reloadData];
    [main.coverScrollView reloadData];
    [main.bookShelfView reloadData];
    [main.bookStoreView reloadData];
    //    [magazines  release];
    [self setCurrentMagzine:[KSModelMagzine loadById:[self currentMagzine].magzineId]];
    [main setNeedsLayout];

}

-(void)downloadTheMagazineWithId:(NSInteger)magazineId
{

    for (int i = 0; i<[_magzines count]; i++)
    {
        if ([[_magzines objectAtIndex:i] magzineId]==magazineId)
        {
            main.coverScrollView.contentOffset = CGPointMake(768*i, main.coverScrollView.contentOffset.y);
            main.bottomShelfView.contentOffset = CGPointMake((ITEM_WIDTH+ITEM_MARGIN)*i, main.bottomShelfView.contentOffset.y);
            break;
        }
    }
    [self showView:@"bookStore"];
    [self setCurrentMagzine:[KSModelMagzine loadById:magazineId]];
    [main setNeedsLayout];
//    [self buy:main.buy];
//    KSDownMagazineOperation *op = [[KSBootstrap dataCenter] valueForKey:KEY_DOWNLOADING_M_ID];
//    
//    if (op)
//    {
//        [[KSBootstrap dataCenter] removeObjectForKey:KEY_DOWNLOADING_M_ID];
//        
//    }
//    [main.coverScrollView whenMagzineDownloader:magazineId];
//    [main.bottomShelfView whenMagzineDownloader:magazineId];
//    [main.bookShelfView whenMagzineDownloader:magazineId];
//    [main.bookStoreView whenMagzineDownloader:magazineId];
//    [self setCurrentMagzine:[KSModelMagzine loadById:[self currentMagzine].magzineId]];
//    [main setNeedsLayout];

    
//    KSMagzineShelfView *bookShelf = main.bookshelf;
//    NSMutableArray *magazineList = [bookShelf dataList];
//    NSMutableArray *shelfViewList = [bookShelf cacheViewsList];
//    for (int i = 0;i<[shelfViewList count];i++)
//    {
//        
//        KSMagzineShelfItemView *view = (KSMagzineShelfItemView*)[shelfViewList objectAtIndex:i];
//
//        KSModelMagzine *magazine = [magazineList objectAtIndex:i];
//        
//        if (magazine.magzineId == magazineId)
//        {   
//            if ([view isKindOfClass:[NSNull class]])
//            {
////                [bottomShelfView moveToViewAtPage:i/6 animated:YES];
//            }
//            view = (KSMagzineShelfItemView*)[shelfViewList objectAtIndex:i];
//
//            [view readMagazine:nil];
//            KSDINFO(@"%d ",magazineId);
//            break;
//        }
//    }
}

#pragma mark -
- (void) showView:(NSString *)type{
    
    [_loginView removeFromSuperview], [_loginView release],_loginView = nil;
    [collection removeFromSuperview], [collection release],collection = nil;
    [search removeFromSuperview], [search release], search = nil;
    [_settingView removeFromSuperview], [_settingView release], _settingView = nil;
    [_accountView removeFromSuperview], [_accountView release], _accountView = nil;
    [_helpView removeFromSuperview],[_helpView release],_helpView = nil;
    if([type isEqualToString:@"login"]){
        [main cancelDownload:[self currentMagzine]];
        _loginView = [[KSLoginView alloc] initWithFrame:[self CGRectFull] handler:self];
        [self.view addSubview:_loginView];
        //[UIUtil addAnimationShow:login];
    }
    else if([type isEqualToString:@"collection"]){
        [main cancelDownload:[self currentMagzine]];
        collection = [[KSCollectionView alloc] initWithFrame:[self CGRectFull] handler:self];
        [self.view addSubview:collection];
        //[UIUtil addAnimationShow:collection];
    }
    else if([type isEqualToString:@"search"]){
        [main cancelDownload:[self currentMagzine]];
        search = [[KSSearchView alloc] initWithFrame:[self CGRectFull] handler:self];
        [self.view addSubview:search];
        //[UIUtil addAnimationShow:search];
    } else if ([type isEqualToString:@"setting"]) {
        [main cancelDownload:[self currentMagzine]];
        _settingView = [[KSSettingView alloc] initWithFrame:[self CGRectFull] handler:self];
        [self.view addSubview:_settingView];
        //[UIUtil addAnimationShow:_settingView];
    } else if ([type isEqualToString:@"account"]) {
        [main cancelDownload:[self currentMagzine]];
        _accountView = [[CXAccountView alloc] initWithFrame:[self CGRectFull]];
        [self.view addSubview:_accountView];
    }
    else if([type isEqualToString:@"helpView"]) {
        [main cancelDownload:[self currentMagzine]];
        _helpView = [[KSHelpView alloc] initWithFrame:[self CGRectFull] handler:self];
        [self.view addSubview:_helpView];
    }
    else if([type isEqualToString:@"bookShelf"]) {


//        if (!self.footer.bookShelfBtn.selected)
//        {
        if (main.bookShelfView.top==1024)
            [self.main showBookShlefView];

//        }
//        else {
//            [self.main hiddenBookShelf];
//
//        }
    }
    else if([type isEqualToString:@"bookStore"]) {

//        if (!self.footer.bookStoreBtn.selected)
//        {
//            [self.main showBookStoreView];
//            
//        }
//        else {
            [self.main hiddenStoreViewWithNoAnimation];
        if (main.bookShelfView.top!=1024)
        {
            [self.main hiddenBookShelf];
        }
            
//        }
    }
    //返回首页刷新服务器
    else if ([type isEqualToString:@"none"]) {
        KSGetMagzineListOperation *operGetMagzineList = [[KSGetMagzineListOperation alloc] init];
        [[KSBootstrap operationQueue] addOperation:operGetMagzineList];
        [operGetMagzineList release];
    }
//    else if ([type isEqualToString:@"downladoMagazine"]){
//        [self downloadTheMagazineWithId:170];
//    }
    [footer lightIcon:type];
}

- (void) showLogin{
    [self showView:@"login"];
}
- (void)showSubscriptionView {
    [self showView:@"none"];
}
- (void)showAccountView {
    if(_accountView==nil){
        [self showView:@"account"];
        [self.view bringSubviewToFront:footer];
    }else{
        [self showView:@"none"];
    }
}
- (void)showAccountViewFromLogin {
    if(_accountView==nil){
        [self showView:@"account"];
        [self.view bringSubviewToFront:footer];
    }else{
        [self showView:@"none"];
    }
    [_accountView releaseAllSettingSubViews];
    [_accountView showGiftcardView];
}
- (void)showAccountViewFromSetting {
    [self showAccountView];
    _accountView.viewfrom = @"setting";
}
- (void) showSetting{
    if(_settingView == nil){
        [self showView:@"setting"];
        [self.view bringSubviewToFront:footer];
    }else{
        [self showView:@"none"];
    }
    
}

-(void)showBookShelf
{
    if(_bookShelfView == nil)
    {
        [self showView:@"bookShelf"];
        [self.view bringSubviewToFront:footer];
    }
    else
    {
        [self showView:@"none"];
//        [_bookShelfView removeFromSuperview];
//        _bookShelfView = nil;
    }

//    [footer lightIcon:@"bookShelf"];
}
-(void)showBookStore
{
    if(_bookStoreView == nil)
    {
        [self showView:@"bookStore"];
        [self.view bringSubviewToFront:footer];
    }
    else
    {
        [self showView:@"none"];
//        [_bookStoreView removeFromSuperview];
//        _bookStoreView = nil;
    }
    
//    [footer lightIcon:@"bookStore"];
}

- (void) showSearch:(id)sender{
    if(search==nil){
        [self showView:@"search"];
        [self.view bringSubviewToFront:footer];
    }else{
        [self showView:@"none"];
    }
}
- (void) showHelpViews:(id)sender
{
    if (_helpView==nil)
    {
        [self showView:@"helpView"];
        [self.view bringSubviewToFront:footer];
    }
    else {
        [self showView:@"none"];
    }
}
- (void) showCollection:(id)sender{
    if(collection==nil){
        [self showView:@"collection"];
        [self.view bringSubviewToFront:footer];
    }else{
        [self showView:@"none"];
    }
}
- (void) backToMain{
    [self showView:@"none"];    
}

#pragma mark -
- (void)showRegSuccessViewWithMail:(NSString *)email password:(NSString *)pwd {
    UIView *containerView = [[UIView alloc] initWithFrame:self.view.bounds];
    containerView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    [self.view addSubview:containerView];
    containerView.tag = 9001;
    containerView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.8];
    [containerView release];
    
    NSArray *views = [[NSBundle mainBundle] loadNibNamed:@"KSRegSuccView" owner:self options:nil];
    //KSRegSuccView *reg_succ_view = [[views objectAtIndex:0] retain];
    KSRegSuccView *reg_succ_view = [views objectAtIndex:0];
    //    reg_succ_view.frame = CGRectMake(0, 0, 422, 336);
    reg_succ_view.center = CGPointMake(roundf(self.view.width/2), roundf(self.view.height/2));
    reg_succ_view.layer.cornerRadius = 5;
    
    reg_succ_view.email = email;
    reg_succ_view.handler = self;
    [containerView addSubview:reg_succ_view];    
    //animation
    reg_succ_view.alpha = 0;
    [UIView animateWithDuration:0.3 animations:^{
        reg_succ_view.alpha = 1;
    } completion:^(BOOL finished) {
        
    }];
}
- (void)dismissRegSuccView {
    [[self.view viewWithTag:9001] removeFromSuperview];
}
- (void)showRegView {
    [self showLogin];
    [_loginView showRegFormView];
}
- (void)showTrievePassView {
    [self showLogin];
    [_loginView showRetrievePassView];
}
#pragma mark -
- (void) loginUser:(NSString *)user{
    [KSBootstrap setCurrentUser:[user lowercaseString]];
    [self showView:@"none"];

//    [_magzines release];
//    _magzines = nil;
    [footer logstateChange ];
//    NSMutableArray *magazines = [KSModelMagzine loadAllFree:[user lowercaseString]];
//    for (KSModelMagzine *magaz in magazines)
//    {
//        magaz.isPurchased = YES;
//    }
//    NSMutableArray *magazines = [[NSMutableArray alloc] initWithArray:[self loadMagazineByYear:main.selectYear]];
//    [main.bottomShelfView reloadData];
//    [main.coverScrollView reloadData];
//    [main.bookShelfView reloadData];
//    [main.bookStoreView reloadData];
////    [magazines  release];
//    [self setCurrentMagzine:[KSModelMagzine loadById:[self currentMagzine].magzineId]];
//
//    [main setNeedsLayout];
    
    [self refreshData];
}
- (void)loginUserQuiet:(NSString *)user{
    [self loginUser:user];
}
- (void)logout{
    [KSBootstrap setCurrentUser:nil];
    [footer logstateChange];
    [_magzines release];
    _magzines = nil;
    
//    NSMutableArray *magazines = [[NSMutableArray alloc] initWithArray:[self loadMagazineByYear:main.selectYear]];
//    [main.bottomShelfView reloadData];
//    [main.coverScrollView reloadData];
//    [main.bookShelfView reloadData];
//    [main.bookStoreView reloadData];
////    [magazines  release];
//    [self setCurrentMagzine:[KSModelMagzine loadById:[self currentMagzine].magzineId]];
//    [main setNeedsLayout];

    [self refreshData];

}

- (void) registerUser:(NSString *)email name:(NSString *)name pwd:(NSString *) pwd pwd_repeat:(NSString *) pwd_repeat verify_code:(NSString *) code{
    //
    [_loginView displayRegSuccView:email password:pwd];
}



- (void) gotoArticle:(NSInteger)articleId magzineId:(NSInteger)magzineId from:(NSString *)from{
    //NSLog(@"gotoArticle %d, %d, %@", articleId, magzineId, from);
//    KSArticleViewController *articleViewController = [[KSArticleViewController alloc] init:magzineId articleId:articleId];
//    [self presentModalViewController:articleViewController animated:YES];
//    [articleViewController release];
    [[KSMainController mainController] presentArticleViewControllerWithMagId:magzineId ArticleId:articleId from:from];
}

- (NSObject *) getUser{
    return [KSBootstrap currentUser];
}
#pragma mark - View lifecycle

- (void)loadView
{
    [super loadView];
    _magzines = [self magzines];
//    background = [[KSMagzineBackgroundView alloc] initWithFrame:self.view.bounds];
//    [self.view addSubview:background];
    
    
    main = [[KSMagzineMainView alloc] initWithFrame:CGRectMake(0, 0, self.view.width, self.view.height) controller:self];
    main.clipsToBounds = YES;
    [self.view addSubview:main];
    self.view.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    footer = [[KSMagzineFooterBarView alloc] initWithFrame:CGRectMake(0, self.view.height-71, self.view.width, 71) delegate:self];
    [self.view addSubview:footer];

    if ([_magzines count]>0)
    {
        [self setCurrentMagzine:[_magzines objectAtIndex:0]];
    }

    //更新杂志列表
    if (!_viewLoaded) {
        KSGetMagzineListOperation *operGetMagzineList = [[KSGetMagzineListOperation alloc] init];
        [[KSBootstrap operationQueue] addOperation:operGetMagzineList];
        [operGetMagzineList release];
    }
    
    //第一次显示显示帮助
    NSString *oldVersion = [USER_DEFAULT objectForKey:@"oldVersion"];
    NSString *newVersion = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    if (![oldVersion isEqualToString:newVersion]) {
        /*
        if([oldVersion isEqualToString:@"2.1.2"]){
             //更新数据库结构（每一份已下载杂志更新一下）
             //1.更新相关表结构
             NSString *sql = @"ALTER TABLE catalogs add column catalogcolor_id varchar(255);ALTER TABLE magzines add column ad_url varchar(255); ALTER TABLE magzines add column ad_pic varchar(255);ALTER TABLE subscribed add column  email Varchar(255);ALTER TABLE articles add column catalogPicType NUMERIC;ALTER TABLE articles add column catalogPicPath TEXT;";
             [[KSDB db] executeQuery:sql];
             
             //2.更新各表数据
             KSGetAllArticlesDownloader *dl = [[KSGetAllArticlesDownloader alloc] init];
             sql = @"select magzine_id from magzines where is_download=1";
             FMResultSet *rs = [[KSDB db] executeQuery:sql];
             while (rs.next) {
             NSDictionary *dict = rs.resultDict;
             dl.magzineId = DICT_INTVAL(dict, @"magzine_id");
             [dl saveMagazineToDB];
             }
             [dl release];
             [rs close];       
            
        }
        */ 
        [KSDB saveString:[[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"] forKey:KEY_CURRENT_VERSION];
        [USER_DEFAULT setObject:[[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"] forKey:@"oldVersion"];
        [USER_DEFAULT synchronize];
        KSFirstHelpView *helpView = [[KSFirstHelpView alloc] initWithFrame:self.view.bounds];
        
        helpView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
        [self.view addSubview:helpView];
        [helpView release];
        
    }
    
//    if ([[KSBootstrap dataCenter] valueForKey:KEY_SHOW_FIRST_HELP]!=nil) {
//        [[KSBootstrap dataCenter] removeObjectForKey:KEY_SHOW_FIRST_HELP];
//
//    }
    [self startDownLoadCoverImage];
}

- (KSModelMagzine *) currentMagzine{
    KSDataCenter *dataCenter = [KSBootstrap dataCenter];
    return [dataCenter valueForKey:@"current_magzie"];
}

- (void) setCurrentMagzine:(KSModelMagzine *)magzine{
    KSDataCenter *dataCenter = [KSBootstrap dataCenter];
    [dataCenter setValue:magzine forKey:@"current_magzie"];
}

- (NSArray *) magzines
{
    if(_magzines)
    {
        RELEASE_SAFELY(_magzines);
    }
    _magzines = [[KSModelMagzine magzines] retain];

    return _magzines;
}



-(NSMutableArray*)getMagazinesYear
{
    NSMutableSet *set = [[NSMutableSet alloc] init];
    if (!_magzines)
    {
        _magzines = [self magzines];
    }
    if ([_magzines count]==0)
    {
        return nil;
    }
    for (KSModelMagzine *magz in _magzines)
    {
        NSDate *date = [NSDate dateWithTimeIntervalSince1970:magz.pubDate];

        NSNumber *yearNum = [[NSNumber alloc] initWithInteger:[DateUtil getYearByDate:date]];
        [set addObject:[yearNum stringValue]];
        [yearNum release];
        
    }
    NSMutableArray *allObjs = [[NSMutableArray alloc] initWithArray:[set allObjects]];
    [set release];
    KSDINFO(@"%@",allObjs);
    for (int i = 0; i<[allObjs count]-1; i++)
    {
        for (int j = i+1; j<[allObjs count]; j++)
        {
            NSInteger first = [[allObjs objectAtIndex:i] intValue];
            NSInteger last = [[allObjs objectAtIndex:j] intValue];
            if (first<last)
            {
                [allObjs exchangeObjectAtIndex:i withObjectAtIndex:j];
            }
        }
    }
    KSDINFO(@"%@",allObjs);
    
    return [allObjs autorelease];
}
-(NSMutableArray*)loadMagazineByYear:(NSInteger)year
{
    NSMutableArray *_selectMagazines = [[NSMutableArray alloc] init];
    if (_magzines)
    {
        RELEASE_SAFELY(_magzines);
    }
    [self magzines];
    for (KSModelMagzine *magaz in _magzines)
    {
        NSDate *date = [NSDate dateWithTimeIntervalSince1970:magaz.pubDate];

        if ([DateUtil getYearByDate:date] == year) 
        {
            [_selectMagazines addObject:magaz];
        }
    }
    return [_selectMagazines autorelease];
}
-(void)selectMagazine:(UIGestureRecognizer*)gr
{
    KSMagazinMainBottomShelfItemView *view = (KSMagazinMainBottomShelfItemView*)gr.view;
    NSInteger selectMagazineId = view.tag;
    for (int i = 0; i<[_magzines count]; i++)
    {
        KSModelMagzine *selectMagazine = [_magzines objectAtIndex:i];
        if (selectMagazineId == selectMagazine.magzineId)
        {
            main.coverScrollView.contentOffset = CGPointMake(main.coverScrollView.width*i, main.coverScrollView.contentOffset.y);
            break;
        }
    }
    
}
-(void)selectCoverMagazineAtIndex:(NSInteger)index magazine:(KSModelMagzine*)magazine
{
    [main.bottomShelfView loadSubViewsWithIndex:index];

    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDuration:0.25];
    main.bottomShelfView.contentOffset = CGPointMake((ITEM_WIDTH+ITEM_MARGIN)*index, main.bottomShelfView.contentOffset.y);
    [main cancelDownload];

    [self setCurrentMagzine:[KSModelMagzine loadById:magazine.magzineId]];

//    [main changeMagazine:[[self magzines] objectAtIndex:index]];
    [main setNeedsLayout];
    [UIView commitAnimations];
   
}
-(void)selectBookShelfMagazineAtIndex:(NSInteger)index magazine:(KSModelMagzine*)magazine
{
    
//    [UIView beginAnimations:nil context:nil];
//    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
//    [UIView setAnimationDuration:0.25];
    [main.coverScrollView loadSubViewsWithIndex:index];
    main.coverScrollView.contentOffset = CGPointMake(main.coverScrollView.width*index, main.coverScrollView.contentOffset.y);
    [UIUtil showFadeInAnimation:main.coverScrollView endAlpha:1];
    [main cancelDownload];

    [self setCurrentMagzine:[KSModelMagzine loadById:magazine.magzineId]];
//    [main changeMagazine:[[self magzines] objectAtIndex:index]];
    [main setNeedsLayout];

//    [UIView commitAnimations];
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
//    _viewLoaded = YES;
}
- (void)viewDidUnload
{
    [super viewDidUnload];
    [footer removeFromSuperview];
    RELEASE_SAFELY(footer);
    
    if (![_settingView superview]) {
        [_settingView release],_settingView = nil;
    }
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if(!main){
        main = [[KSMagzineMainView alloc] initWithFrame:CGRectMake(0, 0, self.view.width, self.view.height-40) controller:self];
        [self.view addSubview:main];
        [self.view sendSubviewToBack:main];
    }
    if(!background){
        background = [[KSMagzineBackgroundView alloc] initWithFrame:CGRectMake(0, 0, self.view.width, self.view.height)];
        [self.view addSubview:background];
        [self.view sendSubviewToBack:background];
    }
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
//    [main removeFromSuperview];
//    RELEASE_SAFELY(main);
//    [background removeFromSuperview];
//    RELEASE_SAFELY(background);
//    if (isRetina) {
//        self.view = nil;
//    }
}

- (void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration{
   // NSDictionary *userInfo = [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithInt:toInterfaceOrientation], @"to",
   //                           [NSNumber numberWithInt:[[UIApplication sharedApplication] statusBarOrientation]], @"from",
   //                           nil];
   // [[NSNotificationCenter defaultCenter] postNotificationName:@"ROTATION_OCCURS" object:self userInfo:userInfo];
   // [UIUtil setOrientation:toInterfaceOrientation];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    //return !_purchasing;//return YES;
    UIInterfaceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation;
    if(UIInterfaceOrientationLandscapeLeft == orientation || UIInterfaceOrientationLandscapeRight == orientation){
        [[UIApplication sharedApplication] setStatusBarOrientation:UIInterfaceOrientationPortrait animated:NO];
    }
    if (interfaceOrientation == UIInterfaceOrientationPortrait||interfaceOrientation == UIInterfaceOrientationPortraitUpsideDown) {
        return YES;
    }
    return NO;
}
- (void) try_read
{
    if (![[self magzines] count]) return;
    [self gotoArticle:0 magzineId:[self currentMagzine].magzineId from:nil];
}
- (void) buy:(UIButton*)btn
{
    [main.bottomShelfView autoChangePosition];
    
    if([main.buy backgroundImageForState:UIControlStateNormal]==BTN_READ_IMAGE)
    {
        [self gotoArticle:0 magzineId:[self currentMagzine].magzineId from:@"bookself"];
    }
    else
    {
        if (![UIUtil checkInternetConnection])
        {
            return;
        }
        if ([main.buy backgroundImageForState:UIControlStateNormal]==BTN_DOWNLOAD_IMAGE)
        {
            [main.buy setBackgroundImage:BTN_DOWNLOADING_IMAGE forState:UIControlStateNormal];
            
            [main readMagazine:btn];
        }
        else if ([main.buy backgroundImageForState:UIControlStateNormal]==BTN_DOWNLOADING_IMAGE)
        {
            [main.buy setBackgroundImage:BTN_PAUSE_IMAGE forState:UIControlStateNormal];
            
            [main readMagazine:btn];
        }
        else if ([main.buy backgroundImageForState:UIControlStateNormal]==BTN_PAUSE_IMAGE)
        {
            [main.buy setBackgroundImage:BTN_DOWNLOADING_IMAGE forState:UIControlStateNormal];
            
            [main readMagazine:btn];
        }
        else if([main.buy backgroundImageForState:UIControlStateNormal]==BTN_BUY_IMAGE)
        {
            [KSAppStoreProxy buy:[self currentMagzine] fromView:self.view];
            
        }

    }
    
    

}

#pragma mark - subscription
- (void) s_1y{
    [KSAppStoreProxy subscribe:12 fromView:self.view];
}
- (void) s_6m{
    [KSAppStoreProxy subscribe:6 fromView:self.view];
}
- (void) s_3m{
    [KSAppStoreProxy subscribe:3 fromView:self.view];
}
- (void) purchaseOccurs:(NSNotification *)notification
{
    NSDictionary *userInfo = [notification userInfo];
    NSString *type = [userInfo valueForKey:@"type"];
    if([@"buy" isEqualToString:type]){
//        NSString *issueNumber = [userInfo valueForKey:@"issue_number"];
//        KSModelMagzine *magzine = nil;
//        if(issueNumber){
//            magzine = [KSModelMagzine loadByIssueNumber:[issueNumber intValue]];
//        }else{
//            NSString *customIssueNumber = [userInfo valueForKey:@"custom_issue_number"];
//            magzine = [KSModelMagzine loadByCustomIssueNumber:customIssueNumber];
//        }
//        [magzine update:@"is_purchased" value:[NSNumber numberWithInt:1]];
        //显示动画效果
//        [main animateShowPurchased];
        [_magzines release];
        _magzines = nil;
        [self setCurrentMagzine:[KSModelMagzine loadById:[self currentMagzine].magzineId]];
        [main setNeedsLayout];
        
//        if (!magazine)
//        {
//            return;
//        }
//        if (magazine.isDownload)
//        {
//            [main.buy setBackgroundImage:BTN_READ_IMAGE forState:UIControlStateNormal];
////            [main.try_read setBackgroundImage:BTN_PREVIEW_IMAGE forState:UIControlStateNormal];
//
//        }
//        else 
//        {
//            [main.buy setBackgroundImage:BTN_DOWNLOAD_IMAGE forState:UIControlStateNormal];
////            [main.try_read setBackgroundImage:BTN_PREVIEW_IMAGE forState:UIControlStateNormal];
//
//        }
//
//        main.try_read.hidden = YES;

        [main.coverScrollView whenMagzinePurchased:[self currentMagzine].magzineId];

        NSInteger magazineId = 0;
        NSString *issue_number = [[userInfo objectForKey:@"custom_issue_number"] stringByReplacingOccurrencesOfString:STORE_PRODUCT_PREFIX withString:@""];
        if (issue_number)
        {
            magazineId = [KSModelMagzine loadByCustomIssueNumber:issue_number].magzineId;
        }
        else
        {
            issue_number = [[userInfo objectForKey:@"issue_number"] stringByReplacingOccurrencesOfString:STORE_PRODUCT_PREFIX withString:@""];
            magazineId = [KSModelMagzine loadByIssueNumber:[issue_number intValue]].magzineId;
        }

        [main.bottomShelfView whenMagzinePurchased:magazineId];
        [main.bookShelfView whenMagzinePurchased:magazineId];
        [main.bookStoreView whenMagzinePurchased:magazineId];
        
        
        
        if ([[[KSMainController mainController] activeController] isKindOfClass:[KSArticleViewController class]])
        {
//            KSArticleViewController *controllrt = (KSArticleViewController*)[[KSMainController mainController] activeController];
//            KSDirectoryMainView *view = (KSDirectoryMainView*)[controllrt.articlePageView.cacheViewsList objectAtIndex:controllrt.articlePageView.pageIndex];
//            if([view isKindOfClass:[KSDirectoryMainView class]])
//            {
//                [controllrt articles];
//                KSArticleListTabelView *list = view.articleTabelView;
//                [list reloadData:list.currentCatalogId];
//            }
            [self gotoArticle:0 magzineId:[self currentMagzine].magzineId from:@""];
        }
    }
    else if([@"subscribe" isEqualToString:type])
    {

        IF_IOS5_OR_GREATER(
                           if([USER_DEFAULT boolForKey:BACKGROUND_DOWNLOAD])
                           {
                               [USER_DEFAULT setBool:NO forKey:BACKGROUND_DOWNLOAD];
                               [USER_DEFAULT synchronize];
                               [main chooseOpenBackgroundDownload];

                           }
                           );
        
//        NSNumber *start = [userInfo valueForKey:@"start"];
//        NSNumber *end = [userInfo valueForKey:@"end"];
//        NSString *order_no = [userInfo valueForKey:@"tran_id"];
//        NSString *identifier = [userInfo valueForKey:@"identifier"];
//        [[KSDB db] executeUpdate:@"delete from subscribed where order_no=?", order_no];
//        [[KSDB db] executeUpdate:@"insert into subscribed(order_no, start, end,subsribe_type) values(?, ?, ?)", order_no, start, end,identifier];
        if ([KSBootstrap currentUser])
        {
            [UIUtil showMsgAlertWithTitle:@"提示" message:@"订阅成功。"];
            //事件类型为1
            [CXFireSubscriptionEventDataRequest requestWithDelegate:self url:SERVER_URL(@"/fireEvent/%@/1/%@/%@", MAGZINE_TYPE,[KSBootstrap currentUser],[[UIDevice currentDevice] uniqueGlobalDeviceIdentifier]) withParameters:nil withIndicatorView:nil withCancelSubject:@"CXFireDonateEvent-sub"];
        } 
        else 
        {
            [[NSUserDefaults standardUserDefaults] setObject:[NSString stringWithFormat:@"%.f",[[NSDate date] timeIntervalSince1970]] forKey:UD_SUBSCRIPTION_DATE];
            [[NSUserDefaults standardUserDefaults] synchronize];
            
            [UIUtil hideProcessIndicatorWithView:self.view];
            
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"感谢您的订阅！" message:@"如您以财新网通行证登录，还可获赠全部《新世纪》过刊阅读权限，并可查阅您的订阅信息。" delegate:self cancelButtonTitle:@"稍后再说" otherButtonTitles:@"立即登录", nil];
            alert.tag = 1010;
            [alert show];
            [alert release];
            
            //[main.bookshelf reloadData];
        }
        
    }
    
}
#pragma mark - UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (alertView.tag == 1010) {
        if (buttonIndex == 1) {
            //登录
            [self showLogin];
        }
    }
}

- (void)restoreOccurs:(NSNotification *)notify {

    
//    NSMutableArray *array = [[self loadMagazineByYear:[main.yearSeg.currentYear intValue]] retain];
//    [main.bottomShelfView reloadData];
//    [main.coverScrollView reloadData];
//    [main.bookShelfView reloadData];
//    [main.bookStoreView reloadData];
//    [self setCurrentMagzine:[KSModelMagzine loadById:[self currentMagzine].magzineId]];
//    [main setNeedsLayout];
//    [array release];
    [self refreshData];
}
#pragma mark - restore for footer butn
- (void)restorePurchases {
    [footer lightIcon:@"restore"];

    _hasSubscription = NO;
    [UIUtil showProcessIndicatorWithView:self.view atPoint:[UIUtil currentOrientation]==0?CGPointMake(384, 512):CGPointMake(512, 384) hasMask:YES];
    
    KStoreManager *mkstore = [KStoreManager sharedManager];
    [mkstore restorePreviousTransactionsOnComplete:^{
        [UIUtil showMsgAlertWithTitle:@"提示" message:@"成功恢复购买。"];
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_RESTORE_COMPLETED object:nil];
        [UIUtil hideProcessIndicatorWithView:self.view];
    } onError:^(NSError *err) {
        [UIUtil hideProcessIndicatorWithView:self.view];
        if (err.code != SKErrorPaymentCancelled) {
            [UIUtil showMsgAlertWithTitle:@"提示" message:[NSString stringWithFormat:@"恢复未成功:%@",err.localizedDescription] ];
        }
    }];
}

#pragma mark - public
- (void)savePushSettingToServer {
    [KSRemoteNotificationHanlder savePushSettingToServer];
}

- (void)openMail:(NSString *)url {
    //[[UIApplication sharedApplication] openURL:[NSURL URLWithString:[@"mailto:?from=" stringByAppendingString:url]]];
    if (url.length > 1) {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://mail.%@",[url substringFromIndex:[url indexOf:@"@"]+1]]]];
    }
}
- (void)closeModal {
    [self dismissModalViewControllerAnimated:YES];
}
-(void)startDownLoadCoverImage
{
    KSDownloadManager *dm = [KSDownloadManager sharedManager];
    for (KSModelMagzine *magzine in _magzines)
    {
        if (![UIImage imageWithContentsOfFile:magzine.cover_2])
        {
            NSInteger magzineId = magzine.magzineId;
            KSGetMagzineCoverDownloader *dl = [[KSGetMagzineCoverDownloader alloc] init:magzineId coverIndex:2];
            [dm addDownloader:dl];
            [dl release];
        }
        
    }
    for (KSModelMagzine *magzine in _magzines)
    {
        if (![UIImage imageWithContentsOfFile:magzine.cover_3])
        {
            NSInteger magzineId = magzine.magzineId;
            KSGetMagzineCoverDownloader *dl = [[KSGetMagzineCoverDownloader alloc] init:magzineId coverIndex:3];
            [dm addDownloader:dl];
            [dl release];
        }

    }

}
-(void)whenMagzinePurchased:(NSNotification*)notification
{
//    RELEASE_SAFELY(_magzines);
//    _magzines = [self magzines];
    
//    [main  initYearNaviBar];
//    NSDictionary *user = [notification userInfo];
//    NSInteger magazId;
//    for (KSModelMagzine *modMaga in _magzines)
//    {
//        if (modMaga.issueNumber == [[user objectForKey:@"issue_number"] intValue])
//        {
//            magazId = modMaga.magzineId;
//        }
//    }
//    [main.coverScrollView whenMagzinePurchased:magazId];
//    [main.bottomShelfView whenMagzinePurchased:magazId];  
//    [main.bookStoreView whenMagzinePurchased:magazId];
//    [main.bookShelfView whenMagzinePurchased:magazId];
//    [main.coverScrollView whenMagzineDownloader:[self currentMagzine].magzineId];
//    [main.bottomShelfView whenMagzinePurchased:magazineId];
}
- (void)whenMagzineListUpdated:(NSNotification*)notification
{

    
    RELEASE_SAFELY(_magzines);
    [UserHelper convFreeLogic2MagId];
    _magzines = [self magzines];
    [self startDownLoadCoverImage];
    [main  initYearNaviBar];
    [main.coverScrollView whenInitOrMagzineListUpdate];
    [main.bottomShelfView whenInitOrMagzineListUpdate];
    [main.bookShelfView whenInitOrMagzineListUpdate];
    [main.bookStoreView whenInitOrMagzineListUpdate];
    if ([_magzines count]>0)
    {
        if ([self currentMagzine])
        {
            [self setCurrentMagzine:[KSModelMagzine loadById:[self currentMagzine].magzineId]];

        }
        else {
            [self setCurrentMagzine:[_magzines objectAtIndex:0]];

        }
    }
    [self.main setNeedsLayout];
}

- (void) whenMagzineDownloaded:(NSNotification*)notification{
    KSDownMagazineOperation *op = [[KSBootstrap dataCenter] valueForKey:KEY_DOWNLOADING_M_ID];

    if (op)
    {
        [[KSBootstrap dataCenter] removeObjectForKey:KEY_DOWNLOADING_M_ID];

    }
    NSDictionary *data = notification.userInfo;
    [main.coverScrollView whenMagzineDownloader:DICT_INTVAL(data, @"magzine_id")];
    [main.bottomShelfView whenMagzineDownloader:DICT_INTVAL(data, @"magzine_id")];
    [main.bookShelfView whenMagzineDownloader:DICT_INTVAL(data, @"magzine_id")];
    [main.bookStoreView whenMagzineDownloader:DICT_INTVAL(data, @"magzine_id")];
    
    [self setCurrentMagzine:[KSModelMagzine loadById:[self currentMagzine].magzineId]];
    [main setNeedsLayout];
}

- (void) whenMagzineCoverDownloaded:(NSNotification*)notification{
    NSDictionary *data = notification.userInfo;
    if(DICT_INTVAL(data, @"cover")==2){
        [main.coverScrollView whenMagzineCover1Download:DICT_INTVAL(data, @"magzine_id")];
        [main.coverScrollView whenMagzineCover0Download:DICT_INTVAL(data, @"magzine_id")];
        [main.bottomShelfView whenMagzineCover0Download:DICT_INTVAL(data, @"magzine_id")];
        [main.bookStoreView whenMagzineCoverDownloaded:DICT_INTVAL(data, @"magzine_id")];
        [main.bookShelfView whenMagzineCoverDownloaded:DICT_INTVAL(data, @"magzine_id")];
    }
//    else  if(DICT_INTVAL(data, @"cover")==3)
//    {
//        [main.coverScrollView whenMagzineCover0Download:DICT_INTVAL(data, @"magzine_id")];
//        [main.bottomShelfView whenMagzineCover0Download:DICT_INTVAL(data, @"magzine_id")];
//        [main.bookStoreView whenMagzineCoverDownloaded:DICT_INTVAL(data, @"magzine_id")];
//        [main.bookShelfView whenMagzineCoverDownloaded:DICT_INTVAL(data, @"magzine_id")];
//    }
}

- (void)whenArticleDownload:(NSNotification *)notification{
    NSDictionary *data = notification.userInfo;
    NSInteger magzineId = DICT_INTVAL(data, @"magzine_id");
    KSModelMagzine *magzine = [KSModelMagzine loadById:magzineId];
    if(magzine.downloadArticlesNumber>=magzine.articlesNumber)return;
    RELEASE_SAFELY(_magzines);
//    [main.bookshelf whenInitOrMagzineListUpdate];
}

- (void)whenMagzineDeleted:(KSModelMagzine *)magazine
{
    [main.bottomShelfView whenMagzineDeleted:magazine];
    [main.coverScrollView whenMagzineDeleted:magazine];
    [main.bookStoreView whenMagzineDeleted:magazine];
    [main.bookShelfView whenMagzineDeleted:magazine];
    
    [main setNeedsLayout];
}
- (void)storageCleaned {
//    RELEASE_SAFELY(_magzines);
//    [main.coverflow dropAndLoadCoverflow];
//    [main.bottomShelfView reloadData];
    [self refreshData];
}

- (void)showNoPermissionView:(KSModelMagzine *)mag delegate:(id<KSNoPermissionAlertViewDelegate>)delegate{
    if (!_noPermissionAlertView) {
        _noPermissionAlertView = [[KSNoPermissionAlertView alloc] initWithFrame:CGFULL magazine:mag];
    }
    _noPermissionAlertView.delegate = delegate;
    [self.view addSubview:_noPermissionAlertView];
    [UIUtil addAnimationPop:_noPermissionAlertView];
}
- (void)dismissNoPermissionView {
    [_noPermissionAlertView removeFromSuperview];
    RELEASE_SAFELY(_noPermissionAlertView);
}

#pragma mark - KSDataRequestDelegate
- (void)requestDidStarted:(KSBaseDataRequest *)request {
    
}
- (void)requestDidFinished:(KSBaseDataRequest *)request {
    [UIUtil hideProcessIndicatorWithView:self.view];
    if ([request isKindOfClass:[CXFireSubscriptionEventDataRequest class]]) 
    {
        KSDINFO(@"%@",request.resultDict);
        [UserHelper saveMyFreeToDB:request.resultDict];
        [self loginUser:[KSBootstrap currentUser]];
//        [UserHelper saveMyFreeToDB:request.resultDict];
//        RELEASE_SAFELY(_magzines);
//        [main.coverScrollView   reloadData];
//        [main.bottomShelfView reloadData];
        
//        [self refreshData];
    }
}
- (void)requestDidCanceled:(KSBaseDataRequest *)request {
    [UIUtil hideProcessIndicatorWithView:self.view];
}
- (void)requestDidFailed:(KSBaseDataRequest *)request withError:(NSError*)error {
    [UIUtil hideProcessIndicatorWithView:self.view];
}



@end
