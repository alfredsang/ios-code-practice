//
//  KSArticleViewController.h
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSArticleBackgroundView.h"
#import "KSArticleHeaderBarView.h"
#import "KSArticleFooterBarView.h"
#import "KSGetMagzineArticlesOperation.h"
#import "KSCaixinCommentView.h"
#import "KSArticleSearchView.h"
#import "KSArticleProgressView.h"
#import "KSUIWindow.h"
#import "KSArticlePagesScrollView.h"
#import "KSArticleHelpView.h"
#import "KSNoPermissionAlertView.h"
#import "KSArticlePagesView.h"
#import "KSNoPermissionAlertView.h"
#import "KSDirectoryListView.h"

@class KSArticlePagesScrollView;

@interface KSArticleViewController : UIViewController<KSUIWindowDelegate,UIGestureRecognizerDelegate,UIPopoverControllerDelegate,KSNoPermissionAlertViewDelegate>{
    NSInteger _magzineId;
    NSInteger _articleId;
    
    NSInteger _launchFrom;// 0,主界面，1，收藏 2,搜索
    
    NSInteger _currentPageIndex;            //
    NSInteger _currentCatalogIndex;         //
    
    KSModelMagzine *_currentMagazine;
    KSArticleBackgroundView *background;
    KSArticleHeaderBarView *header;
    KSArticleFooterBarView *footer;
    KSArticleProgressView *progressView;
    
    KSArticlePagesScrollView *pagesScrollView;
    KSArticlePagesView *_articlePageView;
    NSArray *_articles;
    NSMutableArray *_readableArticlesArray;
    NSMutableArray* contentLengthOffsetArr;
    UIPageControl *pageControl;
    NSTimer *hideTimer;
    BOOL _headerHide;
    BOOL _forceHideHeader;
    
    UIPopoverController *_sharePopController;
    KSCaixinCommentView *_commentView;
    KSArticleSearchView *_articleSearchView;
    KSArticleHelpView *_articleHelpView;
    KSNoPermissionAlertView *_noPermissionAlertView;
    BOOL _isDidAppear;
    
    BOOL _panning;
    BOOL _loadPrevMagzine;
    
    UIImageView *_tmpMainImageView;
    CGFloat _tripleStart;
    
    KSModelArticle *_currentArticle;
    NSInteger _oldPageIndex;
    KSDirectoryListView *_directoryListView;
}
@property(nonatomic, assign)NSInteger magzineId;
@property(nonatomic, readonly)NSInteger currentPageIndex;
@property(nonatomic, readonly)NSMutableArray *contentLengthOffsetArr;
@property(nonatomic, assign)BOOL forceHideHeader;
@property(nonatomic, assign)BOOL headerHide;
@property(nonatomic, assign)NSInteger launchFrom;
@property(nonatomic, readonly)KSArticlePagesView *articlePageView;
@property(nonatomic, retain)NSMutableArray *readableArticlesArray;
@property(nonatomic, retain)NSArray *articles;

- (id)init:(NSInteger)magzineId articleId:(NSInteger)articleId;
- (KSModelArticle *)currentArticle;
- (KSModelMagzine *)currentMagzine;
- (NSArray *)articles;
- (void) loadPages;
- (void) whenArticleDownload:(NSNotification *)notification;
- (void) reloadData;
- (void) gotoArticleId:(NSInteger) articleId;
- (void) gotoArticleFromCatalog:(NSString *) articleId;
- (void) showArticleSlide:(NSInteger) articleId;
- (void) showSlide:(NSArray *)images;
- (void) showArticleVideo:(NSInteger) articleId full:(BOOL)full;
- (void) showArticleVideo:(NSInteger) articleId vIndex:(NSInteger)i full:(BOOL)full;
- (void) showVideo:(NSURL *)url full:(BOOL)full;
- (void) showChildren:(NSArray *)articles;
- (void) showChildArticles:(KSModelArticle *)articl;
- (void)showArticleMapView:(KSModelArticle *)articl;
- (void) resetHideTimer:(BOOL)need;

- (NSInteger)currentCatalogIndex;

//
- (void)articleLoaded;
- (void)articleDidLoad:(NSInteger)index;
//根据ID返回可阅读的文章，如果不存在或不可阅读返回nil
- (KSModelArticle *)articleById:(NSInteger)articleId;
- (void) gotoPageWithIndex:(NSInteger) index;
- (void)gotoNextPage;
- (void)gotoPrevPage;
//分享
- (void)showShareMenu;
- (void)dismissShareMenuAnimated:(BOOL)animat;
//评论
- (void)openCommentView;
- (void)dismissCommentView;
//无权限提示
- (void)showNoPermissionView:(KSModelMagzine *)mag delegate:(id<KSNoPermissionAlertViewDelegate>)delegate;
- (void)dismissNoPermissionView;
//搜索
- (void)searchThis;
- (void)dismissArticleSearchView;
//帮助
- (void)showHelpView;
- (void)showHelp:(id)target;
- (void)dismissHelpview;
//
- (void)resetTripstate;
//
- (void)removeAllArticleViews;

-(void)showCatalogListView;

- (void) gotoArticleId:(NSInteger) articleId;

- (void)hideHeaderAndFooter;

- (void)showHeaderAndFooter;

@end
