//
//  KSPopShareViewController.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 1/4/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KSPopShareViewController.h"
#import "KSArticleViewController.h"
#import "KSModelArticle.h"
#import "SHKSharer.h"

@implementation KSPopShareViewController
@synthesize item = _item;
@synthesize type;

- (void)dealloc {
    [_sharers release];
    [_item release];
    
    [super dealloc];
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (id)initWithShareType:(SHKShareType)shareType {
    self = [self initWithNibName:nil bundle:nil];
    if (self) {
        type = shareType;
    }
    return self;
}
- (id)initWithSHKItem:(SHKItem *)i {
    self = [self initWithNibName:nil bundle:nil];
    if (self) {
        _item = [i retain];
        type = _item.shareType;
    }
    return self;
}
- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle


// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
    [super loadView];
    //SHKShareType shareType = SHKShareTypeText;
    if (_item) {
        type = _item.shareType;
    }
    NSArray *array = [SHK favoriteSharersForType:type];
	
	NSMutableArray *newSharers = [NSMutableArray array];
	
	// Add buttons for each favoriate sharer
	id class;
    int i = 0;
	for(NSString *sharerId in array) {
		class = NSClassFromString(sharerId);
		if ([class canShare]) {
            UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(0, i*45, 248, 45)];
            [btn setBackgroundImage:[UIImage imageNamed:@"btn_shareitem.png"] forState:UIControlStateNormal];
            [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
            [self.view addSubview:btn];
            btn.tag = 3000+i;
            [btn addTarget:self action:@selector(showShare:) forControlEvents:UIControlEventTouchUpInside];
            [btn release];
            NSString *title;
            if ([sharerId isEqualToString:@"SHKMail"]) {
                title = [NSString stringWithFormat:@"%@分享", [class sharerTitle]] ;
            } else if ([sharerId isEqualToString:@"SHKPhotoAlbum"]){
                title = @"保存到相册";//[NSString stringWithFormat:@"%@分享", SHKLocalizedString([class sharerTitle])] ;
            }
            else {
                title = [NSString stringWithFormat:@"分享到%@", [(SHKSharer *)class sharerTitle]];
            }
			[newSharers addObject:sharerId];
            [btn setTitle:title forState:UIControlStateNormal];
            
            i++;
		}
        
	}
    if (_sharers) {
        [_sharers release];
    }
    _sharers = [newSharers retain];
    self.view.frame = CGRectMake(0, 0, 248, i*45);
}



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark -
- (void)showShare:(id)sender {
    NSInteger index = ((UIView *)sender).tag-3000;
    if ([[_sharers objectAtIndex:index] isEqualToString:@"SHKMail"]) {
        KSModelArticle *article = [KSModelArticle loadById:[[_item customValueForKey:@"articleid"] intValue] withContent:YES];
        if (article.artitype == 0) {
            //[_item setCustomValue:article.content forKey:@"articleContent"];
            [_item setCustomValue:@"1" forKey:@"fulltext"];
        }else {
            [_item setCustomValue:@"1" forKey:@"fulltext"];
        }
    }
    [NSClassFromString([_sharers objectAtIndex:index]) performSelector:@selector(shareItem:) withObject:_item];
    [(KSArticleViewController *)[[KSMainController mainController] activeController] dismissShareMenuAnimated:NO];
}


@end
