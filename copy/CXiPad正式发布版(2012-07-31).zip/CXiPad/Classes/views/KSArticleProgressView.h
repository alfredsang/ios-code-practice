//
//  KSArticleProgressView.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 1/8/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSViewInitor.h"

@interface KSArticleProgressView : UIView<KSViewInitor>{
    NSInteger _downloadArticlesNum;
    NSInteger _articlesNum;
    UILabel *lblProgress;
    UIView *progressBarView;
}
- (void) setProgress:(NSInteger)downloadNum allNums:(NSInteger)allNums;
@end
