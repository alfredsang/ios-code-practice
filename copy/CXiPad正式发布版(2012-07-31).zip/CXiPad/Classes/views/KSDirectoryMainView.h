//
//  KSDirectoryMainView.h
//  CenturyWeeklyV2
//
//  Created by 广亮 高 on 12-6-19.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSCatalogTableView.h"
#import "KSCatalogTableView.h"
#import "KSArticleListTabelView.h"

#define LEFT_WIDTH  256
#define MID_WIDTH   256
#define RIGHT_WIDTH 256

#define PUBDATE_FONT    [UIFont systemFontOfSize:9]




@class KSArticleViewController;
@interface KSDirectoryMainView : UIView
{
    UIImageView     *_magazineCoverImageView;
    UILabel         *_magazinePubdateLabel;
    UIButton     *_adImageView;
    KSModelMagzine  *_magazine;
    KSArticleViewController *_controller;
    KSCatalogTableView      *_catalogTabelView;
    KSArticleListTabelView  *_articleTabelView;
    UIView          *_headerBarBgView;
    UIImageView *_bgView;
    UIImageView *_adCutOffImageView;
    UIImageView *_firstCutOffImageView;
    UIImageView *_secondCutOffImageView;
}

@property(nonatomic,retain) KSCatalogTableView      *catalogTabelView;
@property(nonatomic,retain) KSArticleListTabelView  *articleTabelView;
@property(nonatomic,retain) KSArticleViewController *controller;
@property(nonatomic,retain) UIView          *headerBarBgView;

- (id)initWithFrame:(CGRect)frame magazine:(NSInteger)magazineId controller:(id)controller;
-(void)showHeaderBar;
-(void)hiddenHeaderBar;

@end


