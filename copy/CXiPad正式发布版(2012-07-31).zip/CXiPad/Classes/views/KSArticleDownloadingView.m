//
//  KSArticleDownloadingView.m
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSArticleDownloadingView.h"

@implementation KSArticleDownloadingView

- (id)initWithFrame:(CGRect)frame index:(NSInteger)index
{
    self = [super initWithFrame:frame];
    if (self) {
        _index = index;
        [self initSubviews];
    }
    return self;
}
- (void)dealloc{
    [_indicator stopAnimating],[_indicator release];
    [super dealloc];
}

- (void)layoutSubviews {
    if ([UIUtil currentOrientation] == 0) {
        _indicator.center = CGPointMake(384, 512);
    } else {
        _indicator.center = CGPointMake(512, 384);
    }
}
- (void)initSubviews{
//    UILabel *downLbl = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.width, self.height)];
//    downLbl.backgroundColor = [UIColor clearColor];
//    downLbl.text = @"正在为您下载，请耐心等候。";
//    downLbl.font = [UIFont systemFontOfSize:36.0];
//    downLbl.textAlignment = UITextAlignmentCenter;
//    [self addSubview:downLbl];
//    [downLbl release];
    
    _indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    //_indicator.frame = CGRectMake(0, 0, 400, 400);
    _indicator.center = self.center;
    [_indicator startAnimating];
    [self addSubview:_indicator];
    
}

- (NSInteger)getIndex{
    return _index;
}
@end
