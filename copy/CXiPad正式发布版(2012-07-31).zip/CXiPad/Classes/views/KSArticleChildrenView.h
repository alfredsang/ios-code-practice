//
//  KSArticleChildrenView.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 2/9/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KSPageView.h"
#import "KSArticleWebView.h"
#import "KSModelArticle.h"

@interface KSArticleChildrenView : KSPageView {
    KSModelArticle *_parentArticle;
    
    //NSMutableArray *_articleList;
    
    UIButton *_dismissBtn;
}
- (id)initWithFrame:(CGRect)frame article:(KSModelArticle *)article;
@end
