//
//  KSArticleMapView.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 2/11/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KSArticleMapView.h"

@implementation KSArticleMapView

- (void)dealloc {
    [_article release];
    _articleMapView.delegate = nil;
    [_articleMapView release];
    [_locationArray release];
    [_dismissBtn release];
    [super dealloc];
}
- (void)initSubviews {
    _articleMapView = [[MKMapView alloc] initWithFrame:self.bounds];
    _articleMapView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    [self addSubview:_articleMapView];
    
    _dismissBtn = [[UIButton alloc] initWithFrame:CGRectMake(self.width-50, 0, 50, 50)];
    _dismissBtn.showsTouchWhenHighlighted = YES;
    [_dismissBtn setImage:[UIImage imageNamed:@"btn_slideshow_close.png"] forState:UIControlStateNormal];
    [_dismissBtn addTarget:self action:@selector(dismissThis:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_dismissBtn];
    _dismissBtn.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin|UIViewAutoresizingFlexibleBottomMargin;
    
    double maxX = 0, minX = 0, maxY = 0,minY = 0;
    int i = 0;
    for (KSModelLocation *l in _locationArray) {
        if(i==0) {
            maxX = minX = l.longitude;
            maxY = minY = l.latitude;
        } else {
            maxX = MAX(l.longitude, maxX);
            minX = MIN(l.longitude, minX);
            maxY = MAX(l.latitude, maxX);
            minY = MIN(l.latitude, minX);
        }
        CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake(l.longitude, l.latitude);
        CustomAnnotation *annotation = [[CustomAnnotation alloc]
                                        initWithCoordinate:coordinate];
        
        annotation.title = l.annotation;
        annotation.subtitle = @"";
        [_articleMapView addAnnotation:annotation];
        [annotation release];
    }
    if (maxX != 0 || minX != 0) {
        MKCoordinateRegion viewRegion = MKCoordinateRegionMakeWithDistance(CLLocationCoordinate2DMake(minX+(maxX-minX)/2, minY+(maxY-minY)/2),10000, 10000);
        MKCoordinateRegion adjustedRegion = [_articleMapView regionThatFits:viewRegion];
        [_articleMapView setRegion:adjustedRegion animated:YES];
    }
}
- (id)initWithFrame:(CGRect)frame article:(KSModelArticle *)article {
    self = [super initWithFrame:frame];
    if (self) {
        _article = [article retain];
        NSArray *array = [_article.coordinates componentsSeparatedByString:@","];
        _locationArray = [[NSMutableArray alloc] init];
        if ([array count] > 0) {
            int num = [array count];
            for (int i = 0; i<num/3; i++) {
                NSInteger startIndex = i*3;
                KSModelLocation *locaiton = [[KSModelLocation alloc] init];
                locaiton.latitude = [[array objectAtIndex:startIndex+1] floatValue];
                locaiton.longitude = [[array objectAtIndex:startIndex] floatValue];
                locaiton.annotation = [array objectAtIndex:startIndex+2];
                [_locationArray addObject:locaiton];
                [locaiton release];
            }
        }
        [self initSubviews];
    }
    return self;
}


- (void) dismissThis:(id)rec{
    [self removeFromSuperview];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end



@implementation KSModelLocation
@synthesize latitude = _latitude;
@synthesize longitude = _longitude;
@synthesize annotation = _annotation;

- (void)dealloc {
    [_annotation release];
    
    [super dealloc];
}

@end

@implementation CustomAnnotation

@synthesize coordinate;
@synthesize title;
@synthesize subtitle;

- (id)initWithCoordinate:(CLLocationCoordinate2D)coords {
	if(self = [super init]) {
		coordinate = coords;
	}
	return self;
}

- (void)dealloc {
	[title release];
	[subtitle release];
    
	[super dealloc];
}

@end

