//
//  CXGiftcardView.m
//  CenturyWeeklyV2
//
//  Created by zyk on 2/29/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "CXGiftcardView.h"
#import "CXDataRequest.h"
#import "CXAccountView.h"
#import "UserHelper.h"
#import "KSMagzineViewController.h"

@implementation CXGiftcardView
@synthesize parent = _parent;

- (void)dealloc {
    [KSBaseDataRequest cancelRequest:@"CXLoadFreeMagazineDataRequest_1"];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
    IF_IOS5_OR_GREATER([[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillChangeFrameNotification object:nil];)
    [KSBaseDataRequest cancelRequest:@"CXLoginDataRequest_gift"];
    [KSBaseDataRequest cancelRequest:@"CXGiftCardDataRequest_1"];
    RELEASE_SAFELY(_loginRequest);
    
    [headerLabel release];
    [giftcardLabel release];
    [giftcardTipLabel release];
    [caxinSwitchLabel release];
    [emailLabel release];
    [passwordLabel release];
    [passverifyLabel release];
    [footerLabel release];
    
    [giftcardNumTextfield release];
    [emailTextfield release];
    [passTextfield release];
    [passverifyTextfield release];
    
    [submitButton release];
    [hasCaixinSwitch release];
    
    [usernameLabel release];
    [usernameTextfield release];
    
    [_emailStr release];
    [_giftcardStr release];
    [_pwdStr release];
    [_introStr release];
    
    [backView release];
    [_webView release];
    [lineView release];
    [super dealloc];
}
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}
- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
        /* Listen for keyboard */
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
        
        IF_IOS5_OR_GREATER([[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeKeyboardFrame:) name:UIKeyboardWillChangeFrameNotification object:nil];);
    }
    return self;
}
- (void)hideLoginform {
    caxinSwitchLabel.hidden = YES;
    emailLabel.hidden = YES;
    passwordLabel.hidden = YES;
    passverifyLabel.hidden = YES;
    
    emailTextfield.hidden = YES;
    passTextfield.hidden = YES;
    passverifyTextfield.hidden = YES;
    hasCaixinSwitch.hidden = YES;
    
    submitButton.top -= 100;
    footerLabel.top -= 100;
    _webView.top -= 100;    //[submitButton addTarget:self action:@selector(doSubmitCardNO) forControlEvents:UIControlEventTouchUpInside];
    submitButton.tag = 3000;
}
- (void)hideRegForm {
    passverifyTextfield.hidden = YES;
    passverifyLabel.hidden = YES;
    usernameLabel.hidden = YES;
    usernameTextfield.hidden = YES;
    passTextfield.top -= 41;
    passwordLabel.top -= 41;
    submitButton.top -= 70;
    footerLabel.top -= 70;
    _webView.top -= 70;
    submitButton.tag = 3001;
}
- (void)showRegForm {
    passverifyTextfield.hidden = NO;
    passverifyLabel.hidden = NO;
    usernameLabel.hidden = NO;
    usernameTextfield.hidden = NO;
    passTextfield.top += 41;
    passwordLabel.top += 41;
    submitButton.top += 70;
    footerLabel.top += 70;
    _webView.top += 70;
    submitButton.tag = 3002;
}
- (void)awakeFromNib {
    giftcardNumTextfield.delegate = self;
    emailTextfield.delegate = self;
    passTextfield.delegate = self;
    passverifyTextfield.delegate = self;
    usernameTextfield.delegate = self;
    
    submitButton.titleLabel.font = [UIFont systemFontOfSize:15.0f];
    [submitButton setBackgroundImage:[UIImage imageNamed:@"btn_com.png"] forState:UIControlStateNormal];
//    [submitButton setTitle:@"提交" forState:UIControlStateNormal];
    [hasCaixinSwitch setOn:YES animated:NO ignoreControlEvents:YES];
    hasCaixinSwitch.offText = @"无";
    hasCaixinSwitch.onText = @"有";
//    [self hideRegForm];
    submitButton.tag = 3001;
    if ([KSBootstrap currentUser]) {
        [self hideLoginform];
        submitButton.tag = 3000;
    }
    
    _introStr = [[NSString alloc] initWithString:@"<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" /><meta name='viewport' content='initial-scale=1, maximum-scale=1'><style type='text/css'>* {-webkit-touch-callout: none;-webkit-user-select: none;}p{font-size:14px;line-height:120%;margin-top:10px;margin-bottom:0px;}li{font-size:14px;margin-left:-20px;margin-top:10px;line-height:120%;}</style></head><body style='background-color: transparent; margin:0;'>"
                 "<p style='font-size:16px;'>什么是读者编号？<p>"
                 "<p>读者编号是印刷版财新《新世纪》的用户ID，为15位数字和字母组合。凡财新《新世纪》订户、赠阅用户，均可在杂志包装袋上的的标签中查到。</p>"
                 "<p>我们同时为财新《新世纪》iPad版赠阅用户提供读者编号。请向赠阅人索取您的读者编号。</p>"
                 "<ul>"
                 "<li>如您是通过财新网订阅中心 <a href='http://shop.caixin.com' target='_blank'>http://shop.caixin.com</a> 订阅，请直接以订阅时使用的财新网通行证登录，开通订期内iPad版阅读权限。</li>"
                 "<li>如您是通过电话、传真等方式向《新世纪》周刊社订阅，请先以财新网通行证登录，并输入您的读者编号，开通订期内iPad版阅读权限。</li>"
                 "<li>如您是通过邮局、电商或其它渠道订阅，请先联系客服（全国免费电话：400-696-0110；电邮： <a href='#sendServiceMail' target='_blank'>service@caixin.com</a>）获取读者编号。以财新网通行证登录，输入读者编号后开通订期内iPad版阅读权限。</li>"
                 "<li>如您是印刷版/iPad版赠阅用户，请先以财新网通行证登录，输入读者编号后，开通iPad版阅读权限。</li></ul></body></html>"];
    _webView.backgroundColor = [UIColor clearColor];
    ((UIScrollView *)[[_webView subviews] objectAtIndex:0]).scrollEnabled = NO;
    [_webView loadHTMLString:_introStr baseURL:nil];
    
    
}
- (void)resignAllTextFields {
    [usernameTextfield resignFirstResponder];
    [giftcardNumTextfield resignFirstResponder];
    [emailTextfield resignFirstResponder];
    [passTextfield resignFirstResponder];
    [passverifyTextfield resignFirstResponder];
    
    usernameTextfield.rightView.hidden = YES;
    usernameTextfield.rightViewMode = UITextFieldViewModeNever;
    
    giftcardNumTextfield.rightView.hidden = YES;
    giftcardNumTextfield.rightViewMode = UITextFieldViewModeNever;
    
    emailTextfield.rightView.hidden = YES;
    emailTextfield.rightViewMode = UITextFieldViewModeNever;
    
    passTextfield.rightView.hidden = YES;
    passTextfield.rightViewMode = UITextFieldViewModeNever;
    
    passverifyTextfield.rightView.hidden = YES;
    passverifyTextfield.rightViewMode = UITextFieldViewModeNever;
    
}
- (void)layoutSubviews {
    //[self resignAllTextFields];
//    if ([UIUtil currentOrientation] == 0) {
        headerLabel.left = 30;
        giftcardLabel.left = 30;
        giftcardTipLabel.left = 148;
        caxinSwitchLabel.left = 30;
        emailLabel.left = 30;
        passwordLabel.left = 30;
        passverifyLabel.left = 30;
        footerLabel.left = 30; footerLabel.width = 376,footerLabel.height = 273;
        usernameLabel.left = 30;
        
        usernameTextfield.left = 147;
        giftcardNumTextfield.left = 147;
        emailTextfield.left = 147;
        passTextfield.left = 147;
        passverifyTextfield.left = 147;
        
        submitButton.left = 148;
        
        hasCaixinSwitch.left = 148;
        lineView.left = 30; lineView.width = 377;
        _webView.left = 20; _webView.width = 400;
//        self.contentSize = CGSizeMake(self.width, 940);
//    } else {
//        headerLabel.left = 60;
//        giftcardLabel.left = 60;
//        giftcardTipLabel.left = 178;
//        caxinSwitchLabel.left = 60;
//        emailLabel.left = 60;
//        passwordLabel.left = 60;
//        passverifyLabel.left = 60;
//        footerLabel.left = 60; footerLabel.width = 472,footerLabel.height = 220;
//        usernameLabel.left = 60;
//        
//        usernameTextfield.left = 177;
//        giftcardNumTextfield.left = 177;
//        emailTextfield.left = 177;
//        passTextfield.left = 177;
//        passverifyTextfield.left = 177;
//        
//        submitButton.left = 178;
//        
//        hasCaixinSwitch.left = 178;
//        lineView.left = 60; lineView.width = 570;
//        _webView.left = 50; _webView.width = 580;
//        self.contentSize = CGSizeMake(self.width, 900);
//    }
}
#pragma mark - helper
- (void)showError:(UITextField *)textField msg:(NSString *)text {
    UILabel *label = (UILabel *)textField.rightView;
    if (!label) {
        label = [UIUtil newLabelWithFrame:CGRectZero text:text textColor:[UIColor redColor] font:[UIFont systemFontOfSize:14]];
        textField.rightView = label;
        [label release];
    }else {
        label.text = text;
    }
    [label sizeToFit];
    textField.rightViewMode = UITextFieldViewModeAlways;
    label.hidden = NO;
    //textField.layer.borderColor = [[UIColor redColor] CGColor];
    //textField.layer.borderWidth = 1.0f;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/


- (IBAction)switchChanged:(id)sender {
    if (hasCaixinSwitch.on) {
        [self hideRegForm];
    } else {
        [self showRegForm];
    }
}

- (IBAction)doSubmit:(id)sender {
    if (submitButton.tag == 3000) {//直接提交订阅卡，已登录
        [self doSubmitCardNO];
    } else if (submitButton.tag == 3001) {//有通行证，走登录逻辑
        [self doLogin];
    } else {                                //无通行证，走注册逻辑
        [self doReg];
    }
}
//注册
- (void)doReg {
    [self resignAllTextFields];
    
    BOOL hasError = NO;
    NSString *giftcardno = [giftcardNumTextfield.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    NSString *mail = [emailTextfield.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    NSString *pwdStr = [passTextfield.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    NSString *confirmPwd = [passverifyTextfield.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    NSString *nickname = [usernameTextfield.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    if (giftcardno==nil || [giftcardno length]==0) {
        hasError = YES;
        [self showError:giftcardNumTextfield msg:@"读者编号为空或不合法  "];
    }
    if (mail==nil || [mail length]==0) {
        hasError = YES;
        [self showError:emailTextfield msg:@"邮箱不能为空  "];
    }else if(![DataUtil validateEmail:mail]){
        hasError = YES;
        [self showError:emailTextfield msg:@"邮箱不合法  "];
    }
    if (pwdStr==nil || ![pwdStr length] || [pwdStr length] < 6) {
        hasError = YES;
        [self showError:passTextfield msg:@"密码不能为空  "];
    } else if ([pwdStr length] < 6) {
        hasError = YES;
        [self showError:passTextfield msg:@"密码太短  "];
    } else if ([pwdStr length] > 16) {
        hasError = YES;
        [self showError:passTextfield msg:@"密码太长  "];
    }else if(![pwdStr isEqualToString:confirmPwd]){
        hasError = YES;
        [self showError:passverifyTextfield msg:@"两次密码不相同  "];
    }
    if (nickname==nil || ![nickname length]) {
        hasError = YES;
        [self showError:usernameTextfield msg:@"用户名不能为空   "];
    } else if ([nickname length] < 3) {
        hasError = YES;
        [self showError:usernameTextfield msg:@"用户名太短   "];
    } else if ([nickname length] > 16) {
        hasError = YES;
        [self showError:usernameTextfield msg:@"用户名太长   "];
    }
    [_emailStr release];
    [_pwdStr release];
    [_giftcardStr release];
    _emailStr = [mail retain];
    _pwdStr = [pwdStr retain];
    _giftcardStr = [giftcardno retain];
    
    if (hasError) {
        return;
    }
    
    [CXRegDataRequest requestWithDelegate:self withParameters:[NSDictionary dictionaryWithObjectsAndKeys:mail,@"email",pwdStr,@"pwd",nickname,@"nickname", nil] withIndicatorView:_parent withCancelSubject:@"CXRegDataRequest"];
    
}
//提交礼品卡
- (void)doSubmitCardNO {
    [self resignAllTextFields];
    BOOL hasError = NO;
    NSString *giftcardno = [giftcardNumTextfield.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    if (giftcardno==nil || [giftcardno length]==0) {
        hasError = YES;
        [self showError:giftcardNumTextfield msg:@"读者编号为空或不合法  "];
    }
    [_giftcardStr release];_giftcardStr = [giftcardno retain];
    _emailStr = [[KSBootstrap currentUser] retain];
    if (hasError) {
        return;
    }
    
    [CXGiftCardDataRequest requestWithDelegate:self url:SERVER_URL(@"/usecard/%@/%@/%@", MAGZINE_TYPE,_emailStr,[_giftcardStr URLEncodedString]) withParameters:nil withIndicatorView:_parent withCancelSubject:@"CXGiftCardDataRequest_1"];
}
//登录
- (void)doLogin {
    [self resignAllTextFields];
    
    BOOL hasError = NO;
    NSString *giftcardno = [giftcardNumTextfield.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    NSString *mail = [emailTextfield.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    NSString *pwdStr = [passTextfield.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    if (giftcardno==nil || [giftcardno length]==0) {
        hasError = YES;
        [self showError:giftcardNumTextfield msg:@"读者编号为空或不合法  "];
    }
    if (mail==nil || [mail length]==0) {
        hasError = YES;
        [self showError:emailTextfield msg:@"邮箱不能为空  "];
    }else if(![DataUtil validateEmail:mail]){
        hasError = YES;
        [self showError:emailTextfield msg:@"邮箱不合法  "];
    }
    if (pwdStr==nil || ![pwdStr length]) {
        hasError = YES;
        [self showError:passTextfield msg:@"密码不能为空  "];
    }
    if (hasError) {
        return;
    }
    [_emailStr release];
    [_pwdStr release];
    [_giftcardStr release];
    _emailStr = [mail retain];
    _pwdStr = [pwdStr retain];
    _giftcardStr = [giftcardno retain];
    
    [CXLoginDataRequest requestWithDelegate:self withParameters:[NSDictionary dictionaryWithObjectsAndKeys:_emailStr,@"email",_pwdStr,@"pwd", nil] withIndicatorView:_parent withCancelSubject:@"CXLoginDataRequest_gift"];
}

#pragma mark -
- (UIView*)findFirstResponderWithinView:(UIView*)view {
    // search recursively for first responder
    for ( UIView *childView in view.subviews ) 
    {
        if ( [childView respondsToSelector:@selector(isFirstResponder)] && [childView isFirstResponder] ) return childView;
        UIView *result = [self findFirstResponderWithinView:childView];
        if ( result ) return result;
    }
    return nil;
}
- (void)moveUp {
    float innerKeyboardHeight = [UIUtil currentOrientation] == 0?316:406;
    UIView *v = [self findFirstResponderWithinView:self];
    CGRect rect = CGRectZero;
    if (v) {
        rect = [self convertRect:v.frame fromView:v.superview];
    }
    CGFloat height;//= rect.origin.y;
    if ([UIUtil currentOrientation] == 0) {
        height = 1024 - rect.origin.y;
    } else {
        height = 768 - rect.origin.y;
    }
    _moveHeight = innerKeyboardHeight - height + 90;
    if (_moveHeight<0) {
        _moveHeight = 0;
    }
    if (_moveHeight >= 0) {
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:0.3];
        backView.frame = CGRectMake(backView.frame.origin.x, backView.frame.origin.y-_moveHeight, backView.frame.size.width, backView.frame.size.height);
        [UIView commitAnimations];
    }
}
- (void)changeKeyboardFrame:(NSNotification *)notification {
    
}
- (void)keyboardWillShow:(NSNotification *)notification {
    //return;
    if (_isKeyboardShowing) {
        return;
    }
    _isKeyboardShowing = YES;
    [self moveUp];
    
}

- (void)keyboardWillHide:(NSNotification *)notification {
    _isKeyboardShowing = NO;
    if (_moveHeight >= 0) {
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:0.3];
        backView.frame = CGRectMake(backView.frame.origin.x, 0, backView.frame.size.width, backView.frame.size.height);
        [UIView commitAnimations];
    }
}
#pragma mark - UITextFieldDelegate
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    textField.rightView.hidden = YES;
    textField.rightViewMode = UITextFieldViewModeNever;
    return YES;
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    textField.rightView.hidden = YES;
    textField.rightViewMode = UITextFieldViewModeNever;
    [self moveUp];
    return YES;
}
//- (BOOL)textFieldShouldReturn:(UITextField *)textField {
//    //[textField resignFirstResponder];
//    return YES;
//}

#pragma mark -
- (void)didLoginSuccess:(KSBaseDataRequest *)request {
    //处理登录的请求
    KSDINFO(@"%@",request.resultDict);
    NSString *result = [[request.resultDict objectForKey:@"data"] objectForKey:@"code"];
    if ([result intValue]==-1) {
        [UIUtil hideProcessIndicatorWithView:self];
        [self showError:emailTextfield msg:@"用户名或密码错误  "];
//    } else if ([result intValue]==-2) {
//        [UIUtil hideProcessIndicatorWithView:self];
//        [self showError:emailTextfield msg:@"您的用户未激活  "];
    } else if ([result intValue]==0 || [result intValue]==2 || [result intValue]==-2) {
        //如果是礼品卡用户，没有激活也表示登录成功
        KSDINFO(@"%@", request.resultDict);
        //[KSBootstrap setCurrentUser:_emailStr];
        if ([request.resultDict objectForKey:@"data"]) {
            NSNumber *uid = [[request.resultDict objectForKey:@"data"] objectForKey:@"uid"];
            if (uid) {
                [KSDB saveString:STR_FORMAT(@"%d", [uid intValue]) forKey:UD_KEY_USERID];
            }
        }
        // 触发第一次登录
        //if ([[KSDB stringForKey:UD_KEY_FIRST_LOGIN] intValue] < 1) {//first
        //    [KSDB saveString:@"1" forKey:UD_KEY_FIRST_LOGIN];
        //参数分别为：杂志类型/赠送事件类型/用户email/
        [CXFireDonateEventDataRequest requestWithDelegate:self url:SERVER_URL(@"/fireEvent/%@/0/%@/%@", MAGZINE_TYPE,_emailStr,[[UIDevice currentDevice] uniqueGlobalDeviceIdentifier]) withParameters:nil withIndicatorView:_parent withCancelSubject:@"CXFireDonateEventDataRequest_1"];
        //与订阅中心同步杂志
        //[DataPersistence execWithDelegate:self operationName:@"syncMagazieWithWeb"];
        //[UIUtil showProcessIndicatorWithView:self atPoint:CGPointMake(self.frame.size.width/2-5, 520) hasMask:NO];
        //
    } else {
        [self showError:emailTextfield msg:@"用户不存在  "];
    } 
}
- (void)didLoadFree:(KSBaseDataRequest *)request {
    [KSBootstrap setCurrentUser:[_emailStr lowercaseString]];
    [UserHelper saveMyFreeToDB:request.resultDict];
    
    [(KSMagzineViewController *)self.viewController loginUserQuiet:_emailStr];
}
#pragma mark - KSDataRequestDelegate
- (void)requestDidStarted:(KSBaseDataRequest *)request {
    
}
- (void)requestDidFinished:(KSBaseDataRequest *)request {
    if ([request isKindOfClass:[CXRegDataRequest class]]) {
        NSString *rltStr = [request.resultDict objectForKey:@"data"];
        if( rltStr!=nil && ![rltStr isEqualToString:@""] ){
            if( [rltStr integerValue] == -1 ){
                [self showError:emailTextfield msg:@"注册信息不合法  "];
                return;
            }else if( [rltStr integerValue] == 1 ){
                [self showError:emailTextfield msg:@"邮箱或用户名已存在  "];
                return;
            } else if( [rltStr integerValue] == 0) {//注册成功请求server端发送激活邮件
                [CXActiveUserDataRequest requestWithDelegate:self withParameters:[NSDictionary dictionaryWithObjectsAndKeys:_emailStr, @"email", nil]];
            }else {
                [self showError:emailTextfield msg:@"未知问题  "];
                return;
            }
        }else{
            [self showError:emailTextfield msg:@"未知错误  "];
            return;
        }
    } else if ([request isKindOfClass:[CXActiveUserDataRequest class]]) {
        //[_parent displayRegSuccView:_emailStr password:_pwdStr];
        //[UIUtil showMsgAlertWithTitle:@"注册成功" message:@"激活邮件已发送到您的邮箱，根据邮件中向导完成激活您才拥有财新网通行证全部功能。"];
        [hasCaixinSwitch setOn:YES animated:NO ignoreControlEvents:NO];
        submitButton.tag = 3001;
        [self doLogin];
    }
    //正常登录返回
    if ([request isKindOfClass:[CXLoginDataRequest class]]) {
        [self didLoginSuccess:request];
        return;
    }
    //处理赠送返回
    if ([request isKindOfClass:[CXFireDonateEventDataRequest class]]) {
        RELEASE_SAFELY(_loginRequest);
        //_loginRequest = [request retain];
        
        [CXGiftCardDataRequest requestWithDelegate:self url:SERVER_URL(@"/usecard/%@/%@/%@", MAGZINE_TYPE,_emailStr,[_giftcardStr URLEncodedString]) withParameters:nil withIndicatorView:_parent withCancelSubject:@"CXGiftCardDataRequest_1"];
        return;
    }
    if ([request isKindOfClass:[CXGiftCardDataRequest class]]) {
        NSDictionary *dict = request.resultDict;
        //NSString *code = [dict objectForKey:@"success"];
        BOOL code = DICT_BOOLVAL(dict, @"success");
        if (!code) {
            NSString *msg = [dict objectForKey:@"info"];
            if (!msg || ![msg length]) {
                msg = @"卡号无效";
            }
            [UIUtil showMsgAlertWithTitle:@"提示" message:msg];
            return;
        } else {//1. 首次登录赠送 2. 礼品卡赠送 3. 订阅用户赠送 4. 人工赠阅 5. 纸刊订单赠送
//            if (_loginRequest != nil) {
//                [self didLoadFree:_loginRequest];
//            }
            NSDictionary *info = DICT_VAL(dict, @"info");
            NSInteger startTime = DICT_INTVAL(info, @"starttime");
            NSInteger endtime = DICT_INTVAL(info, @"endtime");
            //NSInteger magazineType = DICT_INTVAL(info, @"magazine_type");
            //NSString *str = @"读者编号赠送";
            //NSString *donateType = 1;
            //[[KSDB db] executeUpdate:@"insert into my_free_logic(user_email,start_time,end_time,free_count,free_type) values(?,?,?,?,?)",[KSBootstrap currentUser], INTEGER(startTime),INTEGER(endtime),INTEGER(0),INTEGER(2)];
            [CXLoadFreeMagazineDataRequest requestWithDelegate:self url:SERVER_URL(@"/myfree/%@/%@/%@", MAGZINE_TYPE,_emailStr,[KSDB stringForKey:KEY_DEVICE_UDID_STR]) withParameters:nil withIndicatorView:_parent withCancelSubject:@"CXLoadFreeMagazineDataRequest_1"];
            
            [UIUtil showMsgAlertWithTitle:@"提示" message:STR_FORMAT(@"读者编号提交成功,您已获赠%@至%@的期刊", [DateUtil strFromTimeIntervalSince1970:startTime format:@"yyyy年MM月dd日"],[DateUtil strFromTimeIntervalSince1970:endtime format:@"yyyy年MM月dd日"]) ];
            giftcardNumTextfield.text = @"";
            
            if(caxinSwitchLabel.hidden == NO) {
                [self hideLoginform];
            }
        }
    }
    if ([request isKindOfClass:[CXLoadFreeMagazineDataRequest class]]) {
        [self didLoadFree:request];
    }
}
- (void)requestDidCanceled:(KSBaseDataRequest *)request {
    
}
- (void)requestDidFailed:(KSBaseDataRequest *)request withError:(NSError*)error {
    
}
#pragma mark -
- (void)showService {
    [KSWebViewController presentWithURL:@"http://service.caixin.com/" inController:self.viewController];
}
- (void)sendServiceMail {
    if ([MFMailComposeViewController canSendMail]) {
        MFMailComposeViewController *mailController = [[[MFMailComposeViewController alloc] init] autorelease];
        mailController.navigationBar.barStyle = UIBarStyleDefault;
        mailController.mailComposeDelegate = self;
        [mailController setSubject:@"反馈订阅问题"];
        [mailController setToRecipients:[NSArray arrayWithObjects:@"service@caixin.com", nil]];
        [self.viewController presentModalViewController:mailController animated:YES];
    } else {
        [UIUtil showMsgAlertWithTitle:@"未配置邮箱" message:@"您可以在设置中配置好邮箱，可以直接发邮件。"];
    }
}
- (void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error {
    [self.viewController dismissModalViewControllerAnimated:YES];
}
#pragma mark -
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
    NSString *requestURL = [[request URL] absoluteString];
	if( [requestURL rangeOfString:@"#showService"].length>0 ){
		[self showService];
		return NO;
	}else if( [requestURL rangeOfString:@"#sendServiceMail"].length>0 ){
		[self sendServiceMail];
		return NO;
	}
	
	return YES;
}
- (void)webViewDidStartLoad:(UIWebView *)webView {
    
}
- (void)webViewDidFinishLoad:(UIWebView *)webView {
    
}

@end
