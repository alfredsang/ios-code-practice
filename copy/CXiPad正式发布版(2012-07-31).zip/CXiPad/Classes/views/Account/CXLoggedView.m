//
//  CXLoggedView.m
//  CenturyWeeklyV2
//
//  Created by zyk on 3/12/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "CXLoggedView.h"
#import "KSMagzineViewController.h"

@implementation CXLoggedView
@synthesize parent = _parent;

- (void)loadLoggedSubviews {
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(61, 48, 160, 30)];
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont boldSystemFontOfSize:18.0f];
    label.text = @"当前用户：";
    label.tag = 1014;
    [self addSubview:label];
    [label release];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(label.right, 45, 89, 30)];
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont systemFontOfSize:16.0f];
    label.text = [KSBootstrap currentUser];
    label.tag = 1016;
    label.adjustsFontSizeToFitWidth = YES;
    label.minimumFontSize = 5.0;
    [self addSubview:label];
    [label release];
    
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(200, label.bottom +20, 80, 28)];
    btn.tag = 1017;
    btn.titleLabel.font = [UIFont systemFontOfSize:15.0f];
    [btn setBackgroundImage:[UIImage imageNamed:@"btn_com.png"] forState:UIControlStateNormal];
    [btn setTitle:@"退出" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(logout) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:btn];
    btn.center = CGPointMake(round(self.width/2), btn.centerY);
    [btn release];
}
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self loadLoggedSubviews];
    }
    return self;
}
- (void)layoutSubviews {
    if ([UIUtil currentOrientation] == 0) {
        [self viewWithTag:1014].left = 30,[self viewWithTag:1014].width = 160;  //当前用户:
        [self viewWithTag:1016].left = 130,[self viewWithTag:1016].width = 240; //当前用户名
        [self viewWithTag:1017].left = 180;
    } else {
        [self viewWithTag:1014].left = 61,[self viewWithTag:1014].width = 160;  //当前用户:
        [self viewWithTag:1016].left = 160,[self viewWithTag:1016].width = 240; //当前用户名
        [self viewWithTag:1017].left = 260;
    }
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

#pragma mark -
- (void)logout {
    [(KSMagzineViewController *)self.viewController logout];
    [(CXAccountView *)self.superview freshAccountFormView];
}
@end
