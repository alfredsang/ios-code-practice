//
//  KSSubscribeSettingView.h
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-7.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CXDataRequest.h"


@class CXSubscribeElement;
@interface KSSettingSubscribeView : UIView<UITextFieldDelegate,KSDataRequestDelegate> {
    UIScrollView *_scrollView;
    UITextField *_cardTextField;
    
//    NSString *_subScribeString;
//    NSMutableString *_donateString;
//    NSMutableString *_boughtString;
//    NSMutableArray *_subScribeList;
//    NSMutableArray *_donateList;
//    NSMutableArray *_boughtList;
    NSMutableArray *_sectionData;
    NSMutableString *_sectionString;
    
    BOOL _isKeyboardShowing;
    CGFloat _moveHeight;
}

@end

@interface CXSubscribeElement : NSObject {
    NSString *_tranId;//事务ID
    NSInteger _issueYearNumber;
    NSInteger _issueTotalNumber;
    NSInteger _issueMonthNumber;
    NSInteger _issueDate;
    
    NSInteger _endIssueYearNumber;
    NSInteger _endIssueTotalNumber;
    NSInteger _endIssueMonthNumber;
    NSInteger _endIssueDate;
    
    NSString *_subscribeType;
}
@property(nonatomic, retain)NSString *tranId;
@property(nonatomic, assign)NSInteger issueYearNumber;
@property(nonatomic, assign)NSInteger issueTotalNumber;
@property(nonatomic, assign)NSInteger issueMonthNumber;
@property(nonatomic, assign)NSInteger endIssueYearNumber;
@property(nonatomic, assign)NSInteger endIssueTotalNumber;
@property(nonatomic, assign)NSInteger endIssueMonthNumber;
@property(nonatomic, assign)NSInteger issueDate;
@property(nonatomic, assign)NSInteger endIssueDate;
@property(nonatomic, retain)NSString *subscribeType;

+ (CXSubscribeElement *)subscribeElementWithDict:(NSDictionary *)dict;
- (NSString *)toSaveString;
- (NSString *)toPresentString;
@end