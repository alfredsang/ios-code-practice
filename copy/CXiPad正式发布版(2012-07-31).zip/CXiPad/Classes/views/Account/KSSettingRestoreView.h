//
//  KSSettingRestoreView.h
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-7.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CXAccountView;
@interface KSSettingRestoreView: UIView<UITableViewDelegate,UITableViewDataSource> {
    UITableView *_tableView;
    UILabel *_label;
    UIView *_footerView;
    
    BOOL _hasSubscription;
    CXAccountView *_parent;
}
@property(nonatomic, assign)CXAccountView *parent;

- (void)caixinSavePurchased:(NSString*)productIdentifier;
- (void)caixinSaveSubscription:(NSDictionary *)receipt verifiedReceiptDictionary:(NSDictionary *)verifiedReceiptDictionary;

@end
