//
//  CXAccountView.h
//  CenturyWeeklyV2
//
//  Created by zyk on 2/28/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSSettingRestoreView.h"
#import "KSSettingSubscribeView.h"
#import "CXGiftcardView.h"
#import "CXAccountFormView.h"
#import "CXLoggedView.h"
#import "KSCollectionView.h"

@class KSMagzineViewController;
@interface CXAccountView : UIView<UITableViewDelegate, UITableViewDataSource> {
    NSArray *_settingsArray;
    NSArray *_settingMethodsArray;
    
    UIImageView *_bgImageView;
    UIImageView *_popImageView;
    
    UILabel *_titleLabel;
    UILabel *_subTitleLabel;
    UIButton *_backButton;
    UITableView *_leftTableView;
    
    KSSettingRestoreView *_restoreView;
    KSSettingSubscribeView *_subsribeSettingView;
    CXGiftcardView *_giftcardView;
    CXAccountFormView *_accountFormView;
    CXLoggedView *_loggedView;
    KSCollectionView    *_collection;
    //KSMagzineViewController *_controller;
    NSString *_viewfrom;
}
@property(nonatomic, retain)NSString *viewfrom;

- (void)releaseAllSettingSubViews;

- (void)showSubscribeView;
- (void)freshSubscribeView;

- (void)freshAccountFormView;
- (void)showRegSuccessView;
- (void)showGiftcardView;
- (void)showRegSuccessViewWithMail:(NSString *)email password:(NSString *)pwd;
@end
