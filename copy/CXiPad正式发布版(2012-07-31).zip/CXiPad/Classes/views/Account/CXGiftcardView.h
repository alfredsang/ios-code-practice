//
//  CXGiftcardView.h
//  CenturyWeeklyV2
//
//  Created by zyk on 2/29/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <MessageUI/MessageUI.h>
#import <UIKit/UIKit.h>
#import <KUIKit/KUISwitch.h>
#import "CXDataRequest.h"

@class CXAccountView;
@interface CXGiftcardView : UIScrollView<UITextFieldDelegate,KSDataRequestDelegate,UIWebViewDelegate,MFMailComposeViewControllerDelegate> {
    CXAccountView *_parent;
    
    IBOutlet UILabel *headerLabel;
    IBOutlet UILabel *giftcardLabel;
    IBOutlet UILabel *giftcardTipLabel;
    IBOutlet UILabel *caxinSwitchLabel;
    IBOutlet UILabel *emailLabel;
    IBOutlet UILabel *usernameLabel;
    IBOutlet UILabel *passwordLabel;
    IBOutlet UILabel *passverifyLabel;
    IBOutlet UILabel *footerLabel;
    IBOutlet UIView *lineView;
    
    IBOutlet KUISwitch *hasCaixinSwitch;
    
    IBOutlet UITextField *giftcardNumTextfield;
    IBOutlet UITextField *emailTextfield;
    IBOutlet UITextField *usernameTextfield;
    IBOutlet UITextField *passTextfield;
    IBOutlet UITextField *passverifyTextfield;
    
    IBOutlet UIButton *submitButton;
    IBOutlet UIView *backView;
    
    IBOutlet UIWebView *_webView;
    
    NSString *_emailStr;
    NSString *_giftcardStr;
    NSString *_pwdStr;
    
    NSString *_introStr;
    
    BOOL _isKeyboardShowing;
    CGFloat _moveHeight;
    
    KSBaseDataRequest *_loginRequest;
}
@property(nonatomic, assign)CXAccountView *parent;


- (IBAction)switchChanged:(id)sender;
- (IBAction)doSubmit:(id)sender;

@end
