//
//  CXAccountFormView.h
//  CenturyWeeklyV2
//
//  Created by zyk on 3/11/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CXDataRequest.h"
#import "KSRegSuccView.h"
#import "KSRetrievePassView.h"

@class CXAccountView;
@class KSMagzineViewController;
@interface CXAccountFormView : UIView<UITextFieldDelegate,KSDataRequestDelegate> {
    
    IBOutlet UILabel *titleLabel;
    IBOutlet UILabel *accountLabel;
    IBOutlet UILabel *passwordLabel;
    IBOutlet UILabel *switchLabel;
    
    IBOutlet UITextField *emailTextField;
    IBOutlet UITextField *passwordTextField;
    IBOutlet UISwitch *autoLoginSwitch;
    
    IBOutlet UIButton *loginButton;
    IBOutlet UIButton *regButton;
    IBOutlet UIButton *trieveButton;
    
    CXAccountView *_parent;
    KSMagzineViewController *_handler;
    
    NSString *_emailStr;
    NSString *_pwdStr;
    
    BOOL _isGiftcardUser;
    BOOL is_remember;
    
    KSBaseDataRequest *_loginRequest;
    
    KSRegSuccView *reg_succ_view;
    KSRetrievePassView *_retrievePassView;
    
}
@property(nonatomic, assign)CXAccountView *parent;
@property(nonatomic, assign)KSMagzineViewController *handler;

- (IBAction)doLogin:(id)sender;
- (IBAction)doReg:(id)sender;
- (IBAction)trievePassword:(id)sender;
- (IBAction)changeAutoLogin:(id)sender;

@end
