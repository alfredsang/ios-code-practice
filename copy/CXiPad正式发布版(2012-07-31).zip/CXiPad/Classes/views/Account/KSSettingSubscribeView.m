//
//  KSSubscribeSettingView.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-7.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "KSSettingSubscribeView.h"
#import "KSModelMagzine.h"
#import "KSMagzineViewController.h"
#import "DateUtil.h"
#import "CXAccountView.h"


@implementation KSSettingSubscribeView

- (void)dealloc {
    [KSBaseDataRequest cancelRequest:@"KSSettingSubscribeView"];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
    IF_IOS5_OR_GREATER([[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillChangeFrameNotification object:nil];)
    
//    [_donateString release];
//    [_boughtString release];
    
    [_cardTextField release];
    //[_subScribeString release];
//    [_subScribeList release];
    [_scrollView release];
//    [_donateList release];
//    [_boughtList release];
//    [_sectionData release];
//    [_sectionString release];
    [super dealloc];
}

- (void)loadSubviews {
    _scrollView = [[UIScrollView alloc] initWithFrame:self.bounds];
    //_scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    [self addSubview:_scrollView];
    
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(61, 48, 160, 30)];
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont boldSystemFontOfSize:18.0f];
    label.text = @"当前用户：";
    label.tag = 1014;
    [_scrollView addSubview:label];
    [label release];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(label.right, 45, 89, 30)];
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont systemFontOfSize:16.0f];
    label.text = [KSBootstrap currentUser];
    label.tag = 1016;
    label.adjustsFontSizeToFitWidth = YES;
    label.minimumFontSize = 5.0;
    [_scrollView addSubview:label];
    [label release];
    
    //    _cardTextField = [[UITextField alloc] initWithFrame:CGRectMake(130, label.top-3, 100, 30)];
    //    _cardTextField.tag = 1016;
    //    _cardTextField.borderStyle = UITextBorderStyleRoundedRect;
    //    _cardTextField.placeholder = @"订阅卡号";
    //    _cardTextField.font = [UIFont systemFontOfSize:15.0f];
    //    _cardTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
    //    _cardTextField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    //    [_scrollView addSubview:_cardTextField];
    //    _cardTextField.delegate = self;
    
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(200, label.bottom +20, 80, 28)];
    btn.tag = 1017;
    btn.titleLabel.font = [UIFont systemFontOfSize:15.0f];
    [btn setBackgroundImage:[UIImage imageNamed:@"btn_com.png"] forState:UIControlStateNormal];
    [btn setTitle:@"退出" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(logout) forControlEvents:UIControlEventTouchUpInside];
    [_scrollView addSubview:btn];
    btn.center = CGPointMake(round(self.width/2), btn.centerY);
    [btn release];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(61, label.bottom + 60, 189, 30)];
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont boldSystemFontOfSize:18.0f];
    label.text = @"订阅及购买记录：";
    label.tag = 1010;
    [_scrollView addSubview:label];
    [label release];
    
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(61, label.bottom + 20, 380, 76)];
    label.height = [_sectionData count]* 20+20;
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont systemFontOfSize:16.0f];
    label.numberOfLines = 0;
    label.tag = 1011;
    label.text = _sectionString;
    [_scrollView addSubview:label];
    [label release];
    
    
    _scrollView.contentSize = CGSizeMake(_scrollView.width, label.bottom+100);
    
    //if (![KSBootstrap currentUser]) {
    [self hideLogoutView];
    //}
}

#if 0
- (void)loadSubviews {
    _scrollView = [[UIScrollView alloc] initWithFrame:self.bounds];
    //_scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    [self addSubview:_scrollView];
    
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(61, 48, 160, 30)];
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont boldSystemFontOfSize:18.0f];
    label.text = @"当前用户：";
    label.tag = 1014;
    [_scrollView addSubview:label];
    [label release];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(label.right, 45, 89, 30)];
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont systemFontOfSize:16.0f];
    label.text = [KSBootstrap currentUser];
    label.tag = 1016;
    label.adjustsFontSizeToFitWidth = YES;
    label.minimumFontSize = 5.0;
    [_scrollView addSubview:label];
    [label release];
    
//    _cardTextField = [[UITextField alloc] initWithFrame:CGRectMake(130, label.top-3, 100, 30)];
//    _cardTextField.tag = 1016;
//    _cardTextField.borderStyle = UITextBorderStyleRoundedRect;
//    _cardTextField.placeholder = @"订阅卡号";
//    _cardTextField.font = [UIFont systemFontOfSize:15.0f];
//    _cardTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
//    _cardTextField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
//    [_scrollView addSubview:_cardTextField];
//    _cardTextField.delegate = self;
    
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(200, label.bottom +20, 80, 28)];
    btn.tag = 1017;
    btn.titleLabel.font = [UIFont systemFontOfSize:15.0f];
    [btn setBackgroundImage:[UIImage imageNamed:@"btn_com.png"] forState:UIControlStateNormal];
    [btn setTitle:@"退出" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(logout) forControlEvents:UIControlEventTouchUpInside];
    [_scrollView addSubview:btn];
    btn.center = CGPointMake(round(self.width/2), btn.centerY);
    [btn release];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(61, label.bottom + 60, 89, 30)];
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont boldSystemFontOfSize:18.0f];
    label.text = @"订阅记录";
    label.tag = 1010;
    [_scrollView addSubview:label];
    [label release];
    
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(61, label.bottom + 20, 380, 76)];
    label.height = [_subScribeList count]* 20+20;
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont systemFontOfSize:16.0f];
    label.numberOfLines = 0;
    label.tag = 1011;
    label.text = _subScribeString;
    [_scrollView addSubview:label];
    [label release];
        
    label = [[UILabel alloc] initWithFrame:CGRectMake(61, label.bottom +20, 189, 30)];
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont boldSystemFontOfSize:18.0f];
    label.text = @"单期购买记录";
    label.tag = 1012;
    [_scrollView addSubview:label];
    [label release];
    
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(61, label.bottom, 380, 30)];
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont systemFontOfSize:16.0f];
    label.numberOfLines = 0;
    label.text = _boughtString;
    CGSize maxsize = CGSizeMake(label.width, 99999.0);
    CGSize sz = [_boughtString sizeWithFont:label.font constrainedToSize:maxsize lineBreakMode:UILineBreakModeWordWrap];
    label.height = sz.height + 20.0f;
    label.tag = 1013;
    [_scrollView addSubview:label];
    [label release];

    label = [[UILabel alloc] initWithFrame:CGRectMake(61, label.bottom+10, 89, 20)];
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont boldSystemFontOfSize:18.0f];
    label.text = @"赠阅记录";
    label.tag = 1015;
    [_scrollView addSubview:label];
    [label release];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(61, label.bottom, 380, 30)];
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont systemFontOfSize:16.0f];
    label.numberOfLines = 0;
    label.text = _donateString;
    sz = [_donateString sizeWithFont:label.font constrainedToSize:maxsize lineBreakMode:UILineBreakModeWordWrap];
    label.height = sz.height + 20.0f;
    //label.height = [_boughtList count]*10 + 60.0f;
    label.tag = 1018;
    [_scrollView addSubview:label];
    [label release];
    
    _scrollView.contentSize = CGSizeMake(_scrollView.width, label.bottom+100);
    
    //if (![KSBootstrap currentUser]) {
        [self hideLogoutView];
    //}
}
#endif


- (void)loadData {

    _sectionData = [NSMutableArray arrayWithCapacity:0];	
    
    //订阅信息
    NSMutableArray *subScribeList = [NSMutableArray arrayWithCapacity:0];
    NSArray *arry = [KSModelMagzine loadSubscribed];
    for (NSDictionary *d in arry) {
        [subScribeList addObject:[CXSubscribeElement subscribeElementWithDict:d]];
    }
    if ([subScribeList count]>0) {
        for (CXSubscribeElement *s in subScribeList) {
            [_sectionData addObject:[NSDictionary dictionaryWithObjectsAndKeys:s.toPresentString,@"info",[NSNumber numberWithInt:s.issueDate],@"timestamp",nil]];
        }
    }
    
    //赠刊信息

    NSString *tmpStr = @"（财新网赠阅）";
    FMResultSet *rs = [[KSDB db] executeQuery:@"select * from magzines where magzine_id in (select issue_number from my_device_free) order by pub_date asc"];
    while (rs.next) {
        NSDictionary *d = [rs resultDict];
        NSString * tmpStr2 = [NSString stringWithFormat:@"%@    第%@期%@", ([DateUtil strFromTimeIntervalSince1970:DICT_INTVAL(d, @"pub_date") format:@"yyyy年MM月dd日出版"]), DICT_BOOLVAL(d,@"is_special_issue")? DICT_VAL(d,@"custom_number"):([NSString stringWithFormat:@"%02d", DICT_INTVAL(d,@"stage_number")]),tmpStr];
        [_sectionData addObject:[NSDictionary dictionaryWithObjectsAndKeys:tmpStr2,@"info",[d objectForKey:@"pub_date"],@"timestamp",nil]];
    }
    [rs close];
    
    if ([KSBootstrap currentUser]) {
        NSMutableArray *donateList = [NSMutableArray arrayWithCapacity:0];
        rs = [[KSDB db] executeQuery:@"select * from my_free_logic where user_email=? order by start_time,end_time asc",[KSBootstrap currentUser]];
        while (rs.next) {
            NSDictionary *dict = [rs resultDict];
            [donateList addObject:dict];
        }
        [rs close];

        for (NSDictionary *dict in donateList) {
            NSInteger free_count = DICT_INTVAL(dict, @"free_count");
            if (free_count == 0) {
                NSString * tmpStr2 = [NSString stringWithFormat:@"%@至%@%@",[DateUtil strFromTimeIntervalSince1970:DICT_INTVAL(dict, @"start_time") format:@"yyyy年MM月dd日"],[DateUtil strFromTimeIntervalSince1970:DICT_INTVAL(dict, @"end_time") format:@"yyyy年MM月dd日"],tmpStr];
                [_sectionData addObject:[NSDictionary dictionaryWithObjectsAndKeys:tmpStr2,@"info",[dict objectForKey: @"start_time"],@"timestamp",nil]];
            } else {
                NSString *sql = [NSString stringWithFormat:@"select * from magzines where pub_date >= ?  order by pub_date asc limit %d",DICT_INTVAL(dict, @"free_count")];
                FMResultSet *rs = [[KSDB db] executeQuery:sql,[dict objectForKey:@"start_time"]];
                while (rs.next) {
                    NSDictionary *d = [rs resultDict];
                    NSMutableString *tmpStr2 = [NSString stringWithFormat:@"%@    第%@期%@", [DateUtil strFromTimeIntervalSince1970:DICT_INTVAL(d, @"pub_date") format:@"yyyy年MM月dd日出版"],[NSString stringWithFormat:@"%02d", DICT_INTVAL(d,@"stage_number")],tmpStr];
                    [_sectionData addObject:[NSDictionary dictionaryWithObjectsAndKeys:tmpStr2,@"info",[d objectForKey:@"pub_date"],@"timestamp",nil]];
                }
                [rs close];
            }
        }
        
    }

    //购买信息    
    tmpStr = @"（APP STORE购买）";
    rs = [[KSDB db] executeQuery:@"SELECT magzine_id,pub_date,stage_number,is_special_issue,custom_number FROM magzines WHERE is_purchased=1 ORDER BY magzine_id DESC"];
    while (rs.next) {
        NSDictionary *dict = [rs resultDict];
        NSMutableString *tmpStr2 = [NSString stringWithFormat:@"%@    第%@期%@",[DateUtil strFromTimeIntervalSince1970:DICT_INTVAL(dict, @"pub_date") format:@"yyyy年MM月dd日出版"],([NSString stringWithFormat:@"%02d", DICT_INTVAL(dict,@"stage_number")]),tmpStr];
        [_sectionData addObject:[NSDictionary dictionaryWithObjectsAndKeys:tmpStr2,@"info",[dict objectForKey:@"pub_date"],@"timestamp",nil]];
        
    }
    [rs close];
    
    
    NSSortDescriptor *sorter = [[NSSortDescriptor alloc] initWithKey:@"timestamp" ascending:YES]; 
    NSArray *sortDescriptors = [[NSArray alloc] initWithObjects:&sorter count:1]; 
    NSArray *sortedArray = [_sectionData sortedArrayUsingDescriptors:sortDescriptors];     
    /*
    if (_sectionData.count)
        [_sectionData sortUsingDescriptors:[NSArray arrayWithObject:[[[NSSortDescriptor alloc] initWithKey:@"timestamp" ascending:YES selector:@selector(localizedCaseInsensitiveCompare:)] autorelease]]];
    */
    if(_sectionString==nil){
        _sectionString = [[NSMutableString alloc] initWithCapacity:200];
    }
    [_sectionString setString:@""];
    for (int i=0; i<[sortedArray count]; i++) { 
        NSLog(@"%@",[[sortedArray objectAtIndex:i] objectForKey:@"info"]); 
        [_sectionString appendFormat:@"%@\n",[[sortedArray objectAtIndex:i] objectForKey:@"info"]];
    }
    

    //获得排序后的信息字符串
    
    //return sectionData;

}
#if 0
- (void)loadData {
    _subScribeList = [[NSMutableArray alloc] initWithCapacity:1];
    NSArray *arry = [KSModelMagzine loadSubscribed];
    for (NSDictionary *d in arry) {
        [_subScribeList addObject:[CXSubscribeElement subscribeElementWithDict:d]];
    }
    if ([_subScribeList count]>0) {
        _subScribeString = @"";
        for (CXSubscribeElement *s in _subScribeList) {
            _subScribeString = [_subScribeString stringByAppendingFormat:@"%@\n",s.toPresentString];
        }
    } else {
        _subScribeString = @"无";
    }
    
    _donateString = [[NSMutableString alloc] initWithCapacity:200];
    
    FMResultSet *rs = [[KSDB db] executeQuery:@"select * from magzines where magzine_id in (select issue_number from my_device_free)"];
    NSMutableString *tmpStr = [[NSMutableString alloc] initWithCapacity:40];
    while (rs.next) {
        if ([tmpStr length]) {
            [tmpStr appendString:@"\n"];
        }
        NSDictionary *d = [rs resultDict];
        [tmpStr appendFormat:@"%@    第%@期（首次安装获赠）", ([DateUtil strFromTimeIntervalSince1970:DICT_INTVAL(d, @"pub_date") format:@"yyyy年MM月dd日出版"]), DICT_BOOLVAL(d,@"is_special_issue")? DICT_VAL(d,@"custom_number"):([NSString stringWithFormat:@"%02d", DICT_INTVAL(d,@"stage_number")])];
    }
    [rs close];
    if ([tmpStr length]) {
        [_donateString appendString:tmpStr];
    }
    [tmpStr release];
    if ([KSBootstrap currentUser]) {
        _donateList = [[NSMutableArray alloc] initWithCapacity:1];
        
        rs = [[KSDB db] executeQuery:@"select * from my_free_logic where user_email=? order by free_type asc",[KSBootstrap currentUser]];
        while (rs.next) {
            NSDictionary *dict = [rs resultDict];
            [_donateList addObject:dict];
        }
        [rs close];
        //user_email start_time end_time free_count free_type
        //0.未知 1.首次登录赠送  2.订阅卡赠送(消费)  3.订阅用户赠送   4.人工赠阅 5.纸刊订单赠送
        for (NSDictionary *dict in _donateList) {
            if ([_donateString length]) {
                [_donateString appendString:@"\n"];
            }
            NSInteger freetype = DICT_INTVAL(dict, @"free_type");
            NSString *tmpStr = @"赠送";
            if (freetype == 1) {
                tmpStr = @"（首次登录获赠）";
            }else if (freetype == 2) {
                tmpStr = @"（读者编号获赠）";
            }else if (freetype == 3) {
                tmpStr = @"（订阅用户获赠过刊）";
            }else if (freetype == 4) {
                tmpStr = @"（手动赠送）";
            }else if (freetype == 5) {
                tmpStr = @"（订杂志送iPad版）";
            }
            NSInteger free_count = DICT_INTVAL(dict, @"free_count");
            if (free_count == 0) {
                [_donateString appendFormat:@"%@至%@%@",[DateUtil strFromTimeIntervalSince1970:DICT_INTVAL(dict, @"start_time") format:@"yyyy年MM月dd日"],[DateUtil strFromTimeIntervalSince1970:DICT_INTVAL(dict, @"end_time") format:@"yyyy年MM月dd日"],tmpStr];
            } else {
                NSString *sql = [NSString stringWithFormat:@"select * from magzines where pub_date >= ?  order by pub_date asc limit %d",DICT_INTVAL(dict, @"free_count")];
                FMResultSet *rs = [[KSDB db] executeQuery:sql,[dict objectForKey:@"start_time"]];
                NSMutableString *tmpStr2 = [[NSMutableString alloc] initWithCapacity:160];
                while (rs.next) {
                    if ([tmpStr2 length]) {
                        [tmpStr2 appendString:@"\n"];
                    }
                    NSDictionary *d = [rs resultDict];
                    [tmpStr2 appendFormat:@"%@    第%@期%@", [DateUtil strFromTimeIntervalSince1970:DICT_INTVAL(d, @"pub_date") format:@"yyyy年MM月dd日出版"],DICT_BOOLVAL(d,@"is_special_issue")?DICT_VAL(d,@"custom_number"): [NSString stringWithFormat:@"%02d", DICT_INTVAL(d,@"stage_number")],tmpStr];
                }
                [rs close];
                [_donateString appendString:tmpStr2];
                [tmpStr2 release];
            }
        }
        
    }
    if (![_donateString length]) {
        [_donateString appendString:@"无"];
    }
    _boughtList = [[NSMutableArray alloc] init];
    _boughtString = [[NSMutableString alloc] initWithCapacity:200];
    rs = [[KSDB db] executeQuery:@"SELECT magzine_id,pub_date,stage_number,is_special_issue,custom_number FROM magzines WHERE is_purchased=1 ORDER BY magzine_id DESC"];
    while (rs.next) {
        NSDictionary *dict = [rs resultDict];
        [_boughtList addObject:dict];
    }
    [rs close];
    NSString *currentYear = nil;
    int i = 0;
    for (NSDictionary *dict in _boughtList) {
        if (i%2 == 0 && i != 0) {
            [_boughtString appendString:@"\n"];
        }else if(i != 0) {
            [_boughtString appendString:@"         "];
        }
        i++;
        NSString *year = [DateUtil strFromTimeIntervalSince1970:DICT_INTVAL(dict, @"pub_date") format:@"yyyy年\n"];
        if (currentYear == nil) { currentYear = year; [_boughtString appendString:currentYear];}
        if (![currentYear isEqualToString:year]) {
            [_boughtString appendString:@"\n"];
            if (i%2 == 0) {
                [_boughtString appendString:@"\n"];
            }
            
            currentYear = year;
            [_boughtString appendString:currentYear];
            i=1;
        }
        [_boughtString appendFormat:@"%@ 第%@期",[DateUtil strFromTimeIntervalSince1970:DICT_INTVAL(dict, @"pub_date") format:@"MM月dd日出版"],DICT_BOOLVAL(dict,@"is_special_issue")? DICT_VAL(dict,@"custom_number"):([NSString stringWithFormat:@"%02d", DICT_INTVAL(dict,@"stage_number")])];
    }
    if (![_boughtString length]) {
        [_boughtString appendString:@"无"];
    }
}
#endif

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self loadData];
        [self loadSubviews];
        
        /* Listen for keyboard */
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
        
        IF_IOS5_OR_GREATER([[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeKeyboardFrame:) name:UIKeyboardWillChangeFrameNotification object:nil];);
        
        
        
        [self viewWithTag:1016].left = 130,[self viewWithTag:1016].width = 240; //当前用户名
        //[self viewWithTag:1017].left = 310,[self viewWithTag:1017].width = 60;  //退出
        
        //[self viewWithTag:1010].frame = CGRectMake(30, 48, 89, 30);
        [self viewWithTag:1010].left = 30;//订阅记录
        [self viewWithTag:1011].left = 30,[self viewWithTag:1011].width = 380;  //scriptions list
      
        [self viewWithTag:1012].left = 30,[self viewWithTag:1012].width = 189;   //赠送记录
        [self viewWithTag:1013].left = 30,[self viewWithTag:1013].width = 380;  //赠送记录列表
        
        [self viewWithTag:1014].left = 30,[self viewWithTag:1014].width = 160;  //当前用户
        [self viewWithTag:1015].left = 30,[self viewWithTag:1015].width = 100;  //email
       
        [self viewWithTag:1017].centerX = round(self.width/2);
        [self viewWithTag:1017].top = 90;
        [self viewWithTag:1018].left = 30,[self viewWithTag:1018].width = 380;  //购买记录列表
        _scrollView.frame = self.bounds;
        _scrollView.contentSize = CGSizeMake(self.width, _scrollView.contentSize.height);
    }
    return self;
}

- (void)layoutSubviews {
//    if ([UIUtil currentOrientation] == 0) {

        
//    } else {
//        [self viewWithTag:1016].left = 160,[self viewWithTag:1016].width = 240; //当前用户名
//        //[self viewWithTag:1017].left = 401,[self viewWithTag:1017].width = 60;  //退出
//        
//        //[self viewWithTag:1010].frame = CGRectMake(61, 48, 89, 30);
//        [self viewWithTag:1010].left = 61;
//        [self viewWithTag:1011].left = 61,[self viewWithTag:1011].width = 400;  //scriptions list
//        [self viewWithTag:1012].left = 61,[self viewWithTag:1012].width = 189;
//        [self viewWithTag:1013].left = 61,[self viewWithTag:1013].width = 450;
//        [self viewWithTag:1014].left = 61,[self viewWithTag:1014].width = 160;  //当前用户
//        [self viewWithTag:1015].left = 61,[self viewWithTag:1015].width = 100;  //email
//        
//        [self viewWithTag:1017].left = 420, [self viewWithTag:1017].top = 46;
//        [self viewWithTag:1018].left = 61,[self viewWithTag:1018].width = 400;  //购买记录列表
//        
//    }
    
    

}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

#pragma mark -
- (void)hideLogoutView {
    for (UIView *view in _scrollView.subviews) {
        if ([view isKindOfClass:[UILabel class]] || [view isKindOfClass:[UIButton class]]) {
            view.top -= 80;
        }
    }
    [self viewWithTag:1017].hidden = YES;
    [self viewWithTag:1014].hidden = YES;
    [self viewWithTag:1016].hidden = YES;
}
- (void)submitCard:(id)sender {
    if (![KSBootstrap currentUser]) {
        [UIUtil showMsgAlertWithTitle:@"提示" message:@"您未登录，不能进行该操作。"];
        return;
    }
    NSString *cardNum = _cardTextField.text;
    if (!cardNum || ![cardNum length]) {
        [UIUtil showMsgAlertWithTitle:@"提示" message:@"读者编号不能为空。"];
        return;
    }
    
    [CXGiftCardDataRequest requestWithDelegate:self url:SERVER_URL(@"/usecard/%@/%@/%@", MAGZINE_TYPE,[KSBootstrap currentUser],[cardNum URLEncodedString]) withParameters:nil withIndicatorView:nil withCancelSubject:@"KSSettingSubscribeView"];
    
}
- (void)logout {
    [(KSMagzineViewController *)self.viewController logout];
    [self hideLogoutView];
    //刷新当前视图 
    [(CXAccountView *)self.superview freshSubscribeView];
}
#pragma mark - KSDataRequestDelegate
- (void)requestDidStarted:(KSBaseDataRequest *)request{
    [UIUtil showProcessIndicatorWithView:self atPoint:CGPointMake(_cardTextField.right+90, _cardTextField.centerY) hasMask:NO];
}
- (void)requestDidFinished:(KSBaseDataRequest *)request {
    [UIUtil hideProcessIndicatorWithView:self];
    NSDictionary *dict = request.resultDict;
    //NSString *code = [dict objectForKey:@"success"];
    BOOL code = DICT_BOOLVAL(dict, @"success");
    if (!code) {
        NSString *msg = [dict objectForKey:@"info"];
        if (!msg || ![msg length]) {
            msg = @"卡号无效";
        }
        [UIUtil showMsgAlertWithTitle:@"提示" message:msg];
        return;
    }
    //1. 首次登录赠送
    //2. 礼品卡赠送
    //3. 订阅用户赠送
    //4. 人工赠阅
    //5. 纸刊订单赠送
    else {
        NSDictionary *info = DICT_VAL(dict, @"info");
        NSInteger startTime = DICT_INTVAL(info, @"starttime");
        NSInteger endtime = DICT_INTVAL(info, @"endtime");
        //NSInteger magazineType = DICT_INTVAL(info, @"magazine_type");
        //NSString *str = @"订阅卡赠送";
        //NSString *donateType = 1;
        [[KSDB db] executeUpdate:@"insert into my_free_logic(user_email,start_time,end_time,free_count,free_type) values(?,?,?,?,?)",[KSBootstrap currentUser], INTEGER(startTime),INTEGER(endtime),INTEGER(0),INTEGER(2)];
        
        [UIUtil showMsgAlertWithTitle:@"提示" message:STR_FORMAT(@"读者编号提交成功,您已获赠%@至%@的期刊", [DateUtil strFromTimeIntervalSince1970:startTime format:@"yyyy年MM月dd日"],[DateUtil strFromTimeIntervalSince1970:endtime format:@"yyyy年MM月dd日"]) ];
        _cardTextField.text = @"";
    }
    //NSLog(@"%@",request.resultDict);
}
- (void)requestDidCanceled:(KSBaseDataRequest *)request {
    [UIUtil hideProcessIndicatorWithView:self];
}
- (void)requestDidFailed:(KSBaseDataRequest *)request withError:(NSError*)error {
    [UIUtil hideProcessIndicatorWithView:self];
}
#pragma mark -
#pragma mark UITextFieldDelegate
- (void)textFieldDidBeginEditing:(UITextField *)textField {
    
    
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    
}
#pragma mark -
- (void)changeKeyboardFrame:(NSNotification *)notification {
    
}
- (void)keyboardWillShow:(NSNotification *)notification {
    //return;
    if (_isKeyboardShowing) {
        return;
    }
    float innerKeyboardHeight = [UIUtil currentOrientation] == 0?316:406;
    _isKeyboardShowing = YES;
    CGRect rect = [self.superview convertRect:[self viewWithTag:1016].frame fromView:_scrollView];
    CGFloat height ;//= rect.origin.y;
    if ([UIUtil currentOrientation] == 0) {
        height = 1024 - rect.origin.y;
    } else {
        height = 768 - rect.origin.y;
    }
    _moveHeight = innerKeyboardHeight - height + 60;
    if (_moveHeight > 0) {
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:0.3];
        self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y-_moveHeight, self.frame.size.width, self.frame.size.height);
        [UIView commitAnimations];
    }
    
}

- (void)keyboardWillHide:(NSNotification *)notification {
    _isKeyboardShowing = NO;
    if (_moveHeight > 0) {
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:0.3];
        self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y+_moveHeight, self.frame.size.width, self.frame.size.height);
        [UIView commitAnimations];
    }
}

@end







@implementation CXSubscribeElement

@synthesize tranId = _tranId;
@synthesize issueDate = _issueDate;
@synthesize issueYearNumber = _issueYearNumber;
@synthesize issueMonthNumber = _issueMonthNumber;
@synthesize issueTotalNumber = _issueTotalNumber;
@synthesize endIssueDate = _endIssueDate;
@synthesize endIssueYearNumber = _endIssueYearNumber;
@synthesize endIssueMonthNumber = _endIssueMonthNumber;
@synthesize endIssueTotalNumber = _endIssueTotalNumber;
@synthesize subscribeType = _subscribeType;

- (void)dealloc {
    [_tranId release];
    [_subscribeType release];
    
    [super dealloc];
}
- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

+ (CXSubscribeElement *)subscribeElementWithDict:(NSDictionary *)dict {
    CXSubscribeElement *s = [[CXSubscribeElement alloc] init];
    s.tranId = DICT_VAL(dict, @"order_no");
    s.subscribeType = DICT_VAL(dict, @"subsribe_type");
    s.issueDate = DICT_INTVAL(dict, @"start");
    s.endIssueDate = DICT_INTVAL(dict, @"end");
    
    return [s autorelease];
}

- (NSString *)toSaveString {
    return [NSString stringWithFormat:@"%@|%@|%@|%@",_tranId ,_subscribeType,_issueDate,_endIssueDate];
}

- (NSString *)chineseIssueDate:(NSInteger)dateInt {
    return [DateUtil strFromTimeIntervalSince1970:dateInt format:@"yyyy年MM月dd日"];
}
- (NSString *)issueYear:(NSString *)dateStr {
    return [dateStr substringToIndex:4];
}

- (NSString *)toPresentString {
    NSString *desc = @"（订期1年）";
    if ([_subscribeType isEqualToString:@"com.caing.ipad.s.s12"]) {
        if(_endIssueDate - _issueDate < 365*3600*24){
            desc = @"(APP STORE免费试订阅)";  
        }
    } else if ([_subscribeType isEqualToString:@"com.caing.ipad.s.s6"]) {
        desc = @"（APP STORE订阅）";
    } else if ([_subscribeType isEqualToString:@"com.caing.ipad.s.s3"]) {
        desc = @"（APP STORE订阅）";
    }else if([_subscribeType isEqualToString:@"10"]){
        desc = @"（通过财新网订阅）";
    }
    NSString *PresentString = [NSString stringWithFormat:@"%@至%@ %@",[self chineseIssueDate:_issueDate],[self chineseIssueDate:_endIssueDate],desc];
    
    return PresentString;
}

/*
- (NSString *)toPresentString {
    NSString *desc = @"（订期1年）";
    if ([_subscribeType isEqualToString:@"com.caing.ipad.s.s12"]) {
        //desc = @"一年";
    } else if ([_subscribeType isEqualToString:@"com.caing.ipad.s.s6"]) {
        desc = @"（订期半年）";
    } else if ([_subscribeType isEqualToString:@"com.caing.ipad.s.s3"]) {
        desc = @"（订期3个月）";
    }else if([_subscribeType isEqualToString:@"10"]){
        desc = @"（网站订阅）";
    }
    return [NSString stringWithFormat:@"%@至%@ %@",[self chineseIssueDate:_issueDate],[self chineseIssueDate:_endIssueDate],desc];
}
*/


@end