//
//  CXLoggedView.h
//  CenturyWeeklyV2
//
//  Created by zyk on 3/12/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CXAccountView;
@interface CXLoggedView : UIView {
    CXAccountView *_parent;
}
@property(nonatomic, assign)CXAccountView *parent;

@end
