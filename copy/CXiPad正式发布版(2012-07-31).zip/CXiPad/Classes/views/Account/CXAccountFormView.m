//
//  CXAccountFormView.m
//  CenturyWeeklyV2
//
//  Created by zyk on 3/11/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "CXAccountFormView.h"
#import "CXAccountView.h"
#import "UserHelper.h"
#import "KSMagzineViewController.h"

@implementation CXAccountFormView
@synthesize parent = _parent;
@synthesize handler = _handler;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}
- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
    }
    return self;
}
- (void)awakeFromNib {
    is_remember = YES;

}
- (void)layoutSubviews {
//    if ([UIUtil currentOrientation] == 0) {
        titleLabel.left = 40;
        accountLabel.left = 40;
        passwordLabel.left = 40;
        switchLabel.left = 40;
        emailTextField.left = 135;
        passwordTextField.left = 135;
        autoLoginSwitch.left = 135;
        loginButton.left = 271;
        regButton.left = 135;
        trieveButton.left = 271;
//    } else {
//        titleLabel.left = 110;
//        accountLabel.left = 110;
//        passwordLabel.left = 110;
//        switchLabel.left = 110;
//        emailTextField.left = 205;
//        passwordTextField.left = 205;
//        autoLoginSwitch.left = 205;
//        loginButton.left = 341;
//        regButton.left = 205;
//        trieveButton.left = 341;
//    }
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void)dealloc {
    [titleLabel release];
    [accountLabel release];
    [passwordLabel release];
    [switchLabel release];
    [emailTextField release];
    [passwordTextField release];
    [autoLoginSwitch release];
    [loginButton release];
    [regButton release];
    [trieveButton release];
    
    [_emailStr release];
    [_pwdStr release];
    
    [_loginRequest release];
    [reg_succ_view release];
    
    [super dealloc];
}
#pragma mark -
- (void) displayRegSuccView:(NSString *)email password:(NSString *)passwd{
    [(CXAccountView *)_parent showRegSuccessViewWithMail:_emailStr password:_pwdStr];
    return;
    
    NSArray *views = [[NSBundle mainBundle] loadNibNamed:@"KSRegSuccView" owner:self options:nil];
    reg_succ_view = [[views objectAtIndex:0] retain];
    //    reg_succ_view.frame = CGRectMake(0, 0, 422, 336);
    reg_succ_view.center = CGPointMake(roundf(self.centerX), roundf(self.centerY));
    reg_succ_view.layer.cornerRadius = 5;
    
    reg_succ_view.email = email;
    reg_succ_view.handler = self.viewController;
    reg_succ_view.parent = _parent;
//    login_bg.hidden = YES;
//    [_containerView addSubview:reg_succ_view];
//    
//    user_name.text = email;
//    user_pwd.text = passwd;
//    
//    //animation
//    reg_succ_view.alpha = 0;
//    [UIView animateWithDuration:0.3 animations:^{
//        register_view.alpha = 0;
//        reg_succ_view.alpha = 1;
//    } completion:^(BOOL finished) {
//        register_view.hidden = YES;
//        register_view.alpha = 1;
//    }];
}

#pragma mark -
- (void)showError:(UITextField *)textField msg:(NSString *)text {
    UILabel *label = (UILabel *)textField.rightView;
    if (!label) {
        label = [UIUtil newLabelWithFrame:CGRectZero text:text textColor:[UIColor redColor] font:[UIFont systemFontOfSize:14]];
        textField.rightView = label;
        [label release];
    }else {
        label.text = text;
    }
    [label sizeToFit];
    textField.rightViewMode = UITextFieldViewModeAlways;
    label.hidden = NO;
    //textField.layer.borderColor = [[UIColor redColor] CGColor];
    //textField.layer.borderWidth = 1.0f;
}
- (void)resignAllTextFields {
    [emailTextField resignFirstResponder];
    [passwordTextField resignFirstResponder];
    
    emailTextField.rightView.hidden = YES;
    emailTextField.rightViewMode = UITextFieldViewModeNever;
    
    passwordTextField.rightView.hidden = YES;
    passwordTextField.rightViewMode = UITextFieldViewModeNever;
}

- (IBAction)doLogin:(id)sender {
    [self resignAllTextFields];
    _handler = (KSMagzineViewController *)self.viewController;
    BOOL hasError = NO;
    NSString *mail = [emailTextField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    NSString *pwdStr = [passwordTextField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    if (mail==nil || [mail length]==0) {
        hasError = YES;
        [self showError:emailTextField msg:@"邮箱不能为空  "];
    }else if(![DataUtil validateEmail:mail]){
        hasError = YES;
        [self showError:emailTextField msg:@"邮箱不合法  "];
    }
    if (pwdStr==nil || ![pwdStr length]) {
        hasError = YES;
        [self showError:passwordTextField msg:@"密码不能为空  "];
    }
    if (hasError) {
        return;
    }
    [_emailStr release];
    [_pwdStr release];
    _emailStr = [mail retain];
    _pwdStr = [pwdStr retain];
    
    //先检查是否为订阅卡用户
    [CXGiftCardDataRequest requestWithDelegate:self url:SERVER_URL(@"/isgiftcarduser/%@/%@",MAGZINE_TYPE,_emailStr) withParameters:nil withIndicatorView:_handler.view withCancelSubject:nil];
    //[CXLoginDataRequest requestWithDelegate:self withParameters:[NSDictionary dictionaryWithObjectsAndKeys:_emailStr,@"email",_pwdStr,@"pwd", nil] withIndicatorView:_parent withCancelSubject:@"CXLoginDataRequest_accountFrom"];
}

- (IBAction)doReg:(id)sender {
    [(KSMagzineViewController *)self.viewController showRegView];
}

- (IBAction)trievePassword:(id)sender {
    [(KSMagzineViewController *)self.viewController showTrievePassView];
}

- (IBAction)changeAutoLogin:(id)sender {
    if (autoLoginSwitch.on) {
        is_remember = YES;
    } else {
        is_remember = NO;
    }
}

- (void)didProcessLoginSuccess:(KSBaseDataRequest *)request {
    KSDINFO(@"%@", request.resultDict);
    if (is_remember) {
        [KSDB saveString:@"1" forKey:UD_KEY_AUTOLOGIN];
    } else {
        [KSDB saveString:@"0" forKey:UD_KEY_AUTOLOGIN];
    }
    [KSBootstrap setCurrentUser:_emailStr];
    if ([request.resultDict objectForKey:@"data"]) {
        NSNumber *uid = [[request.resultDict objectForKey:@"data"] objectForKey:@"uid"];
        if (uid) {
            [KSDB saveString:STR_FORMAT(@"%d", [uid intValue]) forKey:UD_KEY_USERID];
        }
    }
    
    // 触发第一次登录
    //if ([[KSDB stringForKey:UD_KEY_FIRST_LOGIN] intValue] < 1) {//first
    //    [KSDB saveString:@"1" forKey:UD_KEY_FIRST_LOGIN];
    //参数分别为：杂志类型/赠送事件类型/用户email/
    [CXFireDonateEventDataRequest requestWithDelegate:self url:SERVER_URL(@"/fireEvent/%@/0/%@/%@", MAGZINE_TYPE,_emailStr,[[UIDevice currentDevice] uniqueGlobalDeviceIdentifier]) withParameters:nil withIndicatorView:_handler.view withCancelSubject:@"CXFireDonateEventDataRequest_2"];
    //} else {
    // 请求my_free
    //    [self startLoadFree];
    //}
    //与订阅中心同步杂志
    //[DataPersistence execWithDelegate:self operationName:@"syncMagazieWithWeb"];
    //[UIUtil showProcessIndicatorWithView:self atPoint:CGPointMake(self.frame.size.width/2-5, 520) hasMask:NO];
    //
}

- (void)didLoginSuccess:(KSBaseDataRequest *)request {
    //处理登录的请求
    KSDINFO(@"%@",request.resultDict);
    //    if ([[request.resultDict objectForKey:@"error"] intValue] != 0) {
    //        [UIUtil hideProcessIndicatorWithView:self];
    //        [self showError:[request.resultDict objectForKey:@"message"]];
    //        return;
    //    }
    NSString *result = [[request.resultDict objectForKey:@"data"] objectForKey:@"code"];
    if ([result intValue]==-1) {
        [UIUtil hideProcessIndicatorWithView:self];
        [self showError:emailTextField msg:@"用户名或密码错误！"];
    } else if ([result intValue]==-2) {
        [UIUtil hideProcessIndicatorWithView:self];
        if (_isGiftcardUser) {
            [self didProcessLoginSuccess:request];
        } else {
            [self showError:emailTextField msg:@"您的用户未激活！"];
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"注册邮箱激活" message:@"您还差一步就可以完成注册，点击邮箱确认信的激活链接来完成注册" delegate:self cancelButtonTitle:@"下次提醒" otherButtonTitles:@"立即激活",nil];
            alertView.tag = 1020;
            [alertView show];
            [alertView release];  
            //[controller showAccountActiveView];
        }
        
    } else if ([result intValue]==0 || [result intValue]==2) {
        [self didProcessLoginSuccess:request];
    } else {
        [UIUtil hideProcessIndicatorWithView:self];
        [self showError:passwordTextField msg:@"用户不存在"];
    } 
}
- (void)didLoadFree:(KSBaseDataRequest *)request {
    [UserHelper saveMyFreeToDB:request.resultDict];
    [_parent freshAccountFormView];

    [_handler loginUserQuiet:_emailStr];
}
- (void)startFireSub {
    //事件类型为1
    [CXFireSubscriptionEventDataRequest requestWithDelegate:self url:SERVER_URL(@"/fireEvent/%@/1/%@/%@", MAGZINE_TYPE,_emailStr,[[UIDevice currentDevice] uniqueGlobalDeviceIdentifier]) withParameters:nil withIndicatorView:_handler.view withCancelSubject:nil];
}

#pragma mark - UITextFieldDelegate
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    textField.rightView.hidden = YES;
    textField.rightViewMode = UITextFieldViewModeNever;
    return YES;
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    textField.rightView.hidden = YES;
    textField.rightViewMode = UITextFieldViewModeNever;
    return YES;
}

#pragma mark - KSDataRequestDelegate
- (void)requestDidStarted:(KSBaseDataRequest *)request {
    
}
- (void)requestDidFinished:(KSBaseDataRequest *)request {
    //NSLog(@"%@",request.resultString);
    //处理赠送返回
    if ([request isKindOfClass:[CXFireDonateEventDataRequest class]]) {
        //如果NSUserDefaults中有数据，处理订阅赠送
        if ([[[NSUserDefaults standardUserDefaults] objectForKey:UD_SUBSCRIPTION_DATE] floatValue]>0) {
            [self startFireSub];
        } else {
            [self didLoadFree:request];
        }
        return;
    }
    //订阅事件处理完成，返回的是myfree的所有数据
    if ([request isKindOfClass:[CXFireSubscriptionEventDataRequest class]]) {
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:UD_SUBSCRIPTION_DATE];
        //[[NSUserDefaults standardUserDefaults] setObject:@"0" forKey:UD_SUBSCRIPTION_DATE];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        [self didLoadFree:request];
        //[self startLoadFree];
        return;
    }
    //处理LoadFree的请求
    if ([request isKindOfClass:[CXLoadFreeMagazineDataRequest class]]) {
        [self didLoadFree:request];
        
        [UIUtil hideProcessIndicatorWithView:self];
        return;
    }
    //检查订阅卡用户
    if ([request isKindOfClass:[CXGiftCardDataRequest class]]) {
        NSDictionary *dict = request.resultDict;
        _isGiftcardUser = DICT_BOOLVAL(dict, @"isgiftcarduser");
        //[self didLoginSuccess:request];
        //发起正常的登录过程
        [CXLoginDataRequest requestWithDelegate:self withParameters:[NSDictionary dictionaryWithObjectsAndKeys:_emailStr,@"email",_pwdStr,@"pwd", nil] withIndicatorView:_handler.view withCancelSubject:@"CXLoginDataRequest"];
        
        return;
    }
    
    //正常登录返回
    if ([request isKindOfClass:[CXLoginDataRequest class]]) {
        [self didLoginSuccess:request];
        return;
    }
}
- (void)requestDidCanceled:(KSBaseDataRequest *)request {
    
}
- (void)requestDidFailed:(KSBaseDataRequest *)request withError:(NSError*)error {
    if ([request isKindOfClass:[CXGiftCardDataRequest class]]) {
        [CXLoginDataRequest requestWithDelegate:self withParameters:[NSDictionary dictionaryWithObjectsAndKeys:_emailStr,@"email",_pwdStr,@"pwd", nil] withIndicatorView:self withCancelSubject:@"CXLoginDataRequest"];
        return;
    }
}
#pragma mark - UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (alertView.tag == 1020) {
        if (buttonIndex == 1) {
            [self displayRegSuccView:_emailStr password:_pwdStr];
        }
    }
}
@end
