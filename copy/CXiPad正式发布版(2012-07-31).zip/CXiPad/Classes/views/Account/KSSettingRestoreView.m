//
//  KSSettingRestoreView.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-7.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSSettingRestoreView.h"
#import "KStoreManager.h"
#import "CXAccountView.h"
#import "KSAppStoreProxy.h"

@implementation KSSettingRestoreView
@synthesize parent = _parent;

- (void)dealloc {
    [_tableView release];
    [_label release];
    [_footerView release];
    
    [super dealloc];
}
- (void)loadView {
    _tableView = [[UITableView alloc] initWithFrame:self.bounds style:UITableViewStyleGrouped];
    _tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.scrollEnabled = YES;
    _tableView.backgroundColor = [UIColor clearColor];
    _tableView.backgroundView = nil;
    
    [self addSubview:_tableView];
    
    _footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.width, 200)];
    //_footerView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    
    _label = [[UILabel alloc] initWithFrame:CGRectMake(35, 10, self.width - 70, 200)];
    _label.text = @"点击恢复购买，可恢复您之前订阅和单期购买的记录，免费重新下载已购买和订阅的杂志。\n\n如果您需要免费重新下载赠阅的杂志，只需要以获得赠阅时使用的财新网通行证邮箱和密码登录即可。";
    _label.numberOfLines = 0;
    _label.font = [UIFont fontWithName:@"Helvetica" size:15.0];
    //_label.font =[UIFont systemFontOfSize:15.0f];
    //_label.textColor = [UIColor colorWithRed:0.298039  green:0.337255 blue:0.423529 alpha:  1];
    _label.shadowColor = [UIColor colorWithWhite:1 alpha:1];
    _label.shadowOffset = CGSizeMake(0, 1);
    _label.textAlignment = UITextAlignmentLeft;
    _label.backgroundColor = [UIColor clearColor];
    [_footerView addSubview:_label];
    
    
//    _label.frame = CGRectMake(35, 10, self.width - 70, 100);
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        _hasSubscription = NO;
        [self loadView];
    }
    return self;
}
- (void)layoutSubviews {
    [_tableView reloadData];

//    if ([UIUtil currentOrientation] == 0) {
        //_tableView.frame = CGRectMake(0, 0, 470, 980);


//    } else {
//        //_tableView.frame = CGRectMake(0, 0, 724, 724);
//        _label.frame = CGRectMake(45, 10, self.width - 90, 100);
//    }
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void)caixinSavePurchased:(NSString*)productIdentifier {
    [KSAppStoreProxy caixinSavePurchased:productIdentifier];
}

- (void)caixinSaveSubscription:(NSDictionary *)receipt verifiedReceiptDictionary:(NSDictionary *)verifiedReceiptDictionary {
    [KSAppStoreProxy caixinSaveSubscription:receipt verifiedReceiptDictionary:verifiedReceiptDictionary];
}
- (void)doRestorePurchase {
    [KSAppStoreProxy restorefromView:_parent.superview];
    
}
#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 50;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [self doRestorePurchase];
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}
#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [[UITableViewCell alloc] init];
    cell.textLabel.text = @"恢复购买";
    cell.textLabel.font = [UIFont systemFontOfSize:14.0];
    cell.selectionStyle = UITableViewCellSelectionStyleGray;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return [cell autorelease];
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return @"恢复购买";
    }
    return nil;
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    if (section == 0) {
        return _footerView;
    }
    return nil;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return _footerView.height;
}


@end
