//
//  CXAccountView.m
//  CenturyWeeklyV2
//
//  Created by zyk on 2/28/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "CXAccountView.h"
#import "KSMagzineViewController.h"

@implementation CXAccountView
@synthesize viewfrom = _viewfrom;

- (void)dealloc {
    [_settingsArray release];
    [_settingMethodsArray release];
//    [_bgImageView release];
    [_popImageView release];
    [_titleLabel release];
    [_subTitleLabel release];
    [_backButton release];
    [_leftTableView release];
    [_restoreView release];
    [_subsribeSettingView release];
    [_giftcardView release];
    [_accountFormView release];
    [_viewfrom release];
    [_loggedView release];
    
    [super dealloc];
}
- (void)initAccountSubview {
//    self.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
//    _bgImageView = [[UIImageView alloc] initWithFrame:self.bounds];
//    _bgImageView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
//    [self addSubview:_bgImageView];
    
    _popImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamedNocache:@"pop_search_h.png"]];
    _popImageView.frame = CGRectMake(30, 35, 708, 943);
    [self addSubview:_popImageView];
    _popImageView.userInteractionEnabled = YES;
    
    _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(8, 6, 260, 32)];
    _titleLabel.textAlignment = UITextAlignmentCenter;
    _titleLabel.font = [UIFont systemFontOfSize:24.0f];
    _titleLabel.textColor = [UIColor colorWithRed:0.4353 green:0.4667 blue:0.5373 alpha:1.0];
    _titleLabel.backgroundColor = [UIColor clearColor];
    _titleLabel.text = @"账户管理";
    [_popImageView addSubview:_titleLabel];
    
    _subTitleLabel =[[UILabel alloc] initWithFrame:CGRectMake(312, 34, 412, 32)];
    _subTitleLabel.textAlignment = UITextAlignmentCenter;
    _subTitleLabel.font = [UIFont systemFontOfSize:24.0f];
    _subTitleLabel.textColor = [UIColor colorWithRed:0.4353 green:0.4667 blue:0.5373 alpha:1.0];
    _subTitleLabel.backgroundColor = [UIColor clearColor];
    _subTitleLabel.text = [_settingsArray objectAtIndex:0];
    [_popImageView addSubview:_subTitleLabel];
    
    _backButton = [[UIButton alloc] initWithFrame:CGRectMake(32, 31, 72, 37)];
    [_backButton setImage:[UIImage imageWithContentsOfFile:KSPathForBundleResource(@"btn_back.png")] forState:UIControlStateNormal];
    [_backButton setImage:[UIImage imageWithContentsOfFile:KSPathForBundleResource(@"btn_back.png")] forState:UIControlStateHighlighted];
    [_backButton addTarget:self action:@selector(dismiss) forControlEvents:UIControlEventTouchUpInside];
    _backButton.highlighted = YES;
    [_popImageView addSubview:_backButton];
    
    
    _leftTableView = [[UITableView alloc] initWithFrame:CGRectMake(32, 80, 273, 500.0f) style:UITableViewStyleGrouped];
    _leftTableView.backgroundColor = [UIColor clearColor];
    _leftTableView.backgroundView = nil;
    //_leftTableView.autoresizingMask = UIViewAutoresizingFlexibleHeight;
    _leftTableView.delegate = self;
    _leftTableView.dataSource = self;
    [_popImageView addSubview:_leftTableView];
    
    [UIUtil addAnimationShow:_popImageView];
    
    [self showAccountFormView];
}
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageWithContentsOfFile:KSPathForBundleResource(@"book_store_bg.png")]];

        _settingsArray = [[NSArray arrayWithObjects:
                           @"账户管理",
//                           @"我的收藏",
                           @"读者编号",
                           @"购买记录",
                           @"恢复购买",
                           nil] retain];
        _settingMethodsArray = [[NSArray arrayWithObjects:
                                 @"showAccountFormView",
//                                 @"showMyCollection",
                                 @"showGiftcardView",
                                 @"showSubscribeView", 
                                 @"showRestoreView",
                                 nil] retain];
        [self initAccountSubview];
    }
    return self;
}
- (void)layoutSubviews {
//    if ([UIUtil currentOrientation] == 0 ) {
//        _bgImageView.image = [UIImage imageWithContentsOfFile:KSPathForBundleResource(@"bg_pop_v.png")];
        _popImageView.image = [UIImage imageNamedNocache:@"pop_setting_v.png"];
        _popImageView.frame = CGRectMake(30, 28, 708, 943);
        
        _backButton.frame = CGRectMake(2, 3, 72, 37);
        _leftTableView.frame = CGRectMake(2, 52, 273, 500);
        _subTitleLabel.frame = CGRectMake(282, 6, 412, 32);
        
        _subsribeSettingView.frame = CGRectMake(311, 72, 418, 880);
        _restoreView.frame = CGRectMake(311, 72, 418, 884);
        _giftcardView.frame = CGRectMake(311, 72, 418, 884);
        _accountFormView.frame = CGRectMake(311, 72, 418, 884);
        _loggedView.frame = CGRectMake(311, 72, 418, 884);
//    } else {
//        _bgImageView.image = [UIImage imageWithContentsOfFile:KSPathForBundleResource(@"bg_pop_h.png")];
//        _popImageView.image = [UIImage imageNamedNocache:@"pop_setting_h.png"];
//        _popImageView.frame = CGRectMake(37, 30, 948, 694);
//        
//        _backButton.frame = CGRectMake(2, 3, 72, 37);
//        _leftTableView.frame = CGRectMake(2, 80, 273, 500);
//        _subTitleLabel.frame = CGRectMake(275, 6, 666, 32);
//        
//        _subsribeSettingView.frame = CGRectMake(314, 76, 666, 628);
//        _restoreView.frame = CGRectMake(314, 76, 666, 630);
//        _giftcardView.frame = CGRectMake(314, 76, 666, 630);
//        _accountFormView.frame = CGRectMake(314, 76, 666, 630);
//        _loggedView.frame = CGRectMake(314, 76, 666, 630);
//    }
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/
#pragma mark - Switch subViews
- (void)dismiss {
    if ([_viewfrom isEqualToString:@"setting"]) {
        [(KSMagzineViewController *)self.viewController showSetting];
    } else {
        [UIView animateWithDuration:0.3 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
            self.alpha = 0;
        } completion:^(BOOL finished) {
            [(KSMagzineViewController *)self.viewController showView:@"none"];
        }];
    }   
}
- (void)releaseAllSettingSubViews {
    [_accountFormView removeFromSuperview],[_accountFormView release],_accountFormView = nil;
    [_giftcardView removeFromSuperview],[_giftcardView release],_giftcardView = nil;
    [_subsribeSettingView removeFromSuperview],[_subsribeSettingView release],_subsribeSettingView = nil;
    [_restoreView removeFromSuperview],[_restoreView release],_restoreView = nil;
    [_loggedView removeFromSuperview],[_loggedView release], _loggedView = nil;
}
- (void)showAccountFormView {
    if ([KSBootstrap currentUser]) {
        if (!_loggedView) {
            _loggedView = [[CXLoggedView alloc] initWithFrame:CGRectMake(312, 68, 412, 700)];
            _loggedView.parent = self;
        }
        [self addSubview:_loggedView];
        [UIUtil addAnimationShow:_loggedView];
    } else {
        if (!_accountFormView) {
            NSArray *views = [[NSBundle mainBundle] loadNibNamed:@"CXAccountFormView" owner:self options:nil];
            _accountFormView = [[views objectAtIndex:0] retain];
            _accountFormView.frame = CGRectMake(312, 68, 412, 700);
            _accountFormView.parent = self;
        }
        [self addSubview:_accountFormView];
        [UIUtil addAnimationShow:_accountFormView];
    }
}
- (void)freshAccountFormView {
    if (_loggedView) {
        [_loggedView removeFromSuperview];
        RELEASE_SAFELY(_loggedView);
    }
    if (_accountFormView) {
        [_accountFormView removeFromSuperview];
        RELEASE_SAFELY(_accountFormView);
    }
    [self showAccountFormView];
}
- (void)showSubscribeView {
    if (!_subsribeSettingView) {
        _subsribeSettingView = [[KSSettingSubscribeView alloc] initWithFrame:CGRectMake(312, 68, 412, 700)];
    }
    [self addSubview:_subsribeSettingView];
    [UIUtil addAnimationShow:_subsribeSettingView];
}
- (void)freshSubscribeView {
    if (_subsribeSettingView) {
        [_subsribeSettingView removeFromSuperview];
        RELEASE_SAFELY(_subsribeSettingView);
        [self showSubscribeView];
    }
    
}
- (void)showRestoreView {
    if (!_restoreView) {
        _restoreView = [[KSSettingRestoreView alloc] initWithFrame:CGRectMake(312, 68, 412, 700)];
        _restoreView.parent = self;
    }
    [self addSubview:_restoreView];
    [UIUtil addAnimationShow:_restoreView];
}
-(void)showMyCollection
{
    if (!_collection)
    {
        _collection = [[KSCollectionView alloc] initWithFrame:CGRectMake(0, 0, 768, 1024) handler:self.viewController];
    }
    [self addSubview:_collection];
    [UIUtil addAnimationShow:_collection];
}

- (void)showGiftcardView {
    if (!_giftcardView) {
        NSArray *views = [[NSBundle mainBundle] loadNibNamed:@"CXGiftcardView" owner:self options:nil];
        _giftcardView = [[views objectAtIndex:0] retain];
        _giftcardView.frame = CGRectMake(312, 68, 412, 700); //= [[KSAppRecommendView alloc] initWithFrame:CGRectMake(312, 68, 412, 700)];
        _giftcardView.parent = self;
    }
    [self addSubview:_giftcardView];
    [UIUtil addAnimationShow:_giftcardView];
    
//    if (!_giftcardView) {
//        _giftcardView = [[CXGiftcardView alloc] initWithFrame:CGRectMake(312, 68, 412, 700)];
//        _giftcardView.parent = self;
//    }
//    [self addSubview:_giftcardView];
//    [UIUtil addAnimationShow:_giftcardView];
}
#pragma mark -
- (void)showRegSuccessView {
    
}
- (void)showRegSuccessViewWithMail:(NSString *)email password:(NSString *)pwd {
    UIView *containerView = [[UIView alloc] initWithFrame:self.bounds];
//    containerView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    [self addSubview:containerView];
    containerView.tag = 9001;
    containerView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.8];
    [containerView release];
    
    NSArray *views = [[NSBundle mainBundle] loadNibNamed:@"KSRegSuccView" owner:self options:nil];
    //KSRegSuccView *reg_succ_view = [[views objectAtIndex:0] retain];
    KSRegSuccView *reg_succ_view = [views objectAtIndex:0];
    //    reg_succ_view.frame = CGRectMake(0, 0, 422, 336);
    reg_succ_view.center = CGPointMake(roundf(self.centerX), roundf(self.centerY));
    reg_succ_view.layer.cornerRadius = 5;
    
    reg_succ_view.email = email;
    reg_succ_view.handler = self.viewController;
    [containerView addSubview:reg_succ_view];    
    //animation
    reg_succ_view.alpha = 0;
    [UIView animateWithDuration:0.3 animations:^{
        reg_succ_view.alpha = 1;
    } completion:^(BOOL finished) {

    }];
}
#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 50.0f;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 0;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [self releaseAllSettingSubViews];
    _subTitleLabel.text = [_settingsArray objectAtIndex:indexPath.row];
    
    [self performSelector:NSSelectorFromString([_settingMethodsArray objectAtIndex:indexPath.row])];
}
#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [_settingsArray count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.textLabel.text = [_settingsArray objectAtIndex:indexPath.row];
    
    return [cell autorelease];
}

@end
