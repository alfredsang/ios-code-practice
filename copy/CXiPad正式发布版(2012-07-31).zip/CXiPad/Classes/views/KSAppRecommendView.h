//
//  KSAppRecommendView.h
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-7.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KSAppRecommendView : UIScrollView {
    
}
- (IBAction)goAppStore:(id)sender;

@end
