//
//  KSArticleCoreTextHeaderView.m
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSArticleCoreTextHeaderView.h"

@implementation KSArticleCoreTextHeaderView
@synthesize shouldTuneFrame = _shouldTuneFrame;
@synthesize moveGap = _moveGap;

- (id)initWithFrame:(CGRect)frame article:(KSModelArticle *)article
{
    self = [super initWithFrame:frame];
    if (self) {
        _article = [article retain];
        _moveGap = 0;
        _shouldTuneFrame = NO;
        _isDoubleTitle = NO;
        [self initSubviews];
    }
    return self;
}
- (id)initWithFrame:(CGRect)frame article:(KSModelArticle *)article leftimg:(NSString *)leftImage rightimg:(NSString *)rightImge {
    self = [super initWithFrame:frame];
    if (self) {
        if (frame.size.height!=0)
        {
            self.top+=20;
        }
        _article = [article retain];
        _leftImage = [leftImage copy];
        _rightImage = [rightImge copy];
        _moveGap = 0;
        _shouldTuneFrame = NO;
        _isDoubleTitle = NO;
        [self initSubviews];
    }
    return self;
}
- (void)dealloc{
    [_article release];
    [titleView release];
    [subtitleView release];
    [summaryLabel release];
    [authorsView release];
    [_leftImage release];
    [_rightImage release];
    [_imageView release];
    [columnistView release];
    [super dealloc];
}

- (void)initSubviews{
    float left = 0;
    if(self.left==0){
        left = 35;
    }
    NSRange range = [_article.title rangeOfString:@"|"];
    if (range.length>0)
    {
        _isDoubleTitle = YES;
    }
    
    titleView = [[UILabel alloc] initWithFrame:CGRectMake(left+5, 0, self.width-10, 60.0f)];
    titleView.numberOfLines = 0;
    titleView.lineBreakMode = UILineBreakModeWordWrap;
    if (_isDoubleTitle)
    {
        titleView.font = ARTICLE_DOUBLE_TITLE_FONT;
        titleView.text = [_article.title stringByReplacingOccurrencesOfString:@"\|" withString:@"\n"];

    }
    else 
    {
        titleView.font = ARTICLE_SINGLE_TITLE_FONT;
        titleView.text = _article.title;

    }
    titleView.textColor = str2rgb(@"#373737");
    titleView.backgroundColor= [UIColor clearColor];
    [self addSubview:titleView];
    
    subtitleView = [[UILabel alloc] initWithFrame:CGRectZero];
    subtitleView.font = ARTICLE_SUB_TITLE_FONT;
    subtitleView.textColor = str2rgb(@"#414141");
    subtitleView.text = [_article.subtitle isEmpty]?@"":[@"----" stringByAppendingString:_article.subtitle];
    subtitleView.backgroundColor= [UIColor clearColor];
    [self addSubview:subtitleView];
    
    summaryLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    summaryLabel.clipsToBounds = NO;
    summaryLabel.lineBreakMode = UILineBreakModeWordWrap;
    summaryLabel.numberOfLines = 0;
    summaryLabel.font = ARTICLE_SUMARRY_FONT;//[UIFont fontWithName:@"STZhongsong" size:18];//华文中宋
    summaryLabel.textColor = str2rgb(@"#505050");
    //summaryLabel.text = _article.subtitle.length>0?_article.subtitle:_article.summary;//@"副标题";
    summaryLabel.text = _article.summary;
    summaryLabel.backgroundColor= [UIColor clearColor];
    [self addSubview:summaryLabel];
    
    self.height += _moveGap;
    
    authorsView = [[UILabel alloc] initWithFrame:CGRectMake(titleView.left , summaryLabel.bottom+11, self.width, 20)];
    authorsView.font = [UIFont systemFontOfSize:18.0f];
    authorsView.textColor = str2rgb(@"#7d7d7d");//str2rgb(@"#3a3a3a");
    authorsView.text = _article.authors;//STR_FORMAT(@"口 本刊记者 %@ |文", _article.authors);
    authorsView.backgroundColor= [UIColor clearColor];
    [self addSubview:authorsView];
    
    
    if (_leftImage && [_leftImage length]) 
    {//存在专栏作家
        _imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 9.5, 129, 170)];
        authorsView.frame = CGRectMake(_imageView.left , _imageView.bottom+8, _imageView.width, 20);

        if([_leftImage indexOf:@"http://"]>=0)
        {
            _imageView.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:_leftImage]]];
        }
        else
        {
            NSString *str = STR_FORMAT(@"%@/%@", _article.filepath, _leftImage);
            _imageView.image = [UIImage imageWithContentsOfFile:str];
        }
        [self addSubview:_imageView];
        if ([UIUtil currentOrientation]==0) 
        {
            titleView.frame = CGRectMake(_imageView.left, authorsView.bottom+8, self.width, 60);
            CGSize maxSz = CGSizeMake(titleView.width, 9999.0f);
            CGSize sz = [_article.title sizeWithFont:titleView.font constrainedToSize:maxSz lineBreakMode:UILineBreakModeWordWrap];
            if (sz.height > 60)
            {
                titleView.height = 120;
                _shouldTuneFrame = YES;
                _moveGap += 60;
            }
            if (![_article.subtitle isEmpty])
            {
//                subtitleView.frame = CGRectMake(titleView.left, titleView.bottom+DISTANCE_BETWEEN_TITLE_AND_SUBTITLE, titleView.width, 30.0f);
//                maxSz = CGSizeMake(titleView.width, 9999.0f);
//                sz = [subtitleView.text sizeWithFont:subtitleView.font constrainedToSize:maxSz lineBreakMode:UILineBreakModeWordWrap];
//                if (sz.height > 30) 
//                {
//                    subtitleView.height = 30;
//                    _shouldTuneFrame = YES;
                    _moveGap += DISTANCE_BETWEEN_TITLE_AND_SUBTITLE+30;
//                }
                
            }

            
//            summaryLabel.frame = CGRectMake(titleView.left, titleView.bottom+3, round(titleView.width-5), 30);
//            maxSz = CGSizeMake(summaryLabel.width, 9999.0f);
//            sz = [summaryLabel.text sizeWithFont:summaryLabel.font constrainedToSize:maxSz lineBreakMode:UILineBreakModeWordWrap];
//            if (sz.height > 30) 
//            {
//                summaryLabel.height = sz.height;
//                _shouldTuneFrame = YES;
//                _moveGap += (sz.height-30.0f);
//            }
            
            if (![_article.summary isEmpty]) 
            {
                summaryLabel.frame = CGRectMake(titleView.left, ([_article.subtitle isEmpty]?titleView.bottom:subtitleView.bottom)+DISTANCE_BETWEEN_SUBTITLE_AND_SUMMARY, titleView.width, 30);
                maxSz = CGSizeMake(summaryLabel.width, 9999.0f);
                sz = [summaryLabel.text sizeWithFont:summaryLabel.font constrainedToSize:maxSz lineBreakMode:UILineBreakModeWordWrap];
                if (sz.height > 30) 
                {
                    summaryLabel.height = sz.height;
                    _shouldTuneFrame = YES;
                    _moveGap += (sz.height-30.0f)+DISTANCE_BETWEEN_SUBTITLE_AND_SUMMARY;
                }
                
            }

            
            self.height += _moveGap;
        } 
        else
        {
         /*   
            columnistView = [[UILabel alloc] init];
            columnistView.frame = CGRectMake(_imageView.right+16.5, _imageView.top, 100, 15);
            columnistView.backgroundColor = [UIColor clearColor];
            columnistView.text = @"专栏";
            columnistView.font = [UIFont boldSystemFontOfSize:14];
            columnistView.textColor = str2rgb(@"#000000");
            [self addSubview:columnistView];
       */     
            columnistView = [[UILabel alloc] initWithFrame:CGRectZero];
            authorsView.frame = CGRectMake(_imageView.left+5 , _imageView.bottom+5, 200, 20);
            titleView.frame = CGRectMake(_imageView.right+16.5, 30, self.width-_imageView.right-30, 60);
            CGSize maxSz = CGSizeMake(titleView.width, 9999.0f);
            CGSize sz = [_article.title sizeWithFont:titleView.font constrainedToSize:maxSz lineBreakMode:UILineBreakModeWordWrap];
            CGFloat move1 = 0, move2 = 0;
            if (sz.height > 60) 
            {
                titleView.height = sz.height;
                _shouldTuneFrame = YES;
                move1 += (sz.height-60);
            }
            
            if (![_article.subtitle isEmpty])
            {
                subtitleView.frame = CGRectMake(titleView.left, titleView.bottom+DISTANCE_BETWEEN_TITLE_AND_SUBTITLE, titleView.width, 30.0f);
//                maxSz = CGSizeMake(titleView.width, 9999.0f);
//                sz = [subtitleView.text sizeWithFont:subtitleView.font constrainedToSize:maxSz lineBreakMode:UILineBreakModeWordWrap];
//                if (sz.height > 30) 
//                {
//                    subtitleView.height = 30;
//                    _shouldTuneFrame = YES;
                    move1 += DISTANCE_BETWEEN_TITLE_AND_SUBTITLE+30;
//                }
                
            }
            if (![_article.summary isEmpty]) 
            {
                summaryLabel.frame = CGRectMake(titleView.left, ([_article.subtitle isEmpty]?titleView.bottom:subtitleView.bottom)+DISTANCE_BETWEEN_SUBTITLE_AND_SUMMARY, titleView.width, 30);
                maxSz = CGSizeMake(summaryLabel.width, 9999.0f);
                sz = [summaryLabel.text sizeWithFont:summaryLabel.font constrainedToSize:maxSz lineBreakMode:UILineBreakModeWordWrap];
                if (sz.height > 30) 
                {
                    summaryLabel.height = sz.height;
                    _shouldTuneFrame = YES;
                    move2 += (sz.height-30.0f)+DISTANCE_BETWEEN_SUBTITLE_AND_SUMMARY;
                }
                
            }
            
//            summaryLabel.frame = CGRectMake(titleView.left, titleView.bottom+3, round(titleView.width-5), 30);
//            maxSz = CGSizeMake(summaryLabel.width, 9999.0f);
//            sz = [summaryLabel.text sizeWithFont:summaryLabel.font constrainedToSize:maxSz lineBreakMode:UILineBreakModeWordWrap];
//            if (sz.height > 30) 
//            {
//                summaryLabel.height = sz.height;
//                _shouldTuneFrame = YES;
//                move2 += (sz.height-30.0f);
//            }
            if (move1 + move2 > 50)
            {
                _moveGap = move1+move2-50;
            }
            self.height += _moveGap;
        }
    }
    else if (_rightImage && [_rightImage length]) 
    {
        _imageView = [[UIImageView alloc] initWithFrame:CGRectMake(self.width-202, 22, 200, 133)];
        if([_rightImage indexOf:@"http://"]>=0)
        {
            _imageView.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:_rightImage]]];
        }
        else
        {
            NSString *str = STR_FORMAT(@"%@/%@", _article.filepath, _rightImage);
            _imageView.image = [UIImage imageWithContentsOfFile:str];
        }
        [self addSubview:_imageView];
        
        titleView.width -= 200;
        summaryLabel.width -= 200;
        CGSize maxSz = CGSizeMake(titleView.width-10, 9999.0f);
        CGSize sz = [_article.title sizeWithFont:titleView.font constrainedToSize:maxSz lineBreakMode:UILineBreakModeWordWrap];
        if (sz.height > 60) 
        {
            titleView.height = sz.height;
            _shouldTuneFrame = YES;
            _moveGap += (sz.height-60);
        }
        maxSz = CGSizeMake(summaryLabel.width, 9999.0f);
        sz = [summaryLabel.text sizeWithFont:summaryLabel.font constrainedToSize:maxSz lineBreakMode:UILineBreakModeWordWrap];
        if (sz.height > 30)
        {
            summaryLabel.height = sz.height;
            _shouldTuneFrame = YES;
            _moveGap += (sz.height-30.0f);
        }
        self.height += _moveGap;
        authorsView.frame = CGRectMake(roundf(titleView.left) , roundf(summaryLabel.bottom+11), roundf(self.width), 20);
    } 
    else 
    {
        CGSize maxSz = CGSizeMake(self.width-left-10, 9999.0f);
        CGSize sz = [_article.title sizeWithFont:titleView.font constrainedToSize:maxSz lineBreakMode:UILineBreakModeWordWrap];
        if (sz.height > 60) 
        {
            titleView.height = sz.height;
            _shouldTuneFrame = YES;
            _moveGap += (sz.height-60);
        }
        if (![_article.subtitle isEmpty])
        {
            subtitleView.frame = CGRectMake(titleView.left, titleView.bottom+DISTANCE_BETWEEN_TITLE_AND_SUBTITLE, titleView.width, 30.0f);
//            maxSz = CGSizeMake(titleView.width, 9999.0f);
//            sz = [subtitleView.text sizeWithFont:subtitleView.font constrainedToSize:maxSz lineBreakMode:UILineBreakModeWordWrap];
//            if (sz.height > 30) 
//            {
//                subtitleView.height = 30;
//                _shouldTuneFrame = YES;
                _moveGap += DISTANCE_BETWEEN_TITLE_AND_SUBTITLE+30;
//            }
            
        }
        
        if (![_article.summary isEmpty]) 
        {
            summaryLabel.frame = CGRectMake(titleView.left, ([_article.subtitle isEmpty]?titleView.bottom:subtitleView.bottom)+DISTANCE_BETWEEN_SUBTITLE_AND_SUMMARY, titleView.width, 30);
            maxSz = CGSizeMake(summaryLabel.width, 9999.0f);
            sz = [summaryLabel.text sizeWithFont:summaryLabel.font constrainedToSize:maxSz lineBreakMode:UILineBreakModeWordWrap];
            if (sz.height > 30) 
            {
                summaryLabel.height = sz.height;
                _shouldTuneFrame = YES;
                _moveGap += (sz.height-30.0f)+DISTANCE_BETWEEN_SUBTITLE_AND_SUMMARY;
            }
            
        }
        CGFloat authorMoveGap = 0;
        if (subtitleView.height!=0 )
        {
            authorMoveGap = subtitleView.bottom + DISTANCE_BETWEEN_TITLE_AND_SUBTITLE;
        }
        if (summaryLabel.height !=0)
        {
            authorMoveGap = summaryLabel.bottom + DISTANCE_BETWEEN_SUBTITLE_AND_SUMMARY;
        }
        if (subtitleView.height==0&&summaryLabel.height==0)
        {
            authorMoveGap = titleView.bottom + 40;
        }
        
        self.height += _moveGap;
        
        authorsView.frame = CGRectMake(titleView.left , authorMoveGap+11, self.width, 20);
    }
}
@end
