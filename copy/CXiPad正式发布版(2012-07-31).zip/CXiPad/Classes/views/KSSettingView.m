//
//  KSSettingView.m
//  CenturyWeeklyV2
//
//  Created by zyk on 12/22/11.
//  Copyright (c) 2011 KSMobile. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "KSMagzineViewController.h"
#import "KSSettingView.h"
#import "KSHelpView.h"

@implementation KSSettingView
@synthesize handler = _controller;
@synthesize shouldUpdatePush = _shouldUpdatePush;
@synthesize titleLabel = _titleLabel;

- (void)dealloc {
    if (_shouldUpdatePush) {
        [_controller savePushSettingToServer];
    }
    
    [_settingsArray release];
    [_settingMethodsArray release];
    
//    [_bgImageView release];
    [_popImageView release];
    
    [_titleLabel release];
    [_backButton release];
    [_subTitleLabel release];
    
    [_notifiSettingView release];
    [_subsribeSettingView release];
    [_restoreView release];
    [_appRecommendView release];
    [_fontSettingView release];
    [_helpView release];
    [_newHelpView release];
    [_aboutView release];
    [_faqView release];
    [markView release];
    [_noticeView release];
    [appRecommendView release];
    [super dealloc];
}

- (void)loadSubViews {
    
//    self.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
//    _bgImageView = [[UIImageView alloc] initWithFrame:self.bounds];
//    _bgImageView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
//    [self addSubview:_bgImageView];

    _popImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamedNocache:@"pop_setting_v.png"]];
    _popImageView.frame = CGRectMake(30, 35, 708, 943);
    [self addSubview:_popImageView];
    _popImageView.userInteractionEnabled = YES;
    
    _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(8, 6, 260, 32)];
    _titleLabel.textAlignment = UITextAlignmentCenter;
    _titleLabel.font = [UIFont systemFontOfSize:24.0f];
    _titleLabel.textColor = [UIColor colorWithRed:0.4353 green:0.4667 blue:0.5373 alpha:1.0];
    _titleLabel.backgroundColor = [UIColor clearColor];
    _titleLabel.text = @"设置";
    [_popImageView addSubview:_titleLabel];
    
    _subTitleLabel =[[UILabel alloc] initWithFrame:CGRectMake(312, 34, 412, 32)];
    _subTitleLabel.textAlignment = UITextAlignmentCenter;
    _subTitleLabel.font = [UIFont systemFontOfSize:24.0f];
    _subTitleLabel.textColor = [UIColor colorWithRed:0.4353 green:0.4667 blue:0.5373 alpha:1.0];
    _subTitleLabel.backgroundColor = [UIColor clearColor];
    _subTitleLabel.text = [_settingsArray objectAtIndex:0];
    [_popImageView addSubview:_subTitleLabel];
    
    _backButton = [[UIButton alloc] initWithFrame:CGRectMake(32, 31, 72, 37)];
    [_backButton setImage:[UIImage imageWithContentsOfFile:KSPathForBundleResource(@"btn_back.png")] forState:UIControlStateNormal];
    [_backButton setImage:[UIImage imageWithContentsOfFile:KSPathForBundleResource(@"btn_back.png")] forState:UIControlStateHighlighted];
    [_backButton addTarget:self action:@selector(dismiss) forControlEvents:UIControlEventTouchUpInside];
    _backButton.highlighted = YES;
    [_popImageView addSubview:_backButton];
    
    
    _leftTableView = [[UITableView alloc] initWithFrame:CGRectMake(32, 80, 273, 500.0f) style:UITableViewStyleGrouped];
    _leftTableView.backgroundColor = [UIColor clearColor];
    _leftTableView.backgroundView = nil;
    //_leftTableView.autoresizingMask = UIViewAutoresizingFlexibleHeight;
    _leftTableView.delegate = self;
    _leftTableView.dataSource = self;
    [_popImageView addSubview:_leftTableView];
    
    [UIUtil addAnimationShow:_popImageView];
    //[self setNeedsLayout];
    
    //[self showPushView];
    
    
    _popImageView.image = [UIImage imageNamedNocache:@"pop_setting_v.png"];
    _popImageView.frame = CGRectMake(30, 28, 708, 943);
    
    _backButton.frame = CGRectMake(2, 3, 72, 37);
    _leftTableView.frame = CGRectMake(2, 52, 273, 500);
    _subTitleLabel.frame = CGRectMake(282, 6, 412, 32);
    


}
- (id)initWithFrame:(CGRect)frame handler:(KSMagzineViewController *)handler {
    self = [self initWithFrame:frame];
    if (self) {
        _controller = handler;
    }
    return self;
}
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageWithContentsOfFile:KSPathForBundleResource(@"book_store_bg.png")]];

        // Initialization code
        _settingsArray = [[NSArray arrayWithObjects:
                           @"账户管理",
                           @"推送通知",
                           @"功能设置",
                           @"分享管理",
//                           @"常见问题",
//                           @"关于我们",
                           @"应用推荐",
                           @"应用评分",
                           @"使用帮助",
                           nil] retain];
        _settingMethodsArray = [[NSArray arrayWithObjects:
                                 @"showAccoutView",
                                 @"showPushView",
                                 @"showFontSettingView",
                                 @"showShareView",
//                                 @"showFaqView",
//                                 @"showAboutView",
                                 @"showAppRecommendView",
                                 @"showMarkView",
                                 @"showNewHelpView",
                                 nil] retain];
        [self loadSubViews];
    }
    return self;
}

- (void)layoutSubviews {
//    _notifiSettingView.frame = CGRectMake(311, 72, 418, 884);
//    _subsribeSettingView.frame = CGRectMake(311, 72, 418, 884);
//    _restoreView.frame = CGRectMake(311, 72, 418, 884);
//    _appRecommendView.frame = CGRectMake(311, 72, 418, 884);
//    _fontSettingView.frame = CGRectMake(311, 72, 418, 884);
    _helpView.frame = CGRectMake(311, 72, 418, 884);
//    _aboutView.frame = CGRectMake(311, 72, 418, 880);
//    _faqView.frame = CGRectMake(311, 72, 418, 880);
//    _shareView.frame = CGRectMake(311, 72, 418, 884);
//    appRecommendView.frame = CGRectMake(311, 72, 418, 884);
//    markView.frame = CGRectMake(311, 72, 418, 884);
//    if ([UIUtil currentOrientation] == 0 ) {
//        _bgImageView.image = [[UIImage imageWithContentsOfFile:KSPathForBundleResource(@"book_store_bg.png")] stretchableImageWithLeftCapWidth:10 topCapHeight:10];
        //    } else {
//        _bgImageView.image = [UIImage imageWithContentsOfFile:KSPathForBundleResource(@"bg_pop_h.png")];
//        _popImageView.image = [UIImage imageNamedNocache:@"pop_setting_h.png"];
//        _popImageView.frame = CGRectMake(37, 30, 948, 694);
//        
//        _backButton.frame = CGRectMake(2, 3, 72, 37);
//        _leftTableView.frame = CGRectMake(2, 80, 273, 500);
//        _subTitleLabel.frame = CGRectMake(275, 6, 666, 32);
//        
//        _notifiSettingView.frame = CGRectMake(314, 76, 666, 630);
//        _subsribeSettingView.frame = CGRectMake(314, 76, 666, 630);
//        _restoreView.frame = CGRectMake(314, 76, 666, 630);
//        _appRecommendView.frame = CGRectMake(314, 76, 666, 630);
//        _fontSettingView.frame = CGRectMake(314, 76, 666, 630);
//        _helpView.frame = CGRectMake(314, 76, 666, 630);
//        _aboutView.frame = CGRectMake(314, 76, 666, 626);
//        _faqView.frame = CGRectMake(314, 76, 666, 626);
//        _shareView.frame = CGRectMake(314, 76, 666, 630);
//        appRecommendView.frame = CGRectMake(314, 76, 666, 630);
//        markView.frame = CGRectMake(314, 76, 666, 630);
//    }
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

#pragma mark -
- (void)savePushSetting {
    if (_shouldUpdatePush) {
        [_controller savePushSettingToServer];
        _shouldUpdatePush = NO;
    }
}
#pragma mark - Switch subViews
//
- (void)dismiss {
    [self savePushSetting];
    [UIView animateWithDuration:0.3 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        self.alpha = 0;
    } completion:^(BOOL finished) {
        [_controller showView:@"none"];
    }];
}
- (void)releaseAllSettingSubViews {

    [_notifiSettingView removeFromSuperview],[_notifiSettingView release],_notifiSettingView = nil;
    [_subsribeSettingView removeFromSuperview],[_subsribeSettingView release],_subsribeSettingView = nil;
    [_restoreView removeFromSuperview],[_restoreView release],_restoreView = nil;
    [_appRecommendView removeFromSuperview],[_appRecommendView release],_appRecommendView = nil;
    [_fontSettingView removeFromSuperview],[_fontSettingView release],_fontSettingView = nil;
    [_helpView removeFromSuperview],[_helpView release],_helpView = nil;
    [_newHelpView removeFromSuperview],[_newHelpView release],_newHelpView = nil;
    [_shareView removeAllSubviews], [_shareView release],_shareView = nil;
    [_aboutView removeFromSuperview],[_aboutView release],_aboutView = nil;
    [_faqView removeFromSuperview],[_faqView release],_faqView = nil;    
    [markView removeFromSuperview],[markView release],markView = nil;
    [_noticeView removeFromSuperview],[_noticeView release],_noticeView = nil;
    [appRecommendView removeFromSuperview];
}
- (void)showAccoutView {
    [(KSMagzineViewController *)self.viewController showAccountViewFromSetting];
}
- (void)showPushView {
    if (!_notifiSettingView) {
        _notifiSettingView = [[KSSettingNotificationView alloc] initWithFrame:CGRectMake(311, 72, 418, 880)];
        _notifiSettingView.parent = self;
    }
    [self addSubview:_notifiSettingView];
    [UIUtil addAnimationShow:_notifiSettingView];
}
- (void)showSubscribeView {
    if (!_subsribeSettingView) {
        _subsribeSettingView = [[KSSettingSubscribeView alloc] initWithFrame:CGRectMake(311, 72, 418, 880)];
    }
    [self addSubview:_subsribeSettingView];
    [UIUtil addAnimationShow:_subsribeSettingView];
}
//- (void)showRestoreView {
//    if (!_restoreView) {
//        _restoreView = [[KSSettingRestoreView alloc] initWithFrame:CGRectMake(312, 68, 412, 700)];
//        _restoreView.parent = self;
//    }
//    [self addSubview:_restoreView];
//    [UIUtil addAnimationShow:_restoreView];
//}
- (void)showAppRecommendView {
//    if (!_appRecommendView) {
//        NSArray *views = [[NSBundle mainBundle] loadNibNamed:@"KSAppRecommendView" owner:self options:nil];
//        _appRecommendView = [[views objectAtIndex:0] retain];
//        _appRecommendView.frame = CGRectMake(312, 68, 412, 700); //= [[KSAppRecommendView alloc] initWithFrame:CGRectMake(312, 68, 412, 700)];
//    }
//    [self addSubview:_appRecommendView];
//    [UIUtil addAnimationShow:_appRecommendView];
    
    
    if (!appRecommendView)
    {
        appRecommendView = [[KSSettingAppRecommendView alloc] initWithFrame:CGRectMake(312, 68, 412, 860)];
        
    }
    [self addSubview:appRecommendView];
    [UIUtil addAnimationShow:appRecommendView];
}
- (void)showFontSettingView {
    if (!_fontSettingView) {
        _fontSettingView = [[KSSettingFontView alloc] initWithFrame:CGRectMake(311, 72, 418, 880)];
    }
    [self addSubview:_fontSettingView];
    [UIUtil addAnimationShow:_fontSettingView];
}

- (void)showHelpView {
    if (!_helpView) {
        _helpView = [[[[NSBundle mainBundle] loadNibNamed:@"KSSettingHelpView" owner:self options:nil] objectAtIndex:0] retain];
        //[[KSSettingHelpView alloc] initWithFrame:CGRectMake(312, 68, 412, 700)];
    }
    [self addSubview:_helpView];
    [UIUtil addAnimationShow:_helpView];
}
-(void)showNewHelpView
{
    if (!_newHelpView) {
        _newHelpView = [[KSHelpView alloc] initWithFrame:CGRectMake(0,0,768,1024) handler:_controller];
        //[[KSSettingHelpView alloc] initWithFrame:CGRectMake(312, 68, 412, 700)];
    }
    [self addSubview:_newHelpView];
    [UIUtil addAnimationShow:_newHelpView];}
-(void)showMarkView
{
    if (!markView)
    {
        markView = [[KSSettingMarkView alloc] initWithFrame:CGRectMake(311, 72, 418, 880)];

    }
    [self addSubview:markView];
    [UIUtil addAnimationShow:markView];


}
- (void)showAboutView {
    if (!_aboutView) {
        _aboutView = [[KSSettingAboutView alloc] initWithFrame:CGRectMake(311, 72, 418, 880)];
    }
    [self addSubview:_aboutView];
    [UIUtil addAnimationShow:_aboutView];
}
- (void)showFaqView {
    if (!_faqView) {
        _faqView = [[KSSettingFaqView alloc] initWithFrame:CGRectMake(311, 72, 418, 880)];
    }
    [self addSubview:_faqView];
    [UIUtil addAnimationShow:_faqView];
    
}
- (void)showShareView {
    if (!_shareView) {
        _shareView = [[KSSettingShareView alloc] initWithFrame:CGRectMake(311, 72, 418, 880)];
    }
    [self addSubview:_shareView];
    [UIUtil addAnimationShow:_shareView];
}
-(void)showNotice
{
    if (!_noticeView)
    {
        _noticeView = [[KSSettingNoticeView alloc] initWithFrame:CGRectMake(311, 72, 418, 880)];
        
    }
    [self addSubview:_noticeView];
    [UIUtil addAnimationShow:_noticeView];
}
#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 50.0f;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 0;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [self releaseAllSettingSubViews];
    _subTitleLabel.text = [_settingsArray objectAtIndex:indexPath.row];
    
    [self performSelector:NSSelectorFromString([_settingMethodsArray objectAtIndex:indexPath.row])];
//    if (indexPath.row == 0) {
//        [self showPushView];
//    } else if (indexPath.row == 1) {
//        [self showSubscribeView];
//    } else if (indexPath.row == 2) {
//        [self showRestoreView];
//    } else if (indexPath.row == 3) {
//        [self showAppRecommendView];
//    } else if (indexPath.row == 4) {
//        [self showFontSettingView];
//    } else if (indexPath.row == 5) {
//        [self showHelpView];
//    } else if (indexPath.row == 6) {
//        [self showAboutView];
//    } else if (indexPath.row == 7) {
//        [self showFaqView];
//    }
}
#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [_settingsArray count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.textLabel.text = [_settingsArray objectAtIndex:indexPath.row];
    
    return [cell autorelease];
}


@end
