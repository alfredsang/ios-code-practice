//
//  KSMagazineBookStoreView.h
//  CenturyWeeklyV2
//
//  Created by 广亮 高 on 12-6-11.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSMagzineMainView.h"
#import "KSGetAllArticlesDownloader.h"
#import "KSDownMagazineOperation.h"

@class KSMagzineViewController;
@interface KSMagazineBookStoreView : UIView<UITableViewDelegate,UITableViewDataSource>

{
    KSMagzineViewController *_controller;
    UITableView *_theTabelView;
    NSMutableArray *_magazinsArray;
    UIImageView     *_magazineCover0ImageView;
    UIImageView     *_magazineCover1ImageView;
    UIImageView     *_magazineCover2ImageView;
    UITableViewCell *_buyCell;
    UITableViewCell *_lastCell;
    NSInteger       _lastIndex;
    KSModelMagzine  *_magazine;
    NSInteger buyIndex;

    NSString *year;
    NSMutableArray  *existYear;
    NSMutableArray  *allYears;
    BOOL    isEditModel;

}
@property(nonatomic,retain) KSNavigationSegBtnView *yearSeg;
@property(nonatomic,retain) KSModelMagzine  *magazine;
@property(nonatomic,assign) BOOL    isEditModel;
@property(nonatomic,retain) UITableViewCell *lastCell;
@property(nonatomic,assign) NSInteger lastIndex;


- (id)initWithFrame:(CGRect)frame controller:(id)controller;
-(void)reloadData;
-(void)whenMagzineDownloader:(NSInteger)magzineId;
-(void)whenMagzinePurchased:(NSInteger)magazineId;
-(void)reloadCellDataWithColumns:(NSInteger)columns rows:(NSInteger)rows Cell:(UIView*)cell;
-(void)downloadMagazine;
- (void)whenMagzineDeleted:(KSModelMagzine *)magazine;
-(void)whenMagzineCancelDownload:(NSInteger)magzineId reloadData:(BOOL)isRelad;
-(void)selectYear:(NSInteger)selectYear;
- (void) whenInitOrMagzineListUpdate;
- (void) whenMagzineCoverDownloaded:(NSInteger)magzineId;
-(void)buyBtnPress:(UIButton*)btn;
- (NSString *)calPubDate:(KSModelMagzine*)magazine;
@end
