//
//  KSFirstHelpView.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 2/2/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "KSFirstHelpView.h"
#import "KSMagzineViewController.h"

@implementation KSFirstHelpView 

- (void)dealloc {
    [_skipButton release];
    [super dealloc];
    
}
- (void)initSubviews {
    [self loadView];
    _scrollView.bounces = NO;
    _skipButton = [[UIButton alloc] initWithFrame:CGRectMake(self.width-220, 0, 200, 100)];
    _skipButton.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
    
    [_skipButton addTarget:self action:@selector(doClose) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_skipButton];
    
    _scrollView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.8];
    _scrollView.bounces = YES;
    
    _pageViewController = [[KSPageViewController alloc] initWithFrame:CGRectMake(0, 960, 768, 20)];
    _pageViewController.numberOfPages = 3;
    [self addSubview:_pageViewController];
    [_pageViewController release];
}
- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        _pageCount = 4;
        _pageSize = 1;
        _pageWidth = self.width;
        
        for (int i=0; i<_pageCount; i++) {
            [_cacheViewsList addObject:[NSNull null]];
        }
        [self initSubviews];
        
        [self moveToViewAtPage:0 animated:NO];
    }
    return self;
}
- (void)layoutSubviews {
    if (_scrolling) {
        return;
    }
    NSInteger p = _pageIndex;
    CGFloat h = 1024.0f;
    CGFloat w = 768.0f;
    if ([UIUtil currentOrientation]!=0) {
        h = 768;
        w = 1024;
    }
    _pageWidth = _cellWidth = w;
    _scrollView.frame = CGRectMake(0, 0, w, h);
    _scrollView.contentSize = CGSizeMake(_pageWidth*_pageCount, h);
    _scrollView.scrollEnabled = NO;
    for (int i = 0; i< [_cacheViewsList count]; i++) {
        UIView *v = [_cacheViewsList objectAtIndex:i];
        if (v!= nil && (NSNull *)v != [NSNull null]) {
//            NSString *imageName = [NSString stringWithFormat:@"help_f_%@_%d.jpg",[UIUtil currentOrientation]==0?@"v":@"h",i+1];
//            [(UIImageView *)v setImage:[UIImage imageNamedNocache:imageName]];
            v.frame = CGRectMake(_pageWidth*i, 0, w, h);
            //[_cacheViewsList replaceObjectAtIndex:i withObject:[NSNull null]];
        }
    }
    [_scrollView setContentOffset:CGPointMake(_pageWidth*p, 0) animated:NO];
    _scrollView.scrollEnabled = YES;
    
}
- (void)gotoCurrentPage {
    [self moveToViewAtPage:_pageIndex animated:NO];
}
#pragma mark -
- (void)moveToViewAtPage:(NSInteger)page animated:(BOOL)animated{
    _pageIndex = page;
	if (!_cacheViewsList || ![_cacheViewsList count]) {
        return;
    }
    if (_pageIndex >= _pageCount) {
        _pageIndex = _pageCount-1;
    }
    
    [self loadScrollViewWithPage:_pageIndex];
    [self loadScrollViewWithPage:_pageIndex+1];
	//[_scrollView scrollRectToVisible:((UIView *)[_cacheViewsList objectAtIndex:page*_pageSize]).frame animated:animated];
    [_scrollView setContentOffset:CGPointMake(_pageIndex*_pageWidth, 0) animated:animated];
    //[self layoutScrollViewSubviewsAnimated:NO];
    //[self setCachedViewState:_pageIndex];
    
}

- (UIView*)newCachedView:(NSInteger)index {
    UIView *v = [[UIView alloc] init];
    v.userInteractionEnabled = YES;

    v.backgroundColor = str2rgb(@"#e5e5e5");
    switch (index)
    {
        case 0:
        {
            UIImageView *img_1 = [[UIImageView alloc] initWithImage:[UIImage imageNamedNocache:@"start_1_img.png"]];
            img_1.frame = CGRectMake(240, 100, 345, 211);
            [v addSubview:img_1];
            [img_1 release];
            
            UIImageView *img_2 = [[UIImageView alloc] initWithImage:[UIImage imageNamedNocache:@"start_1_text.png"]];
            img_2.frame = CGRectMake(0, img_1.bottom, 647, 491);
            img_2.centerX = self.centerX;
            img_2.bottom = _pageViewController.top-75;
            [v addSubview:img_2];
            [img_2 release];
        }
            break;
        case 1:
        {
            UIImageView *img_1 = [[UIImageView alloc] initWithImage:[UIImage imageNamedNocache:@"start_2_text.png"]];
            img_1.frame = CGRectMake(134, 113, 520, 360);
            img_1.centerX = self.centerX;
            
            [v addSubview:img_1];
            [img_1 release];
            
            UIImageView *img_2 = [[UIImageView alloc] initWithImage:[UIImage imageNamedNocache:@"start_2_img.png"]];
            img_2.frame = CGRectMake(0, img_1.bottom+120, 480, 302);
            img_2.centerX = self.centerX;
            [v addSubview:img_2];
            [img_2 release];
        }
            break;
        case 2:
        {
            UIImageView *img_1 = [[UIImageView alloc] initWithImage:[UIImage imageNamedNocache:@"start_3_img_1.png"]];
            img_1.frame = CGRectMake(132, 110, 481, 51);
            img_1.centerX = self.centerX;
            [v addSubview:img_1];
            [img_1 release];
            
            UIImageView *img_2 = [[UIImageView alloc] initWithImage:[UIImage imageNamedNocache:@"start_3_text.png"]];
            img_2.frame = CGRectMake(0, img_1.bottom+89, 570, 253);
            img_2.centerX = self.centerX;
            [v addSubview:img_2];
            [img_2 release];
            
//            UIImageView *img_3 = [[UIImageView alloc] initWithImage:[UIImage imageNamedNocache:@"start_3_img_2.png"]];
//            img_3.frame = CGRectMake(132, img_2.bottom+134, 265, 51);
//            img_3.centerX = self.centerX;
//            [v addSubview:img_3];
//            [img_3 release];
            
            UIButton *img_3_btn = [UIButton buttonWithType:UIButtonTypeCustom];
            img_3_btn.frame = CGRectMake(0, img_2.bottom+134, 265, 51);
            img_3_btn.centerX = self.centerX;
            img_3_btn.userInteractionEnabled = YES;
            [img_3_btn setImage:[UIImage imageNamedNocache:@"start_3_img_2.png"] forState:UIControlStateNormal];
            [img_3_btn addTarget:self action:@selector(subscrib) forControlEvents:UIControlEventTouchUpInside];
            [v addSubview:img_3_btn];

            UIButton *img_4_btn = [UIButton buttonWithType:UIButtonTypeCustom];
            img_4_btn.frame = CGRectMake(0, img_3_btn.bottom+68, 265, 51);
            img_4_btn.centerX = self.centerX;
            img_4_btn.userInteractionEnabled = YES;
            [img_4_btn setImage:[UIImage imageNamedNocache:@"start_3_img_3.png"] forState:UIControlStateNormal];
            [img_4_btn addTarget:self action:@selector(goSkip) forControlEvents:UIControlEventTouchUpInside];
            [v addSubview:img_4_btn];
            
            UIImageView *img_5 = [[UIImageView alloc] initWithImage:[UIImage imageNamedNocache:@"start_3_img_4.png"]];
            img_5.frame = CGRectMake(0, 0, 133, 25);
            img_5.right = 768-45;
            img_5.bottom = 1024-24;
            [v addSubview:img_5];
            [img_5 release];
        }
            break;
        default:
            v.backgroundColor = [UIColor clearColor];
            break;

            
    }
    v.frame = CGRectMake(_pageWidth*index, 0, 768, 1024);

    return v;

}
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if (scrollView == _scrollView) {
        if (_pageIndex != [self centerViewIndex] && !_rotating) {
            NSInteger newIndex = [self centerViewIndex];
            if (newIndex >= _pageCount || newIndex < 0) {
                return;
            }
            _pageIndex = newIndex;
            _pageViewController.currentPage = _pageIndex;
        }
    }
    if (scrollView.contentOffset.x > _pageWidth * (_pageCount-1)) {
        //scrollView.delegate = nil;
        //scrollView.scrollEnabled = NO;
        scrollView.backgroundColor = [UIColor clearColor];
        //[self performSelector:@selector(goSkip) withObject:nil afterDelay:0];
    }
}
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    if (scrollView == _scrollView && !_rotating) {
        [self moveToViewAtPage:[self centerViewIndex] animated:YES];
        //[self layoutScrollViewSubviewsAnimated:NO];
    }
	_scrolling = NO;
    
    if (_pageIndex >= _pageCount-1)
    [self performSelector:@selector(goSkip) withObject:nil afterDelay:0];
}
#pragma mark -
- (void)doClose {
    [self removeFromSuperview];
}
- (void)goSkip {
    if (_pageIndex >= _pageCount-2) {
        [self removeFromSuperview];
    } else {
        [self moveToViewAtPage:_pageIndex+1 animated:YES];
        //[self performSelector:@selector(gotoNextPage) withObject:nil afterDelay:0.1];
    }
}
-(void)subscrib
{
    [KSAppStoreProxy subscribe:12 fromView:self];
}
@end
