//
//  KSNoPermissionAlertView.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 3/17/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSTapableView.h"
#import "KSModelMagzine.h"

@class KSNoPermissionAlertView;
@protocol KSNoPermissionAlertViewDelegate <NSObject>

@optional;
- (void)beforeDoBuy:(KSNoPermissionAlertView *)alertView;
- (void)afterDoBuy:(KSNoPermissionAlertView *)alertView;
@end
@interface KSNoPermissionAlertView : UIView {
    KSTapableView *_bgView;
    UIImageView *_imageView;
    UIButton *_loginBtn;
    UIButton *_subscriptionBtn;
    UIButton *_buyBtn;
    UIButton *_cancelBtn;
    UILabel *_tipLabel;
    KSModelMagzine *_magazine;
    
    id<KSNoPermissionAlertViewDelegate> _delegate;
}
@property(nonatomic, assign)id<KSNoPermissionAlertViewDelegate> delegate;

- (id)initWithFrame:(CGRect)frame magazine:(KSModelMagzine *)mag;
@end
