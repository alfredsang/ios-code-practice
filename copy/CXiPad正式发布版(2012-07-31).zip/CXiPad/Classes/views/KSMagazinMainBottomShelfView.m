//
//  KSMagazinMainBottomShelfView.m
//  CenturyWeeklyV2
//
//  Created by 广亮 高 on 12-6-8.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import "KSMagazinMainBottomShelfView.h"
#import "KSMagzineViewController.h"
#import "KSDownMagazineOperation.h"

static NSInteger lastIndex = 0;

@implementation KSMagazinMainBottomShelfItemView
@synthesize magazine = _magazine;
-(id)initWithFrame:(CGRect)frame controller:(id)controller
{
    self = [self initWithFrame:frame Magazine:nil controller:controller];
    {
        
    }
    return self;
}

-(id)initWithFrame:(CGRect)frame Magazine:(KSModelMagzine*)magazine controller:(id)controller
{
    self = [super initWithFrame:frame];
    if (self)
    {
        _controller = [controller retain];
        if (magazine)
        {
            _magazine = [magazine retain];

        }
        
//        _maskImagView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"shelf_item_mask.png"]];
//        _maskImagView.frame = CGRectMake(0, 0, self.width, self.height);
//        _maskImagView.hidden = YES;
//        [self addSubview:_maskImagView];
//        [_maskImagView release];
        
//        _progressView = [[KSShelfProgressView alloc] initWithFrame:CGRectMake(10, 70, 70, 40)];
//        [self refreshProgress:_magazine];
//        //[_progressView setBackgroundColor:[UIColor clearColor]];
//        [_progressView setTintColor:[UIColor colorWithRed:0.36 green:0.4 blue:0.5 alpha:1]];
//        [self addSubview:_progressView];
//        _progressView.hidden = YES;
//        if (magazine.rateDownload>0&&magazine.rateDownload<1)
//        {
//            _progressView.hidden = NO;
//        }
        [self loadMagazine:_magazine];
        

        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(selectMagazine)];
        [self addGestureRecognizer:tap];
        [tap release];
    }
    return self;
}
-(void)selectMagazine
{
    NSInteger index = (self.left-ITEM_MARGIN/2)/(ITEM_WIDTH+ITEM_MARGIN);

    KSModelMagzine *magaz = [KSModelMagzine loadById:_magazine.magzineId];
    if (_magazine)
    {
        RELEASE_SAFELY(_magazine);
    }
    _magazine = [magaz retain];
    [_controller selectBookShelfMagazineAtIndex:index magazine:_magazine];
    KSMagazinMainBottomShelfView *view = (KSMagazinMainBottomShelfView*)[self superview];
    [view autoChangePosition];
}



-(void)loadMagazine:(KSModelMagzine*)magazine
{

    KSDINFO(@"%d",magazine.magzineId);
    if (!magazine)
    {
        return ;
    }
    else 
    {
        if (_magazine)
        {
            RELEASE_SAFELY(_magazine);
        }
        _magazine = [magazine retain];
        UIImage *image = [UIImage imageWithContentsOfFile:magazine.cover_2]; 
        if (image)
        {
            self.image = image;
        }
        else 
        {
            self.image = [UIImage imageNamed:@"default_cover_225_290.png"];
        }
        [UIUtil showFadeInAnimation:self endAlpha:1];
    }
    UIImageView *unpurchased = (UIImageView*)[self viewWithTag:1111];

    if (unpurchased==nil)
    {
        unpurchased = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 22, 22)];
        unpurchased.center = CGPointMake(ITEM_WIDTH, 0);
        unpurchased.tag = 1111;
        [self addSubview:unpurchased];
        [unpurchased release];
    }


    if (![magazine isMybook])
    {
        unpurchased.image = [UIImage imageNamed:@"btn_lock.png"];
        unpurchased.hidden = NO;
    }
    else 
    {
        if (magazine.rateDownload!=1)
        {
            unpurchased.hidden = NO;
            unpurchased.image= [UIImage imageNamed:@"download.png"];
        }
        else 
        {
            unpurchased.hidden = YES;
        }
    }
    [self setUserInteractionEnabled:YES];
//    [self refreshProgress:magazine];

}
- (void)updateMagazine
{
//    _progressView.hidden = YES;
//    _magazine.isArticlesDownload = YES;
//    _maskImagView.hidden = YES;

    UIImageView *unpurchased = (UIImageView*)[self viewWithTag:1111];
    unpurchased.hidden = NO;
    if (unpurchased)
    {
        if (![_magazine isMybook])
        {
            unpurchased.image = [UIImage imageNamed:@"btn_lock.png"];
            
        }
        else 
        {
            if (_magazine.rateDownload!=1)
            {
                unpurchased.image= [UIImage imageNamed:@"download.png"];
            }
            else
            {
                unpurchased.hidden = YES;
            }
        }

    }

    
}

-(void)dealloc
{
    [_magazine release];
    [_controller release];
//    [_progressView release];
    [super dealloc];
}
@end




@implementation KSMagazinMainBottomShelfView

//@synthesize controller = _controller;

- (id)initWithFrame:(CGRect)frame controller:(id)controller
{
    self = [super initWithFrame:frame controller:controller];


    if (self) 
    {
        
//        _controller = [controller retain];

        self.contentSize = CGSizeMake(self.width , frame.size.height);
        self.delegate = self;
        self.showsVerticalScrollIndicator = NO;
        self.showsHorizontalScrollIndicator = NO;
        self.pagingEnabled = NO;
        [self reloadData];
        

    }
    return self;
}

-(void)dealloc
{
//    RELEASE_SAFELY(_controller);
    [super dealloc];
}


-(void)loadMagazineByYear:(NSMutableArray*)magazines
{
    if (_magzines)
    {
        [_magzines removeAllObjects];
        RELEASE_SAFELY(_magzines);
    }
    _magzines = [magazines retain];
    [self reloadDataWithMagazines:_magzines];
}

-(void)reloadDataWithMagazines:(NSMutableArray*)magazs
{
    self.contentSize = CGSizeMake( (ITEM_WIDTH+ITEM_MARGIN)*[magazs count] , self.height);
    for (int i = 0; i < [magazs count]; i++)
    {
        KSModelMagzine *magazine = [magazs objectAtIndex:i];

        KSMagazinMainBottomShelfItemView *item = (KSMagazinMainBottomShelfItemView*)[self viewWithTag:magazine.magzineId];
        if (item)
        {
            item.frame = CGRectMake(ITEM_MARGIN/2+(ITEM_WIDTH+ITEM_MARGIN)*i, 30, ITEM_WIDTH, 110);
            [item loadMagazine:magazine];
        }
        else 
        {
            item = [[KSMagazinMainBottomShelfItemView alloc] initWithFrame:CGRectMake(ITEM_MARGIN/2+(ITEM_WIDTH+ITEM_MARGIN)*i, 30, ITEM_WIDTH, 110) Magazine:magazine controller:_controller];
            item.tag = magazine.magzineId;
            item.userInteractionEnabled = YES;
            [self addSubview:item];
            [item release];
        }
        
        



    }

}
-(void)addToUsedCoverViews:(KSMagazinMainBottomShelfItemView*)item
{
    BOOL find = NO;
    for (KSMagazinMainBottomShelfItemView *itemView in _userdCoverViews)
    {
        if (itemView == item)
        {
            find = YES;
        }
    }
    if (!find)
    {
        [_userdCoverViews addObject:item];
    }
}
-(KSMagazinMainBottomShelfItemView*)getFormUsedCoverViews
{
    BOOL find = NO;
    NSArray *views = [self subviews];
    
    for (KSMagazinMainBottomShelfItemView *usedItem in _userdCoverViews)
    {
        for (KSMagazinMainBottomShelfItemView *usingItem in views)
        {
            if (usingItem == usedItem)
            {
                find = YES;
                break;
            }
            else
            {
                find = NO;
            }
        }
        if(!find)
        {
            return usedItem;
        }
    }
    
    return nil;
}
-(void)loadItemCoverView:(NSInteger)index
{
    if (index<0||index>=[_magzines count])
    {
        return;
    }
    KSModelMagzine *magazine = [_magzines  objectAtIndex:index];
    KSMagazinMainBottomShelfItemView *item = (KSMagazinMainBottomShelfItemView*)[self viewWithTag:magazine.magzineId];
    
    if (!item)
    {
        item = [self getFormUsedCoverViews];
        if (!item)
        {
            item = [[KSMagazinMainBottomShelfItemView alloc] initWithFrame:CGRectMake(ITEM_MARGIN/2+(ITEM_WIDTH+ITEM_MARGIN)*index, 30, ITEM_WIDTH, 110) Magazine:magazine controller:_controller];
//            item.centerX = self.centerX+self.width*index;
            item.tag = magazine.magzineId;
            [self addSubview:item];
            [item release];
            [self addToUsedCoverViews:item];
        }
        else
        {

            item.frame = CGRectMake(ITEM_MARGIN/2+(ITEM_WIDTH+ITEM_MARGIN)*index, 30, ITEM_WIDTH, 110);
            item.tag = magazine.magzineId;
            [item loadMagazine:magazine];
            [self addSubview:item];
        }
        
        
    }
    else
    {
        if (item.left != ITEM_MARGIN/2+(ITEM_WIDTH+ITEM_MARGIN)*index)
        {
            item.frame = CGRectMake(ITEM_MARGIN/2+(ITEM_WIDTH+ITEM_MARGIN)*index, 30, ITEM_WIDTH, 110);
            item.tag = magazine.magzineId;
            [item loadMagazine:magazine];
        }

    }
}

-(void)reloadData
{
    if (_magzines)
    {
        [_magzines removeAllObjects];
    }
    else {
        _magzines = [[NSMutableArray alloc] init];
    }
    [_magzines addObjectsFromArray:[_controller magzines]];
    NSInteger firstIndex =0;
    for (int i = 0; i<[_magzines count]; i++)
    {
        KSModelMagzine *magaz = [_magzines objectAtIndex:i];
        if (magaz.magzineId==[_controller currentMagzine].magzineId)
        {
            firstIndex = i;
            break;
        }
    }
     
    [self removeAllSubviews];
    self.contentSize = CGSizeMake((ITEM_WIDTH+ITEM_MARGIN)*[_magzines count], self.height);
//    self.contentOffset = CGPointMake((ITEM_WIDTH+ITEM_MARGIN)*firstIndex, self.contentOffset.y);
    if ([_magzines count]>6)
    {
        for (int i = 0; i<7; i++)
        {
            [self loadItemCoverView:i+firstIndex];
        }

    }
    else
    {
        for (int i = 0; i<[_magzines count]; i++)
        {
            [self loadItemCoverView:i];
        }
    }
    
    self.contentOffset = CGPointMake((ITEM_WIDTH+ITEM_MARGIN)*firstIndex, self.contentOffset.y);
    
//    if (_magzines)
//    {
//        [_magzines removeAllObjects];
//    }
//    else 
//    {
//        _magzines = [[NSMutableArray  alloc] init];
//    }
//    [_magzines addObjectsFromArray:[_controller magzines]];
//    if ([_magzines count]==0)
//    {
//        return;
//    }
//    [self reloadDataWithMagazines:_magzines];

}
#pragma mark -
-(void)whenMagzinePurchased:(NSInteger)magazineId
{
    for (KSMagazinMainBottomShelfItemView *itemView in [self subviews]) 
    {

        if (itemView.tag == magazineId)
        {
            UIImageView *unpurchased = (UIImageView*)[itemView viewWithTag:1111];

            if (unpurchased)
            {
                if ([_controller currentMagzine].isDownload)
                {
                    unpurchased.hidden = YES;
                }
                else 
                {
                    unpurchased.image= [UIImage imageNamed:@"download.png"];

                }
                
            }

        }
        
    }
      
}
- (void) whenInitOrMagzineListUpdate{
    [self reloadData];
}
- (void) whenMagzineDownloader:(NSInteger)magzineId{
    //    [self reloadData];
    //    return;
    
    KSMagazinMainBottomShelfItemView *itemView = (KSMagazinMainBottomShelfItemView *)[self viewWithTag:magzineId];
    if(!itemView)return;
//    itemView.magazine = [KSModelMagzine loadById:magzineId];
    [itemView loadMagazine:[KSModelMagzine loadById:magzineId]];

    dispatch_async(dispatch_get_global_queue(0, 0), ^{
    
        for (int i=0; i<_magzines.count; i++) 
        {
            KSModelMagzine *item = [_magzines objectAtIndex:i];
            if(item.magzineId ==magzineId) 
            {
                KSModelMagzine *m = [KSModelMagzine loadById:item.magzineId];
                [_magzines replaceObjectAtIndex:i withObject:m];
                break;
            }
        }
    });



}
- (void)whenMagzineCover0Download:(NSInteger)magzineId
{
    for (int i=0, n =_magzines.count; i<n; i++) 
    {
        KSModelMagzine *item = [_magzines objectAtIndex:i];
        
        if(item.magzineId!=magzineId)
            continue;


            
            KSMagazinMainBottomShelfItemView *itemView = (KSMagazinMainBottomShelfItemView*)[self viewWithTag:magzineId];
            if (itemView && [itemView isKindOfClass:[KSMagazinMainBottomShelfItemView class]])
            {
                [itemView loadMagazine:item];

            }




    }
}
- (void)whenMagzineDeleted:(KSModelMagzine *)magazine
{
    for (int i=0; i<_magzines.count; i++) 
    {
        KSModelMagzine *item = [_magzines objectAtIndex:i];
        if(item.magzineId == magazine.magzineId) 
        {
            KSModelMagzine *m = [KSModelMagzine loadById:item.magzineId];
            [_magzines replaceObjectAtIndex:i withObject:m];

            break;
        }
    }
    
    KSMagazinMainBottomShelfItemView *itemView = (KSMagazinMainBottomShelfItemView*)[self viewWithTag:magazine.magzineId];
    if (!itemView)
    {
        return;
    }
//    itemView.magazine = magazine;
    [itemView loadMagazine:magazine];
   
}
-(void)selectYear:(NSInteger)selectYear
{
    
    NSInteger row = 0;
    for (int i = 0; i<[_magzines count]; i++)
    {
        if ([[_magzines objectAtIndex:i] isKindOfClass:[KSModelMagzine class]])
        {
            KSModelMagzine *magazine = [_magzines objectAtIndex:i];
            NSDate *date = [NSDate dateWithTimeIntervalSince1970:magazine.pubDate];
            
            if ([DateUtil getYearByDate:date] == selectYear) 
            {
                row = i;
                break;
            }
            
        }
    }
    self.contentOffset = CGPointMake((ITEM_WIDTH+ITEM_MARGIN)*row, self.contentOffset.y);
//    [self loadSubViewsWithIndex:row];
}
-(void)loadSubViewsWithIndex:(NSInteger)page
{
//    if (page>=0&&page<[_magzines count])
//    {
        [self loadItemCoverView:page];
        [self loadItemCoverView:page+1];
        [self loadItemCoverView:page-1];
        [self loadItemCoverView:page+2];
        [self loadItemCoverView:page-2];
        [self loadItemCoverView:page+3];
        [self loadItemCoverView:page-3];
        [self loadItemCoverView:page+4];
        [self loadItemCoverView:page-4];
        [self loadItemCoverView:page+5];
        [self loadItemCoverView:page-5];
        [self loadItemCoverView:page+6];
        [self loadItemCoverView:page-6];
//    }
//    if (page+1<[_magzines count]&&page-1>=0)
//    {
        if (page-7>=0)
        {
            KSMagazinMainBottomShelfItemView *item = (KSMagazinMainBottomShelfItemView*)[self viewWithTag:[[_magzines objectAtIndex:page-7] magzineId]];
            if (item)
            {
                
                [item removeFromSuperview];
            }
            
        }
        if (page+7<[_magzines count])
        {
            KSMagazinMainBottomShelfItemView *item = (KSMagazinMainBottomShelfItemView*)[self viewWithTag:[[_magzines objectAtIndex:page+7] magzineId]];
            if (item)
            {
                [item removeFromSuperview];
            }
        }
        

//    }
}
#pragma UIScrollView
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    //    [_controller.main.bottomShelfView scrollViewDidScroll:scrollView];
    CGFloat pageWidth = ITEM_WIDTH+ITEM_MARGIN;
    int page = floor((scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    if (lastIndex == page || page<0 || page>[_magzines count]-1||[_magzines count]==0)
    {
        return;
    }
    [self loadSubViewsWithIndex:page];
    KSModelMagzine *magaz = [_magzines objectAtIndex:page];
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:magaz.pubDate];
    
    NSInteger currentYear = [[_controller.main.yearSeg currentYear] intValue];
    NSInteger magazineYear = [DateUtil getYearByDate:date];
    if (currentYear != magazineYear) 
    {
        NSString *yearStr = [[NSString alloc] initWithFormat:@"%d",magazineYear];
        NSInteger index = [_controller.main.yearSeg.titleArray indexOfObject:yearStr];
        [yearStr release];
        UIButton *btn = (UIButton*)[_controller.main.yearSeg viewWithTag:10+index];
        [_controller.main.yearSeg changeBtnWithAnimation:btn];
    }
    
    lastIndex = page;

    
}
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    //    [_controller.main.bottomShelfView scrollViewDidEndDecelerating:scrollView];
}
- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView
{
    KSDINFO(@"stop1111111111111111");
}
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self autoChangePosition];
       
}
-(void)autoChangePosition
{
    CGFloat width = ITEM_WIDTH+ITEM_MARGIN;
    NSInteger count = (self.contentOffset.x-width/2)/width;
    CGFloat distance = self.contentOffset.x - width*count;
    
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDuration:0.75];
    if(abs(distance)<=width/2)
    {
        self.contentOffset = CGPointMake(width*count, self.contentOffset.y);
    }
    else 
    {
        self.contentOffset = CGPointMake(width*(count+1), self.contentOffset.y);
    }
    [UIView commitAnimations];

}







@end