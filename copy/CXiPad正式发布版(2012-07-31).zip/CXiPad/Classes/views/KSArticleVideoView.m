//
//  KSArticleVideoView.m
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//
#import <MediaPlayer/MediaPlayer.h>
#import "KSArticleVideoView.h"

@implementation KSArticleVideoView

- (id)initWithFrame:(CGRect)frame url:(NSURL *)url full:(BOOL)full
{
    self = [super initWithFrame:frame];
    if (self) {
        _url = [url retain];
        _full = full;
        [self initSubviews];
    }
    return self;
}

- (void)dealloc{
    [_url release];
    [super dealloc];
}

- (void)showVideo {
    MPMoviePlayerViewController *player = [[KSMoviePlayerViewController alloc] initWithContentURL:_url];
    
    player.moviePlayer.scalingMode = MPMovieScalingModeNone;
    [[NSNotificationCenter defaultCenter] addObserver:self 
                                             selector:@selector(moviePlayBackDidFinish:) 
                                                 name:MPMoviePlayerPlaybackDidFinishNotification
                                               object:player.moviePlayer];
    
    //[self.viewController presentMoviePlayerViewControllerAnimated:player];
    IF_IOS5_OR_GREATER(
                       [self.viewController presentViewController:player animated:YES completion:^{
        [player.moviePlayer play];
    }];          
                       );
    IF_PRE_IOS5([self.viewController presentModalViewController:player animated:YES];);
    //- (void)dismissViewControllerAnimated: (BOOL)flag completion: (void (^)(void))completion
    
    //[self presentModalViewController:moviePlayerViewController animated:YES];
    [player.moviePlayer play];
    [player release];
}
- (void)initSubviews{
    [self performSelector:@selector(showVideo) withObject:nil afterDelay:0];
    
}
- (void)moviePlayBackDidFinish:(NSNotification *)notify {
    
    MPMoviePlayerController *theMovie = [notify object];
    [theMovie pause];
    [theMovie stop];
    
    //以特殊的方式解决
    IF_IOS5_OR_GREATER([self addSubview:theMovie.view];);
    
    NSError *error = [[notify userInfo] valueForKey:@"error"];
    if (error != nil){
        [UIUtil showMsgAlertWithTitle:@"提示" message:@"视频文件不存在或格式不支持"];
        KSDERROR(@"error=%@", error);
    }
    
    [[NSNotificationCenter defaultCenter] removeObserver:self 
                                                    name:MPMoviePlayerPlaybackDidFinishNotification 
                                                  object:theMovie];
    //[self dismissMoviePlayerViewControllerAnimated];
    [self.viewController dismissModalViewControllerAnimated:YES];
    IF_PRE_IOS5([self.viewController.view setNeedsLayout];);
    [self performSelector:@selector(dismissThis) withObject:nil afterDelay:0.1];
}
- (void)dismissThis {
    [[UIApplication sharedApplication] setStatusBarHidden:NO];
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
    [self removeFromSuperview];
}
- (void)layoutSubviews{
    if(_full){
    //		MPMoviePlayerViewController *moviePlayerViewController = [[MPMoviePlayerViewController alloc] initWithContentURL:nsURL];
    //		
    //		[[DataEnv sharedDataEnv].menuViewController presentMoviePlayerViewControllerAnimated:moviePlayerViewController];
    //		//[self presentModalViewController:moviePlayerViewController animated:YES];
    //		[moviePlayerViewController.moviePlayer play];
    //		[moviePlayerViewController release];
    }
}
@end

@implementation KSMoviePlayerViewController

- (void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration {
    if (UIInterfaceOrientationIsPortrait(toInterfaceOrientation)) {
        [[KSBootstrap dataCenter] setValue:@"0" forKey:@"orientation"];
    }else {
        [[KSBootstrap dataCenter] setValue:@"1" forKey:@"orientation"];
    }
    [super willRotateToInterfaceOrientation:toInterfaceOrientation duration:duration];
}

@end
