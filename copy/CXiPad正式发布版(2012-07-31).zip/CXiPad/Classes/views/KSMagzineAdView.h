//
//  KSMagzineAdView.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 1/28/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSWebViewController.h"

@class  KSMagzineMainView;
@interface KSMagzineAdView : UIView<UIWebViewDelegate,UIGestureRecognizerDelegate> {
    UIWebView *_webView;
    KSMagzineMainView *_handler;
    UITapGestureRecognizer *tap;
}
@property(nonatomic,assign) BOOL isShow;
@property(nonatomic,retain) NSString  *urlStr;
@property(nonatomic,retain) NSString  *imgStr;
@property(nonatomic,retain) UIWebView *webView;

- (id)initWithFrame:(CGRect)frame handler:(id)handler;
@end
