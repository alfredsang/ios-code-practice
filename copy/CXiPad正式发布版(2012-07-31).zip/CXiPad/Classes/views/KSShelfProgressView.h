//
//  KSShelfProgressView.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 4/17/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <KUIKit/KUIProgressView.h>
#import "KSModelMagzine.h"
#import "DDProgressView.h"

@interface KSShelfProgressView : UIView {
    DDProgressView *_progressView;
    UILabel *_progressTextLabel;
    KSModelMagzine *_magazine;
}
@property(nonatomic, retain)KSModelMagzine *magazine;
@property(nonatomic, retain)DDProgressView *progressView;
- (float)progress;
- (void)setTintColor:(UIColor *)aColor;
//- (void)setProgress:(CGFloat)progress animated:(BOOL)animated;
- (void)setProgress:(float)progress;
- (void)setOriginProgress:(float)progress;
-(void)startToDownLoad;
-(void)reStartToDownLoad;
@end
