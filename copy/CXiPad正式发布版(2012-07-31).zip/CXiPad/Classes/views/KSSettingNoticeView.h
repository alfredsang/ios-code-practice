//
//  KSSettingNoticeView.h
//  CenturyWeeklyV2
//
//  Created by jerry gao on 12-7-20.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CXDataRequest.h"

@interface KSSettingNoticeView : UIView<KSDataRequestDelegate,UITableViewDataSource,UITableViewDelegate>
{
    NSDictionary *_dataDic;
    NSMutableDictionary *_titleDic;
    NSMutableDictionary *_contentDic;
    UITableView *_theTabelView;
}
@end
