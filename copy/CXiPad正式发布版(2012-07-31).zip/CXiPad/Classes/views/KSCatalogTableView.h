//
//  KSCatalogTableView.h
//  CenturyWeeklyV2
//
//  Created by 广亮 高 on 12-6-19.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIColorAddition.h"

#define CELL_TEXT_NORMAL_COLOR  str2rgb(@"#373737")
#define CELL_TEXT_SELECT_COLOR  str2rgb(@"#a40000")
#define CELL_TEXT_COLOR  str2rgb(@"#898989")
#define CELL_TEXT_FONT  [UIFont boldSystemFontOfSize:16]

@class KSDirectoryMainView;
@interface KSCatalogTableView : UIView<UITableViewDelegate,UITableViewDataSource>
{
    UITableView     *_tableView;
    NSMutableArray  *_catalogArray;
    KSModelMagzine  *_magazine;
    NSInteger       _lastIndexRow;
    KSDirectoryMainView *_hander;
    BOOL            _isFirstLunch;
    UILabel *_label;
    UIView  *_view;
}
-(void)reloadData:(NSInteger)magazineId;
- (id)initWithFrame:(CGRect)frame magazine:(KSModelMagzine*)magazine hander:(id)hander;
@end
