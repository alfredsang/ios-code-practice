//
//  KSArticleListTabelView.h
//  CenturyWeeklyV2
//
//  Created by 广亮 高 on 12-6-19.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSCatalogTableView.h"

#define TOPIC_FONT  [UIFont boldSystemFontOfSize:14]
#define TITLE_FONT  [UIFont boldSystemFontOfSize:21]
#define SUMMARY_FONT  [UIFont boldSystemFontOfSize:14]

#define TITLE_COLOR             str2rgb(@"#373737")
#define SUMMARY_COLOR           str2rgb(@"#898989")
#define TITLE_GRAY_COLOR        str2rgb(@"#797979")


@interface KSArticleListTabelViewCell : UITableViewCell
{
    UILabel     *_topicLabel;
    UILabel     *_titleLabel;
    UILabel     *_summaryLabel;
    UIImageView *_titleImageView;
    UILabel     *_author;
}
@end

@interface KSArticleListTabelView : KSCatalogTableView
{
    
}

@property(nonatomic,assign) NSInteger currentCatalogId;

- (id)initWithFrame:(CGRect)frame magazine:(KSModelMagzine*)magazine hander:(id)hander;
-(void)reloadData:(NSInteger)catalogId;
@end
