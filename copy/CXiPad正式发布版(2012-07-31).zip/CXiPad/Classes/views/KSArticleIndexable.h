//
//  KSArticlePageView.h
//  CenturyWeeklyV2
//
//  Created by liuyou on 12-1-9.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol KSArticleIndexable <NSObject>
@required
- (NSInteger) getIndex;
@end
