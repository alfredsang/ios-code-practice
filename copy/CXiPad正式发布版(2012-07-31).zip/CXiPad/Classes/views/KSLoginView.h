//
//  KSLoginView.h
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-16.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSViewInitor.h"
#import "UIViewAdditions.h"
#import "KSIconButton.h"
#import "KSRegisterView.h"
#import "KSRegSuccView.h"
#import "KSRetrievePassView.h"
#import "CXDataRequest.h"

@class KSMagzineViewController;
@interface KSLoginView : UIView<KSViewInitor, KSDataRequestDelegate>{
    KSMagzineViewController *_handler;
    UIView *_containerView;
    
    UIView *login_bg;
    BOOL is_remember;
    UIButton *remember_pwd;
    UIButton *find_password;
    UIButton *register_user;
    UIButton *login;
    UITextField *user_name;
    UITextField *user_pwd;
    UILabel *err_msg;
    UIImageView *err_icon;
    KSRegisterView *register_view;
    NSString *reg_succ_email;

    NSInteger userId;
    
    KSRegSuccView *reg_succ_view;
    KSRetrievePassView *_retrievePassView;
    
    BOOL _isGiftcardUser;
    
    BOOL _hasSubscription;
}
- (id) initWithFrame:(CGRect)frame handler:(id)handler;
- (void) popView:(UIView *)view;

- (void) resetRememberPassword;

//显示注册界面
- (void)showRegFormView;
- (void)animateShowRegFormView;
//隐藏注册界面
- (void)animateDismissRegFormView;
//显示登录框界面
- (void)animateShowLoginFormView;
//隐藏登录框界面
- (void)animateDismissLoginFormView;
//显示注册成功界面
- (void) displayRegSuccView:(NSString *)email password:(NSString *)passwd;
//隐藏注册成功界面
- (void)dismissRegSuccView;
//显示找回密码界面
- (void)showRetrievePassView;
//隐藏找回密码界面
- (void)dismissRetrievePassView;

@end


