//
//  KSSettingQQWeiboTableCell.m
//  CenturyWeeklyV2
//
//  Created by zyk on 1/8/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KSSettingQQWeiboTableCell.h"
#import "SHK.h"
#import "SHKTencent.h"

@implementation KSSettingQQWeiboTableCell
@synthesize weiboBindBtn;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"kSHTencentAuthenticationFinished" object:nil];
    [weiboBindBtn release];
    [super dealloc];
}
- (IBAction)bindWeiboAccount:(id)sender {
    if (binded == YES) {
        [SHKTencent logout];
        binded = NO;
        [weiboBindBtn setTitle:@"绑定" forState:UIControlStateNormal];
    }else {
        [SHK currentHelper].rootViewController = self.viewController;
        SHKTencent *tencent = [[SHKTencent alloc] init];
        [tencent restoreAccessToken];
        [tencent promptAuthorization];
        //[SHKSina logout];
        [tencent release];
    }
}
- (void)awakeFromNib {
    if (loaded) {
        return;
    }
    loaded = YES;
    SHKTencent *tencent = [[SHKTencent alloc] init];
    if ([tencent isAuthorized]) {
        [weiboBindBtn setTitle:@"取消绑定" forState:UIControlStateNormal];
        binded = YES;
    }else {
        [weiboBindBtn setTitle:@"绑定" forState:UIControlStateNormal];
        binded = NO;
    }
    tencent.shareDelegate = nil;
    [tencent release];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeState:) name:@"kSHTencentAuthenticationFinished" object:nil];
}
- (void)changeState:(NSNotification *)notify {
    binded = YES;
    [weiboBindBtn setTitle:@"取消绑定" forState:UIControlStateNormal];
}

@end
