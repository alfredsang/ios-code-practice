//
//  KSHelpView.h
//  CenturyWeeklyV2
//
//  Created by 广亮 高 on 12-6-1.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "KSSettingView.h"

@interface KSHelpView : KSSettingView
{
//    KSMagzineViewController *_controller;
//    KSSettingHelpView       *_settingHelpView;
//    KSSettingAboutView      *_aboutView;
//    KSSettingFaqView        *_faqView;
//    
//    UIImageView             *_bgImageView;
//    UIImageView             *_popImageView;
}
- (id)initWithFrame:(CGRect)frame handler:(KSMagzineViewController *)handler;
@end
