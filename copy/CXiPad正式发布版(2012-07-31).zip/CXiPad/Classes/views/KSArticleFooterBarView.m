//
//  KSArticleFooterBarView.m
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "KSArticleFooterBarView.h"
//#import "UIImageExtras.h"
#import "KSArticleViewController.h"
#import "KSCatalogTipView.h"
#import "KSArticlePagesView.h"

@implementation KSArticleFooterBarView
@synthesize allLen = _allLen;
@synthesize handler = _handler;

- (id)initWithFrame:(CGRect)frame handler:(id)handler{
	if (self = [super initWithFrame:frame]) {
        _handler = handler;
		self.backgroundColor = [UIColor clearColor];
		self.autoresizingMask = UIViewAutoresizingFlexibleWidth;// | UIViewAutoresizingFlexibleTopMargin;
		[self initSubviews];
	}
	return self;
}

- (void)dealloc{
    [rulerView release];
    [lightRulerView release];
    [sanjiaoView release];
    [articleTitleNavView release];
    [articleTitleNavSummaryLabel release];
    [_movingLightView release];
    
    [super dealloc];
}

- (void) initSubviews{
    rulerView = [[UIImageView alloc] initWithFrame:CGRectMake(35, 17, 696, 3)];
    rulerView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    [self addSubview:rulerView];
    
    lightRulerView = [[UIImageView alloc] initWithFrame:CGRectMake(35, 17, 31, 3)];
    lightRulerView.image = [UIImage imageNamed:@"a_ruler_light.png"];
    [self addSubview:lightRulerView];
    
    _movingLightView = [[UIView alloc] initWithFrame:lightRulerView.frame];
    _movingLightView.backgroundColor = [UIColor darkGrayColor];
    [self addSubview:_movingLightView];
    _movingLightView.hidden = YES;
    
    sanjiaoView = [[UIImageView alloc] initWithFrame:CGRectMake(35, 20, 34, 30)];
    sanjiaoView.image = [UIImage imageNamed:@"a_sanjiao.png"];
    sanjiaoView.userInteractionEnabled = YES;
    [self addSubview:sanjiaoView];
    [sanjiaoView addGestureRecognizer:[[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panSanjiao:)] autorelease]];
    _translation = CGPointMake(0, 0);
//    articleTitleNavView = [[UIView alloc] initWithFrame:CGRectMake(0, 1024-157, 216, 123)];
//    articleTitleNavView.layer.borderColor = [UIColor redColor].CGColor;
//    articleTitleNavView.layer.borderWidth = 1;
//    articleTitleNavView.autoresizingMask = UIViewAutoresizingFlexibleTopMargin;
//    articleTitleNavView.backgroundColor = [UIColor clearColor];
//    articleTitleNavView.hidden = YES;
    
    articleTitleNavView = [[KSCatalogTipView alloc] initWithFrame:CGRectMake(0, 1024-157, 216, 123)];
    [self addSubview:articleTitleNavView];
    articleTitleNavView.hidden = YES;
    
//    [self addSubview:articleTitleNavView];
//    UIImageView *articleTitleNavBackground = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 216, 123)];
//    articleTitleNavBackground.image = [UIImage imageNamedNocache:@"a_kuang_bg.png"];
//    //[articleTitleNavView addSubview:articleTitleNavBackground];
//    articleTitleNavLabel = [[UILabel alloc] initWithFrame:CGRectMake(18, 15, 178, 36)];
//    articleTitleNavLabel.backgroundColor = [UIColor clearColor];
//    articleTitleNavLabel.font = yahei(14.0);
//    articleTitleNavLabel.numberOfLines = 2;
//    articleTitleNavLabel.baselineAdjustment = UIBaselineAdjustmentNone;
//    articleTitleNavLabel.text = @"";
//    [articleTitleNavView addSubview:articleTitleNavLabel];
//    articleTitleNavSummaryLabel = [[UILabel alloc] initWithFrame:CGRectMake(18, 51, 178, 44)];
//    articleTitleNavSummaryLabel.backgroundColor = [UIColor clearColor];
//    articleTitleNavSummaryLabel.font = [UIFont systemFontOfSize:12.0f];
//    articleTitleNavSummaryLabel.textColor = [UIColor colorWithWhite:0.2 alpha:1];
//    articleTitleNavSummaryLabel.numberOfLines = 3;
//    articleTitleNavSummaryLabel.text = @"";
//    [articleTitleNavView addSubview:articleTitleNavSummaryLabel];
}

- (KSModelArticle *) getArticle:(float)newleft{
    NSArray *articles = [_handler articles];
    float offsetX = newleft * _allLen;
    float newOffsetX = 0;
    KSModelArticle *articleNeedShow = nil;
    for (KSModelArticle *item in articles) {
        newOffsetX += MAX(ceil(item.contentLength/PAGE_CHAR_COUNT),1.0);
        if(newOffsetX>=offsetX){
            articleNeedShow = item;
            break;
        }
    }
    return articleNeedShow;
}
- (KSModelArticle *)getArticleById:(NSInteger)articelId {
    for (KSModelArticle *item in [_handler articles]) {
        if (item.articleId == articelId) {
            return item;
        }
    }
    return nil;
}
- (void) panSanjiao:(UIPanGestureRecognizer *)recognizer{
    if(recognizer.state == UIGestureRecognizerStateBegan){
        _dragging = YES;
        _handler.articlePageView.shouldLocateLastPage = NO;
        _movingLightView.hidden = NO;
        _lastCentX = sanjiaoView.centerX;
        _lastTranslation = _translation;
        sanjiaoView.width = 94;
        sanjiaoView.left -= 30;
        sanjiaoView.image = [UIImage imageNamed:@"a_sanjiao_dragging.png"];
        articleTitleNavView.frame = CGRectMake(0, 1024-157, 216, 123);
        if([UIUtil currentOrientation]==1){
            articleTitleNavView.frame = CGRectMake(0, 768-157, 216, 123);
        }
        [articleTitleNavView removeFromSuperview];
        [self.superview addSubview:articleTitleNavView];
        articleTitleNavView.hidden = NO;
        //articleTitleNavView.left = sanjiaoView.left - 10;
        _movingLightView.width = lightRulerView.width;
        _movingLightView.centerX = articleTitleNavView.pointerX = sanjiaoView.centerX;
        //[_handler resetHideTimer:NO];
    }
    else if (recognizer.state == UIGestureRecognizerStateChanged) { 
        _translation = [recognizer translationInView:recognizer.view];
        NSInteger width = 696;//, fullwidth = 768;
//        if([UIUtil currentOrientation]==1){
//            width = 952;
//            fullwidth = 1024;
//        }
        width = rulerView.width;
        sanjiaoView.left = MIN(MAX(_translation.x + _lightLeft*width + rulerView.left + _lightWidth * width/2 - 47.0f, rulerView.left - 47.0f), rulerView.right - 47.0f);
        articleTitleNavView.left = sanjiaoView.left - 10;
        articleTitleNavView.pointerX = sanjiaoView.centerX;
        
        float newLeft = _lightLeft + _lightWidth/2 + _translation.x/width;
        KSModelArticle *article = [self getArticle:newLeft];
        if(article){
            _articleId = article.articleId;
            //left需取前几篇的offset，不能随动
//            lightRulerView.left = newLeft*width + 35;
//            lightRulerView.width = (1.0*article.contentLength/900)/_allLen*width;
//            lightRulerView.image = [[UIImage imageNamed:@"a_ruler_light.png"] rescaleImageToSize:CGSizeMake(lightRulerView.width, lightRulerView.height)];
            articleTitleNavView.titleLabel.text = article.title;
            articleTitleNavView.summaryLabel.text = article.summary;
            articleTitleNavView.lockView.hidden = article.isFree || [_handler currentMagzine].isMybook;
//            articleTitleNavLabel.text = article.title;
//            articleTitleNavSummaryLabel.text = article.summary;
            _movingLightView.width = MAX(1.0*article.contentLength/PAGE_CHAR_COUNT,1.0)/_allLen * width;
            _movingLightView.centerX = sanjiaoView.centerX;
            [[_handler contentLengthOffsetArr] objectAtIndex:[_handler currentCatalogIndex]];
        }
    }
    else if(recognizer.state == UIGestureRecognizerStateEnded){
        _translation = [recognizer translationInView:recognizer.view];
        NSInteger width = 696;// fullwidth = 768;
//        if([UIUtil currentOrientation]==1){
//            width = 952;
//            //fullwidth = 1024;
//        }
        width = rulerView.width;
        _movingLightView.hidden = YES;
        sanjiaoView.left = MIN(MAX(_translation.x + _lightLeft*width + rulerView.left + _lightWidth * width/2 - 47.0f, rulerView.left - 47.0f), rulerView.right - 47.0f);
//        _translation = CGPointMake(0, 0);   
        sanjiaoView.width = 34;
        sanjiaoView.image = [UIImage imageNamed:@"a_sanjiao.png"];
        articleTitleNavView.hidden = YES;
        //float newLeft = _lightLeft + _lightWidth/2 + _translation.x/width;
        //KSModelArticle *article = [self getArticle:newLeft];
        KSModelArticle *article = [self getArticleById:_articleId];
        if (!article.isFree && ![_handler currentMagzine].isMybook) {
            sanjiaoView.centerX = _lastCentX;
            _translation = _lastTranslation;
            [_handler showNoPermissionView:[_handler currentMagzine] delegate:_handler];
        } else {
            [_handler gotoArticleId:article.articleId];
            //[_handler resetHideTimer:YES];
        }
        _dragging = NO;
    }
}
//高亮当前文章目录条
//_lightLeft当前目录条文章位置的起点，即当前滑动坐标的起点，为总页数的比率
//长度
- (void)lightRuler:(float)left width:(float)width{
    _lightLeft = left;
    _lightWidth = width;
    _translation = CGPointMake(0, 0);   
    [self setNeedsLayout];
}

- (void) layoutSubviews{
    NSInteger width = 696;
    if([UIUtil currentOrientation]==0){
        rulerView.image = [UIImage imageNamedNocache:@"a_ruler_v.png"];
    }else{
        width = 952;
        rulerView.image = [UIImage imageNamedNocache:@"a_ruler_h.png"];
    }
    if(!_dragging){
        sanjiaoView.image = [UIImage imageNamed:@"a_sanjiao.png"];
        sanjiaoView.width = 34;
        sanjiaoView.left = MIN(MAX(_translation.x + _lightLeft*width + rulerView.left + _lightWidth * width/2 - 17,rulerView.left - 17.0f),rulerView.right - 17.0f);
        //lightRulerView.frame = CGRectMake(_translation.x + _lightLeft*width + 35, 17, _lightWidth*width,3);
        lightRulerView.frame = CGRectMake(sanjiaoView.centerX - _lightWidth*width/2, 17, _lightWidth*width,3);
        //lightRulerView.image = [[UIImage imageNamed:@"a_ruler_light.png"] rescaleImageToSize:CGSizeMake(lightRulerView.width, lightRulerView.height)];
    }
}
@end
