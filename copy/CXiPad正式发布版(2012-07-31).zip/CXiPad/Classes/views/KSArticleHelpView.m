//
//  UIArticleHelpView.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 2/3/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "KSArticleHelpView.h"
#import "KSArticleViewController.h"

@implementation KSArticleHelpView

- (void)dealloc {
    [_tapableView release];
    [_helpView release];
    
    [super dealloc];
}
- (void)initSubviews {
    _tapableView = [[KSTapableView alloc] initWithFrame:self.bounds];
    _tapableView.tapDelegate = self;
    _tapableView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.7];
    [self addSubview:_tapableView];
    _helpView = [[[[NSBundle mainBundle] loadNibNamed:@"KSSettingHelpView" owner:self options:nil] objectAtIndex:0] retain];
    _helpView.backgroundColor = [UIColor whiteColor];
    _helpView.layer.cornerRadius = 5;
    [_tapableView addSubview:_helpView];
}
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [self initSubviews];
    }
    return self;
}
- (void)layoutSubviews {
    if ([UIUtil currentOrientation] == 0) {
        _helpView.frame = CGRectMake(0, 0, 418, 884);
        _helpView.center = CGPointMake(384, 512);
    } else {
        _helpView.frame = CGRectMake(0, 0, 448, 630);
        _helpView.center = CGPointMake(512, 384);
    }
}
#pragma mark - KSTapableDelegate
- (void)didTapped {
    [(KSArticleViewController *)self.viewController dismissHelpview];
}
@end
