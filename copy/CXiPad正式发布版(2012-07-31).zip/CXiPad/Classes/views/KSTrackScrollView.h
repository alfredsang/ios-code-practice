//
//  KSTrackScrollView.h
//  CenturyWeeklyV2
//
//  Created by 木参 傅 on 12-7-2.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KSTrackScrollView : UIScrollView

@end
