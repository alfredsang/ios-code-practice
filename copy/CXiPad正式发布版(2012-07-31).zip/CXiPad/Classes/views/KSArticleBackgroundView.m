//
//  KSArticleBackgroundView.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-28.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSArticleBackgroundView.h"

@implementation KSArticleBackgroundView
- (id) initWithFrame:(CGRect)frame{
    if(self=[super initWithFrame:frame]){
        self.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    }
    return self;
}
- (void) layoutSubviews{
    if([UIUtil currentOrientation]==0){
        self.image = [UIImage imageNamedNocache:@"a_bg_v.png"];
    }else{
        self.image = [UIImage imageNamedNocache:@"a_bg_h.png"];
    }
}
@end
