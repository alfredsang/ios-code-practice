//
//  KSArticleSearchTableCell.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 1/6/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSModelSearchItem.h"

@interface KSArticleSearchTableCell : UITableViewCell {
    KSModelSearchItem *_searchItem;
    UIImageView *_lockImageView;
    UILabel *_timeLabel;
    UILabel *_titleLabel;
    UILabel *_summaryTextLabel;
}
@property(nonatomic, retain)KSModelSearchItem *searchItem;
- (id)initWithSearchItem:(KSModelSearchItem *)item reuseIdentifier:(NSString *)reuseIdentifier;
@end
