//
//  KSRetrievePassView.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 12/29/11.
//  Copyright (c) 2011 KSMobile. All rights reserved.
//

#import "KSRetrievePassView.h"
#import "KSLoginView.h"

@implementation KSRetrievePassView
@synthesize mailTextField = _mailTextField;
@synthesize parent = _parent;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)awakeFromNib {
    _mailTextField.delegate = self;
    _indicatorView.hidden = YES;
    _mailTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
    _mailTextField.font = [UIFont systemFontOfSize:17.0f];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void)dealloc {
    [_mailTextField release];
    
    [_indicatorView stopAnimating];
    [_indicatorView release];
    [super dealloc];
}
#pragma mark -
- (void)showError:(UITextField *)textField msg:(NSString *)text {
    UILabel *label = (UILabel *)textField.rightView;
    if (!label) {
        label = [UIUtil newLabelWithFrame:CGRectZero text:text textColor:[UIColor redColor] font:[UIFont systemFontOfSize:16]];
        textField.rightView = label;
        [label release];
    }else {
        label.text = text;
    }
    [label sizeToFit];
    textField.rightViewMode = UITextFieldViewModeAlways;
    label.hidden = NO;
    //    textField.layer.borderColor = [[UIColor redColor] CGColor];
    //    textField.layer.borderWidth = 1.0f;
}

#pragma mark - actions
- (IBAction)dismiss:(id)sender {
    [CXRetrievePassDataRequest cancelRequest:NSStringFromClass([self class])];
    [_parent dismissRetrievePassView];
}

- (IBAction)doRetrieve:(id)sender {
    NSString *email = _mailTextField.text;
    if (!email || ![email length]) {
        [self showError:_mailTextField msg:@"邮箱不能为空  "];
        return;
    }
    if (![DataUtil validateEmail:email]) {
        [self showError:_mailTextField msg:@"邮箱不合法  "];
        return;
    }
    [CXRetrievePassDataRequest requestWithDelegate:self withParameters:[NSDictionary dictionaryWithObjectsAndKeys:email,@"email", nil] withCancelSubject:NSStringFromClass([self class])];
}

#pragma mark -
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 0) {
        
    } else if (buttonIndex == 1) {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://mail.%@",[_mailTextField.text substringFromIndex:[_mailTextField.text indexOf:@"@"]+1]]]];
    }
}
#pragma mark - UITextFieldDelegate
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    textField.rightView.hidden = YES;
    textField.rightViewMode = UITextFieldViewModeNever;
    return YES;
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    textField.rightView.hidden = YES;
    textField.rightViewMode = UITextFieldViewModeNever;
    return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

#pragma mark - KSDataRequestDelegate
- (void)requestDidStarted:(KSBaseDataRequest *)request {
    _indicatorView.hidden = NO;
    [_indicatorView startAnimating];
}
- (void)requestDidFinished:(KSBaseDataRequest *)request {
    _indicatorView.hidden = YES;
    [_indicatorView stopAnimating];
    
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:STR_FORMAT(@"找回密码的邮件已发送到您的邮箱%@", _mailTextField.text)  delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"登录邮箱",nil];
	[alertView show];
	[alertView release];
}
- (void)requestDidCanceled:(KSBaseDataRequest *)request {
    _indicatorView.hidden = YES;
    [_indicatorView stopAnimating];
}
- (void)requestDidFailed:(KSBaseDataRequest *)request withError:(NSError*)error {
    _indicatorView.hidden = YES;
    [_indicatorView stopAnimating];
    request.useSilentAlert = NO;
}
@end
