//
//  KSSettingMarkView.h
//  CenturyWeeklyV2
//
//  Created by 广亮 高 on 12-5-17.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KSSettingMarkView : UIView

@end
