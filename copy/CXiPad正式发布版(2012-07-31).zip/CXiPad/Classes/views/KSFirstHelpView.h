//
//  KSFirstHelpView.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 2/2/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KSPageView.h"
#import "KSPageViewController.h"

@interface KSFirstHelpView : KSPageView {
    UIButton *_skipButton;
    KSPageViewController    *_pageViewController;
}

//- (void)loadScrollViewWithPage:(NSInteger)page;
@end
