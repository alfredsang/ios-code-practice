//
//  KSSettingFontView.m
//  CenturyWeeklyV2
//
//  Created by zyk on 12/22/11.
//  Copyright (c) 2011 KSMobile. All rights reserved.
//

#import "KSSettingFontView.h"
#import "KSGetMagzineListOperation.h"
#import "KSMagzineViewController.h"

@implementation KSSettingFontView

- (void)dealloc {
    [_fontSizeLabel release];
    [_fileSizeLabel release];
    [_indicator release];
    
    
    _clearOperation.delegate = nil;
    [_clearOperation cancel];
    RELEASE_SAFELY(_clearOperation);
    
    _calOperation.delegate = nil;
    [_calOperation cancel];
    RELEASE_SAFELY(_calOperation);
    
    [super dealloc];
}
- (void)loadSubViews {
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(30, 54, 62, 20)];
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont systemFontOfSize:15.0f];
    label.text = @"默认字体";
    label.tag = 1010;
    [self addSubview:label];
    [label release];
    
    UISlider *slider = [[UISlider alloc] initWithFrame:CGRectMake(116, 53, 210, 23)];
    slider.tag = 1011;
    slider.maximumValue = 36;
    slider.minimumValue = 12;
    slider.value = [_fontSize floatValue];
    [self addSubview:slider];
    [slider release];
    [slider addTarget:self action:@selector(saveDefFont:) forControlEvents:UIControlEventTouchUpInside|UIControlEventTouchDragExit];
    [slider addTarget:self action:@selector(changeDefFont:) forControlEvents:UIControlEventValueChanged];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(339, 54, 62, 20)];
    label.backgroundColor = [UIColor clearColor];
    label.tag = 1012;
    label.text = _fontSize;
    label.font = [UIFont systemFontOfSize:15.0f];
    [self addSubview:label];
    [label release];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(30, 123, 62, 20)];
    label.backgroundColor = [UIColor clearColor];
    label.tag = 1013;
    label.font = [UIFont systemFontOfSize:15.0f];
    label.text = @"已用空间";
    [self addSubview:label];
    [label release];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(120, 123, 62, 20)];
    label.backgroundColor = [UIColor clearColor];
    label.tag = 1014;
    label.font = [UIFont systemFontOfSize:15.0f];
    label.text = _fileSize;
    [self addSubview:label];
    [label release];
    
    _indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    _indicator.center = label.center;
    [self addSubview:_indicator];
    [_indicator startAnimating];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(30, 150, 62, 20)];
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont systemFontOfSize:15.0f];
    label.text = @"字体预览";
    label.tag = 1016;
    [self addSubview:label];
    [label release];
    
    _textTipLabel = [[UILabel alloc] initWithFrame:CGRectMake(116, 0, 200, 80)];
    _textTipLabel.textAlignment = UITextAlignmentLeft;
    _textTipLabel.text = @"新世纪";
    _textTipLabel.font = [UIFont systemFontOfSize:[_fontSize floatValue]];
    _textTipLabel.backgroundColor = [UIColor clearColor];
    [self addSubview:_textTipLabel];
    
    UIButton *cleanBtn = [[UIButton alloc] initWithFrame:CGRectMake(196, 119, 84, 28)];
    cleanBtn.tag = 1015;
    cleanBtn.titleLabel.font = [UIFont systemFontOfSize:15.0f];
    [cleanBtn setBackgroundImage:[UIImage imageNamed:@"btn_com.png"] forState:UIControlStateNormal];
    [cleanBtn setTitle:@"立即清理" forState:UIControlStateNormal];
    [cleanBtn addTarget:self action:@selector(cleanDisk:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:cleanBtn];
    [cleanBtn release];
    
    [self viewWithTag:1010].frame = CGRectMake(30, 124, 62, 20);         //默认字体
    [self viewWithTag:1011].frame = CGRectMake(116, 123, 210, 23);       //UISlider
    
    [self viewWithTag:1012].frame = CGRectMake(339, 124, 62, 20);        //fontSize
    
    [self viewWithTag:1013].frame = CGRectMake(30, 53, 62, 20);        //已用空间
    [self viewWithTag:1014].frame = CGRectMake(120, 53, 62, 20);       //fileSize
    [self viewWithTag:1015].frame = CGRectMake(196, 49, 84, 28);       //立即清理
    [self viewWithTag:1016].frame = CGRectMake(30, 175, 84, 28);       //字体预览
    _textTipLabel.frame = CGRectMake(116, 150, 200, 80);
    _indicator.center = [self viewWithTag:1014].center;
    
    _calOperation = [[KSCalculateFileSizeOperation alloc] initWithDirectory:KSPathForDocumentsResource(@"")];
    _calOperation.delegate = self;
    NSOperationQueue *operationQueue = [[[NSOperationQueue alloc] init] autorelease];
    [operationQueue addOperation:_calOperation];
    
}

- (void)initData {
    _fontSize = [KSDB stringForKey:@"KEY_DEFAULT_FONT_SIZE"];
    if (_fontSize == nil) {
        _fontSize = @"18.0";
    }
    _fileSize = @"";//[DataUtil getHRFolderSize:KSPathForDocumentsResource(@"")];
}

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self initData];
        [self loadSubViews];
    }
    return self;
}
- (void)layoutSubviews {
//    if ([UIUtil currentOrientation]==0) {


//    } else {
//        [self viewWithTag:1010].frame = CGRectMake(64, 124, 62, 20);
//        [self viewWithTag:1011].frame = CGRectMake(196, 123, 210, 23);
//        [self viewWithTag:1012].frame = CGRectMake(418, 124, 62, 20);
//        [self viewWithTag:1013].frame = CGRectMake(64, 53, 62, 20);
//        [self viewWithTag:1014].frame = CGRectMake(196, 53, 62, 20);
//        [self viewWithTag:1015].frame = CGRectMake(282, 49, 84, 28);
//        [self viewWithTag:1016].frame = CGRectMake(64, 175, 84, 28);       //字体预览
//        
//        _textTipLabel.frame = CGRectMake(196, 150, 200, 80);
//    }
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/
#pragma mark -
- (void)doCleanDisk {
    [UIUtil showProcessIndicatorWithView:self.viewController.view atPoint:self.viewController.view.center hasMask:YES];
    _clearOperation = [[KSClearFilesOperation alloc] initWithDirectory:KSPathForBundleResource(@"")];
    _clearOperation.delegate = self;
    [[KSBootstrap operationQueue] addOperation:_clearOperation];
}
- (void)cleanDisk:(id)sender {
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:@"立即清理将删除所有文杂志的文章数据，确定清理？" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    [alertView show];
    [alertView release];
}
- (void)changeDefFont:(id)sender {
    CGFloat s = ((UISlider *)[self viewWithTag:1011]).value;
    ((UILabel *)[self viewWithTag:1012]).text = [NSString stringWithFormat:@"%.0f", s];
    _textTipLabel.font = [UIFont systemFontOfSize:s];
}
- (void)saveDefFont:(id)sender {
    CGFloat s = ((UISlider *)[self viewWithTag:1011]).value;
    ((UILabel *)[self viewWithTag:1012]).text = [NSString stringWithFormat:@"%.0f", s];
    _textTipLabel.font = [UIFont systemFontOfSize:s];
    [KSDB saveString:((UILabel *)[self viewWithTag:1012]).text forKey:KEY_DEFAULT_FONT_SIZE];
}

#pragma mark - UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 1) {
        [self doCleanDisk];
    }
}

#pragma mark - KSCalculateFileSizeOperationDelegate
- (void)didCalculated:(NSString *)filesize {
    [(UILabel *)[self viewWithTag:1014] setText:filesize];
    [_indicator stopAnimating];
    _indicator.hidden = YES;
}

#pragma mark - KSClearFilesOperationOperationDelegate
- (void)didCleared {
    [(KSMagzineViewController *)self.viewController storageCleaned];
    //[((KSMagzineViewController *)self.viewController).main.bookshelf reloadData];
    //[((KSMagzineViewController *)self.viewController).main.coverflow dropAndLoadCoverflow];
    
    [UIUtil hideProcessIndicatorWithView:self.viewController.view];
    
//    [UIUtil showMsgAlertWithTitle:@"提示" message:@""];
    [_indicator startAnimating];
    _indicator.hidden = NO;
    if (_calOperation) {
        [_calOperation cancel];
        [_calOperation release];
        _calOperation = nil;
    }
    _calOperation = [[KSCalculateFileSizeOperation alloc] initWithDirectory:KSPathForDocumentsResource(@"")];
    _calOperation.delegate = self;
    NSOperationQueue *operationQueue = [[[NSOperationQueue alloc] init] autorelease];
    [operationQueue addOperation:_calOperation];
    
    RELEASE_SAFELY(_clearOperation);
}
@end


@implementation KSCalculateFileSizeOperation
@synthesize delegate = _delegate;

- (id)initWithDirectory:(NSString *)dir {
    self = [super init];
    if (self) {
        _directory = [dir retain];
    }
    return self;
}
- (void)dealloc{
    [_directory release];
    [super dealloc];
}

- (void)main{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    NSString *filesize = [DataUtil getHRFolderSize:_directory];
    if ([_delegate respondsToSelector:@selector(didCalculated:)]) {
        [_delegate didCalculated:filesize];
    }
    [pool release];
}

@end



@implementation KSClearFilesOperation
@synthesize delegate = _delegate;

- (id)initWithDirectory:(NSString *)dir {
    self = [super init];
    if (self) {
        _directory = [dir retain];
    }
    return self;
}
- (void)dealloc{
    [_directory release];
    [super dealloc];
}

- (void)main{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    
    NSFileManager *fileManager = [[NSFileManager alloc] init];
    NSArray *fileList = [fileManager contentsOfDirectoryAtPath:[KSBootstrap root] error:nil];
    for (NSString *filePath in fileList) {
        if ([filePath hasSuffix:@".tmp"]||[filePath hasSuffix:@".zip"]) {
            [fileManager removeItemAtPath:[[KSBootstrap root] stringByAppendingFormat:@"/%@",filePath] error:nil];
        }
    }
    [fileManager release];
    
    //NSString *filesize = [DataUtil getHRFolderSize:_directory];
    NSArray *magzineList = [KSModelMagzine magzines];
//#if IS_TEST_ENV
//    FMResultSet *rs = [[KSDB db] executeQuery:@"select magzine_id from magzines where is_purchased=1"];
//    NSMutableArray *tmp = [[NSMutableArray alloc] init];
//    while (rs.next) {
//        NSDictionary *dict = [rs resultDict];
//        [tmp addObject:[NSNumber numberWithInt: DICT_INTVAL(dict, @"magzine_id")]];
//    }
//    [rs close];
//    [[KSBootstrap dataCenter] setValue:tmp forKey:@"KEY_PURCHASED_MAGAZINES"];
//    [tmp release];
//#endif
    
    for (KSModelMagzine *magzine in magzineList) {
//#if IS_TEST_ENV
//        [magzine remove:YES];
//        
//#else
        if(magzine.downloadArticlesNumber<=0)continue;
        [magzine remove:NO];
//#endif
    }
//#if IS_TEST_ENV
//    KSGetMagzineListOperation *operGetMagzineList = [[KSGetMagzineListOperation alloc] init];
//    [[KSBootstrap operationQueue] addOperation:operGetMagzineList];
//    [operGetMagzineList release];
//#endif
//    
    if ([_delegate respondsToSelector:@selector(didCalculated:)]) {
        [_delegate didCleared];
    }
    [pool release];
}

@end
