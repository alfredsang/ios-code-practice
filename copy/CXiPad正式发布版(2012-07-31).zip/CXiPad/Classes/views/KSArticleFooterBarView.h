//
//  KSArticleFooterBarView.h
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSViewInitor.h"
#import "KSIconButton.h"
#import "KSCatalogTipView.h"

@class KSArticleViewController;
@interface KSArticleFooterBarView : UIView<KSViewInitor>{
    UIImageView *rulerView;
    UIImageView *lightRulerView;
    UIView *_movingLightView;
    UIImageView *sanjiaoView;
    float _lightLeft;
    float _lightWidth;
    CGFloat _lastCentX;
    NSInteger _articleId;
    BOOL _dragging;
    CGPoint _translation;
    CGPoint _lastTranslation;
    KSArticleViewController *_handler;
    UILabel *articleTitleNavLabel;
    UILabel *articleTitleNavSummaryLabel;
    KSCatalogTipView *articleTitleNavView;
}
@property(nonatomic, assign)KSArticleViewController *handler;
@property(nonatomic) NSInteger allLen;

- (id) initWithFrame:(CGRect)frame handler:(KSArticleViewController*)handler;
- (void) lightRuler:(float)left width:(float)width;
@end
