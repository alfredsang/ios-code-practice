//
//  KSSettingFontView.h
//  CenturyWeeklyV2
//
//  Created by zyk on 12/22/11.
//  Copyright (c) 2011 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol KSClearFilesOperationOperationDelegate <NSObject>
@required
- (void)didCleared;

@end

@interface KSClearFilesOperation : NSOperation {
    NSString *_directory;
    id<KSClearFilesOperationOperationDelegate> _delegate;
}
@property(nonatomic, assign)id<KSClearFilesOperationOperationDelegate> delegate;

- (id)initWithDirectory:(NSString *)dir;
@end

//==========================================================
#pragma mark -
@protocol KSCalculateFileSizeOperationDelegate <NSObject>
@required
- (void)didCalculated:(NSString *)filesize;

@end

@interface KSCalculateFileSizeOperation : NSOperation {
    NSString *_directory;
    id<KSCalculateFileSizeOperationDelegate> _delegate;
}
@property(nonatomic, assign)id<KSCalculateFileSizeOperationDelegate> delegate;

- (id)initWithDirectory:(NSString *)dir;
@end

//==========================================================
@interface KSSettingFontView : UIView<KSClearFilesOperationOperationDelegate,KSCalculateFileSizeOperationDelegate> {
    UILabel *_fontSizeLabel;
    UILabel *_fileSizeLabel;
    
    UILabel *_textTipLabel;
    
    NSString *_fontSize;
    NSString *_fileSize;
    
    UIActivityIndicatorView *_indicator;
    
    KSCalculateFileSizeOperation *_calOperation;
    KSClearFilesOperation *_clearOperation;
}

@end




