//
//  KSArticleEmptyPageView.h
//  CenturyWeeklyV2
//
//  Created by liuyou on 12-1-2.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSViewInitor.h"
#import "KSArticleIndexable.h"

@interface KSArticleEmptyPageView : UIView<KSViewInitor, KSArticleIndexable>{
    NSInteger _index;
}

- (id)initWithFrame:(CGRect)frame index:(NSInteger)index;
@end
