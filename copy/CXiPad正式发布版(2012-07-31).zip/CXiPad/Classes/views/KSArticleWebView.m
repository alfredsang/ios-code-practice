//
//  KSArticleWebView.m
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSArticleWebView.h"

@implementation KSArticleWebView
- (id)initWithFrame:(CGRect)frame article:(KSModelArticle *)article hanlder:(KSArticleViewController *)handler index:(NSInteger)index
{
    self = [super initWithFrame:frame];
    if (self) {
        _article = [article retain];
        _handler = handler;
        _index = index;
        [self initSubviews];
    }
    return self;
}
- (id)initWithFrame:(CGRect)frame article:(KSModelArticle *)article hanlder:(KSArticleViewController *)handler child:(BOOL)isChild
{
    self = [super initWithFrame:frame];
    if (self) {
        _article = [article retain];
        _handler = handler;
        _isChildren = isChild;
        [self initSubviews];
    }
    return self;
}

- (void)dealloc{
    RELEASE_SAFELY(_article);
    _webView.delegate = nil;
    [_webView stopLoading];
    RELEASE_SAFELY(_webView);
    [pinchGestureRecognizer release];
    [fontScaleLbl release];
    [super dealloc];
}

- (void)initSubviews{
    _webView = [[UIWebView alloc] initWithFrame:self.bounds];
    _webView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    _webView.delegate = self;
    _webView.dataDetectorTypes = UIDataDetectorTypeNone;
    _webView.scalesPageToFit = YES;
    _webView.backgroundColor = [UIColor clearColor];
    ((UIScrollView*)[_webView.subviews objectAtIndex:0]).backgroundColor = [UIColor clearColor];
    ((UIScrollView*)[_webView.subviews objectAtIndex:0]).showsHorizontalScrollIndicator = NO;
    ((UIScrollView*)[_webView.subviews objectAtIndex:0]).bounces = NO;
    if (_index == 0 && !_isChildren) {//对封面编码
        ((UIScrollView*)[_webView.subviews objectAtIndex:0]).scrollEnabled = NO;
    } else {
        ((UIScrollView*)[_webView.subviews objectAtIndex:0]).scrollEnabled = _article.scrollable;
    }
    ((UIScrollView*)[_webView.subviews objectAtIndex:0]).pagingEnabled = _article.pageable;
    [self addSubview:_webView];
    
}

- (void)layoutSubviews{
    [_webView stopLoading];
    [self loadPage];
    if([UIUtil currentOrientation]==0){
    }else{
        
    }
}


- (void)loadPage {
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    NSString *filePath = [_article htmlFile:[UIUtil currentOrientation]];
    KSDINFO(@"%@", filePath);
    [_webView loadRequest:[NSURLRequest requestWithURL:[NSURL fileURLWithPath:filePath]]];
    [pool release];
}

- (BOOL)isExternalURL:(NSString *)url {
	if ([[url substringToIndex:5] isEqualToString:@"file:"]|| [url isEqualToString:@"about:blank"]) {
		return NO;
	}
	if ([url length] > 24 && [[url substringToIndex:24] isEqualToString:@"http://ipadcms.caing.com"]) {
		return NO;
	}
    if ([url length] > 25 && [[url substringToIndex:25] isEqualToString:@"http://ipadcms.caixin.com"]) {
		return NO;
	}
    if ([url length] > 25 && [[url substringToIndex:25] isEqualToString:@"http://ipadtest.caing.com"]) {
		return NO;
	}
	return YES;
}
#pragma mark UIWebViewDelegate
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
	NSString *requestURL = [[request URL] absoluteString];
	//NSLog(@"%d: requestURL:%@",(globalPage-pagesView.pageControl.currentPage),requestURL);
	if( [requestURL rangeOfString:@"#showvideos"].length>0 ){
		[_handler showArticleVideo:_article.articleId full:NO];
		return NO;
	}else if( [requestURL rangeOfString:@"#showimages"].length>0 ){
		[_handler showArticleSlide:_article.articleId];
		return NO;
	} else if ([requestURL rangeOfString:@"#showfullscreenvideo"].length > 0) {
		//[_handler showArticleVideo:_article.articleId full:YES];
        [_handler showArticleVideo:_article.articleId vIndex:0 full:YES];
		return NO;
    } else if ([requestURL rangeOfString:@"#showfullvideo1"].length > 0) {
		//[_handler showArticleVideo:_article.articleId full:YES];
        [_handler showArticleVideo:_article.articleId vIndex:0 full:YES];
		return NO;
    } else if ([requestURL rangeOfString:@"#showfullvideo2"].length > 0) {
            //[_handler showArticleVideo:_article.articleId full:YES];
            [_handler showArticleVideo:_article.articleId vIndex:2 full:YES];
            return NO;
    } else if ([requestURL rangeOfString:@"#showfullvideo3"].length > 0) {
        //[_handler showArticleVideo:_article.articleId full:YES];
        [_handler showArticleVideo:_article.articleId vIndex:3 full:YES];
        return NO;
	} else if ([requestURL rangeOfString:@"#showpertain2"].length > 0 && !_isChildren) {
		[self showPertain];
		return NO;
	}else if ([self isExternalURL:requestURL]) {
		[self openExternalWebView:requestURL];
		return NO;
	}
    
    //目录页的跳转
    NSRange range = [requestURL rangeOfString:@"article_id=" options:NSCaseInsensitiveSearch];
    if( range.location>0 && range.length>0 ){
        NSString *articleId = [requestURL substringFromIndex:(range.location+range.length)];
        NSRange newRange = [articleId rangeOfCharacterFromSet:[NSCharacterSet characterSetWithCharactersInString:@"&"]];
        articleId = [articleId substringToIndex:newRange.location];
        //如果没有权限 不跳转直接返回
        if (![_handler articleById:[articleId intValue]]) {
            [_handler showNoPermissionView:[_handler currentMagzine] delegate:_handler];
            return NO;
        }
        //定位到该文章
        //[_handler gotoArticleFromCatalog:[articleId intValue]];
        [_handler performSelector:@selector(gotoArticleFromCatalog:) withObject:articleId afterDelay:0.1];
         return NO;
    }
	
	return YES;
}

- (void)webViewDidFinishLoad:(UIWebView *)webView{
	((UIScrollView*)[webView.subviews objectAtIndex:0]).contentSize = CGSizeMake(self.bounds.size.width, ((UIScrollView*)[webView.subviews objectAtIndex:0]).contentSize.height-5);
}

- (void)openExternalWebView:(NSString *)url{
	if ( [[url substringToIndex:10] isEqualToString:@"itms-apps:"]) {//打开itunes
		[[UIApplication sharedApplication] openURL:[NSURL URLWithString:url]];
        
	}else {//打开内置浏览器
        [KSWebViewController presentWithURL:url inController:_handler];
	}
}

- (void)slideshow{
    [_handler showArticleSlide:_article.articleId];
}

- (void)showFullScreenVideo{
	//NSURL *nsURL;
    NSString *url = _article.videoSrc;
    if ([url rangeOfString:@"http:"].length<=0) {
        url = STR_FORMAT(@"%@/%@", [KSModelArticle articlePath:_article.articleId magzineId:_article.magzineId], url);
        //nsURL = [NSURL fileURLWithPath:url];
    }else {
        //nsURL = [NSURL URLWithString:url];
    }
}

- (void)showPertain {
    [_handler showChildArticles:_article];
}

- (void)showVideo{
	CGFloat imageWidth = 0;
	CGFloat imageHeight = 0;
	if( [UIUtil currentOrientation] == 0 ){
		imageWidth = 600;
		imageHeight = 800;
	}else{
		imageWidth = 800;
		imageHeight = 600;
	}
	KSArticleVideoView *videoView= [[KSArticleVideoView alloc] initWithFrame:CGRectMake(0, 0, imageWidth, imageHeight)];
    [self addSubview:videoView];
    [videoView release];
}
- (NSInteger) getIndex{
    return _index;
}

#pragma mark -
- (void)locateToLastPage {
    UIScrollView *sv = (UIScrollView *)[_webView.subviews objectAtIndex:0];
    [sv setContentOffset:CGPointMake(sv.contentSize.width-sv.width, 0) animated:NO];
    [_webView stringByEvaluatingJavaScriptFromString:@"locateToLastPage();"];
}

- (void)locateToFirstPage {
    UIScrollView *sv = (UIScrollView *)[_webView.subviews objectAtIndex:0];
    [sv setContentOffset:CGPointMake(0, 0) animated:NO];
    [_webView stringByEvaluatingJavaScriptFromString:@"locateToFirstPage();"];
}
@end
