//
//  KSCaixinCommentTableViewCell.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 2/10/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KSCaixinCommentTableViewCell.h"

@implementation KSCaixinCommentTableViewCell
@synthesize comment = _comment;

- (NSString *)calTimeString {
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:_comment.postTime];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
	[formatter setDateFormat:@"yyyy年MM月dd日 HH时mm分"];
	NSString *str = [formatter stringFromDate:date];
    
	[formatter release];
    
    
    return str;
    
}

- (void)dealloc {
    [_comment release];
    [_timeLabel release];
    [super dealloc];
}
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}
- (id)initWithComment:(KSModelComment *)mcomment reuseIdentifier:(NSString *)reuseIdentifier {
    self = [self initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:reuseIdentifier];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        _comment = [mcomment retain];
        
        self.textLabel.text = _comment.author;
        self.textLabel.font = [UIFont systemFontOfSize:15.0f];
        self.textLabel.textColor = [UIColor grayColor];
        
        //CGSize textLabelSize = [self.textLabel.text sizeWithFont:self.textLabel.font];
        //self.textLabel.width = textLabelSize.width;
        
        self.detailTextLabel.text = _comment.content;
        self.detailTextLabel.textColor = [UIColor blackColor];//[UIColor colorWithWhite:0.27 alpha:1];
        self.detailTextLabel.font = [UIFont systemFontOfSize:16.0f];
        self.detailTextLabel.numberOfLines = 0;
        //CGSize size = [summary.newsInfo sizeWithFont:[UIFont systemFontOfSize:14] constrainedToSize:CGSizeMake(contentWidth, 3) lineBreakMode:UILineBreakModeWordWrap]
        
        _timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.width - 250, 16, 240, 20)];
        _timeLabel.textColor = [UIColor grayColor];//[UIColor colorWithRed:0xAF/255.0f green:0xAE/255.0f blue:0xAA/255.0f alpha:1];
        _timeLabel.textAlignment = UITextAlignmentRight;
        _timeLabel.backgroundColor = [UIColor clearColor];
        _timeLabel.font = [UIFont systemFontOfSize:12.0f];
        _timeLabel.text = [self calTimeString];
        [self.contentView addSubview:_timeLabel];
        
        self.accessoryType = UITableViewCellAccessoryNone;
        
        
    }
    return self;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}
- (void)layoutSubviews {
    [super layoutSubviews];
    self.textLabel.frame = CGRectMake(20, 12, self.width-40, 27);
    
    CGSize titleSize = [self.detailTextLabel.text sizeWithFont:self.detailTextLabel.font constrainedToSize:CGSizeMake(self.width-40, MAXFLOAT) lineBreakMode:UILineBreakModeWordWrap];
    CGFloat h = titleSize.height > 30 ? titleSize.height:30;
    self.detailTextLabel.frame = CGRectMake(20, 40, self.width - 40.0f, h);
    //[self.detailTextLabel alignTop];
    _timeLabel.right = self.width - 10.0f;
    //self.height = h + 40.0f;
}
- (void)setComment:(KSModelComment *)comment {
    if (comment != _comment) {
        [_comment release];
        _comment = [comment retain];
        
        self.textLabel.text = _comment.author;
        self.detailTextLabel.text = _comment.content;
        _timeLabel.text = [self calTimeString];
        [self setNeedsLayout];
    }
}
@end
