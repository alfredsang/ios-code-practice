//
//  KSMagzineMainView.h
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-10.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSViewInitor.h"
#import "KSMagazineSecondAdView.h"
#import <KUIKit/KSProgressView.h>
#import "KSMagazineCoverView.h"
#import "KSMagazinMainBottomShelfView.h"
#import "KSNavigationSegBtnView.h"
#import "DDProgressView.h"

#define MARGIN  50
#define BTN_NORMAL_COLOR        str2rgb(@"#7d7d7d")
#define BTN_HIGHT_COLOR         str2rgb(@"#ffffff")
#define BTN_BUY_IMAGE           [UIImage imageNamed:@"btn_bug.png"]
#define BTN_READ_IMAGE          [UIImage imageNamed:@"btn_read.png"]
#define BTN_DOWNLOAD_IMAGE      [UIImage imageNamed:@"btn_download.png"]
#define BTN_PREVIEW_IMAGE          [UIImage imageNamed:@"btn_preview.png"]
#define BTN_FREE_TO_READ_IMAGE      [UIImage imageNamed:@"btn_free_read.png"]
#define BTN_DOWNLOADING_IMAGE      [UIImage imageNamed:@"btn_downloading.png"]
#define BTN_PAUSE_IMAGE      [UIImage imageNamed:@"btn_pause.png"]

@class KSMagzineViewController;
@class KSMagzineShelfView;
@class KSMagazineBookStoreView;
@class KSMagazineBookShelfView;
@interface KSMagzineMainView : UIView<KSViewInitor>{
    UIButton *subscibe;
//    UILabel *cover_title;
//    UILabel *cover_desc;
//    UILabel *cover_doc_1;
//    UILabel *cover_doc_2;
//    UILabel *cover_doc_3;
//    UILabel *cover_doc_4;
//    UIView *actions;
    UIButton *buy;
//    UILabel *buyTitle;
    UIButton *try_read;
//    UILabel *try_readTitle;
    KSMagzineViewController *_controller;
    
    NSInteger _currentMagzineIndex;
    
    KSMagzineAdView *_adView;
    
    DDProgressView *_progressView;
    UIButton *_glassButton;
    
    UIButton *_logoButton;
    KSMagazineCoverView *_coverScrollView;
    KSMagazinMainBottomShelfView *_bottomShelfView;
    KSMagazineBookStoreView     *_bookStoreView;
    KSMagazineBookShelfView     *_bookShelfView;
//    UIButton *_leftArrowBtn;
//    UIButton *_rightArrowBtn;
    UIImageView *_yearNaviBarImageView;
    UIButton *_editBtn;
    UIButton *_backDownloadBtn;
    UIButton *_discubBtn;
    KSNavigationSegBtnView *yearSeg;
    KSNavigationSegBtnView *typeSeg;
    BOOL     _backGroundDownload;
    UIImageView     *_bgView;
    UIView     *_bookShelfBgView;
    KSMagazineSecondAdView *_adWebView;
}
- (id)initWithFrame:(CGRect)frame controller:(id)controller;
@property(nonatomic,retain) UIButton *buy;
@property(nonatomic,retain) UIButton *try_read;
@property(nonatomic,retain) UIButton *editBtn;
@property(nonatomic,readonly) KSMagzineShelfView *bookshelf;
@property(nonatomic,readonly) KSMagzineAdView *adView;
@property(nonatomic,retain) KSMagazineCoverView *coverScrollView;
@property(nonatomic,retain) KSMagazinMainBottomShelfView *bottomShelfView;
@property(nonatomic,retain) KSMagazineBookStoreView     *bookStoreView;
@property(nonatomic,retain) KSMagazineBookShelfView     *bookShelfView;
@property(nonatomic,retain) NSMutableArray *years;
@property(nonatomic,retain) KSMagzineViewController *controller;
@property(nonatomic,assign)   NSInteger selectYear;
@property(nonatomic,retain) DDProgressView *progressView;
@property(nonatomic,retain) KSNavigationSegBtnView *yearSeg;
@property(nonatomic,retain) KSMagazineSecondAdView *adWebView;


- (void)animateShowPurchased;
- (void)reloadData;
-(void)doDownload;
- (void)readMagazine:(UIButton*)btn;
-(void)reloadDataWithYear:(NSInteger)year;
-(void)showBookShlefView;
-(void)hiddenBookShelf;
-(void)showBookStoreView;
-(void)hiddenStoreView;
-(void)initYearNaviBar;
-(void)changeMagazine:(KSModelMagzine*)magazine;
- (void)cancelDownload;
- (void)cancelDownload:(KSModelMagzine*)magazine;
-(void)hiddenStoreViewWithNoAnimation;
-(void)chooseOpenBackgroundDownload;
-(void)showWhiteBoardView;
-(void)hiddenWhiteBoardView;
@end
