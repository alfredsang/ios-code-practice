//
//  KSHelpView.m
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSSettingHelpView.h"

@implementation KSSettingHelpView


- (void)dealloc {
    [_topScrollView release];
    
    [_title1Label release];
    [_help1ScrollView release];
    [_pageController1 release];
    
    [_title2Label release];
    [_help2ScrollView release];
    [_pageController2 release];
    
    [_title3Label release];
    [_help3ScrollView release];
    [_pageController3 release];
    
    [super dealloc];
}


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
    
    }
    return self;
}

- (void)awakeFromNib {
    _topScrollView.contentSize = CGSizeMake(_topScrollView.width, self.height-80);
//    _topScrollView.autoresizingMask = UIViewAutoresizingFlexibleHeight;
//    _topScrollView.scrollEnabled = NO;
    _help1ScrollView.contentSize = CGSizeMake(_help1ScrollView.width*2, _help1ScrollView.height);
    _help1ScrollView.delegate = self;
    _help2ScrollView.contentSize = CGSizeMake(_help2ScrollView.width*3, _help2ScrollView.height);
    _help2ScrollView.delegate = self;
    _help3ScrollView.contentSize = CGSizeMake(_help3ScrollView.width*2, _help3ScrollView.height); //图片只用两张，不用三指
    _help3ScrollView.delegate = self;
    
    _pageController1.numberOfPages = 2;
    _pageController2.numberOfPages = 3;
    _pageController3.numberOfPages = 2;
}

- (void)layoutSubviews {
    _topScrollView.frame = self.bounds;
    
    _title1Label.left = _help1ScrollView.left + 20.0f;
    _title2Label.left = _help2ScrollView.left + 20.0f;
    _title3Label.left = _help3ScrollView.left + 20.0f;
    
}

#pragma mark - UIScrollViewDelegate
- (NSInteger)centerViewIndex:(UIScrollView *)scroll {
    CGFloat pageWidth = scroll.frame.size.width;
	return floor((scroll.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
}
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    NSInteger page = [self centerViewIndex:scrollView];
    if (scrollView == _help1ScrollView) {
        _pageController1.currentPage = page;
    } else if (scrollView == _help2ScrollView) {
        _pageController2.currentPage = page;
    } else if (scrollView == _help3ScrollView) {
        _pageController3.currentPage = page;
    }
}
- (void)scrollViewWillBeginDecelerating:(UIScrollView *)scrollView {
    NSInteger page = [self centerViewIndex:scrollView];
    if (scrollView == _help1ScrollView) {
        _pageController1.currentPage = page;
    } else if (scrollView == _help2ScrollView) {
        _pageController2.currentPage = page;
    } else if (scrollView == _help3ScrollView) {
        _pageController3.currentPage = page;
    }
}

@end
