//
//  KSRegSuccView.h
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-20.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CXDataRequest.h"

@class KSLoginView;
@interface KSRegSuccView : UIView<KSDataRequestDelegate> {
    NSString *_email;
    KSLoginView *_parent;
}


@property(retain, nonatomic) NSString *email;
@property(assign, nonatomic) id handler;
@property (assign, nonatomic) id parent;
@property (retain, nonatomic) IBOutlet UILabel *lbl_email;
- (IBAction)onClose:(id)sender;
- (IBAction)onLoginToEmail:(id)sender;
- (IBAction)onResend:(id)sender;

@end
