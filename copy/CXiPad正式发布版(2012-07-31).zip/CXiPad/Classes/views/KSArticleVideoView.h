//
//  KSArticleVideoView.h
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//
#import <MediaPlayer/MediaPlayer.h>
#import <UIKit/UIKit.h>
#import "KSViewInitor.h"

@interface KSArticleVideoView : UIView<KSViewInitor>{
    NSURL *_url;
    BOOL _full;
}
- (id)initWithFrame:(CGRect)frame url:(NSURL *)url full:(BOOL)full;
@end

@interface KSMoviePlayerViewController : MPMoviePlayerViewController {

    
}
@end