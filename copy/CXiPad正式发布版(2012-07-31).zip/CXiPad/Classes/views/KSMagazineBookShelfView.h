//
//  KSMagazineBookShelfView.h
//  CenturyWeeklyV2
//
//  Created by 广亮 高 on 12-6-11.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSMagazineBookStoreView.h"
#import "KSMagazinMainBottomShelfView.h"

@interface KSMagazineBookShelfView : KSMagazineBookStoreView<UIGestureRecognizerDelegate,UIAlertViewDelegate>
{
    UIActivityIndicatorView *activity;
    UIButton *_deleteButton;
}
- (id)initWithFrame:(CGRect)frame controller:(id)controller;
-(void)whenMagzineCancelDownload:(NSInteger)magzineId reloadData:(BOOL)isRelad;
-(void)editBtnPress:(UIButton*)btn;
@end
