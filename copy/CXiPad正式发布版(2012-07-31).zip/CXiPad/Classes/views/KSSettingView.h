//
//  KSSettingView.h
//  CenturyWeeklyV2
//
//  Created by zyk on 12/22/11.
//  Copyright (c) 2011 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "KSSettingNotificationView.h"
#import "KSSettingSubscribeView.h"
#import "KSSettingRestoreView.h"
#import "KSAppRecommendView.h"
#import "KSSettingFontView.h"
#import "KSSettingHelpView.h"
#import "KSSettingAboutView.h"
#import "KSSettingFaqView.h"
#import "KSSettingShareView.h"
#import "KSSettingMarkView.h"
#import "KSSettingAppRecommendView.h"
#import "KSSettingNoticeView.h"

@class KSHelpView;
@class KSMagzineViewController;
@interface KSSettingView : UIView <UITableViewDelegate, UITableViewDataSource> {
    NSArray *_settingsArray;
    NSArray *_settingMethodsArray;
    
//    UIImageView *_bgImageView;
    UIImageView *_popImageView;
    
    UILabel *_titleLabel;
    UILabel *_subTitleLabel;
    UIButton *_backButton;
    UITableView *_leftTableView;
    
    
    KSSettingNotificationView *_notifiSettingView;
    KSSettingRestoreView *_restoreView;
    KSSettingSubscribeView *_subsribeSettingView;
    KSAppRecommendView *_appRecommendView;
    KSSettingFontView *_fontSettingView;
    KSSettingHelpView *_helpView;
    KSSettingAboutView *_aboutView;
    KSSettingFaqView *_faqView;
    KSSettingShareView *_shareView;
    KSSettingMarkView *markView;
    KSMagzineViewController *_controller;
    KSSettingAppRecommendView  *appRecommendView;
    KSHelpView          *_newHelpView;
    KSSettingNoticeView *_noticeView;
    BOOL _shouldUpdatePush;
}
@property(nonatomic, assign)KSMagzineViewController *handler;
@property(nonatomic, assign)BOOL shouldUpdatePush;
@property(nonatomic, retain)UILabel *titleLabel;

- (id)initWithFrame:(CGRect)frame handler:(id)handler;

- (void)showPushView;
- (void)showHelpView;
- (void)loadSubViews;
- (void)dismiss;
-(void)showNotice;
@end
