//
//  KSRegisterView.h
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-17.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSViewInitor.h"
#import "KSIconButton.h"
#import "CXDataRequest.h"

@class KSLoginView;
@class KSMagzineViewController;
@interface KSRegisterView : UIView<KSViewInitor,UITextFieldDelegate,KSDataRequestDelegate>{
    KSLoginView *_parent;
    KSMagzineViewController *_handler;
    BOOL is_agree;
    UIImageView *register_bg;
    UIButton *agree_license;
    UIButton *regUserButton;
    UITextField *emailTextField;
    UITextField *nameTextField;
    UITextField *pwdTextField;
    UITextField *confirmPwdTextField;
    UIButton *tiaokuanButton;
    UIButton *yinsiquanButton;
    UIButton *closeButton;
    UILabel *tipLabel;
    
    UIImageView *smileImageView;
    
    NSString *_emailStr;
    NSString *_pwdStr;
}
- (id) initWithFrame:(CGRect)frame handler:(id)handler parent:(KSLoginView *)parent;

- (void) resetAgreeLicense;
@end
