//
//  KSSettingSinaWeiboTableCell.h
//  CenturyWeeklyV2
//
//  Created by zyk on 1/8/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KSSettingSinaWeiboTableCell : UITableViewCell {
    UIButton *weiboBindBtn;
    BOOL binded;
    BOOL loaded;
}
@property (nonatomic, retain) IBOutlet UIButton *weiboBindBtn;

- (IBAction)bindWeiboAccount:(id)sender;
@end
