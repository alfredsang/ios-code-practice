//
//  KSSettingShareView.h
//  CenturyWeeklyV2
//
//  Created by zyk on 1/8/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>

@class KSSettingView;
@interface KSSettingShareView : UIView<UITableViewDelegate,UITableViewDataSource> {
    UITableView *_tableView;
    
}
@property(nonatomic, assign)KSSettingView *parent;

@end
