//
//  KSArticleRelationsListView.m
//  CenturyWeeklyV2
//
//  Created by 广亮 高 on 12-5-28.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import "KSArticleRelationsListView.h"

#define TITLE_TAG   100
#define SUMMARY_TAG 101
#define IMAGE_TAG   102


@implementation KSArticleRelationsListCellView

@synthesize titleLabel,summaryLabel,typeImage;

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
            
        titleLabel = [[UILabel alloc] init];
        titleLabel.backgroundColor = [UIColor clearColor];
        titleLabel.frame = CGRectMake(10, 10, self.width-40, 20);
        titleLabel.tag = TITLE_TAG;
        [self addSubview:titleLabel];
        
        summaryLabel = [[UILabel alloc] init];
        summaryLabel.backgroundColor = [UIColor clearColor];
        summaryLabel.frame = CGRectMake(10, 10, self.width-20, 20);
        summaryLabel.textAlignment = UITextAlignmentRight;
        summaryLabel.tag = SUMMARY_TAG;
        [self addSubview:summaryLabel];
        
        typeImage = [[UIImageView alloc] init];
        typeImage.frame = CGRectMake(titleLabel.left+titleLabel.width+5, titleLabel.top, 15, 10);
        typeImage.tag = IMAGE_TAG;
        typeImage.hidden = YES;
        [self addSubview:typeImage];
        
    }
    return self;
}
-(void)dealloc
{
    [titleLabel release];
    [summaryLabel release];
    [typeImage release];
    [super dealloc];
}

-(void)relaodData:(NSDictionary*)dic
{
    titleLabel.text = [dic objectForKey:@"relartititle"];
    summaryLabel.text = [dic objectForKey:@"relartisource"];
     [dic objectForKey:@"relartitype"];
}
@end


@implementation KSArticleRelationsListView
@synthesize dataArray;

- (id)initWithFrame:(CGRect)frame array:(NSMutableArray*)array
{
    self = [super initWithFrame:frame];
    if (self) {
        dataArray = [array retain];

        
        theTableView = [[UITableView alloc] initWithFrame:frame style:UITableViewStylePlain];
        theTableView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"relationBg.png"]];
        theTableView.delegate = self;
        theTableView.dataSource =self;
        [self addSubview:theTableView];
    }
    return self;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/
-(void)dealloc
{
    [dataArray release];
    [theTableView release];
    [super dealloc];
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 0;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [dataArray count];
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 44.0f;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"userdCell";
    KSArticleRelationsListCellView *cell = (KSArticleRelationsListCellView*)[tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil)
    {
        cell = [[[KSArticleRelationsListCellView alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier] autorelease];
        
    }
    [cell relaodData:[dataArray objectAtIndex:[indexPath row]]];
    return cell;
}

@end
