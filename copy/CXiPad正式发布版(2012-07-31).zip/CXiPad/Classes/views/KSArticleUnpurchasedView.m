//
//  KSArticleUnpurchasedView.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 12-1-10.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import "KSArticleUnpurchasedView.h"

@implementation KSArticleUnpurchasedView

- (id)initWithFrame:(CGRect)frame index:(NSInteger)index
{
    self = [super initWithFrame:frame];
    if (self) {
        _index = index;
        [self initSubviews];
    }
    return self;
}
- (void)dealloc{
    
    [super dealloc];
}

- (void)initSubviews{
    UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.width, self.height)];
    lbl.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    lbl.backgroundColor = [UIColor clearColor];
    lbl.text = @"这篇文章你没有权限读取，需要订阅或购买。";
    lbl.font = [UIFont systemFontOfSize:36.0];
    lbl.textAlignment = UITextAlignmentCenter;
    [self addSubview:lbl];
    [lbl release];
}

- (NSInteger)getIndex{
    return _index;
}

@end
