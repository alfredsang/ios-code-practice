//
//  KSViewInitor.h
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-11-27.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol KSViewInitor <NSObject>
@required
- (void) initSubviews;
@end
