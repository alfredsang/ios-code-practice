//
//  KSSettingAppRecommendView.h
//  CenturyWeeklyV2
//
//  Created by 广亮 高 on 12-5-16.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CXDataRequest.h"

@interface KSSettingAppRecommendView : UIView<KSDataRequestDelegate>
{
    NSMutableArray *dataArray;
    NSMutableArray *otherAppArray;
    UIScrollView *scrollView;
    UIView      *caixinView;
    UIView      *otherView;

}
@end

@interface KSSettingAppRecommendItemView : UIView
{
    
}
@property(nonatomic,retain) UIImageView    *imageView;
@property(nonatomic,retain) UILabel     *titleLabel;
@property(nonatomic,retain) UILabel     *descriptionLabel;
@property(nonatomic,retain,readonly) NSDictionary     *dataDic;

-(id)initWithFrame:(CGRect)frame dic:(NSDictionary*)dic;

@end