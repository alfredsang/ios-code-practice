//
//  KSSettingAppRecommendView.m
//  CenturyWeeklyV2
//
//  Created by 广亮 高 on 12-5-16.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import "KSSettingAppRecommendView.h"
#import "KSWebViewController.h"

#define APP_URL @"http://caixin.adsame.com/s?z=caixin&c=%@&op=4"

#define CATEGORY_LEFT       20
#define CATEGORY_TOP        10
#define CATEGORY_FONT       [UIFont boldSystemFontOfSize:16];
#define CATEGORY_TEXT_COLOR @"#373737"

#define H_LEFT_MARGIN       44.0f
#define H_WDITH             260.0f
#define H_HEIGHT            90.0f
#define H_SPACE             55.0f

#define V_LEFT_MARGIN       44.0f
#define V_WDITH             345.0f
#define V_HEIGHT            90.0f
#define V_SPACE             42.0f

#define MARGIN_TOP          32.0f+CATEGORY_TOP

#define IMG_WIDTH           90.0f
#define IMG_HEIGHT          90.0f

#define SPACE_BETWEEN_IMG_AND_TITLE 18.0f
#define SPACE_BETWEEN_DESCRIPTION_AND_TITLE 12.0f

#define TITLE_FONT          [UIFont boldSystemFontOfSize:16]
#define DESCRIPTION_FONT    [UIFont systemFontOfSize:12]



@interface KSSettingAppRecommendView ()
-(void)downloadAppImage:(NSString*)url withName:(NSString *)fileName;
-(void)layoutAppItemView;
@end

@implementation KSSettingAppRecommendItemView

@synthesize imageView,titleLabel,descriptionLabel,dataDic;


-(void)downloadAppImage:(NSString*)imgUrl withName:(NSString *)fileName
{
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        NSData *imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:imgUrl]];
        UIImage *img = [UIImage imageWithData:imageData];
        dispatch_sync(dispatch_get_main_queue(), ^{
            imageView.image = img;
            
        });
        NSString *dirPath = [DataUtil getPathByFileName:@"appRecommendImg"];
        if (![[NSFileManager defaultManager] fileExistsAtPath:dirPath]) 
        {
            [[NSFileManager defaultManager] createDirectoryAtPath:dirPath withIntermediateDirectories:YES attributes:nil error:nil];
        }
        NSString *filePath = [dirPath stringByAppendingFormat:@"/%@.jpg",fileName];
        
        [UIImagePNGRepresentation(img) writeToFile: filePath    atomically:YES];
    });
    
}

-(id)initWithFrame:(CGRect)frame dic:(NSDictionary*)dic
{
    self = [super initWithFrame:frame];
    if (self)
    {
        dataDic = [dic retain];
        
        imageView = [[UIImageView alloc] init];
        imageView.frame = CGRectMake(0,0, IMG_WIDTH, IMG_HEIGHT);
        [self addSubview:imageView];
        
        titleLabel = [[UILabel alloc] init];
        titleLabel.frame = CGRectMake(SPACE_BETWEEN_IMG_AND_TITLE+IMG_WIDTH,0, frame.size.width-(SPACE_BETWEEN_IMG_AND_TITLE+IMG_WIDTH), 15);
        titleLabel.text = [dic objectForKey:@"title"];
        titleLabel.backgroundColor = [UIColor clearColor];
        titleLabel.font = TITLE_FONT;
        [self addSubview:titleLabel];
        
        descriptionLabel = [[UILabel alloc] init];
        CGSize size = [[dic objectForKey:@"summary"] sizeWithFont:DESCRIPTION_FONT constrainedToSize:CGSizeMake(titleLabel.width, IMG_HEIGHT-titleLabel.height-SPACE_BETWEEN_DESCRIPTION_AND_TITLE) lineBreakMode:UILineBreakModeWordWrap];
        descriptionLabel.frame = CGRectMake(titleLabel.frame.origin.x, titleLabel.frame.origin.y+titleLabel.frame.size.height+SPACE_BETWEEN_DESCRIPTION_AND_TITLE, size.width, size.height);
        descriptionLabel.text = [dic objectForKey:@"summary"];
        descriptionLabel.backgroundColor = [UIColor clearColor];
        descriptionLabel.numberOfLines = 0;
        descriptionLabel.lineBreakMode = UILineBreakModeClip;
        descriptionLabel.font = DESCRIPTION_FONT;
        [self addSubview:descriptionLabel];
        
        if (isReachability)
        {
            [self downloadAppImage:[dic objectForKey:@"pic"] withName:[dic objectForKey:@"title"]];

        }
        else {
            NSString *dirPath = [DataUtil getPathByFileName:@"appRecommendImg"];
            NSString *filePath = [dirPath stringByAppendingFormat:@"/%@.jpg",[dic objectForKey:@"title"]];
            imageView.image = [UIImage imageWithContentsOfFile:filePath];
        }

        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tagGesture)];
        [self addGestureRecognizer:tap];
        [tap release];

    }
    return self;
}
-(void)layoutSubviews
{

        
//    titleLabel.width = self.width-(SPACE_BETWEEN_IMG_AND_TITLE+IMG_WIDTH);
//    CGSize textSize = [descriptionLabel.text sizeWithFont:DESCRIPTION_FONT constrainedToSize:CGSizeMake(titleLabel.width, IMG_HEIGHT-titleLabel.height-SPACE_BETWEEN_DESCRIPTION_AND_TITLE) lineBreakMode:UILineBreakModeWordWrap];
//    CGFloat height = IMG_HEIGHT-titleLabel.height-SPACE_BETWEEN_DESCRIPTION_AND_TITLE;
//    textSize.height = textSize.height>height?height:textSize.height;
//    descriptionLabel.size = textSize;
//    [descriptionLabel setNeedsDisplay];

}
-(void)tagGesture
{
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[dataDic objectForKey:@"url"]]];
//    [KSWebViewController presentWithURL:[dataDic objectForKey:@"url"] inController:self.viewController];
}

-(void)dealloc
{
    [dataDic release];
    [imageView release];
    [titleLabel release];
    [descriptionLabel release];
    [super dealloc];
}


@end



@implementation KSSettingAppRecommendView



- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {

        scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 10, frame.size.width, frame.size.height)];
//        scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;


        dataArray = [[NSMutableArray alloc] init];
        otherAppArray = [[NSMutableArray alloc] init];
        
        if (!isReachability)
        {

            NSString *path = [NSHomeDirectory() stringByAppendingString:@"/Documents/appRecommend.plist"];
            NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:path];
            RELEASE_SAFELY(dataArray);
            RELEASE_SAFELY(otherAppArray);
            dataArray = [[dic objectForKey:@"1"] retain];
            otherAppArray = [[dic objectForKey:@"2"] retain];
            [scrollView removeAllSubviews];
            [self layoutAppItemView];
        }
        else 
        {
            [CXAppRecommendRequest requestWithDelegate:self];

        }
        [scrollView addSubview:caixinView];
        [scrollView addSubview:otherView];
        [self addSubview:scrollView];
    }
    return self;
}
-(void)dealloc
{
    [scrollView release];
    [dataArray release];
    [otherAppArray release];
    [super dealloc];
}

- (void)layoutSubviews {

//    int count = [dataArray count];
//    int otherCount = [otherAppArray count];
//    KSSettingAppRecommendItemView *lastItem;
//    if (count>0)
//    {
//        lastItem = (KSSettingAppRecommendItemView*)[scrollView viewWithTag:100+count-1];
//
//    }
//    if ([UIUtil currentOrientation] == 0) 
//    {
//
//
//
//        if (count>0)
//        {
//            UIImageView *label = (UIImageView*)[scrollView viewWithTag:60];
//            label.width = self.width-2*CATEGORY_LEFT;
//            for (int i = 0; i<count; i++)
//            {
//                KSSettingAppRecommendItemView *itemView = (KSSettingAppRecommendItemView*)[scrollView viewWithTag:100+i];
//                itemView.frame = CGRectMake(V_LEFT_MARGIN, i*(V_HEIGHT+V_SPACE)+MARGIN_TOP+label.bottom, self.width-V_LEFT_MARGIN*2, V_HEIGHT);
//            }
//            
//
//
//        }
//        if (otherCount>0)
//        {
//
//            UIImageView *label = (UIImageView*)[scrollView viewWithTag:50];
//            label.top = lastItem.bottom+20+CATEGORY_TOP;
//            label.width = self.width-2*CATEGORY_LEFT;
//            for (int i = 0; i<otherCount; i++)
//            {
//                KSSettingAppRecommendItemView *itemView = (KSSettingAppRecommendItemView*)[scrollView viewWithTag:200+i];
//                itemView.frame = CGRectMake(V_LEFT_MARGIN, i*(V_HEIGHT+V_SPACE)+MARGIN_TOP+label.bottom, self.width-V_LEFT_MARGIN*2, V_HEIGHT);
//            }
//
//        }
//        
//        scrollView.contentSize = CGSizeMake(self.frame.size.width, (V_HEIGHT+V_SPACE)*(count+otherCount)+20*2+CATEGORY_TOP*2 +20);//20*2中的20是label的高度，最后一个20是“其他应用”标签距离“财新出品”中应用的下边距
//
//        
//    } 
//    else
//    {
//
//        if (count>0)
//        {
//            UIImageView *label = (UIImageView*)[scrollView viewWithTag:60];
//            label.width = self.width-2*CATEGORY_LEFT;
//            for (int i = 0; i<count; i++)
//            {
//                KSSettingAppRecommendItemView *itemView = (KSSettingAppRecommendItemView*)[scrollView viewWithTag:100+i];
//                int column = i%2;
//                int row = i/2;
//                itemView.frame = CGRectMake(H_LEFT_MARGIN*(column+1)+column*((self.width-3*H_LEFT_MARGIN)/2), row*(H_HEIGHT+V_SPACE)+MARGIN_TOP+label.bottom, (self.width-3*H_LEFT_MARGIN)/2, H_HEIGHT);
//            }
//
//        }
//        if (otherCount>0)
//        {
//            UIImageView *label = (UIImageView*)[scrollView viewWithTag:50];
//            label.top = lastItem.bottom+20+CATEGORY_TOP;
//            label.width = self.width-2*CATEGORY_LEFT;
//            for (int i = 0; i<otherCount; i++)
//            {
//                KSSettingAppRecommendItemView *itemView = (KSSettingAppRecommendItemView*)[scrollView viewWithTag:200+i];
//                int column = i%2;
//                int row = i/2;
//                itemView.frame = CGRectMake(H_LEFT_MARGIN*(column+1)+column*((self.width-3*H_LEFT_MARGIN)/2), row*(H_HEIGHT+V_SPACE)+MARGIN_TOP+label.bottom, (self.width-3*H_LEFT_MARGIN)/2, H_HEIGHT);
//            }
//
//        }
//        scrollView.contentSize = CGSizeMake(self.frame.size.width, (V_SPACE+H_HEIGHT)*(ceil((CGFloat)count/2))+(V_SPACE+H_HEIGHT)*(ceil((CGFloat)otherCount/2))+20*2+CATEGORY_TOP*2 +20);
//
//    }
//
}

-(void)layoutAppItemView
{
    if ([dataArray count]>0)
    {
        UIImageView *titleImageView = [[UIImageView alloc] initWithFrame:CGRectMake(CATEGORY_LEFT, CATEGORY_TOP, self.width-2*CATEGORY_LEFT, 30)];
        titleImageView.tag = 60;
        titleImageView.image = [[UIImage imageNamed:@"btn_recommand_gb.png"] stretchableImageWithLeftCapWidth:40 topCapHeight:0];
        [scrollView addSubview:titleImageView];
        [titleImageView release];
        
        UILabel *lable = [[UILabel alloc] initWithFrame:CGRectMake(20, 5, 200, 20)];
        lable.text = @"财新出品";
        lable.font = CATEGORY_FONT;
        lable.textColor = str2rgb(@"#373737");
        lable.backgroundColor = [UIColor clearColor];
        [titleImageView addSubview:lable];
        [lable release];

        
//        UILabel *lable = [[UILabel alloc] initWithFrame:CGRectMake(CATEGORY_LEFT, CATEGORY_TOP, 200, 20)];
//        lable.text = @"财新出品";
//        lable.tag = 60;
//        lable.font = CATEGORY_FONT;
//        lable.textColor = COLOER(CATEGORY_TEXT_COLOR);
//        lable.backgroundColor = [UIColor clearColor];
//        [scrollView addSubview:lable];
//        [lable release];
        for (int i = 0; i<[dataArray count]; i++)
        {
            
            NSDictionary *itemDic = [dataArray objectAtIndex:i];
            KSSettingAppRecommendItemView *itemView;
//            if ([UIUtil currentOrientation] == 0)
//            {
                itemView = [[KSSettingAppRecommendItemView alloc] initWithFrame:CGRectMake(V_LEFT_MARGIN, (V_SPACE+IMG_HEIGHT)*i+MARGIN_TOP+lable.bottom, self.width-V_LEFT_MARGIN*2, H_HEIGHT) dic:itemDic]; 
//            }
//            else 
//            {
//                int column = i%2 ;
//                int row = i/2;
//                itemView = [[KSSettingAppRecommendItemView alloc] initWithFrame:CGRectMake(H_LEFT_MARGIN*(column+1)+column*((self.width-3*H_LEFT_MARGIN)/2), row*(H_HEIGHT+V_SPACE)+MARGIN_TOP+lable.bottom, (self.width-3*H_LEFT_MARGIN)/2, H_HEIGHT) dic:itemDic]; 
//                
//            }
            
            itemView.tag = 100+i;
            [scrollView addSubview:itemView];
            [itemView release];
            
        }
        
        
    }
    if ([otherAppArray count]>0)
    {
        KSSettingAppRecommendItemView *lastItem = (KSSettingAppRecommendItemView*)[scrollView viewWithTag:100+[dataArray count]-1];
        UIImageView *titleImageView = [[UIImageView alloc] initWithFrame:CGRectMake(CATEGORY_LEFT, 20+CATEGORY_TOP+lastItem.bottom, self.width-2*CATEGORY_LEFT, 30)];
        titleImageView.tag = 50;
        titleImageView.image = [[UIImage imageNamed:@"btn_recommand_gb.png"] stretchableImageWithLeftCapWidth:40 topCapHeight:0];
        [scrollView addSubview:titleImageView];
        [titleImageView release];

        UILabel *lable = [[UILabel alloc] initWithFrame:CGRectMake(20, 5, 200, 20)];
        lable.text = @"其他应用";
        lable.font = CATEGORY_FONT;
        lable.textColor = str2rgb(@"#373737");
        lable.backgroundColor = [UIColor clearColor];
        
        [titleImageView addSubview:lable];
        [lable release];


        for (int i = 0; i<[otherAppArray count]; i++)
        {
            
            NSDictionary *itemDic = [otherAppArray objectAtIndex:i];
            KSSettingAppRecommendItemView *itemView;
//            if ([UIUtil currentOrientation] == 0)
//            {
                itemView = [[KSSettingAppRecommendItemView alloc] initWithFrame:CGRectMake(V_LEFT_MARGIN, (V_SPACE+IMG_HEIGHT)*i+MARGIN_TOP+CATEGORY_TOP+titleImageView.bottom, self.width-V_LEFT_MARGIN*2, H_HEIGHT) dic:itemDic]; 
//            }
//            else 
//            {
//                int column = i%2 ;
//                int row = i/2;
//                itemView = [[KSSettingAppRecommendItemView alloc] initWithFrame:CGRectMake(H_LEFT_MARGIN*(column+1)+column*((self.width-3*H_LEFT_MARGIN)/2), row*(H_HEIGHT+V_SPACE)+MARGIN_TOP+lable.bottom, (self.width-3*H_LEFT_MARGIN)/2, H_HEIGHT) dic:itemDic]; 
//                
//            }
//            
            itemView.tag = 200+i;
            [scrollView addSubview:itemView];
            [itemView release];
            
        }
    }
//    if ([UIUtil currentOrientation] == 0) 
//    {
        scrollView.contentSize = CGSizeMake(self.frame.size.width, (V_HEIGHT+V_SPACE)*([dataArray count]+[otherAppArray count])+20*2+CATEGORY_TOP*2 +20);

//    }
//    else 
//    {
//        scrollView.contentSize = CGSizeMake(self.frame.size.width, (V_SPACE+H_HEIGHT)*(ceil((CGFloat)[dataArray count]/2))+(V_SPACE+H_HEIGHT)*(ceil((CGFloat)[otherAppArray count]/2))+20*2+CATEGORY_TOP*2 +20);
//
//    }


}

-(void)requestDidFinished:(KSBaseDataRequest *)request
{
    NSString *path = [NSHomeDirectory() stringByAppendingString:@"/Documents/appRecommend.plist"];
    [request.resultDict writeToFile:path atomically:YES];
    
    NSArray *array = [[request.resultDict objectForKey:@"1"] retain];
    [dataArray removeAllObjects];
    [otherAppArray removeAllObjects];
    for (int  i = 0; i<[array count]; i++)
    {
        NSDictionary *dic = [array objectAtIndex:i];
        if ([[dic objectForKey:@"type"] intValue]==1)
        {
            [dataArray addObject:dic];
        }
        else if ([[dic objectForKey:@"type"] intValue]==2)
        {
            [otherAppArray addObject:dic];
        }
    }
    [self layoutAppItemView];
    [array release];
}

-(void)requestDidFailed:(KSBaseDataRequest *)request withError:(NSError *)error
{
    
}

@end
