//
//  KSSettingFaqView.m
//  CenturyWeeklyV2
//
//  Created by zyk on 12/22/11.
//  Copyright (c) 2011 KSMobile. All rights reserved.
//

#import "KSSettingFaqView.h"
#import "KSMagzineViewController.h"

@implementation KSSettingFaqView

- (void)dealloc {
    [_scrollView release];
    [_imageView release];
    
    _webView.delegate = nil;
    [_webView stopLoading];
    [_webView release];
    [_faqHtmlStr release];
    [super dealloc];
}
- (void)loadSubviews {
    //_imageView = [[UIImageView alloc] initWithFrame:CGRectZero];
    _scrollView = [[UIScrollView alloc] initWithFrame:self.bounds];
//    _scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    [self addSubview:_scrollView];
    [_scrollView addSubview:_imageView];
    
    _webView = [[UIWebView alloc] initWithFrame:self.bounds];
    _faqHtmlStr = [[NSString alloc] initWithData:[NSData dataWithContentsOfFile:KSPathForBundleResource(@"faq.html")] encoding:NSUTF8StringEncoding];
    [_webView loadHTMLString:_faqHtmlStr baseURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] bundlePath]]];
    [_scrollView addSubview:_webView];
    _webView.backgroundColor = [UIColor clearColor];
    ((UIScrollView *)[[_webView subviews] objectAtIndex:0]).scrollEnabled = NO;
    _webView.delegate = self;
    
    _imageView.image = [UIImage imageNamedNocache:@"setting_faq_v.png"];
    _imageView.frame = CGRectMake(0, 10, 409, 1731);
    _webView.frame = CGRectMake(0, 10, 409, 1731);
    _scrollView.contentSize = CGSizeMake(_webView.width, _webView.height+30);
}
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        [self loadSubviews];
    }
    return self;
}
- (void)layoutSubviews {
//    if ([UIUtil currentOrientation] == 0) {


//    } else {
//        _imageView.image = [UIImage imageNamedNocache:@"setting_faq_h.png"];
//        _imageView.frame = CGRectMake(0, 10, 591, 1450);
//        _webView.frame = CGRectMake(0, 10, 591, 1450);
//    }
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/
#pragma mark -
- (void)showService {
    [KSWebViewController presentWithURL:@"http://service.caixin.com/" inController:self.viewController];
}
- (void)showwebsite {
    [KSWebViewController presentWithURL:@"http://www.caixin.com/" inController:self.viewController];
}
- (void)sendServiceMail {
    if ([MFMailComposeViewController canSendMail]) {
        MFMailComposeViewController *mailController = [[[MFMailComposeViewController alloc] init] autorelease];
        mailController.navigationBar.barStyle = UIBarStyleDefault;
        mailController.mailComposeDelegate = self;
        [mailController setSubject:@"反馈订阅问题"];
        [mailController setToRecipients:[NSArray arrayWithObjects:@"service@caixin.com", nil]];
        [self.viewController presentModalViewController:mailController animated:YES];
    } else {
        [UIUtil showMsgAlertWithTitle:@"未配置邮箱" message:@"您可以在设置中配置好邮箱，可以直接发邮件。"];
    }
}
- (void)showCircMail {
    if ([MFMailComposeViewController canSendMail]) {
        MFMailComposeViewController *mailController = [[[MFMailComposeViewController alloc] init] autorelease];
        mailController.navigationBar.barStyle = UIBarStyleDefault;
        mailController.mailComposeDelegate = self;
        [mailController setSubject:@"反馈订阅问题"];
        [mailController setToRecipients:[NSArray arrayWithObjects:@"circ@caixin.com", nil]];
        [self.viewController presentModalViewController:mailController animated:YES];
    } else {
        [UIUtil showMsgAlertWithTitle:@"未配置邮箱" message:@"您可以在设置中配置好邮箱，可以直接发邮件。"];
    }
    
}
- (void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error {
    [self.viewController dismissModalViewControllerAnimated:YES];
}

#pragma mark - UIWebViewDelegate 
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
    NSString *requestURL = [[request URL] absoluteString];
	if( [requestURL rangeOfString:@"#showService"].length>0 ){
		[self showService];
		return NO;
	}else if( [requestURL rangeOfString:@"#sendServiceMail"].length>0 ){
		[self sendServiceMail];
		return NO;
	}else if( [requestURL rangeOfString:@"#showCircMail"].length>0 ){
		[self showCircMail];
		return NO;
	}else if( [requestURL rangeOfString:@"#showwebsite"].length>0 ){
		[self showwebsite];
		return NO;
	}
    return YES;
}

@end
