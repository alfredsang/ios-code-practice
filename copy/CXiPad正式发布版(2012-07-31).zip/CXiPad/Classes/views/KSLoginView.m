//
//  KSLoginView.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-16.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "KSLoginView.h"
#import "KSMagzineViewController.h"
#import "UserHelper.h"
#import "DataUtil.h"


@implementation KSLoginView

- (void) dealloc{
    //    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidShowNotification object:nil];
    //    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
    [KSBaseDataRequest cancelRequest:@"CXLoadFreeMagazineDataRequest_1"];
    [KSBaseDataRequest cancelRequest:@"CXFireSubscriptionEventDataRequest_1"];
    [KSBaseDataRequest cancelRequest:@"CXLoginDataRequest"];
    
    [_containerView release];
    [login_bg release];
    [remember_pwd release];
    [find_password release];
    [register_user release];
    [login release];
    [user_name release];
    [user_pwd release];
    [register_view release];
    [reg_succ_view release];
    [err_msg release];
    [err_icon release];
    [_retrievePassView release];
    [reg_succ_email release];
    
    [super dealloc];
}

- (id)initWithFrame:(CGRect)frame handler:(id)handler
{
    self = [super initWithFrame:frame];
    if (self) {
        _handler = handler;
        self.backgroundColor = [UIColor colorWithWhite:0 alpha:0.8];//[[UIColor grayColor]colorWithAlphaComponent:0.8];
        self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        [self initSubviews];
        
        _isGiftcardUser = NO;
    }
    return self;
}
- (void) initSubviews{
    _containerView = [[UIView alloc] initWithFrame:self.bounds];
    _containerView.autoresizingMask = UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleWidth;
    [self addSubview:_containerView];
    
    is_remember = YES;
    login_bg = [[UIView alloc] initWithFrame:CGRectMake(172, 120, 424, 560)];
    [_containerView addSubview:login_bg];
    login_bg.alpha = 0;
    
    UIImageView *bg = [[UIImageView alloc] initWithImage:[UIImage imageNamedNocache:@"login_bg.png"]];
    bg.frame = CGRectMake(0, 0, 424, 560);
    [login_bg addSubview:bg];
    [bg release];
    
    remember_pwd = [UIUtil newImageButtonWithFrame:CGRectMake(25, 223, 45, 45) image:nil tappedImage:nil target:self action:@selector(rememberPassword)];
    UIImage *img = [UIImage imageNamedNocache:@"checkbox_selected.png"];
    [remember_pwd setImage:img forState:UIControlStateNormal];
    remember_pwd.showsTouchWhenHighlighted = YES;
    [self resetRememberPassword];
    [login_bg addSubview:remember_pwd];
    find_password = [UIUtil newImageButtonWithFrame:CGRectMake(40, 290, 87, 29) image:[UIImage imageNamedNocache:@"btn_find_password_98_36.png"] target:self action:@selector(showRetrievePassView)];
    [login_bg addSubview:find_password];
    register_user = [UIUtil newImageButtonWithFrame:CGRectMake(140, 290, 87, 29) image:[UIImage imageNamedNocache:@"btn_register_98_36.png"] target:self action:@selector(showRegFormView)];
    [login_bg addSubview:register_user];
    login = [UIUtil newImageButtonWithFrame:CGRectMake(290, 290, 99, 29) image:[UIImage imageNamedNocache:@"btn_login.png"] target:self action:@selector(login)];
    [login_bg addSubview:login];
    
    user_name = [[UITextField alloc] initWithFrame:CGRectMake(120, 137, 256, 32)];
    user_name.clearButtonMode = UITextFieldViewModeWhileEditing;
    user_name.keyboardType = UIKeyboardTypeEmailAddress;
    user_name.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    user_name.placeholder = @"请输入注册邮箱";
    [login_bg addSubview:user_name];
    
    
    user_pwd = [[UITextField alloc] initWithFrame:CGRectMake(120, 188, 256, 32)];
    user_pwd.clearButtonMode = UITextFieldViewModeWhileEditing;
    user_pwd.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    user_pwd.placeholder = @"请输入密码";
    user_pwd.secureTextEntry = YES;
    [login_bg addSubview:user_pwd];
    
    err_icon = [[UIImageView alloc] initWithImage:[UIImage imageNamedNocache:@"error_info.png"]];
    err_icon.frame = CGRectMake(40, 326, 18, 18);
    [login_bg addSubview:err_icon];
    err_icon.hidden = YES;
    
    err_msg = [[UILabel alloc] initWithFrame:CGRectMake(65, 324, 342, 21)];
    err_msg.font = [UIFont systemFontOfSize:13.0];
    err_msg.backgroundColor = [UIColor clearColor];
    err_msg.textColor = str2rgb(@"#FCB217");
    err_msg.text = @"";
    [login_bg addSubview:err_msg];
    err_msg.hidden = YES;
    
    UIButton *closeBtn = [[UIButton alloc] initWithFrame:CGRectMake(382, 30, 40, 40)];
    [closeBtn addTarget:self action:@selector(cancelLogin) forControlEvents:UIControlEventTouchUpInside];
    [closeBtn setImage:[UIImage imageWithContentsOfFile:KSPathForBundleResource(@"btn_login_close.png")] forState:UIControlStateNormal];
    closeBtn.showsTouchWhenHighlighted = YES;
    [login_bg addSubview:closeBtn];
    [closeBtn release];
    
    UIButton *restoreBtn = [[UIButton alloc] initWithFrame:CGRectMake(290, 457, 99, 29)];
    [restoreBtn setImage:[UIImage imageNamedNocache:@"btn_bg_117.png"] forState:UIControlStateNormal];
    [restoreBtn setImage:[UIImage imageNamedNocache:@"btn_bg_117.png"] forState:UIControlStateHighlighted];
    [restoreBtn addTarget:self action:@selector(doRestore) forControlEvents:UIControlEventTouchUpInside];
//    UIColor *actions_color = [UIColor colorWithRed:0x5b/255.0 green:0x39/255.0 blue:0x22/255.0 alpha:1];
//    UILabel *btnTitle = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 117, 24)];
//    btnTitle.font = [UIFont boldSystemFontOfSize:15.0f];
//    btnTitle.backgroundColor = [UIColor clearColor];
//    btnTitle.textColor = actions_color;
//    btnTitle.text = @"恢复购买";
//    btnTitle.textAlignment = UITextAlignmentCenter;
//    [restoreBtn addSubview:btnTitle];
//    [btnTitle release];
    [login_bg addSubview:restoreBtn];
//    [restoreBtn release];
    
    UIButton *readerBtn = [[UIButton alloc] initWithFrame:CGRectMake(290, 505, 99, 29)];
    [readerBtn setImage:[UIImage imageNamedNocache:@"btn_bg_118.png"] forState:UIControlStateNormal];
    [readerBtn setImage:[UIImage imageNamedNocache:@"btn_bg_118.png"] forState:UIControlStateHighlighted];
    [readerBtn addTarget:self action:@selector(showReaderView) forControlEvents:UIControlEventTouchUpInside];
//    btnTitle = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 117, 24)];
//    btnTitle.font = [UIFont boldSystemFontOfSize:15.0f];
//    btnTitle.backgroundColor = [UIColor clearColor];
//    btnTitle.textColor = actions_color;
//    btnTitle.text = @"输入读者编号";
//    btnTitle.textAlignment = UITextAlignmentCenter;
//    [readerBtn addSubview:btnTitle];
//    [btnTitle release];
    [login_bg addSubview:readerBtn];
//    [readerBtn release];
    
    UIButton *readerBtn2 = [[UIButton alloc] initWithFrame:CGRectMake(160, 0, 140, 33)];
    [readerBtn2 addTarget:self action:@selector(showReaderView) forControlEvents:UIControlEventTouchUpInside];
    readerBtn2.backgroundColor = [UIColor clearColor];
    [login_bg addSubview:readerBtn2];
    [readerBtn2 release];
    
    //
    [self performSelector:@selector(animateShowLoginFormView) withObject:nil afterDelay:0.1];
}

- (void) layoutSubviews{
//    if([UIUtil currentOrientation]==0){
        login_bg.frame = CGRectMake(172, 120, 424, 560);
        register_view.frame = CGRectMake((768-423)/2, 125, 423, 590);
        _retrievePassView.center = CGPointMake(self.centerX, 340.0f);
        
//    }else{
//        login_bg.frame = CGRectMake(300, 22, 424, 560);
//        register_view.frame = CGRectMake((1024-786)/2, 63, 786, 335);
//        _retrievePassView.center = CGPointMake(self.centerX, 200.0f);
//    }
    reg_succ_view.center = CGPointMake(768/2, 1024/2);
}

#pragma mark -
- (void) popView:(UIView *)view{
    if(view==register_view){
        //
        [register_view release];
        register_view = nil;
    }else if(view==reg_succ_view){
        reg_succ_view = nil;
    }
    [view removeFromSuperview];
    login_bg.hidden = NO;
}
- (void) resetRememberPassword{
    UIImage *img = nil;
    if(is_remember){
        img = [UIImage imageNamedNocache:@"checkbox_selected.png"];
    }else{
        img = [UIImage imageNamedNocache:@"checkbox_unselect.png"];
    }
    [remember_pwd setImage:img forState:UIControlStateNormal];
}

- (void) rememberPassword{
    is_remember = !is_remember;
    [self resetRememberPassword];
}
- (void)showRegSuccView {
    
}

- (void) showError:(NSString *)msg{
    if (msg && [msg length]) {
        err_msg.text = msg;
        err_msg.hidden = NO;
        err_icon.hidden = NO;
        CGRect orignalRect = login_bg.frame;
        [UIView animateWithDuration:0.05f delay:0.0f options:UIViewAnimationOptionRepeat|UIViewAnimationOptionAutoreverse animations:^{
            [UIView setAnimationRepeatCount:3];
            login_bg.centerX -= 15.0f;
            login_bg.centerX += 30.0f;
        } completion:^(BOOL finished) {
            login_bg.frame = orignalRect;
        }];
    } else {
        err_msg.hidden = YES;
        err_icon.hidden = YES;
    }
}

- (void) login{
    if(!user_name.text || !user_pwd.text){
        [self showError:@"用户名与密码不能为空！"];
        return;
    }
    if (![DataUtil validateEmail:user_name.text]) {
        [self showError:@"邮箱不合法！"];
        return;
    }
    RELEASE_SAFELY(reg_succ_email);
    reg_succ_email = [user_name.text retain];
    [self showError:nil];
    
    //先检查是否为订阅卡用户
    [CXGiftCardDataRequest requestWithDelegate:self url:SERVER_URL(@"/isgiftcarduser/%@/%@",MAGZINE_TYPE,reg_succ_email) withParameters:nil withIndicatorView:self withCancelSubject:nil];
}

- (void)caixinSavePurchased:(NSString*)productIdentifier {
    [KSAppStoreProxy caixinSavePurchased:productIdentifier];
}

- (void)caixinSaveSubscription:(NSDictionary *)receipt verifiedReceiptDictionary:(NSDictionary *)verifiedReceiptDictionary {
    [KSAppStoreProxy caixinSaveSubscription:receipt verifiedReceiptDictionary:verifiedReceiptDictionary];
}
- (void)doRestore {
    [KSAppStoreProxy restorefromView:_handler.view];
}
#pragma mark - Switch Views
- (void)showReaderView {
    [_handler showAccountViewFromLogin];
}
- (void)showRegFormView {
    if(register_view!=nil){
        [register_view removeFromSuperview];
    }
    register_view = [[KSRegisterView alloc] initWithFrame:CGRectMake(0, 0, 786, 335) handler:_handler parent:self];
    if ([UIUtil currentOrientation] == 0) {
        register_view.frame = CGRectMake((768-423)/2, 125, 423, 590);
    } else {
        register_view.frame = CGRectMake((1024-786)/2, 63, 786, 335);
    }
    
    //login_bg.hidden = YES;
    [_containerView addSubview:register_view];
    
    
    [self animateShowRegFormView];
    //[self performSelector:@selector(animateShowRegFormView) withObject:nil afterDelay:0.1];
}
- (void)animateShowRegFormView {
    [UIView transitionFromView:login_bg toView:register_view duration:0.5 options:UIViewAnimationOptionTransitionFlipFromLeft completion:^(BOOL finished) {
        login_bg.hidden = YES;
    }];
}
- (void)animateDismissRegFormView {
    login_bg.hidden = NO;
    [UIView transitionFromView:register_view toView:login_bg duration:0.5 options:UIViewAnimationOptionTransitionFlipFromRight completion:^(BOOL finished) {
        [register_view removeFromSuperview], [register_view release], register_view = nil;
        
    }];
}
- (void)animateShowLoginFormView {
    IF_IOS5_OR_GREATER([UIView transitionWithView:login_bg duration:0.5 options:UIViewAnimationOptionTransitionFlipFromBottom animations:^{
        login_bg.alpha = 1;
    } completion:NULL];)
    IF_PRE_IOS5(
       [UIUtil addAnimationShow:login_bg];
    ;)
    
}
- (void)animateDismissLoginFormView {
    IF_IOS5_OR_GREATER([UIView transitionWithView:login_bg duration:0.5 options:UIViewAnimationOptionTransitionFlipFromTop animations:^{
        login_bg.hidden = YES;
    } completion:^(BOOL completed){
        [_handler showView:@"none"];
    }];)
    
    IF_PRE_IOS5( [UIView animateWithDuration:0.5 animations:^{
        login_bg.hidden = YES;
    } completion:^(BOOL finished) {
        [_handler showView:@"none"];
    }];)
    
}

- (void) displayRegSuccView:(NSString *)email password:(NSString *)passwd{
    NSArray *views = [[NSBundle mainBundle] loadNibNamed:@"KSRegSuccView" owner:self options:nil];
    reg_succ_view = [[views objectAtIndex:0] retain];
    //    reg_succ_view.frame = CGRectMake(0, 0, 422, 336);
    reg_succ_view.center = CGPointMake(roundf(self.centerX), roundf(self.centerY));
    reg_succ_view.layer.cornerRadius = 5;
    
    reg_succ_view.email = email;
    reg_succ_view.handler = _handler;
    reg_succ_view.parent = self;
    login_bg.hidden = YES;
    [_containerView addSubview:reg_succ_view];
    
    user_name.text = email;
    user_pwd.text = passwd;
    
    //animation
    reg_succ_view.alpha = 0;
    [UIView animateWithDuration:0.3 animations:^{
        register_view.alpha = 0;
        reg_succ_view.alpha = 1;
    } completion:^(BOOL finished) {
        register_view.hidden = YES;
        register_view.alpha = 1;
    }];
}
//隐藏RegSuccView,显示 LoginFormView
- (void)dismissRegSuccView {
    login_bg.hidden = NO;
    login_bg.alpha = 0;
    [_containerView addSubview:login_bg];
    [UIView animateWithDuration:0.3 animations:^{
        reg_succ_view.alpha = 0;
        login_bg.alpha = 1;
    } completion:^(BOOL finished) {
        [reg_succ_view removeFromSuperview], [reg_succ_view release], reg_succ_view = nil;
        
    }];
}
- (void)showRetrievePassView {
    login_bg.hidden = YES;
    if (!_retrievePassView) {
        NSArray *views = [[NSBundle mainBundle] loadNibNamed:@"KSRetrievePassView" owner:self options:nil];
        _retrievePassView = [[views objectAtIndex:0] retain];
        _retrievePassView.parent = self;
        //    reg_succ_view.frame = CGRectMake(0, 0, 422, 336);
        _retrievePassView.center = [UIUtil currentOrientation] == 0?CGPointMake(self.centerX, 340.0f):CGPointMake(self.centerX, 200.0f);
        login_bg.hidden = YES;
        [_containerView addSubview:_retrievePassView];
        
        _retrievePassView.mailTextField.text = reg_succ_email;
        //animation
        _retrievePassView.alpha = 0;
        [UIView animateWithDuration:0.3 animations:^{
            login_bg.alpha = 0;
            _retrievePassView.alpha = 1;
        } completion:^(BOOL finished) {
            login_bg.hidden = YES;
            login_bg.alpha = 1;
        }];
    }
}
- (void)dismissRetrievePassView {
    login_bg.hidden = NO;
    login_bg.alpha = 0;
    [UIView animateWithDuration:0.3 animations:^{
        login_bg.alpha = 1;
        _retrievePassView.alpha = 0;
    } completion:^(BOOL finished) {
        [_retrievePassView removeFromSuperview];
        [_retrievePassView release];
        _retrievePassView = nil;
    }];
}

- (void)cancelLogin {
    [self animateDismissLoginFormView];
}

#pragma mark -
- (void)showError:(UITextField *)textField msg:(NSString *)text {
    UILabel *label = (UILabel *)textField.rightView;
    if (!label) {
        label = [UIUtil newLabelWithFrame:CGRectZero text:text textColor:[UIColor redColor] font:[UIFont systemFontOfSize:16]];
        textField.rightView = label;
        [label release];
    }else {
        label.text = text;
    }
    [label sizeToFit];
    textField.rightViewMode = UITextFieldViewModeAlways;
    label.hidden = NO;
//    textField.layer.borderColor = [[UIColor redColor] CGColor];
//    textField.layer.borderWidth = 1.0f;
}
#pragma mark - dataprocess
- (void)startFireSub {
    //事件类型为1
    //首次安装首次订阅首次登陆
    [CXFireSubscriptionEventDataRequest requestWithDelegate:self url:SERVER_URL(@"/fireEvent/%@/1/%@/%@", MAGZINE_TYPE,reg_succ_email,[[UIDevice currentDevice] uniqueGlobalDeviceIdentifier]) withParameters:nil withIndicatorView:nil withCancelSubject:@"CXFireSubscriptionEventDataRequest_1"];
}
- (void)startLoadFree {
    [CXLoadFreeMagazineDataRequest requestWithDelegate:self url:SERVER_URL(@"/myfree/%@/%@/%@", MAGZINE_TYPE,reg_succ_email,[KSDB stringForKey:KEY_DEVICE_UDID_STR]) withParameters:nil withIndicatorView:nil withCancelSubject:@"CXLoadFreeMagazineDataRequest_1"];
}
- (void)didLoadFree:(KSBaseDataRequest *)request {
    [UserHelper saveMyFreeToDB:request.resultDict];
    [_handler loginUser:user_name.text];
}
- (void)didProcessLoginSuccess:(KSBaseDataRequest *)request {
    KSDINFO(@"%@", request.resultDict);
    if (is_remember) {
        [KSDB saveString:@"1" forKey:UD_KEY_AUTOLOGIN];
    } else {
        [KSDB saveString:@"0" forKey:UD_KEY_AUTOLOGIN];
    }
    [KSBootstrap setCurrentUser:reg_succ_email];
    if ([request.resultDict objectForKey:@"data"]) {
        NSNumber *uid = [[request.resultDict objectForKey:@"data"] objectForKey:@"uid"];
        if (uid) {
            [KSDB saveString:STR_FORMAT(@"%d", [uid intValue]) forKey:UD_KEY_USERID];
        }
    }
    
    // 触发第一次登录
    //if ([[KSDB stringForKey:UD_KEY_FIRST_LOGIN] intValue] < 1) {//first
    //    [KSDB saveString:@"1" forKey:UD_KEY_FIRST_LOGIN];
    //参数分别为：杂志类型/赠送事件类型/用户email/
    [CXFireDonateEventDataRequest requestWithDelegate:self url:SERVER_URL(@"/fireEvent/%@/0/%@/%@", MAGZINE_TYPE,reg_succ_email,[[UIDevice currentDevice] uniqueGlobalDeviceIdentifier]) withParameters:nil withIndicatorView:nil withCancelSubject:@"CXFireDonateEventDataRequest_1"];
    //} else {
    // 请求my_free
    //    [self startLoadFree];
    //}
    //与订阅中心同步杂志
    //[DataPersistence execWithDelegate:self operationName:@"syncMagazieWithWeb"];
    //[UIUtil showProcessIndicatorWithView:self atPoint:CGPointMake(self.frame.size.width/2-5, 520) hasMask:NO];
    //
}
- (void)didLoginSuccess:(KSBaseDataRequest *)request {
    //处理登录的请求
    KSDINFO(@"%@",request.resultDict);
//    if ([[request.resultDict objectForKey:@"error"] intValue] != 0) {
//        [UIUtil hideProcessIndicatorWithView:self];
//        [self showError:[request.resultDict objectForKey:@"message"]];
//        return;
//    }
    NSString *result = [[request.resultDict objectForKey:@"data"] objectForKey:@"code"];
    if ([result intValue]==-1) {
        [UIUtil hideProcessIndicatorWithView:self];
        
        [self showError:@"用户名或密码错误！"];
        
    } else if ([result intValue]==-2) {
        [UIUtil hideProcessIndicatorWithView:self];
        if (_isGiftcardUser) {
            [self didProcessLoginSuccess:request];
        } else {
            [self showError:@"您的用户未激活！ "];
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"注册邮箱激活" message:@"您还差一步就可以完成注册，点击邮箱确认信的激活链接来完成注册" delegate:self cancelButtonTitle:@"下次提醒" otherButtonTitles:@"立即激活",nil];
            alertView.tag = 1020;
            [alertView show];
            [alertView release];  
            //[controller showAccountActiveView];
        }
        
    } else if ([result intValue]==0 || [result intValue]==2) {
        [self didProcessLoginSuccess:request];
    } else {
        [UIUtil hideProcessIndicatorWithView:self];
        
        [self showError:user_name msg:@"用户不存在"];
    } 
}
#pragma mark - KSDataRequestDelegate
- (void)requestDidStarted:(KSBaseDataRequest *)request {
    if ([request isKindOfClass:[CXLoginDataRequest class]]) {
        [UIUtil showProcessIndicatorWithView:self atPoint:self.center hasMask:YES];
    }
}
- (void)requestDidFinished:(KSBaseDataRequest *)request {
    //NSLog(@"%@",request.resultString);
    //处理赠送返回
    if ([request isKindOfClass:[CXFireDonateEventDataRequest class]]) {
        //如果NSUserDefaults中有数据，处理订阅赠送
        if ([[[NSUserDefaults standardUserDefaults] objectForKey:UD_SUBSCRIPTION_DATE] floatValue]>0) {
            [self startFireSub];
        } else {
            [self didLoadFree:request];
        }
        return;
    }
    //订阅事件处理完成，返回的是myfree的所有数据
    if ([request isKindOfClass:[CXFireSubscriptionEventDataRequest class]]) {
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:UD_SUBSCRIPTION_DATE];
        //[[NSUserDefaults standardUserDefaults] setObject:@"0" forKey:UD_SUBSCRIPTION_DATE];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        [self didLoadFree:request];
        //[self startLoadFree];
        return;
    }
    //处理LoadFree的请求
    if ([request isKindOfClass:[CXLoadFreeMagazineDataRequest class]]) {
        [self didLoadFree:request];
        
        [UIUtil hideProcessIndicatorWithView:self];
        return;
    }
    //检查订阅卡用户
    if ([request isKindOfClass:[CXGiftCardDataRequest class]]) {
        NSDictionary *dict = request.resultDict;
        _isGiftcardUser = DICT_BOOLVAL(dict, @"isgiftcarduser");
        //[self didLoginSuccess:request];
        //发起正常的登录过程
        [CXLoginDataRequest requestWithDelegate:self withParameters:[NSDictionary dictionaryWithObjectsAndKeys:user_name.text,@"email",user_pwd.text,@"pwd", nil] withIndicatorView:self withCancelSubject:@"CXLoginDataRequest"];
        
        return;
    }
    
    //正常登录返回
    if ([request isKindOfClass:[CXLoginDataRequest class]]) {
        [self didLoginSuccess:request];
        return;
    }
}

- (void)requestDidCanceled:(KSBaseDataRequest *)request {
    [_handler logout];
    [UIUtil hideProcessIndicatorWithView:self];
}

- (void)requestDidFailed:(KSBaseDataRequest *)request withError:(NSError*)error {
    if ([request isKindOfClass:[CXGiftCardDataRequest class]]) {
        [CXLoginDataRequest requestWithDelegate:self withParameters:[NSDictionary dictionaryWithObjectsAndKeys:user_name.text,@"email",user_pwd.text,@"pwd", nil] withIndicatorView:self withCancelSubject:@"CXLoginDataRequest"];
        return;
    }
    [self showError:@"网络异常！"];
    [UIUtil hideProcessIndicatorWithView:self];
}

#pragma mark - UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (alertView.tag == 1020) {
        if (buttonIndex == 1) {
            NSData* data=[reg_succ_email dataUsingEncoding:NSUTF8StringEncoding];
            NSString* email = [data base64EncodedString];
            [CXActiveUserDataRequest requestWithDelegate:self withParameters:[NSDictionary dictionaryWithObjectsAndKeys:email,@"email", nil] withCancelSubject:@"CXActiveUserDataRequest"];
            [self displayRegSuccView:reg_succ_email password:user_pwd.text];
        }
    }
}
@end


