//
//  KSArticleMapView.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 2/11/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <MapKit/MapKit.h>
#import <UIKit/UIKit.h>
#import "KSModelArticle.h"
#import "KSArticleViewController.h"

@interface KSArticleMapView : UIView<MKMapViewDelegate> {
    MKMapView *_articleMapView;
    KSModelArticle *_article;
    KSArticleViewController *_controller;
    UIButton *_dismissBtn;
    
    NSMutableArray *_locationArray;
}

- (id)initWithFrame:(CGRect)frame article:(KSModelArticle *)article;

@end

@interface KSModelLocation : NSObject {
    CLLocationDegrees _latitude;
    CLLocationDegrees _longitude;
    NSString *_annotation;
}
@property(nonatomic, assign)CLLocationDegrees latitude;
@property(nonatomic, assign)CLLocationDegrees longitude;
@property(nonatomic, retain)NSString *annotation;


@end


@interface CustomAnnotation : NSObject <MKAnnotation> {
	CLLocationCoordinate2D coordinate;
	NSString *title;
	NSString *subtitle;
}

@property (nonatomic,readonly)CLLocationCoordinate2D coordinate;
@property (nonatomic,copy) NSString *title;
@property (nonatomic,copy) NSString *subtitle;

- (id)initWithCoordinate:(CLLocationCoordinate2D)coords;

@end
