//
//  KSCaixinCommentView.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 2/10/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KSCaixinCommentView.h"
#import <QuartzCore/QuartzCore.h>
#import "KSArticleViewController.h"
#import "KSModelComment.h"
#import "KSCommentTableViewCell.h"
#import "KSDB.h"

@interface KSCaixinCommentView ()
- (void)loadingComment:(NSInteger)page;
- (void)changeViews;
@end

@implementation KSCaixinCommentView
@synthesize controller = _controller;

- (void)dealloc {
    //IF_PRE_IOS5(
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
    //)
    IF_IOS5_OR_GREATER(
                       [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillChangeFrameNotification object:nil];
                       )
    [KSBaseDataRequest cancelRequest:@"KSCaixinCommentView_POST"];
    [KSBaseDataRequest cancelRequest:@"KSCaixinCommentView_GET"];
    [_leftView release];
    [_rightView release];
    [_closeButton release];
    [_tableView release];
    [_leftFrameView release];
    [_rightFrameView release];
    [_leftTitleLabel release];
    [_leftTipLabel release];
    [_rightTitleLabel release];
    [_righttipLabel release];
    [_rightNameLabel release];
    [_submitButton release];
    [_chooseNameButton release];
    
    [_indicatorView stopAnimating],[_indicatorView release];
    [_rightTitleBgView release];
    [_commentTextView release];
    
    [_commentList release];
    [_modelArticle release],_modelArticle = nil;
    
    //[_author release];
    
    [super dealloc];
}

- (void)loadSubviews {
    _leftView = [[UIImageView alloc] initWithImage:[[UIImage imageNamedNocache:@"bg_comment_left.png"] stretchableImageWithLeftCapWidth:220 topCapHeight:30]];
    [self addSubview:_leftView];
    
    _closeButton = [[UIButton alloc] initWithFrame:CGRectMake(110, 9, 40, 40)];
    [_closeButton setImage:[UIImage imageNamedNocache:@"btn_del.png"] forState:UIControlStateNormal];
    [_closeButton addTarget:_controller action:@selector(dismissCommentView) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_closeButton];
    
    _leftTitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(32, 46, 580, 25)];
    _leftTitleLabel.backgroundColor = [UIColor clearColor];
    _leftTitleLabel.font = [UIFont systemFontOfSize:20.0f];
    _leftTitleLabel.textColor = [UIColor colorWithRed:0.3686 green:0.2627 blue:0.1922 alpha:1];
    _leftTitleLabel.text = _modelArticle.title;
    [self addSubview:_leftTitleLabel];
    
    _leftTipLabel = [[UILabel alloc] initWithFrame:CGRectMake(590, 48, 150, 25)];
    _leftTipLabel.textAlignment = UITextAlignmentRight;
    _leftTipLabel.backgroundColor = [UIColor clearColor];
    _leftTipLabel.font = [UIFont systemFontOfSize:17.0f];
    _leftTipLabel.textColor = [UIColor colorWithRed:0.3686 green:0.2627 blue:0.1922 alpha:1];
    _leftTipLabel.text = @"查看评论";
    [self addSubview:_leftTipLabel];
    
    _leftFrameView = [[UIImageView alloc] initWithImage:[[UIImage imageNamedNocache:@"comment_frame.png"] stretchableImageWithLeftCapWidth:20 topCapHeight:20]];
    [self addSubview:_leftFrameView];
    _leftFrameView.userInteractionEnabled = YES;
    
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(18, 87, 730, 580)];
    _tableView.backgroundColor = [UIColor clearColor];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    [_leftFrameView addSubview:_tableView];
    
    _rightView = [[UIImageView alloc] initWithImage:[[UIImage imageNamedNocache:@"bg_comment_right.png"] stretchableImageWithLeftCapWidth:30 topCapHeight:30]];
    [self addSubview:_rightView];
    
    _rightFrameView = [[UIImageView alloc] initWithImage:[[UIImage imageNamedNocache:@"comment_frame.png"] stretchableImageWithLeftCapWidth:20 topCapHeight:20]];
    [self addSubview:_rightFrameView];
    
    _righttipLabel = [[UILabel alloc] initWithFrame:CGRectMake(590, 48, 200, 25)];
    _righttipLabel.backgroundColor = [UIColor clearColor];
    _righttipLabel.font = [UIFont systemFontOfSize:17.0f];
    _righttipLabel.textColor = [UIColor colorWithRed:0.3686 green:0.2627 blue:0.1922 alpha:1];
    _righttipLabel.textAlignment = UITextAlignmentRight;
    _righttipLabel.text = @"评论仅代表网友个人观点";
    [self addSubview:_righttipLabel];
    
    //_rightTitleBgView = []
    _rightTitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(_rightView.left+25, _rightView.top+50, _rightView.width-45, 50)];
    _rightTitleLabel.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamedNocache:@"bg_comment_author.png"]];
    _rightTitleLabel.font = [UIFont systemFontOfSize:17.0f];
    if (_isAnony) {
        _rightTitleLabel.text =  @"  财新网友：";
    } else {
        _rightTitleLabel.text = [NSString stringWithFormat:@"  %@", _author];
    }
    [self addSubview:_rightTitleLabel];
    
    _commentTextView = [[UITextView alloc] initWithFrame:CGRectMake(_rightTitleLabel.left, _rightTitleLabel.bottom, _rightTitleLabel.width, _rightFrameView.height-_rightTitleLabel.height-5)];
    _commentTextView.layer.cornerRadius = 5;
    _commentTextView.backgroundColor = [UIColor clearColor];
    _commentTextView.font = [UIFont systemFontOfSize:20.0f];
    _commentTextView.delegate = self;
    [self addSubview:_commentTextView];
    
    _chooseNameButton = [[UIButton alloc] initWithFrame:CGRectMake(_rightView.left-20, _rightView.bottom-30, 44, 44)];
    if (_isAnony) {
        [_chooseNameButton setImage:[UIImage imageNamed:@"btn_com_sel.png"] forState:UIControlStateNormal];
    } else {
        [_chooseNameButton setImage:[UIImage imageNamed:@"btn_com_unsel.png"] forState:UIControlStateNormal];
    }
    
    [_chooseNameButton addTarget:self action:@selector(changAnony) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_chooseNameButton];
    _chooseNameButton.hidden = _isAnony;
    
    _rightNameLabel = [[UILabel alloc] initWithFrame:CGRectMake(_chooseNameButton.right+10, _chooseNameButton.top, 120, 25)];
    _rightNameLabel.backgroundColor = [UIColor clearColor];
    _rightNameLabel.font = [UIFont systemFontOfSize:17.0f];
    _rightNameLabel.textColor = [UIColor colorWithRed:0.3686 green:0.2627 blue:0.1922 alpha:1];
    _rightNameLabel.text = @"隐身发表";
    [self addSubview:_rightNameLabel];
    _rightNameLabel.hidden = _isAnony;
    
    _submitButton = [[UIButton alloc] initWithFrame:CGRectMake(_rightView.bottom-40, _rightView.right-100, 60, 28)];
    _submitButton.titleLabel.font = [UIFont systemFontOfSize:17.0f];
    [_submitButton setBackgroundImage:[UIImage imageNamed:@"btn_com.png"] forState:UIControlStateNormal];
    [_submitButton setTitle:@"提交" forState:UIControlStateNormal];
    [_submitButton addTarget:self action:@selector(submitComment) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_submitButton];
    
    _indicatorView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    _indicatorView.center = CGPointMake(333, 57);
    [self addSubview:_indicatorView];
    _indicatorView.hidden = YES;
    
    //IF_PRE_IOS5(
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
    //)
    IF_IOS5_OR_GREATER(
                       [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeKeyboardFrame:) name:UIKeyboardWillChangeFrameNotification object:nil];
                       )
    
    //load data
    [self loadingComment:_page];
}
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
    }
    return self;
}
- (id)initWithFrame:(CGRect)frame article:(KSModelArticle *)article {
    self = [self initWithFrame:frame];
    if (self) {
        _modelArticle = [article retain];
        
        _articleId = _modelArticle.articleId;
        _page = 1;
        _totalPage = 1;
        _pageSize = 20;
        _totalRecord = 0;
        
        _commentList = [[NSMutableArray alloc] init];
        _author = [KSBootstrap currentUser];
        if (_author == nil) {
            _author = @"  财新网友：";
            _isAnony = YES;
        } else {
            _isAnony = NO;
        }
        
        self.backgroundColor = [UIColor colorWithWhite:0 alpha:0.8];
        self.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
        //self.autoresizingMask = UIViewAutoresizingNone;
        [self loadSubviews];
    }
    return self;
}
- (void)layoutSubviews {
    if (_scrolling) {
        return;
    }
    if ([UIUtil currentOrientation]==0) {
        //self.frame = CGRectMake(0, 0, 1024, 768);
        _leftView.frame = CGRectMake(0, 23, 768, 680);
        
        _closeButton.frame = CGRectMake(175, 4, 60,40);
        _leftTitleLabel.frame = CGRectMake(32, 46, 580, 25);
        _leftTipLabel.frame = CGRectMake(590, 48, 150, 25);
        
        _leftFrameView.frame = CGRectMake(13, 80, 741, 598);
        _tableView.frame = CGRectMake(5, 5, 730, 580);
        
        _rightView.frame = CGRectMake(-4, 700, 773, 300);
        _rightFrameView.frame = CGRectMake(13, 757, 740, 188);
        
        _rightTitleLabel.frame = CGRectMake(_rightView.left+23, _rightView.top+61, _rightView.width-44, 70);
        
    } else {
        //self.frame = CGRectMake(0, 0, 768, 1024);
        _leftView.frame = CGRectMake(0, 23, 678, 736);
        _closeButton.frame = CGRectMake(175, 4, 60,40);
        _leftTitleLabel.frame = CGRectMake(32, 46, 580, 25);
        _leftTipLabel.frame = CGRectMake(500, 48, 150, 25);
        
        _leftFrameView.frame = CGRectMake(13, 80, 651, 654);
        _tableView.frame = CGRectMake(5, 5, 640, 636);
        
        _rightView.frame = CGRectMake(668, 23, 356, 736);
        _rightFrameView.frame = CGRectMake(685, 80, 322, 619);
        
        _rightTitleLabel.frame = CGRectMake(_rightView.left+22, _rightView.top+62, _rightView.width-45, 70);
    }
    _commentTextView.frame = CGRectMake(_rightTitleLabel.left, _rightTitleLabel.bottom, _rightTitleLabel.width, _rightFrameView.height-_rightTitleLabel.height-10);
    _chooseNameButton.left = _rightView.left+20, _chooseNameButton.bottom = _rightView.bottom-15;
    _rightNameLabel.left = _chooseNameButton.right+10, _rightNameLabel.top =  _chooseNameButton.top+10;
    _righttipLabel.right = _rightView.right-30,_righttipLabel.top = _rightView.top+25;
    _submitButton.bottom = _rightView.bottom-20, _submitButton.right = _rightView.right-70;
    
    if (_keyboardIsVisible) {
        [self changeViews];
    }
}
/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 }
 */
#pragma mark - UITextViewDelegate
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView {
    _editing = YES;
    return YES;
}
- (BOOL)textViewShouldEndEditing:(UITextView *)textView {
    //_editing = NO;
    return YES;
}
- (void)textViewDidBeginEditing:(UITextView *)textView {
    _editing = NO;
}
#pragma mark - keyboard
- (void)changeViews {
    CGFloat height = _keyboardHeight;
    
    [UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:0.3];
    
    _leftView.frame = CGRectMake(_leftView.left, _leftView.top, _leftView.width, _leftView.height - height);
    _leftFrameView.height -= height;
    //_tableView.height -= height;
    
    
    if (self.isPortrait) {
        //_leftTitleLabel.top -= height;
        //_leftTipLabel.top -= height;
        
        _rightView.top -= height;
        _rightFrameView.top -= height;
        _rightTitleLabel.top -= height;
        _righttipLabel.top -= height;
        _rightTitleBgView.top -= height;
        _rightNameLabel.top -= height;
        
        _submitButton.top -= height;
        _chooseNameButton.top -= height;
        
        _commentTextView.top -= height;
    } else {
        _rightView.height -= height;
        _rightFrameView.height -= height;
        _commentTextView.height -= height;
        
        _rightNameLabel.top -= height;
        //_righttipLabel.top -= height;
        //_rightTitleLabel.top -= height;
        _chooseNameButton.top -= height;
        _submitButton.top -= height;
        
    }
    [UIView commitAnimations];
}
- (void)changeViewsHeight:(CGFloat)height aniDuration:(NSTimeInterval)duration {
    [self setNeedsLayout];
    //_leftView.frame = CGRectMake(_leftView.left, _leftView.top, _leftView.width, _leftView.height - height);
    return;
    [UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:duration];
    _leftView.frame = CGRectMake(_leftView.left, _leftView.top, _leftView.width, _leftView.height - height);
    _leftFrameView.height -= height;
    _tableView.height -= height;
    
    _leftTitleLabel.top -= height;
    _leftTipLabel.top -= height;
    if (self.isPortrait) {
        _rightView.top -= height;
        _rightFrameView.top -= height;
        _rightTitleLabel.top -= height;
        _righttipLabel.top -= height;
        _rightTitleBgView.top -= height;
        _rightNameLabel.top -= height;
        
        _submitButton.top -= height;
        _chooseNameButton.top -= height;
        
        _commentTextView.top -= height;
    } else {
        _rightView.height -= height;
        _rightFrameView.height -= height;
        _commentTextView.height -= height;
        
        _rightNameLabel.top -= height;
        _righttipLabel.top -= height;
        _rightTitleLabel.top -= height;
        _chooseNameButton.top -= height;
        _submitButton.top -= height;
        
    }
    [UIView commitAnimations];
}
- (CGFloat)calculateKeyboardHeight:(NSNotification *)notification {
    NSDictionary *userInfo = [notification userInfo];
    NSValue* aValue = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGRect keyboardRect = [aValue CGRectValue];
    if (self.isPortrait) {
        return keyboardRect.size.height;
    }else
        return keyboardRect.size.width;
}
- (CGFloat)calculateAnimationDuration:(NSNotification *)notify {
    NSDictionary *userInfo = [notify userInfo];
    NSNumber *aValue = [userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey];
    
    return [aValue floatValue];
}
//for ios 5 to change input method
- (void)changeKeyboardFrame:(NSNotification *)notification {
    CGFloat h = [self calculateKeyboardHeight:notification];
    _keyboardHeight = h;
    [self changeViewsHeight:h-_keyboardHeight aniDuration:[self calculateAnimationDuration:notification]];
    
}
//NSValue *animationDurationValue = [userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey];
//NSTimeInterval animationDuration;
//[animationDurationValue getValue:&animationDuration];
//[self moveInputBarWithKeyboardHeight:keyboardRect.size.height withDuration:animationDuration];
- (void)keyboardWillShow:(NSNotification *)notification {
    _keyboardIsVisible = YES;
    NSDictionary *userInfo = [notification userInfo];
    //keyborad height
    //NSValue* aValue = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
    //CGRect keyboardRect = [aValue CGRectValue];
    //float innerKeyboardHeight = keyboardRect.size.height;
    
    // keybord animation duration
    NSValue *animationDurationValue = [userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey];
    NSTimeInterval animationDuration;
    [animationDurationValue getValue:&animationDuration];
    _keyboardHeight = [self calculateKeyboardHeight:notification];
    // change view frame
	[self changeViewsHeight:_keyboardHeight aniDuration:animationDuration];
}

- (void)keyboardWillHide:(NSNotification *)notification {
    _keyboardIsVisible = NO;
    NSDictionary *userInfo = [notification userInfo];
    //keyborad height
    NSValue* aValue = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGRect keyboardRect = [aValue CGRectValue];
    float innerKeyboardHeight = keyboardRect.size.height;
    
    // keybord animation duration
    NSValue *animationDurationValue = [userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey];
    NSTimeInterval animationDuration;
    [animationDurationValue getValue:&animationDuration];
    _keyboardHeight = innerKeyboardHeight;
    
    [self changeViewsHeight:-innerKeyboardHeight aniDuration:animationDuration];
}
#pragma mark - actions
- (void)changAnony {
    _isAnony = !_isAnony;
    if (_isAnony) {
        [_chooseNameButton setImage:[UIImage imageNamed:@"btn_com_sel.png"] forState:UIControlStateNormal];
        _rightTitleLabel.text =  @"  财新网友：";
    } else {
        [_chooseNameButton setImage:[UIImage imageNamed:@"btn_com_unsel.png"] forState:UIControlStateNormal];
        _rightTitleLabel.text = [NSString stringWithFormat:@"  %@：", _author];
    }
    
}
- (void)submitComment {
    NSString *commentText = _commentTextView.text;
    if (commentText == nil || ![commentText length]) {
        [UIUtil showMsgAlertWithTitle:@"提示" message:@"评论内容不能为空"];
        return;
    }
    [CXPostCaixinCommentDataRequest requestWithDelegate:self withParameters:[NSDictionary dictionaryWithObjectsAndKeys:_modelArticle.sourceId==0?@"103":@"100",@"app_id",STR_FORMAT(@"%d", _modelArticle.sourceId==0?_articleId:_modelArticle.sourceId),@"topic_id", _isAnony? @"财新网友": _author,@"user_name",_isAnony?@"0":[KSDB stringForKey:UD_KEY_USERID],@"user_id",commentText,@"content", nil] withCancelSubject:@"KSCaixinCommentView_POST"];
}
- (void)loadingComment:(NSInteger)page {
    [KSBaseDataRequest cancelRequest:@"KSCaixinCommentView_GET"];
    //[CXListCaixinCommentDataRequest requestWithDelegate:self url:SERVER_URL(@"/comment/%d/%d",_articleId, page) withParameters:nil withIndicatorView:nil withCancelSubject:@"KSCaixinCommentView_GET"];
    [CXListCaixinCommentDataRequest requestWithDelegate:self withParameters:[NSDictionary dictionaryWithObjectsAndKeys:STR_FORMAT(@"%d", _modelArticle.sourceId==0?_articleId:_modelArticle.sourceId),@"target_id",_modelArticle.sourceId==0?@"103":@"100",@"app_id",STR_FORMAT(@"%d", _pageSize),@"page_size",STR_FORMAT(@"%d", page),@"page_number", nil] withCancelSubject:@"KSCaixinCommentView_GET"];
}
- (void)doLoadComment{
    _page = 1;
    [self loadingComment:_page];
} 


-(void)loadMore {
    UIActivityIndicatorView	*activiter = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
	[activiter startAnimating];
	
	NSInteger lastRow = [_commentList count];
	NSIndexPath *lastIndexPath = [NSIndexPath indexPathForRow:lastRow inSection:0];
	[_tableView scrollToRowAtIndexPath:lastIndexPath atScrollPosition:UITableViewScrollPositionBottom animated:NO];
	[_tableView cellForRowAtIndexPath:lastIndexPath].textLabel.text = @"加载中...";
	[[_tableView cellForRowAtIndexPath:lastIndexPath] addSubview:activiter];
    
    activiter.frame = CGRectMake(ceilf(_tableView.width/2)-70, [_tableView cellForRowAtIndexPath:lastIndexPath].height/2-10, 20, 20);
	[activiter release];
    
    _loadingMore = YES;
    
    [self loadingComment:_page+1];
}
#pragma mark - KSDataRequestDelegate
- (void)requestDidStarted:(KSBaseDataRequest *)request {
    if ([request isKindOfClass:[CXListCaixinCommentDataRequest  class]]) {
        _indicatorView.center = CGPointMake(_leftView.centerX, _leftTitleLabel.centerY);
    } else {
        _indicatorView.center = CGPointMake(_submitButton.centerX + 50, _submitButton.centerY);
    }
    _indicatorView.hidden = NO;
    [_indicatorView startAnimating];
}
- (void)requestDidFinished:(KSBaseDataRequest *)request {
    _indicatorView.hidden = YES;
    [_indicatorView stopAnimating];
    if ([request isKindOfClass:[CXListCaixinCommentDataRequest  class]]) {
        NSDictionary *resultDict = [request resultDict];
        KSDINFO(@"%@", resultDict);
        if ([[resultDict objectForKey:@"success"] intValue] == 0) {
            [UIUtil showMsgAlertWithTitle:@"没有数据" message:@"评论系统没有该文章的数据"];
            return;
        }
        _page = DICT_INTVAL(resultDict, @"current_page");
        _pageSize = DICT_INTVAL(resultDict, @"page_size");
        _totalRecord = DICT_INTVAL(resultDict, @"record_count");
        _totalPage =  DICT_INTVAL(resultDict, @"total_page");
        
        _hasMorePage = _totalPage > _page;
        //_page = _page < 1?1:_page;
        _loadingMore = NO;
        //第1页数据显示时应将之前的数据清空
        if (_page <= 1) {
            [_commentList removeAllObjects];
        }
        //entries = [[NSMutableArray arrayWithCapacity:20] retain];
        NSArray *arr = [resultDict valueForKey:@"data"];
        for (NSDictionary *dict in arr) {
            KSModelComment *item = [KSModelComment commentWithCXDict:dict];
            [_commentList addObject:item];
        }
        _leftTipLabel.text = [NSString stringWithFormat:@"共 %d 条评论",  _totalRecord];
        [_tableView reloadData];
        
    }
    if ([request isKindOfClass:[CXPostCaixinCommentDataRequest class]]) {
        NSDictionary *resultDict = request.resultDict;
        NSInteger suc = DICT_INTVAL(resultDict, @"success");
        if (suc !=0 ) {
            [UIUtil showMsgAlertWithTitle:@"提示" message:@"您的评论已提交，请耐心等待管理员审核"];
            _commentTextView.text = @"";
            //: 是否需要刷新评论列表
            [self doLoadComment];
        } else {
            NSString *data = [resultDict objectForKey:@"msg"];
            if (![data length]) {
                data = @"未知原因";
            }
            [UIUtil showMsgAlertWithTitle:@"提交失败" message:data];
        }
    }
}
- (void)requestDidCanceled:(KSBaseDataRequest *)request {
    _indicatorView.hidden = YES;
    [_indicatorView stopAnimating];
}
- (void)requestDidFailed:(KSBaseDataRequest *)request withError:(NSError*)error {
    _indicatorView.hidden = YES;
    [_indicatorView stopAnimating];
}

#pragma mark - UIScrollViewDelegate
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    _scrolling = YES;
}
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    _scrolling = NO;
}
#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == [_commentList count]) {
        return 45.0f;
    } else {
        CGSize titleSize = [((KSModelComment *)[_commentList objectAtIndex:indexPath.row]).content sizeWithFont:[UIFont systemFontOfSize:17.0f] constrainedToSize:CGSizeMake(tableView.width-42, MAXFLOAT) lineBreakMode:UILineBreakModeWordWrap];
        CGFloat h = titleSize.height > 30 ? titleSize.height:30;
        return h+40.0f;
    }
    //return 116.0;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == [_commentList count]) {
        if (!_loadingMore) {
            [self loadMore];
        }
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
        return;
    } else {
        //KSModelComment *comment = [_commentList objectAtIndex:indexPath.row];
        // 需要增加点击选中逻辑
        //[_handler gotoArticle:item.articleId magzineId:item.magzineId from:@"search"];
    }
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}
#pragma mark -
#pragma mark Table view creation (UITableViewDataSource)

// customize the number of rows in the table view
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	if (_hasMorePage) {
        return [_commentList count]+1;
    }else return [_commentList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == [_commentList count] && _hasMorePage) {
        UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
        cell.textLabel.textAlignment = UITextAlignmentCenter;
        cell.textLabel.font = [UIFont fontWithName:@"Georgia-Italic" size:14];
        cell.textLabel.text = @"加载更多...";
        return [cell autorelease];
    }
	static NSString *CellIdentifier = @"KSCommentTableCell";
    KSCommentTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[KSCommentTableViewCell alloc] initWithComment:[_commentList objectAtIndex:indexPath.row] reuseIdentifier:CellIdentifier] autorelease];
    } else {
        [cell setComment:[_commentList objectAtIndex:indexPath.row]];
    }
    
    return cell;
}

@end
