//
//  KSRetrievePassView.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 12/29/11.
//  Copyright (c) 2011 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CXDataRequest.h"

@class KSLoginView;
@interface KSRetrievePassView : UIView<UITextFieldDelegate,KSDataRequestDelegate> {
    
    IBOutlet UIActivityIndicatorView *_indicatorView;
    UITextField *_mailTextField;
    KSLoginView *_parent;
}
@property (retain, nonatomic) IBOutlet UITextField *mailTextField;
@property(nonatomic, assign)IBOutlet KSLoginView *parent;


- (IBAction)dismiss:(id)sender;
- (IBAction)doRetrieve:(id)sender;



@end
