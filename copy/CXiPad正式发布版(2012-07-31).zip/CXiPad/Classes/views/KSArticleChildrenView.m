//
//  KSArticleChildrenView.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 2/9/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KSArticleChildrenView.h"

@implementation KSArticleChildrenView

- (void)dealloc {
    
    [_dismissBtn release];
    [super dealloc];
}
- (void)initSubviews {
    [super loadView];
    
    _scrollView.bounces = NO;
    _scrollView.backgroundColor = [UIColor blackColor];
    
    _dismissBtn = [[UIButton alloc] initWithFrame:CGRectMake(self.width-50, 0, 50, 50)];
    _dismissBtn.showsTouchWhenHighlighted = YES;
    [_dismissBtn setImage:[UIImage imageNamed:@"btn_slideshow_close.png"] forState:UIControlStateNormal];
    [_dismissBtn addTarget:self action:@selector(dismissThis) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_dismissBtn];
    _dismissBtn.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin|UIViewAutoresizingFlexibleBottomMargin;
    
    //[self moveToViewAtPage:0 animated:NO];
}

- (id)initWithFrame:(CGRect)frame article:(KSModelArticle *)article {
    self = [super initWithFrame:frame];
    if (self) {
        _parentArticle = [article retain];
        _dataList = (NSMutableArray *)[[KSModelArticle childArticlesInArtilce:_parentArticle.articleId] retain];
        _pageCount = [_dataList count];
        _pageSize = 1;
        _pageWidth = self.width;
        _pageIndex = 0;
        for (int i=0; i<_pageCount; i++) {
            [_cacheViewsList addObject:[NSNull null]];
        }
        
//        FMResultSet *rs = [[KSDB db] executeQuery:@"select child_id from article_children where article_id=? order by ranking asc", INTEGER(_parentArticle.articleId)];
//        NSMutableArray *tmp = [[NSMutableArray alloc] init];
//        while (rs.next) {
//            NSDictionary *dict = [rs resultDict];
//            [tmp addObject:[NSNumber numberWithInt: DICT_INTVAL(dict, @"child_id")]];
//        }
//        [rs close];
//        for (NSString *childId in tmp) {
//            NSString *jsonFile = STR_FORMAT(@"%@/magzineUnpack%d/%d/article.json", [KSBootstrap root], _parentArticle.articleId,[childId intValue]);
//            NSData *jsonData = [NSData dataWithContentsOfFile:jsonFile];
//            NSDictionary *dict = [[CJSONDeserializer deserializer] deserializeAsDictionary:jsonData error:nil];
//            if(dict){
//                [_dataList addObject:dict];
//            }
//        }
        
        [self initSubviews];
    }
    return self;
}
- (void)layoutSubviews {
    if (_scrolling) {
        return;
    }
    _rotating = YES;
    _cellWidth = _pageWidth = self.width;
    _scrollView.frame = self.bounds;
    _scrollView.contentSize = CGSizeMake(_pageWidth*_pageCount, self.height);
    [_scrollView removeAllSubviews];
    for (int i=0; i<_pageCount; i++) {
        [_cacheViewsList replaceObjectAtIndex:i withObject:[NSNull null]];
    }
    [_scrollView setContentOffset:CGPointMake(_pageWidth*_pageIndex, 0) animated:NO];
    [self loadScrollViewWithPage:_pageIndex];
    _rotating = NO;
}
#pragma mark -
//创建新的详细内容视图
- (UIView *)newCachedView:(NSInteger)index {
    KSModelArticle *a = [_dataList objectAtIndex:index];
    KSArticleWebView *webView = [[KSArticleWebView alloc] initWithFrame:self.bounds article:a hanlder:(KSArticleViewController *)self.viewController child:YES];
    webView.left = index*_pageWidth;
    //webView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    
    return webView;
}
//显示详细某详细内容视图时，可能需要对应的操作，改变父视图状态或
//调用其它代理方法
- (void)setCachedViewState:(NSInteger)index {
    
}
- (void) dismissThis{
    ((KSArticleViewController *)self.viewController).forceHideHeader = NO;
    [self removeFromSuperview];
}
@end
