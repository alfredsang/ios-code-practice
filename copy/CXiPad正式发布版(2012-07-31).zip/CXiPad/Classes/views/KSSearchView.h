//
//  KSSearchView.h
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-20.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSViewInitor.h"
#import "KSModelSearchItem.h"
#import "KSUrlRequest.h"
#import "KSDownloader.h"
#import "KSNoPermissionAlertView.h"

#define SEARCH_URL SERVER_URL(@"/search/%@/%d/%@/%d")
//SURL_PREFIX(@"search", @"%@/0/%d/%@")

@class KSMagzineViewController;
@interface KSSearchView : UIView<KSViewInitor, UITableViewDataSource, UITableViewDelegate, KSUrlRequestDelegate, KSDownloaderDelegate, UITextFieldDelegate,KSNoPermissionAlertViewDelegate>{
    KSMagzineViewController *_handler;
//    UIImageView *_bgImageView;
    UIImageView *background;
    UIImageView *_popImageView;
    
    UIButton *btnBack;
    UIButton *btnSearch;
    UIButton *btnDelInputText;
    UITextField *txtSearchWord;
    UILabel *lblResultHint;
    //UIScrollView *scrollView;
    UITableView *_tableView;
    NSMutableArray *_entries;
    NSInteger _currentMagazineId;
    
    UIActivityIndicatorView *_indicatorView;
    
    KSUrlRequest *_request;
    NSInteger _page;
    NSInteger _pageSize;
    NSInteger _totalPage;
    NSInteger _totalRecord;
    BOOL _hasMorePage;
    BOOL _loadingMore;
    NSInteger _selectMagazineId;
}
- (id) initWithFrame:(CGRect)frame handler:(id)handler;
@end

