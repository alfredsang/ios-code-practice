//
//  KSMagazinMainBottomShelfView.h
//  CenturyWeeklyV2
//
//  Created by 广亮 高 on 12-6-8.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "KSShelfProgressView.h"
#import "KSMagazineCoverView.h"


#define ITEM_WIDTH      85
#define ITEM_MARGIN     43


@class KSMagzineViewController;


@interface KSMagazinMainBottomShelfItemView:UIImageView
{
    KSModelMagzine *_magazine;
    KSMagzineViewController *_controller;
    UIImageView *_maskImagView;
}
@property(nonatomic,retain)KSModelMagzine *magazine;

-(id)initWithFrame:(CGRect)frame controller:(id)controller;
-(id)initWithFrame:(CGRect)frame Magazine:(KSModelMagzine*)magazine controller:(id)controller;
-(void)loadMagazine:(KSModelMagzine*)magazine;
-(void)refreshProgress:(KSModelMagzine*)magazine;

@end

@interface KSMagazinMainBottomShelfView : KSMagazineCoverView<UIScrollViewDelegate>
{
//    KSMagzineViewController *_controller;
//    NSMutableArray *_magzines;
}
//@property(nonatomic,retain) KSMagzineViewController *controller;
-(void)whenMagzinePurchased:(NSInteger)magazineId;
-(void)reloadData;
-(void)reloadDataWithMagazines:(NSMutableArray*)magazs;
- (id)initWithFrame:(CGRect)frame controller:(id)controller;
- (void) whenInitOrMagzineListUpdate;
- (void) whenMagzineDownloader:(NSInteger)magzineId;
- (void)whenMagzineCover0Download:(NSInteger)magzineId;
- (void)whenMagzineDeleted:(KSModelMagzine *)magazine;
-(void)loadMagazineByYear:(NSMutableArray*)magazines;
-(void)autoChangePosition;
-(void)selectYear:(NSInteger)selectYear;
@end



