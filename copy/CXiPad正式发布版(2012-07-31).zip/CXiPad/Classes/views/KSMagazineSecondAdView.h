//
//  KSMagazineSecondAdView.h
//  CenturyWeeklyV2
//
//  Created by jerry gao on 12-7-24.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KSMagzineAdView.h"

@interface KSMagazineSecondAdView : KSMagzineAdView

@end
