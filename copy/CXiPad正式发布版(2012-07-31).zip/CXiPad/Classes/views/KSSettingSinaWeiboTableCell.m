//
//  KSSettingSinaWeiboTableCell.m
//  CenturyWeeklyV2
//
//  Created by zyk on 1/8/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KSSettingSinaWeiboTableCell.h"
#import "SHK.h"
#import "SHKSina.h"

@implementation KSSettingSinaWeiboTableCell
@synthesize weiboBindBtn;

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"kSHSinaAuthenticationFinished" object:nil];
    
    [weiboBindBtn release];
    
    [super dealloc];
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        SHKSina *sina = [[SHKSina alloc] init];
        if ([sina authorize]) {
            [weiboBindBtn setTitle:@"绑定" forState:UIControlStateNormal];
            binded = YES;
        }else {
            [weiboBindBtn setTitle:@"取消绑定" forState:UIControlStateNormal];
            binded = NO;
        }
        sina.shareDelegate = nil;
        [sina release];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeState:) name:@"kSHSinaAuthenticationFinished" object:nil];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)bindWeiboAccount:(id)sender {
    
    if (binded == YES) {
        [SHKSina logout];
        binded = NO;
        [weiboBindBtn setTitle:@"绑定" forState:UIControlStateNormal];
    }else {
        [SHK currentHelper].rootViewController = self.viewController;
        SHKSina *sina = [[SHKSina alloc] init];
        [sina restoreAccessToken];
        [sina promptAuthorization];
        //[SHKSina logout];
        [sina release];
    }
}
- (void)awakeFromNib {
    if (loaded) {
        return;
    }
    loaded = YES;
    SHKSina *sina = [[SHKSina alloc] init];
    if ([sina isAuthorized]) {
        [weiboBindBtn setTitle:@"取消绑定" forState:UIControlStateNormal];
        binded = YES;
    }else {
        [weiboBindBtn setTitle:@"绑定" forState:UIControlStateNormal];
        binded = NO;
    }
    sina.shareDelegate = nil;
    [sina release];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeState:) name:@"kSHSinaAuthenticationFinished" object:nil];
}
- (void)changeState:(NSNotification *)notify {
    binded = YES;
    [weiboBindBtn setTitle:@"取消绑定" forState:UIControlStateNormal];
}


@end
