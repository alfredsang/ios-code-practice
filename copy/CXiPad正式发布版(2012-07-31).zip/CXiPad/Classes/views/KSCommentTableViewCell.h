//
//  KSCommentTableViewCell.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 1/4/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSModelComment.h"

@interface KSCommentTableViewCell : UITableViewCell {
    KSModelComment *_comment;
    UILabel *_timeLabel;
}
@property(nonatomic, retain)KSModelComment *comment;

- (id)initWithComment:(KSModelComment *)mcomment reuseIdentifier:(NSString *)reuseIdentifier;
@end
