//
//  KSCollectionView.h
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-20.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSViewInitor.h"
#import "KSModelCollectionItem.h"

@class KSMagzineViewController;
@interface KSCollectionView : UIView<KSViewInitor, UITableViewDataSource, UITableViewDelegate>{
    KSMagzineViewController  *_handler;
    UIImageView *_bgImageView;
    UIImageView *backgroundView;
    UIImageView *_popImageView;
    
    UIButton *btnBack;
    UIButton *btnMyCollection;
    UIButton *btnEditDel;
    UITableView *_tableView;
    NSMutableArray *_entriesArray;
    
    BOOL editing;
}
- (id) initWithFrame:(CGRect)frame handler:(id)handler;
@end
