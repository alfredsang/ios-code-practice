//
//  KSMagazineCoverView.h
//  CenturyWeeklyV2
//
//  Created by 广亮 高 on 12-6-8.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "KSMagzineViewController.h"

@class KSMagzineViewController;
@interface KSMagazineCoverImageView : UIView
{
    KSMagzineViewController *_controller;
}

@property(nonatomic,retain) UIImageView *imageView;

-(id)initWithFrame:(CGRect)frame Magazine:(KSModelMagzine*)magazine controller:(id)controller; 
-(void)loadMagazine:(KSModelMagzine*)magazine;
@end

@interface KSMagazineCoverView : UIScrollView<UIScrollViewDelegate>
{
    NSMutableArray *_magzines;
    KSMagzineViewController *_controller;
    NSMutableArray *_userdCoverViews;
}

@property(nonatomic,retain)     KSMagzineViewController *controller;
@property(nonatomic,retain)     NSMutableArray *magzines;
@property(nonatomic,assign)  NSInteger lastIndex ;

- (id)initWithFrame:(CGRect)frame controller:(id)controller;
- (void) reloadData;
- (KSModelMagzine *)currentMagazine;
-(void)whenMagzinePurchased:(NSInteger)magazineId;
-(void)reloadDataWithMagazines:(NSMutableArray*)magazs;
- (void) whenInitOrMagzineListUpdate;
- (void) whenMagzineDownloader:(NSInteger)magzineId;
- (void)whenMagzineCover0Download:(NSInteger)magzineId;
- (void) whenMagzineCover1Download:(NSInteger)magzineId;
- (void)whenMagzineDeleted:(KSModelMagzine*)magazine ;
-(void)loadMagazineByYear:(NSMutableArray*)magazines;
-(void)selectYear:(NSInteger)selectYear;
-(void)loadSubViewsWithIndex:(NSInteger)page;
@end
