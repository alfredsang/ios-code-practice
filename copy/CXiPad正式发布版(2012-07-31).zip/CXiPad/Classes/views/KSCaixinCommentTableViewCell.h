//
//  KSCaixinCommentTableViewCell.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 2/10/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSModelComment.h"

@class KSModelComment;
@interface KSCaixinCommentTableViewCell : UITableViewCell {
    KSModelComment *_comment;
    UILabel *_timeLabel;
}
@property(nonatomic, retain)KSModelComment *comment;

- (id)initWithComment:(KSModelComment *)mcomment reuseIdentifier:(NSString *)reuseIdentifier;

@end
