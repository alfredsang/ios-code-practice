//
//  KSAppRecommendView.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-7.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSAppRecommendView.h"

@implementation KSAppRecommendView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}
- (void)awakeFromNib {
    
    self.scrollEnabled = NO;
}
- (void)layoutSubviews {
    if ([UIUtil currentOrientation] == 0) {
        [self viewWithTag:1010].frame = CGRectMake(20, 166, 68, 23);
        [self viewWithTag:1011].frame = CGRectMake(8, 46, 93, 112);
        [self viewWithTag:1012].frame = CGRectMake(114, 39, 280, 35);
        [self viewWithTag:1013].frame = CGRectMake(114, 74, 280, 20);
        [self viewWithTag:1014].frame = CGRectMake(114, 102, 280, 50);
        
        [self viewWithTag:1020].frame = CGRectMake(20, 362, 68, 23);
        [self viewWithTag:1021].frame = CGRectMake(8, 217, 93, 139);
        [self viewWithTag:1022].frame = CGRectMake(114, 210, 280, 35);
        [self viewWithTag:1023].frame = CGRectMake(114, 247, 280, 20);
        [self viewWithTag:1024].frame = CGRectMake(114, 275, 280, 128);
        
        [self viewWithTag:1030].frame = CGRectMake(20, 555, 68, 23);
        [self viewWithTag:1031].frame = CGRectMake(8, 435, 93, 112);
        [self viewWithTag:1032].frame = CGRectMake(114, 426, 280, 35);
        [self viewWithTag:1033].frame = CGRectMake(114, 461, 280, 20);
        [self viewWithTag:1034].frame = CGRectMake(114, 489, 280, 50);
        
        
    } else {
        [self viewWithTag:1010].frame = CGRectMake(26, 173, 68, 23);
        [self viewWithTag:1011].frame = CGRectMake(14, 53, 93, 112);
        [self viewWithTag:1012].frame = CGRectMake(120, 53, 280, 35);
        [self viewWithTag:1013].frame = CGRectMake(120, 88, 280, 20);
        [self viewWithTag:1014].frame = CGRectMake(120, 116, 460, 50);
        
        [self viewWithTag:1020].frame = CGRectMake(26, 388, 68, 23);
        [self viewWithTag:1021].frame = CGRectMake(14, 244, 93, 139);
        [self viewWithTag:1022].frame = CGRectMake(120, 236, 280, 35);
        [self viewWithTag:1023].frame = CGRectMake(120, 273, 280, 20);
        [self viewWithTag:1024].frame = CGRectMake(120, 301, 460, 100);
        
        NSInteger increaseHeight = 225;
        [self viewWithTag:1030].frame = CGRectMake(26, 360+increaseHeight, 68, 23);
        [self viewWithTag:1031].frame = CGRectMake(14, 244+increaseHeight, 93, 112);
        [self viewWithTag:1032].frame = CGRectMake(120, 236+increaseHeight, 280, 35);
        [self viewWithTag:1033].frame = CGRectMake(120, 273+increaseHeight, 280, 20);
        [self viewWithTag:1034].frame = CGRectMake(120, 301+increaseHeight, 460, 50);
    }
    self.contentSize = CGSizeMake(self.width, [self viewWithTag:1034].bottom +30);
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (IBAction)goAppStore:(id)sender {
    NSInteger tag = [(UIView *)sender tag];
    NSString *url = @"itms-apps://itunes.apple.com/cn/app//id356023612?l=en&mt=8";
    if (tag == 1010) {
        
    } else if(tag == 1020) {
        url = @"itms-apps://itunes.apple.com/cn/app/caixin-weekly-china-economics/id428891893?l=en&mt=8";
    } else {
        url = @"itms-apps://itunes.apple.com/cn/app/caixin-online/id376148950?mt=8";
    }
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:url]];
}
@end
