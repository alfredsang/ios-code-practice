//
//  KSNoPermissionAlertView.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 3/17/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KSNoPermissionAlertView.h"
#import "KSMainController.h"
#import "KSMagzineViewController.h"
#import "KSArticleViewController.h"

@implementation KSNoPermissionAlertView
@synthesize delegate = _delegate;

- (void)dealloc {
    [KSBootstrap unlisten:self];
    [_magazine release];
    [_bgView release];
    [_imageView release];
    [_loginBtn release];
    [_subscriptionBtn release];
    [_buyBtn release];
    [_tipLabel release];
//    [_cancelBtn release];
    [super dealloc];
}

- (void)initSubviews {
    self.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    self.backgroundColor = [UIColor clearColor];
    _bgView = [[KSTapableView alloc] initWithFrame:self.bounds];
    _bgView.tapDelegate = self;
    [self addSubview:_bgView];
    
    _imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0,0,440,216)];
    _imageView.image = [UIImage imageNamed:@"bg_nopermission.png"];
    _imageView.userInteractionEnabled = YES;
    [self addSubview:_imageView];
    
    _tipLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 65, _imageView.width, 60)];
    _tipLabel.backgroundColor = [UIColor clearColor];
    _tipLabel.textColor = [UIColor whiteColor];
    _tipLabel.font = [UIFont systemFontOfSize:20.0f];
    _tipLabel.textAlignment = UITextAlignmentCenter;
    _tipLabel.text = @"更多精彩阅读，请选择";
    [_imageView addSubview:_tipLabel];
    //40,25
    _loginBtn = [[UIButton alloc] initWithFrame:CGRectMake(24, 135, 100, 30)];
    [_loginBtn setBackgroundImage:[UIImage imageNamed:@"permission_btn_login.png"] forState:UIControlStateNormal];

    [_loginBtn addTarget:self action:@selector(doLogin) forControlEvents:UIControlEventTouchUpInside];
    [_imageView addSubview:_loginBtn];
    
    _subscriptionBtn = [[UIButton alloc] initWithFrame:CGRectMake(_loginBtn.right+34, _loginBtn.top, 100, 30)];
    [_subscriptionBtn setBackgroundImage:[UIImage imageNamed:@"permission_btn_discu.png"] forState:UIControlStateNormal];

    [_subscriptionBtn addTarget:self action:@selector(doSubscription) forControlEvents:UIControlEventTouchUpInside];
    [_imageView addSubview:_subscriptionBtn];
    
    _buyBtn = [[UIButton alloc] initWithFrame:CGRectMake(_subscriptionBtn.right+34, _loginBtn.top, 100, 30)];
    [_buyBtn setBackgroundImage:[UIImage imageNamed:@"permission_btn_buy.png"] forState:UIControlStateNormal];

    [_buyBtn addTarget:self action:@selector(doBuy) forControlEvents:UIControlEventTouchUpInside];
    [_imageView addSubview:_buyBtn];
    
    _cancelBtn = [[UIButton alloc] initWithFrame:CGRectMake(_imageView.width-54, 5, 44, 44)];

    _cancelBtn.showsTouchWhenHighlighted = YES;
    [_cancelBtn addTarget:self action:@selector(cancel) forControlEvents:UIControlEventTouchUpInside];
    [_imageView addSubview:_cancelBtn];
    
}
- (id)initWithFrame:(CGRect)frame magazine:(KSModelMagzine *)mag {
    self = [super initWithFrame:frame];
    if (self) {
        _magazine = [mag retain];
        [self initSubviews];
    }
    return self;
}

- (void)layoutSubviews {
    _imageView.center = self.center;
    if ([KSBootstrap currentUser]) {
        _loginBtn.hidden = YES;
//        _cancelBtn.hidden = NO;
        _subscriptionBtn.left = 55;
        _buyBtn.right = _imageView.width-55;
//        _cancelBtn.left = _buyBtn.right+30;
    } else {
        _loginBtn.hidden = NO;
        _subscriptionBtn.centerX = _imageView.width/2;
        _loginBtn.right = _subscriptionBtn.left-34;
        _buyBtn.left = _subscriptionBtn.right + 34;
//        _cancelBtn.hidden = YES;
    }
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/
#pragma mark -
- (void)doLogin {
    if (![self.viewController isKindOfClass:[KSMagzineViewController class]]) {
        [[KSMainController mainController] presentMagzineViewController];
    } else {
        [((KSMagzineViewController *)[[KSMainController mainController] activeController]) dismissNoPermissionView];
    }
    [((KSMagzineViewController *)[[KSMainController mainController] activeController]) showLogin];
}
- (void)doSubscription {

    if (![self.viewController isKindOfClass:[KSMagzineViewController class]]) {
        [[KSMainController mainController] presentMagzineViewController];
    } else {
        [((KSMagzineViewController *)[[KSMainController mainController] activeController]) dismissNoPermissionView];
    }
    UIViewController *controller = (UIViewController*)[[KSMainController mainController] activeController];
    [KSAppStoreProxy subscribe:12 fromView:controller.view];

//    [((KSMagzineViewController *)[[KSMainController mainController] activeController]) showSubscriptionView];
}
- (void)doBuy {
    if (!_magazine.isMybook) {
        if ([_delegate respondsToSelector:@selector(beforeDoBuy:)]) {
            [_delegate beforeDoBuy:self];
        }
        [KSBootstrap listen:NOTIFY_PURCHASE_COMPLETED target:self selector:@selector(magazinePuchased:)];
        [KSAppStoreProxy buy:_magazine fromView:self];
    }
    //[((KSMagzineViewController *)[[KSMainController mainController] activeController]) dismissNoPermissionView];
}

#pragma mark -
- (void)didTapped {
    //[self removeFromSuperview];
}

-(void)cancel
{    [(KSArticleViewController *)self.viewController dismissNoPermissionView];

//    [self didTapped];
}

#pragma mark -
- (void)magazinePuchased:(NSNotification *)notify {
    NSDictionary *userInfo = [notify userInfo];
    NSString *type = [userInfo valueForKey:@"type"];
    if([@"buy" isEqualToString:type]){
        if ([_delegate respondsToSelector:@selector(afterDoBuy:)]) {
            [_delegate afterDoBuy:self];
        }
//        KSArticleViewController *c = (KSArticleViewController *)self.viewController;
//        if ([c isKindOfClass:[KSArticleViewController class]]) {
//            [UIUtil showMsgAlertWithTitle:@"购买成功" message:@"现在可以阅读全部文章"];
//            KSArticleViewController *controller = (KSArticleViewController *)self.viewController;
//            controller.currentMagzine.isPurchased = YES;
//            [controller reloadData];
//            [c dismissNoPermissionView];
//        }
        //[controller gotoArticleId:controller.currentArticle.articleId];
    }
    [KSBootstrap unlisten:self];
}
@end
