//
//  KSMagzineBackgroundView.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-7.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSMagzineBackgroundView.h"
@implementation KSMagzineBackgroundView
- (id) initWithFrame:(CGRect)frame{
    if(self=[super initWithFrame:frame]){
        self.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    }
    return self;
}
- (void) layoutSubviews{
    if([UIUtil currentOrientation]==0){
        self.frame = CGRectMake(0, 0, 768, 1024);
        self.image = [UIImage imageNamedNocache:@"bookshelf_bg.png"];
    }else{
        self.frame = CGRectMake(0, 0, 1024, 768);
        self.image = [UIImage imageNamedNocache:@"bookshelf_bg.png"];
    }
}
@end
