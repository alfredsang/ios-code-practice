//
//  KSShelfProgressView.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 4/17/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KSShelfProgressView.h"

@implementation KSShelfProgressView
@synthesize magazine = _magazine;
@synthesize progressView = _progressView;

- (void)dealloc {
    [_progressView release];
    [_progressTextLabel release];
    [_magazine release];
    
    [super dealloc];
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        _progressTextLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.width, self.height-20.0f)];
        _progressTextLabel.backgroundColor = [UIColor clearColor];
        _progressTextLabel.textColor = [UIColor whiteColor];
        _progressTextLabel.textAlignment = UITextAlignmentCenter;
        _progressTextLabel.font = [UIFont systemFontOfSize:9.0f];
        _progressTextLabel.text = @"未下载";
        [self addSubview:_progressTextLabel];
        
//        _progressView = [[KUIProgressView alloc] initWithFrame:CGRectMake(0, _progressTextLabel.bottom+5.0f, self.width, 9)];
//        [_progressView setBackgroundColor:[UIColor clearColor]];
//        [_progressView setTintColor:[UIColor colorWithRed:0.36 green:0.4 blue:0.5 alpha:1]];
//        [self addSubview:_progressView];
        
        _progressView = [[DDProgressView alloc] initWithFrame:CGRectMake(0, _progressTextLabel.bottom+5.0f, self.width, 11)];
        _progressView.innerColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_white_progress.png"]];//[UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_blue_progress.png"]];
        _progressView.outerColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_progress_blue.png"]];
        _progressView.emptyColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_progress_blue.png"]];
        _progressView.layer.cornerRadius = 0.5f * _progressView.height;
        _progressView.clipsToBounds = YES;
        [self addSubview:_progressView];
    }
    return self;
}

//- (void)setTintColor:(UIColor *)aColor {
//    [_progressView setTintColor:aColor];
//}
- (float)progress {
    return _progressView.progress;
}
//- (void)setProgress:(float)progress animated:(BOOL)animated {
//    [_progressView setProgress:progress animated:animated];
//}

- (void)setMagazine:(KSModelMagzine *)magazine {
    [_magazine release];
    _magazine = [magazine retain];
    [self setOriginProgress:magazine.rateDownload];
}


-(void)reStartToDownLoad
{
    [_progressView setProgress:0.0];
    _progressTextLabel.text = @"未下载";
    _magazine.rateDownload = _progressView.progress;

}
-(void)startToDownLoad
{
    _progressTextLabel.text = @"准备下载";
}
- (void)setProgress:(float)progress {
    [_progressView setProgress:progress];
    _progressTextLabel.text = [NSString stringWithFormat:@"下载中 %d%%",(int)(progress*100)];
    KSDINFO(@"%F",progress);
}

- (void)setOriginProgress:(float)progress 
{
    [_progressView setProgress:progress];
    if (progress == 0) 
    {
        if ([_progressTextLabel.text isEqualToString:@"准备下载"])
        {
            _progressTextLabel.text = [NSString stringWithFormat:@"未下载"];
        }

    } 
    else 
    {
        _progressTextLabel.text = [NSString stringWithFormat:@"已暂停 %d%%",(int)(progress*100)];
    }
     _magazine.rateDownload = _progressView.progress;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
