//
//  KSSettingNoticeView.m
//  CenturyWeeklyV2
//
//  Created by jerry gao on 12-7-20.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import "KSSettingNoticeView.h"

@implementation KSSettingNoticeView
-(id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.backgroundColor = [UIColor clearColor];
//        UILabel *tipLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 50, frame.size.width, 50)];
//        tipLabel.backgroundColor = [UIColor clearColor];
//        tipLabel.font = [UIFont systemFontOfSize:15.0f];
//        tipLabel.numberOfLines = 0;
//        tipLabel.tag = 111;
//        
//        tipLabel.text = @"公告内容";
//        tipLabel.textAlignment = UITextAlignmentCenter;
//        [self addSubview:tipLabel];
//        [tipLabel release];
        
        _theTabelView = [[UITableView alloc] initWithFrame:CGRectMake(0, 20, self.width, self.height-20) style:UITableViewStylePlain];
        _theTabelView.backgroundColor = [UIColor clearColor];
        _theTabelView.delegate = self;
        _theTabelView.dataSource = self;
        _theTabelView.separatorStyle = UITableViewCellSelectionStyleNone;
        [self addSubview:_theTabelView];
        
        _titleDic = [[NSMutableDictionary alloc] init];
        _contentDic = [[NSMutableDictionary alloc] init];
        [CXNoticeRequest requestWithDelegate:self];
    }
    return self;
}
-(void)requestDidFinished:(KSBaseDataRequest *)request
{
//    if (_titleDic)
//    {
//        RELEASE_SAFELY(_titleDic);
//    }
//    if (_contentDic)
//    {
//        RELEASE_SAFELY(_contentDic);
//    }
    NSDictionary *tempTitleDic = [[request.resultDict objectForKey:@"title"] retain];
    NSDictionary *tempContentDic = [[request.resultDict objectForKey:@"proclamation"] retain];
    
//    NSMutableArray *removeIndexs = [[NSMutableArray alloc] init];
    for (int i = 1;i<=[[tempTitleDic allKeys] count];i++)
    {
        if (![[tempTitleDic objectForKey:STR_FORMAT(@"%d",i)] isEqualToString:@""])
        {
            [_titleDic setObject:[tempTitleDic objectForKey:STR_FORMAT(@"%d",i)] forKey:STR_FORMAT(@"%d",i)];
            [_contentDic setObject:[tempContentDic objectForKey:STR_FORMAT(@"%d",i)] forKey:STR_FORMAT(@"%d",i)];
        }
    }
    [tempContentDic release];
    [tempTitleDic release];
//    for (int i = 0;i<[removeIndexs count]; i++)
//    {
//        NSString *index = [removeIndexs objectAtIndex:i];
//        [_titleDic removeObjectForKey:index];
//        [_contentDic removeObjectForKey:index];
//    }
    [_theTabelView reloadData];
}

-(void)requestDidFailed:(KSBaseDataRequest *)request withError:(NSError *)error
{
    
}

-(void)reloadCellData:(NSInteger)row cell:(UITableViewCell*)cell
{
    UILabel *titleLabel = (UILabel*)[cell viewWithTag:100];
    UILabel *contentLabel = (UILabel*)[cell viewWithTag:200];
    UIImageView *line = (UIImageView*)[cell viewWithTag:300];
    titleLabel.text = [_titleDic  objectForKey:STR_FORMAT(@"%d",row+1)];
    contentLabel.text = [_contentDic  objectForKey:STR_FORMAT(@"%d",row+1)];
    
    CGSize size = [contentLabel.text sizeWithFont:[UIFont boldSystemFontOfSize:15] constrainedToSize:CGSizeMake(contentLabel.width, MAXFLOAT) lineBreakMode:UILineBreakModeCharacterWrap];
    contentLabel.size = size;
    line.hidden = NO;
    if (row == [[_titleDic allKeys] count]-1)
    {
        line.hidden = YES;
    }
    line.top = contentLabel.bottom+30;
    
}
#define LEFT_MARGIN 30
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[_titleDic allKeys] count];
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *title = [_titleDic  objectForKey:STR_FORMAT(@"%d",[indexPath row]+1)];
    NSString *content = [_contentDic  objectForKey:STR_FORMAT(@"%d",[indexPath row]+1)];
    
    CGFloat titleHeight = [title sizeWithFont:[UIFont boldSystemFontOfSize:18] constrainedToSize:CGSizeMake(tableView.width-LEFT_MARGIN*2, MAXFLOAT) lineBreakMode:UILineBreakModeCharacterWrap].height;
    CGFloat contentHeight = [content sizeWithFont:[UIFont boldSystemFontOfSize:15] constrainedToSize:CGSizeMake(tableView.width-LEFT_MARGIN*2, MAXFLOAT) lineBreakMode:UILineBreakModeCharacterWrap].height;
    
    return titleHeight+contentHeight+30*3;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"used";
    UITableViewCell *cell = (UITableViewCell*)[tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell==nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier] autorelease];
        
        UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(LEFT_MARGIN, 30, tableView.width-LEFT_MARGIN*2, 20)];
        titleLabel.backgroundColor = [UIColor clearColor];
        titleLabel.font = [UIFont boldSystemFontOfSize:18];
//        titleLabel.textAlignment = UITextAlignmentCenter;
        titleLabel.tag = 100;
        [cell addSubview:titleLabel];
        [titleLabel release];
        
        UILabel *contentLabel = [[UILabel alloc] initWithFrame:CGRectMake(LEFT_MARGIN, titleLabel.bottom+30, tableView.width-LEFT_MARGIN*2, 20)];
        contentLabel.backgroundColor = [UIColor clearColor];
        contentLabel.font = [UIFont systemFontOfSize:15];
        contentLabel.numberOfLines = 0;
        contentLabel.tag = 200;
        [cell addSubview:contentLabel];
        [contentLabel release];
        
        UIImageView *line = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"directory_line.png"]];
        line.contentMode = UIViewContentModeScaleToFill;
        line.frame = CGRectMake(LEFT_MARGIN, contentLabel.bottom+30, contentLabel.width, 3);
        line.tag = 300;
        [cell addSubview:line];
        [line release];
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    [self reloadCellData:[indexPath row] cell:cell];
    return cell;
}

-(void)dealloc
{
    RELEASE_SAFELY(_titleDic);
    RELEASE_SAFELY(_contentDic);
//    RELEASE_SAFELY(_dataDic);
    RELEASE_SAFELY(_theTabelView);
    [super dealloc];
}
@end
