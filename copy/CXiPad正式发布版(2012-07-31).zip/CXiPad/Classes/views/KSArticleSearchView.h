//
//  KSArticleSearchView.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 1/6/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSTapableView.h"
#import "KSModelSearchItem.h"
#import "KSUrlRequest.h"
#import "KSNoPermissionAlertView.h"

#define SEARCH_ARTICLE_URL SURL_PREFIX(@"search", @"%d/%@/%d/%@")

@class KSArticleViewController;
@interface KSArticleSearchView : UIView<KSTapableDelegate,KSUrlRequestDelegate,UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate,KSNoPermissionAlertViewDelegate> {
    KSTapableView *_tapableView;
    UITableView *_tableView;
    UITextField *_searchTextField;
    UILabel *_resutTextLabel;
    UIActivityIndicatorView *_indicatorView;
    NSInteger _currentMagazineId;
    
    KSArticleViewController *_controller;
    
    KSUrlRequest *_request;
    NSMutableArray *_searchItemList;
    NSInteger _page;
    NSInteger _pageSize;
    NSInteger _totalPage;
    NSInteger _totalRecord;
    BOOL _hasMorePage;
    BOOL _loadingMore;
    
}
@property(nonatomic, assign)KSArticleViewController *controller;


@end
