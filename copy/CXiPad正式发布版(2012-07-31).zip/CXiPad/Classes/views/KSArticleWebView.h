//
//  KSArticleWebView.h
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSModelArticle.h"
#import "KSViewInitor.h"
#import "KSArticleVideoView.h"
#import "KSArticleSlideShowView.h"
#import "KSWebViewController.h"
#import "KSArticleViewController.h"
#import "KSArticleIndexable.h"

@class KSArticleViewController;

@interface KSArticleWebView : UIView<KSViewInitor, KSArticleIndexable, UIWebViewDelegate,UIGestureRecognizerDelegate>{
    UIWebView *_webView;
    KSModelArticle *_article;
    UIPinchGestureRecognizer *pinchGestureRecognizer;
	UILabel *fontScaleLbl;
	NSInteger globalPage;
	NSInteger pagesCount;
	NSInteger orientation;
	float fontScale;
	BOOL isJustClear;
    BOOL _rotating;
    NSInteger _index;
    KSArticleViewController* _handler;
    
    BOOL _isChildren;
}

- (id)initWithFrame:(CGRect)frame article:(KSModelArticle *)article hanlder:(KSArticleViewController *)handler child:(BOOL)isChild;
- (id)initWithFrame:(CGRect)frame article:(KSModelArticle *)article hanlder:(KSArticleViewController *)handler index:(NSInteger)index;
- (void)loadPage;
- (void)slideshow;
- (void)showVideo;
- (void)showPertain;
- (void)showFullScreenVideo;
- (void)openExternalWebView:(NSString *)url;

- (void)locateToLastPage;
- (void)locateToFirstPage;
@end