//
//  KSSearchTableViewCell.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 12/28/11.
//  Copyright (c) 2011 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSModelSearchItem.h"

@interface KSSearchTableViewCell : UITableViewCell {
    KSModelSearchItem *_searchItem;
    UIImageView *_frameImageView;
    UIImageView *_cellImageView;
    UIImageView *_lockImageView;
    UILabel *_timeLabel;
    UILabel *_titleLabel;
}
@property(nonatomic, retain)KSModelSearchItem *searchItem;
@property(nonatomic, retain)UIImageView *cellImageView;

- (id)initWithSearchItem:(KSModelSearchItem *)item reuseIdentifier:(NSString *)reuseIdentifier;

@end
