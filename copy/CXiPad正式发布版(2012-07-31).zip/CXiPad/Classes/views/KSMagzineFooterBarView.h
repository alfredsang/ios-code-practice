//
//  KSMagzineFooterBarView.h
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSStatedIconButton.h"
#import "KSViewInitor.h"

@class KSMagzineViewController;
@interface KSMagzineFooterBarView : UIImageView<KSViewInitor>{
    KSMagzineViewController *_delegate;
    
    UILabel *_usernameLabel;
    UIButton *collect;
    UIButton *search;
    UIButton *setting;
    UIButton *login;
    UIButton *helpBt;
    UIButton *bookShelfBtn;
    UIButton *_usernameButton;
    UIButton *bookStoreBtn;
    UIButton *_restoreBtn;
}

@property(nonatomic,retain)UIButton *bookShelfBtn;
@property(nonatomic,retain)UIButton *bookStoreBtn;


- (id) initWithFrame:(CGRect)frame delegate:(id)delegate;
- (void) logstateChange;
- (void) lightIcon:(NSString *)type;
@end
