//
//  KSArticlePagesScrollView.h
//  CenturyWeeklyV2
//
//  Created by liuyou on 12-1-9.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSViewInitor.h"
#import "KSArticleCoreTextView.h"
#import "KSArticleWebView.h"
#import "KSArticleEmptyPageView.h"
#import "KSArticleDownloadingView.h"
#import "KSArticleUnpurchasedView.h"
#import "KSArticleViewController.h"

@class KSArticleViewController;
@class KSArticleCoreTextView;
@interface KSArticlePagesScrollView : UIView<KSViewInitor, UIScrollViewDelegate,UIGestureRecognizerDelegate>{
    KSArticleViewController *_handler;
    UIScrollView *scrollView;
    NSInteger _current;
    NSInteger _pageNum;
    
    BOOL _shouldGoNext;
    BOOL _scrolling;
    BOOL _roating;
}

- (id)initWithFrame:(CGRect)frame handler:(KSArticleViewController *)handler;
- (void) loadPages:(NSArray *)pages current:(NSInteger)current;

- (KSArticleCoreTextView *)articleCoreTextView;
@end
