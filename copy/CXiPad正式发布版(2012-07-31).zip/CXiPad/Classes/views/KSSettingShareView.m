//
//  KSSettingShareView.m
//  CenturyWeeklyV2
//
//  Created by zyk on 1/8/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KSSettingShareView.h"
#import "KSSettingSinaWeiboTableCell.h"
#import "KSSettingQQWeiboTableCell.h"

@implementation KSSettingShareView
@synthesize parent = _parent;

- (void)dealloc {
    [_tableView release];
    
    [super dealloc];
}
- (void)loadView {
    _tableView = [[UITableView alloc] initWithFrame:self.bounds style:UITableViewStyleGrouped];
//    _tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.scrollEnabled = YES;
    _tableView.backgroundColor = [UIColor clearColor];
    _tableView.backgroundView = nil;
    
    [self addSubview:_tableView];
    
//    _footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.width, 60)];
//    //_footerView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
//    
//    _label = [[UILabel alloc] initWithFrame:CGRectMake(40, 0, 400, 60)];
//    _label.text = @"点击恢复购买，可恢复您 在旧版本《新世纪》App中的购买信息记录，由此可阅读您之前购买的杂志内容。";
//    _label.numberOfLines = 4;
//    _label.font = [UIFont fontWithName:@"Helvetica" size:14.0];
//    _label.textColor = [UIColor colorWithRed:0.298039  green:0.337255 blue:0.423529 alpha:  1];
//    _label.shadowColor = [UIColor colorWithWhite:1 alpha:1];
//    _label.shadowOffset = CGSizeMake(0, 1);
//    _label.textAlignment = UITextAlignmentLeft;
//    _label.backgroundColor = [UIColor clearColor];
//    [_footerView addSubview:_label];
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self loadView];
    }
    return self;
}
//- (void)layoutSubviews {
//
//    [_tableView reloadData];
//}


#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 44;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}
#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 2;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0) {
        KSSettingSinaWeiboTableCell *cell  = (KSSettingSinaWeiboTableCell*) 
        [[[NSBundle mainBundle] loadNibNamed:@"KSSettingSinaWeiboTableCell" 
                                       owner:self options:nil] objectAtIndex:0];
        return cell;
    }else if (indexPath.row == 1) {
    KSSettingQQWeiboTableCell *cell = (KSSettingQQWeiboTableCell*) 
        [[[NSBundle mainBundle] loadNibNamed:@"KSSettingQQWeiboTableCell" 
                                       owner:self options:nil] objectAtIndex:0];
        return cell;
    }
    return nil;
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return @"微博账号管理";
    }
    return nil;
}


@end
