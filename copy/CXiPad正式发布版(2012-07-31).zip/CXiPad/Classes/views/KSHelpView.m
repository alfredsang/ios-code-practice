//
//  KSHelpView.m
//  CenturyWeeklyV2
//
//  Created by 广亮 高 on 12-6-1.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import "KSHelpView.h"

@implementation KSHelpView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}
- (id)initWithFrame:(CGRect)frame handler:(KSMagzineViewController *)handler {
    self = [self initWithFrame:frame];
    if (self) {
        _controller = [handler retain];
        _settingsArray = [[NSArray arrayWithObjects:
                           @"公告",
                           @"使用技巧",
                           @"常见问题",
                           @"关于我们",
                           nil] retain];
        _settingMethodsArray = [[NSArray arrayWithObjects:
                                 @"showNotice",
                                 @"showHelpView",
                                 @"showFaqView",
                                 @"showAboutView",
                                 nil] retain];
        [self loadSubViews];
    }
    return self;
}
-(void)layoutSubviews
{
    [super layoutSubviews];
//    if ([UIUtil currentOrientation] == 0 ) 
//    {
//        
//    }
//    else {
//        _popImageView.image = [UIImage imageNamedNocache:@"pop_help_h.png"];
//        
//    }

}
- (void)loadSubViews 
{
    [super loadSubViews];
    
    self.titleLabel.text = @"帮助";
    
    [self showNotice];
}
- (void)dismiss {
    if ([self.superview isKindOfClass:[KSSettingView class]])
    {
        [self removeFromSuperview];
        [UIUtil addAnimationFade:self];
    }
    else
    {
        if ([super respondsToSelector:@selector(dismiss)])
        {
            [super dismiss];

        }
    }

}
-(void)dealloc
{
//    [_controller release];
//    [_settingHelpView release];
//    [_aboutView release];
//    [_faqView release];
    [super dealloc];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
