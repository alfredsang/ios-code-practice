//
//  KSArticleCoreTextView.m
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSArticleCoreTextView.h"
#import "NSAttributedString+HTML.h"
#import "DTCoreTextFontDescriptor.h"
#import "DTCoreTextParagraphStyle.h"
#import "DTTextAttachment.h"
#import "KSArticleViewController.h"
#import "UIFont+CoreTextExtensions.h"
#import "KSTriggerButton.h"
#import "KSTriggerView.h"
#import "KSArticleHeaderHelper.h"
#import "KSColumnTextView.h"

#define BLOCK_TOP_MARGIN 0
#define BLOCK_LEFT_MARGIN 0


@interface KSArticleCoreTextView()
- (void) initBlocks;
- (void) addControlViewByType:(NSInteger)type inView:(UIView *)view;
- (NSAttributedString*) getContentAttributedString:(float)fontSize;
@end
@implementation KSArticleCoreTextView

- (id)initWithFrame:(CGRect)frame article:(KSModelArticle *)article handler:(KSArticleViewController*)handler index:(NSInteger)index
{
    self = [super initWithFrame:frame];
    if (self) {
        offset = CGPointMake(0, 0);
        currentArticle = [article retain];
        vColumnNum = currentArticle.vcolumns>0?currentArticle.vcolumns:2;
        hColumnNum = currentArticle.hcolumns>0?currentArticle.hcolumns:3;
        _handler = handler;
        _index = index;
        blocks = [[NSMutableDictionary alloc] initWithCapacity:2];
        [self initBlocks];
        self.backgroundColor = [UIColor clearColor];
//        self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        [self initSubviews];
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(decreaseFont) name:NOTIFY_DECREASE_FONT object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(increaseFont) name:NOTIFY_INCREASE_FONT object:nil];
    }
    return self;
}

- (void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_DECREASE_FONT object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_INCREASE_FONT object:nil];
    [multiPageView release];
    [currentArticle release];
    [blocks release];
    [logoView release];
//    [catalogNameView release];
    [catalogNameImageView release];
    [doubleLineView release];
    [super dealloc];
}

- (void)initSubviews{
    //catalogNameView = [[UIImageView alloc] initWithFrame:CGRectMake(35, 34, 400, 30)];
    //catalogNameView.contentMode = UIViewContentModeLeft;
    

    
    
    
    
    doubleLineView = [[UIImageView alloc] initWithFrame:CGRectMake(35, 66+ADD_MARGIN, self.width-70, 6)];
    doubleLineView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    [self addSubview:doubleLineView];
    
    
       
    multiPageView = [[KSPageTextView alloc] initWithFrame:CGRectMake(0, 0, self.width, self.height)];
    multiPageView.backgroundColor = [UIColor clearColor];
    multiPageView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    //multiPageView.columnInset = CGPointMake(14, 19);
    multiPageView.columnInset = CGPointMake(0, 0);
    multiPageView.scrollOffset = CGRectMake(22, 0, 44, 0);
    float fontSize = [[KSDB stringForKey:@"KEY_DEFAULT_FONT_SIZE"] floatValue];
    if (fontSize<=0){
        fontSize = 18.0;
    }
    _defaultFontSize = _fontSize = fontSize;
    _fontScaleRate = fontSize/18.0f;
    
    multiPageView.attributedString = [self getContentAttributedString:fontSize];
    multiPageView.font = nil;
//    multiPageView.font = [UIFont fontWithName:@"Georgia" size:16.0];
    multiPageView.columnCount = [UIUtil currentOrientation]==0 ? vColumnNum : hColumnNum;
    multiPageView.firstCharacterFontsize = 32;
    multiPageView.dataSource = self;
    multiPageView.scrollView.showsVerticalScrollIndicator = NO;
    multiPageView.scrollView.showsHorizontalScrollIndicator = NO;
//    UIPinchGestureRecognizer *pinchRecognizer = [[UIPinchGestureRecognizer alloc] initWithTarget:self 
//                                                                                           action:@selector(changeTextSize:)] ;
//    pinchRecognizer.delegate = self;
//    [multiPageView addGestureRecognizer:pinchRecognizer];
//    [pinchRecognizer release];
    
    //UIPanGestureRecognizer *doubleSwipGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(doubleSwipped:)];
//    UISwipeGestureRecognizer *doubleSwipGesture = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(doubleSwipped:)];
//    doubleSwipGesture.delegate = self;
//    [doubleSwipGesture requireGestureRecognizerToFail:pinchRecognizer];
//    //doubleSwipGesture.minimumNumberOfTouches = 2;
//    doubleSwipGesture.numberOfTouchesRequired = 2;
//    [self addGestureRecognizer:doubleSwipGesture];
//    [doubleSwipGesture release];
    
    [self addSubview:multiPageView];
    
    catalogNameView = [UIButton buttonWithType:UIButtonTypeCustom];
    catalogNameView.frame = CGRectMake(35, 34+ADD_MARGIN, 240, 30);
    [catalogNameView addTarget:_handler action:@selector(showCatalogListView) forControlEvents:UIControlEventTouchUpInside];
    catalogNameView.userInteractionEnabled = YES;
    self.userInteractionEnabled = YES;
    [self addSubview:catalogNameView];
    
    catalogNameImageView = [[UIImageView alloc] initWithFrame:CGRectMake(35, 34+ADD_MARGIN, 240, 30)];
    [self addSubview:catalogNameImageView];
    
    [self refresh];
    
/*
    UIButton *relationButton = [UIButton buttonWithType:UIButtonTypeCustom];
    relationButton.frame = CGRectMake(doubleLineView.width-100, doubleLineView.top+doubleLineView.height+20, 100, 30);
    [relationButton setTitle:@"相关文章" forState:UIControlStateNormal];
    [relationButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [relationButton addTarget:self action:@selector(relationBtPress:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:relationButton];
*/
}


-(void)relationBtPress:(UIButton*)bt
{
    NSString *sql = @"select * from article_relations where id=? order by publish_time asc";
    FMResultSet *rs = [[KSDB db] executeQuery:sql, INTEGER(currentArticle.articleId)];
    while (rs.next)
    {
//        NSDictionary *dict = [rs resultDict];
        
    }
}

- (void) insertBlockOrderByTopAsc:(NSMutableArray*)arr block:(CGRect)rect{
    int insertToIndex = arr.count;
    for (int i=0, n=arr.count; i<n; i++) 
    {
        CGRect item = [[arr objectAtIndex:i] CGRectValue];
        if(item.origin.y>rect.origin.y)
        {
            insertToIndex = i;
            break;
        }
    }
    [arr insertObject:[NSValue valueWithCGRect:rect] atIndex:insertToIndex];
}
- (void) initBlocks{
    //CGFloat moveGap = 0;
    CGFloat moveGap_v = 0;
    CGFloat moveGap_h = 0;
    NSInteger titlePage_v = -1; //竖版标题所在页
    NSInteger titlePage_h = -1; //横版标题所在页
    CGRect titleRect_v = CGRectZero; //竖版标题Rect
    CGRect titleRect_h = CGRectZero; //横版标题Rect
    NSString *sql = @"select * from article_header_blocks where article_id=? order by top asc";
    FMResultSet *rs = [[KSDB db] executeQuery:sql, INTEGER(currentArticle.articleId)];
    while (rs.next) 
    {        
        NSDictionary *dict = rs.resultDict;
        NSString *strPage = [DICT_VAL(dict, @"page") stringValue];
        NSString *strVH = [DICT_VAL(dict, @"is_v") stringValue];
        
        CGRect rect = CGRectMake(DICT_FLOATVAL(dict, @"left") + offset.x, DICT_FLOATVAL(dict, @"top") + offset.y, DICT_FLOATVAL(dict, @"width"), DICT_FLOATVAL(dict, @"height"));
        
        //计算需要微调的高度
        if ([strVH intValue] == 1) {
            titlePage_v = [strPage intValue];
            moveGap_v = [KSArticleHeaderHelper calHeaderMoveGap:currentArticle leftImg:DICT_VAL(dict, @"left_image") rightImg:DICT_VAL(dict, @"right_image") oriRect:rect isV:YES];
            rect.size.height += moveGap_v;
            titleRect_v = rect;
        } 
        else
        {
            titlePage_h = [strPage intValue];
            moveGap_h = [KSArticleHeaderHelper calHeaderMoveGap:currentArticle leftImg:DICT_VAL(dict, @"left_image") rightImg:DICT_VAL(dict, @"right_image") oriRect:rect isV:NO];
            rect.size.height += moveGap_h;
            titleRect_h = rect;
        }
        //
        
        
        NSMutableDictionary *pageBlocks = [blocks objectForKey:strPage];
        if(pageBlocks==nil)
        {
            pageBlocks = [[NSMutableDictionary alloc] initWithCapacity:2];
            [pageBlocks setValue:[NSMutableArray arrayWithCapacity:2] forKey:@"0"];
            [pageBlocks setValue:[NSMutableArray arrayWithCapacity:2] forKey:@"1"];
            [blocks setValue:pageBlocks forKey:strPage];
            [pageBlocks release];
        }
        NSMutableArray *arr = [pageBlocks valueForKey:strVH];
        [self insertBlockOrderByTopAsc:arr block:rect];
        //[arr addObject:[NSValue valueWithCGRect:rect]];
    }
    [rs close];
    sql = @"select * from article_images where article_id=? order by top asc";
    rs = [[KSDB db] executeQuery:sql, INTEGER(currentArticle.articleId)];
    while (rs.next) {
        NSDictionary *dict = rs.resultDict;
        CGRect rect = CGRectMake(DICT_FLOATVAL(dict, @"left") + offset.x, DICT_FLOATVAL(dict, @"top") + offset.y, DICT_FLOATVAL(dict, @"width"), DICT_FLOATVAL(dict, @"height"));
        NSString *strPage = [DICT_VAL(dict, @"page") stringValue];
        NSString *strVH = [DICT_VAL(dict, @"is_v") stringValue];
        NSMutableDictionary *pageBlocks = [blocks objectForKey:strPage];
        
        //将Rect的大小做微调
        CGFloat limitHeight = [strPage intValue]==1?860:606;
        if (moveGap_v>0 && [strVH intValue]==1 && [strPage intValue] == titlePage_v) {//竖版
            if (rect.origin.y >= titleRect_v.origin.y && rect.size.height<=titleRect_v.size.height && (rect.origin.y + rect.size.height) <= (titleRect_v.origin.y + titleRect_v.size.height)) {
                //处理标题图片
                rect.size.height = titleRect_v.origin.y+titleRect_v.size.height-rect.origin.y;
                
            } else if (DICT_FLOATVAL(dict, @"top") >20 && (rect.origin.y < (15.0f+titleRect_v.size.height+titleRect_v.origin.y))) {//左上，右上的图片块的上边距为20.0f
                rect.origin.y += moveGap_v;
                
                if((rect.origin.y+rect.size.height) > limitHeight) rect.size.height -= ((rect.origin.y+rect.size.height)-limitHeight);
            }
        }
        if (moveGap_h>0 && [strVH intValue]==0 && [strPage intValue] == titlePage_h) {//横版
            if (rect.origin.y >= titleRect_h.origin.y && rect.size.height <= titleRect_h.size.height && (rect.origin.y + rect.size.height) <= (titleRect_h.origin.y + titleRect_h.size.height)) {
                //处理标题图片
                rect.size.height = titleRect_h.origin.y+titleRect_h.size.height-rect.origin.y;

            } else if (DICT_FLOATVAL(dict, @"top") >0 && (rect.origin.y < (15.0f+titleRect_h.size.height+titleRect_h.origin.y))) {
                rect.origin.y += moveGap_h;
                if((rect.origin.y+rect.size.height) > limitHeight) rect.size.height -= ((rect.origin.y+rect.size.height)-limitHeight);
            }
        }
        if (moveGap_h == 0 && [strVH intValue]==0 && [strPage intValue] == titlePage_h) {
            if (rect.origin.y == 36) {
                rect.size.height+=20;
            }
        }
        if (moveGap_v == 0 && [strVH intValue]==1 && [strPage intValue] == titlePage_v) {
            if (rect.origin.y == 36) {
                rect.size.height+=20;
            }
        }
        //
        //
        //
        //
        if(pageBlocks==nil){
            pageBlocks = [[NSMutableDictionary alloc] initWithCapacity:2];
            [pageBlocks setValue:[NSMutableArray arrayWithCapacity:2] forKey:@"0"];
            [pageBlocks setValue:[NSMutableArray arrayWithCapacity:2] forKey:@"1"];
            [blocks setValue:pageBlocks forKey:strPage];
            [pageBlocks release];
        }
        NSMutableArray *arr = [pageBlocks valueForKey:strVH];
        [self insertBlockOrderByTopAsc:arr block:rect];
//        [arr addObject:[NSValue valueWithCGRect:rect]];
    }
    [rs close];
}

-(UIImage *)image:(AKOMultiColumnTextView *)textView runRef:(CTRunRef)runRef lineRef:(CTLineRef)lineRef frameRef:(CTFrameRef)frameRef{
    NSDictionary *attributes = (NSDictionary *)CTRunGetAttributes(runRef);
    DTTextAttachment *attachment = [attributes objectForKey:@"DTTextAttachment"];
    if (attachment && [attachment.contents isKindOfClass:[UIImage class]]){
        return (UIImage *)attachment.contents;
    }
    return nil;
}

- (CGRect)placeholder:(AKOMultiColumnTextView*)textView viewForColumn:(NSInteger)column onPage:(NSInteger)page blocksarr:(CGRect *)blocksarr columnRect:(CGRect)columnRect{
//    return CGRectZero;
    NSMutableDictionary *pageDict = [blocks valueForKey:STR_FORMAT(@"%d", page+1)];
    if(!pageDict)return CGRectZero;
    NSMutableArray *arr = [pageDict valueForKey:STR_FORMAT(@"%d", [UIUtil currentOrientation]==0?1:0)];
    if(!arr)return CGRectZero;
    int i = 0;
    
    for (NSValue *rectVal in arr) {
        CGRect rect = [rectVal CGRectValue];
        if(!CGRectIntersectsRect(rect, columnRect))continue;
        blocksarr[i] = CGRectMake(columnRect.origin.x, rect.origin.y, columnRect.size.width, rect.size.height);
        i++;
        if(i>=3)return CGRectZero;
    }
    return CGRectZero;
}
- (void)addSubview:(AKOMultiColumnTextView *)textView onPage:(NSInteger)page{
//    return;
    CGFloat moveGap = 0;
    CGFloat titleViewBottom = 0;
    UIView *headerView = nil;
    UIImageView *logoView2 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"a_foot_logo.png"]];
    //logoView2.frame = CGRectMake(13, self.height-12-72-51, 164, 11);
    //logoView2.frame = CGRectMake(13, self.height-72-51-ADD_MARGIN, 164, 11);
    logoView2.frame = CGRectMake(13, self.height-72-64-ADD_MARGIN, 98, 24);
    logoView2.autoresizingMask = UIViewAutoresizingFlexibleTopMargin;
    [textView addSubview:logoView2];
    [logoView2 release];
    
    NSString *sql = @"select * from article_header_blocks where article_id=? and page=? and is_v=? order by top desc";
    FMResultSet *rs = [[KSDB db] executeQuery:sql, INTEGER(currentArticle.articleId), INTEGER(page+1), INTEGER([UIUtil currentOrientation]==0?1:0)];
    while (rs.next) {
        NSDictionary *dict = rs.resultDict;
        //KSArticleCoreTextHeaderView *view = [[KSArticleCoreTextHeaderView alloc] initWithFrame:CGRectMake(DICT_FLOATVAL(dict, @"left") + offset.x, DICT_FLOATVAL(dict, @"top") + offset.y, DICT_FLOATVAL(dict, @"width"), DICT_FLOATVAL(dict, @"height")) article:currentArticle];
        KSArticleCoreTextHeaderView *view = [[KSArticleCoreTextHeaderView alloc] initWithFrame:CGRectMake(DICT_FLOATVAL(dict, @"left") + offset.x, DICT_FLOATVAL(dict, @"top") + offset.y, DICT_FLOATVAL(dict, @"width"), DICT_FLOATVAL(dict, @"height")) article:currentArticle leftimg:DICT_VAL(dict, @"left_image") rightimg:DICT_VAL(dict, @"right_image")];
        [textView addSubview:view];
        [view release];
        moveGap = view.moveGap;
        titleViewBottom = view.bottom;
        headerView = view;
    }
    [rs close];
    sql = @"select * from article_images where article_id=? and page=? and is_v=? order by top desc";
    rs = [[KSDB db] executeQuery:sql, INTEGER(currentArticle.articleId), INTEGER(page+1), INTEGER([UIUtil currentOrientation]==0?1:0)];
    while (rs.next) 
    {
        NSDictionary *dict = rs.resultDict;
        KSTriggerView *view = [[KSTriggerView alloc] initWithFrame:CGRectMake(DICT_FLOATVAL(dict, @"left")  + offset.x, DICT_FLOATVAL(dict, @"top")  + offset.y, DICT_FLOATVAL(dict, @"width"), DICT_FLOATVAL(dict, @"height"))];
        NSString *title = DICT_VAL(dict, @"title");
        float delta = 0;
        if(title && title.length>0){delta = 24;}
        if (delta > 0 && DICT_FLOATVAL(dict, @"width") < 340) {delta = 36;}
        if(DICT_FLOATVAL(dict, @"top")>0 && view.top + view.height > [textView height] - delta){
            float newheight = [textView height] - delta - view.top;
            if(newheight>0){
                float newwidth = view.width * newheight /view.height;
                view.frame = CGRectMake(view.left, view.top, newwidth, newheight);
            }
        }
        //微调处理
        if (moveGap > 0 && view.top > 20 && titleViewBottom+15.0f > view.top && CGRectIntersectsRect(view.frame, CGRectMake(headerView.origin.x, headerView.origin.y, headerView.size.width, headerView.size.height+15.0f))) {
            view.top += moveGap;
            CGFloat limitHeight = [UIUtil currentOrientation]==0?860:606;
            if(view.bottom > limitHeight) view.height -= (view.bottom-limitHeight);
        }
        //
        view.backgroundColor = [UIColor clearColor];
        [textView addSubview:view];
        [view release];
        
        NSInteger imageHeight = view.height;
        if(title && title.length>0){
            imageHeight -= delta;
            UILabel *labelView = [[UILabel alloc]initWithFrame:CGRectMake(0, imageHeight, view.width, delta+12)];
            labelView.text = DICT_VAL(dict, @"title");
            labelView.font = yahei(12.0);
            labelView.textColor = str2rgb(@"#816a5a");
            labelView.numberOfLines = 3;
            labelView.textAlignment = UITextAlignmentLeft;
            labelView.lineBreakMode = UILineBreakModeWordWrap;
            labelView.backgroundColor = [UIColor clearColor];
            labelView.tag = 2;
            
            [view addSubview:labelView];
            [labelView release];
            
            
        }
        UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, view.width, imageHeight)];
        imageView.contentMode = UIViewContentModeScaleAspectFit;
        NSString *relativePath = DICT_VAL(dict, @"image");
        CGSize newImageSize = imageView.frame.size;
        if (isRetina) {
            newImageSize = CGSizeMake(newImageSize.width * 2, newImageSize.height * 2);
        }
        if([relativePath indexOf:@"http://"]>=0){
            imageView.image = [[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:relativePath]]]  rescaleToSize:newImageSize];
            //imageView.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:relativePath]]];
            view.imagePath = relativePath;
        }else{
            NSString *str = STR_FORMAT(@"%@/%@", currentArticle.filepath, relativePath);
            imageView.image = [[UIImage imageWithContentsOfFile:str] rescaleToSize:newImageSize];
            //imageView.image = [UIImage imageWithContentsOfFile:str];
            view.imagePath = str;
        }
        [view addSubview:imageView];
        [imageView release];
        imageView.tag = 1;
        [self addControlViewByType:DICT_INTVAL(dict, @"controltype") inView:view];
    }
    [rs close];
}
- (void) addControlViewByType:(NSInteger)type inView:(UIView *)view{
    if(type==0)return;
    CGRect frame = CGRectMake(0, 0, view.width, view.height);
    UIImage *image = nil;
    SEL selector = nil;
    switch (type) {
        case 1://slideshow
            image = [UIImage imageNamed:@"icon_slidshow_new.png"];
            frame = CGRectMake(20, view.height - 40 - 49, 49, 49);
            selector = @selector(showSlide:);
            break;
        case 2://video 视频1
            image = [UIImage imageNamed:@"icon_play.png"];
            frame = CGRectMake(20, view.height - 20 - 58 -10, 58, 58);
            selector = @selector(showVideo1:);
            break;
        case 7://video 视频2
            image = [UIImage imageNamed:@"icon_play.png"];
            frame = CGRectMake(20, view.height - 20 - 58 -10, 58, 58);
            selector = @selector(showVideo2:);
            break;
        case 8://video 视频3
            image = [UIImage imageNamed:@"icon_play.png"];
            frame = CGRectMake(20, view.height - 20 - 58 -10, 58, 58);
            selector = @selector(showVideo3:);
            break;
        case 3://别册
        case 4://子文章
            selector = @selector(showChildrenArticles:);
            break;
        case 5://map 显示地图
            selector = @selector(showArticleMapView);
            break;
        case 6://zoom self 放大当前图片
            image = [UIImage imageNamed:@"icon_zoom.png"];
            frame = CGRectMake(20, view.height - 40 - 49, 49, 49);
            selector = @selector(zoomOutImage:);
            break;
        default:
            return;
    }
    UIButton *controlView = [UIUtil newImageButtonWithFrame:frame image:image target:self action:selector];
    controlView.tag = 3;
    [view addSubview:controlView];
    [controlView release];
}


- (void) layoutSubviews{
    if([UIUtil currentOrientation]==0){
        multiPageView.columnCount =  vColumnNum;
        //(0,4)
        //竖2尺寸(35, 72, 698, 903)隔28
        //竖3尺寸(35, 72, 698, 903)隔34
        if(vColumnNum==2){
            multiPageView.columnInset = CGPointMake(14, ARTICLE_COLUMN_INSET_Y);
            multiPageView.scrollOffset = CGRectMake(21, 4+ADD_MARGIN, 42, 4);
            offset = CGPointMake(14, 0);
        }else{
            multiPageView.columnInset = CGPointMake(17, ARTICLE_COLUMN_INSET_Y);
            multiPageView.scrollOffset = CGRectMake(18, 4+ADD_MARGIN, 36, 4);
            offset = CGPointMake(17, 0);
        }
    }else{
        multiPageView.columnCount =  hColumnNum;
        //(0,0)
        //横3尺寸(35, 72, 955, 645)隔26
        //横4尺寸(34, 72, 956, 645)隔32
        if(hColumnNum==3){
            multiPageView.columnInset = CGPointMake(13, ARTICLE_COLUMN_INSET_Y);
            multiPageView.scrollOffset = CGRectMake(22, ADD_MARGIN, 43, 0);
            offset = CGPointMake(13, 0);
        }else{
            multiPageView.columnInset = CGPointMake(16, ARTICLE_COLUMN_INSET_Y);
            multiPageView.scrollOffset = CGRectMake(18, ADD_MARGIN, 36, 0);
            offset = CGPointMake(16, 0);
        }
    }
//    offset = CGPointMake(offset.x, offset.y + 72);
    CGRect tmpScrollOffset = multiPageView.scrollOffset;
    multiPageView.scrollOffset = CGRectMake(tmpScrollOffset.origin.x, tmpScrollOffset.origin.y+72, tmpScrollOffset.size.width, tmpScrollOffset.size.height + 72 + 51);
    [multiPageView setNeedsDisplay];
    if([UIUtil currentOrientation]==0){
        doubleLineView.width = 698;
        doubleLineView.image = [UIImage imageNamedNocache:@"a_double_line_v.png"];
    }else{
        doubleLineView.width = 1024-67;
        doubleLineView.image = [UIImage imageNamedNocache:@"a_double_line_h.png"];
    }
}

- (void)refresh{
//    RELEASE_SAFELY(currentArticle);
//    currentArticle = [[_handler currentArticle] retain];
    NSString *background = [[KSDB db] stringForQuery:@"select background from article_templates where type=? and article_id=? limit 1", @"header", INTEGER(currentArticle.articleId)];
    if(background!=nil)
    {
        UIImage *image = [UIImage imageWithContentsOfFile:STR_FORMAT(@"%@/%@", [currentArticle articlePath], background)];
        catalogNameImageView.hidden = NO;
        [catalogNameImageView setImage:image];
        [self sendSubviewToBack:catalogNameImageView];
        catalogNameView.hidden = NO;
    }
    else
    {
        catalogNameImageView.hidden = YES;
        catalogNameView.hidden = YES;
    }
//    [self setNeedsLayout];
}


- (void)locateToLastPage {
    [multiPageView locateEndPage];
}
- (void)locateToFirstPage {
    [multiPageView locateFirstPage];
}
#pragma mark -
#pragma mark Gesture recognizer methods

- (void)changeTextSize:(UIPinchGestureRecognizer *)recognizer
{
    if (recognizer.state == UIGestureRecognizerStateBegan)
    {
        _previousScale = recognizer.scale;
    }
    else if (recognizer.state == UIGestureRecognizerStateChanged)
    {
    }else if (recognizer.state == UIGestureRecognizerStateEnded){
        _fontSize = MAX(MIN(roundf(_fontSize * recognizer.scale/_previousScale), 36), 12);
        //NSLog(@"%f,%f,%f", _fontSize, recognizer.scale, _previousScale);
        multiPageView.attributedString = [self getContentAttributedString:_fontSize];
        [multiPageView setNeedsDisplay];
    }
}
- (void)resetFont {
    if (_fontSize == 18.0f) return;
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    _fontSize = 18.0f;
    multiPageView.attributedString = [self getContentAttributedString:_fontSize];
    [multiPageView setNeedsDisplay]; 
    [pool release];
}
- (void)increaseFont {
    if (_fontSize == 36.0) return;
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    _fontSize = MIN(36.0, _fontSize+2);
    //[multiPageView increaseFont:_fontSize];
    
    multiPageView.attributedString = [self getContentAttributedString:_fontSize];
    [multiPageView setNeedsDisplay];
    [pool release];
}
- (void)decreaseFont {
    if (_fontSize == 12.0f) return;
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    _fontSize = MAX(12.0f, _fontSize-2.0);
    multiPageView.attributedString = [self getContentAttributedString:_fontSize];
    [multiPageView setNeedsDisplay];
    [pool release];
}
- (void) showVideo1:(id)target{
    [_handler showArticleVideo:currentArticle.articleId vIndex:1 full:YES];
}
- (void) showVideo2:(id)target{
    [_handler showArticleVideo:currentArticle.articleId vIndex:2 full:YES];
}
- (void) showVideo3:(id)target{
    [_handler showArticleVideo:currentArticle.articleId vIndex:3 full:YES];
}

- (void) showSlide:(id)target{
    [_handler showArticleSlide:currentArticle.articleId];
}
- (void)showChildrenArticles:(id)target {
    [_handler showChildArticles:currentArticle];
}
- (void)showArticleMapView {
    [_handler showArticleMapView:currentArticle];
}
- (void) zoomOutImage:(id)target{
    UIView *controlView = (UIView *)target;
    KSTriggerView *triggerView = (KSTriggerView *)controlView.superview;
    //UIImageView *imageView = (UIImageView *)[controlView.superview viewWithTag:1];
    UILabel *labelView = (UILabel *)[controlView.superview viewWithTag:2];
    //NSDictionary *imageDict = [NSDictionary dictionaryWithObjectsAndKeys:imageView.image, @"image", labelView.text, @"title",nil];
    NSDictionary *imageDict = [NSDictionary dictionaryWithObjectsAndKeys:triggerView.imagePath, @"image", labelView.text, @"title",nil];
    [_handler showSlide:[NSArray arrayWithObject:imageDict]];
}

- (NSAttributedString*)getContentAttributedString:(float)fontSize{
    //CGFloat rate = (fontSize/_defaultFontSize);
    _defaultFontSize = fontSize;
    [KSDB saveString:[NSString stringWithFormat:@"%.0f",fontSize] forKey:KEY_DEFAULT_FONT_SIZE];
     
    KSModelArticle *newArticle = [KSModelArticle loadById:currentArticle.articleId withContent:YES];
    NSString *content = [newArticle.content stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if(!content){
        content = @"";
    }
    NSURL *baseUrl = [NSURL fileURLWithPath:[newArticle articlePath] isDirectory:YES];//[newArticle articlePath];
    KSDINFO(@"%@", baseUrl);
    //NSString *styles = STR_FORMAT(@"line-height1:%fpx;color:#000000;font-size:%fpx;font-family:STSong", fontSize+12, fontSize);
    NSString *styles = STR_FORMAT(@"color:#373737;font-size:%fpx;font-family:%@", fontSize, ARTICLE_DEFAULT_FONT_FAMILY);
    //NSString *styles = STR_FORMAT(@"color:#333333;font-size:%fpx;font-family:FZDBSJW--GB1-0",  fontSize);
    //
    if([content length]>0){
        content = STR_FORMAT(@"<div style=\"%@\">%@</div>", styles, content);
    }
	// Create attributed string from HTML
//    NSDictionary *options = [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithFloat:1.0*(fontSize+6)/fontSize], DTDefaultLineHeightMultiplier, baseUrl, NSBaseURLDocumentOption,
//                             [NSValue valueWithCGSize:CGSizeMake((768.0/vColumnNum>1024.0/hColumnNum?768.0/vColumnNum:1024.0/hColumnNum)-20, 900)], DTMaxImageSize,
//                             nil]; // @"green",DTDefaultTextColor,
    NSDictionary *options = [NSDictionary dictionaryWithObjectsAndKeys:
                             baseUrl, NSBaseURLDocumentOption,
                             ARTICLE_FONT_COLOR,DTDefaultTextColor,
                             [NSNumber numberWithFloat:1.4],DTDefaultLineHeightMultiplier,
                             //[NSNumber numberWithFloat:18.0], DTDefaultFontSize,
                             [NSNumber numberWithFloat:_fontSize/18.0f], NSTextSizeMultiplierDocumentOption,
                             //[NSNumber numberWithFloat:1.0], NSTextSizeMultiplierDocumentOption,
                             ARTICLE_DEFAULT_FONT_FAMILY, DTDefaultFontFamily,
                             ARTICLE_DEFAULT_FONT_NAME, DTDefaultFontName,
                             [NSValue valueWithCGSize:CGSizeMake((768.0/vColumnNum>1024.0/hColumnNum?768.0/vColumnNum:1024.0/hColumnNum)-25, 600)], DTMaxImageSize,
                             nil];
    NSMutableAttributedString *attrString = [[NSMutableAttributedString alloc] initWithHTMLStr:content options:options documentAttributes:nil];
    
//    NSRange range = NSMakeRange(0, [attrString length]);
//    CTFontRef f = [UIFont fontWithName:ARTICLE_DEFAULT_FONT_NAME size:_fontSize].CTFont;
//    if (f == NULL) {
//        f = [UIFont fontWithName:@"Helvetica" size:_fontSize].CTFont;
//    }
//    [attrString addAttribute:(NSString *)kCTFontAttributeName value:(id)f range:range];
//    if (f!=NULL) CFRelease(f); 
    
//    if (attrString && rate != 1) {
//        [attrString enumerateAttributesInRange:NSMakeRange(0, [attrString length]) options:NSAttributedStringEnumerationReverse usingBlock:^(NSDictionary *attrs, NSRange range, BOOL *stop) {
//            //NSLog(@"%@",attrs);
//            CTFontRef f = (CTFontRef)[attrs objectForKey:(NSString *)kCTFontAttributeName];
//            CTFontRef newFontRef = CTFontCreateCopyWithAttributes(f, CTFontGetSize(f)*rate,nil,nil);
//            NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithDictionary:attrs];
//            [dict setObject:(id)newFontRef forKey:(NSString *)kCTFontAttributeName];
//            CFRelease(newFontRef);
//            [attrString setAttributes:dict range:range];
////            if (range.length >= [attrString length]) {
////                *stop = YES;
////            }
//        }];
//    }
    [DTCoreTextFontDescriptor clearCache];
    [DTCoreTextParagraphStyle clearCache];
    return [attrString autorelease];
}
- (NSInteger)getIndex{
    return _index;
}

#pragma mark - UIGestureRecognizerDelegate
//- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
//    if ([gestureRecognizer isKindOfClass:[UIPinchGestureRecognizer class]]) {
//        if (touch.tapCount == 2) {
//            return YES;
//        }
//    }
//    return NO;
//}

- (void)doubleSwipped:(UIPanGestureRecognizer *)gesture {
    if (gesture.state == UIGestureRecognizerStateBegan) {
        multiPageView.scrollEnabled = NO;
    } else if(gesture.state == UIGestureRecognizerStateChanged){
        CGPoint p = [gesture translationInView:gesture.view];
        if (p.x < 0)
            _shouldGoNext = YES;
        else
            _shouldGoNext = NO;
    } else if(gesture.state == UIGestureRecognizerStateEnded) {
        //[self performSelector:@selector(didDoubleSwipped) withObject:nil afterDelay:0];
        multiPageView.scrollEnabled = YES;
        if (_shouldGoNext) {
            [_handler gotoNextPage];
        } else {
            [_handler gotoPrevPage];
        }
    }
}
#pragma mark - UIGestureRecognizerDelegate
- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer {
    return YES;
}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer{
    return YES;
}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch{
    return YES;
}
@end
