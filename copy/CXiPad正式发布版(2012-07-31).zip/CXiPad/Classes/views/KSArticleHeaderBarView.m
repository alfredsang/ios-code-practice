//
//  KSArticleHeaderBarView.m
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "KSArticleHeaderBarView.h"
#import "KSModelCollectionItem.h"
#import "KSArticleViewController.h"

@implementation KSArticleHeaderBarView
@synthesize btnShare;

- (id)initWithFrame:(CGRect)frame handler:(KSArticleViewController *)handler
{
	if (self = [super initWithFrame:frame]) {
        _handler = handler;
		self.backgroundColor = [UIColor clearColor];
		self.autoresizingMask = UIViewAutoresizingFlexibleWidth;
		[self initSubviews];
	}
	return self;
}

- (void) initSubviews{
    btnBack = [UIUtil createImageButtonWithFrame:CGRectMake(34, 0, 46, 44) image:[UIImage imageNamed:@"a_btn_back.png"] target:_handler action:@selector(backToMagzineView)];
	[self addSubview:btnBack];
    btnBack.showsTouchWhenHighlighted = YES;
    
	btnCatalog = [UIUtil createImageButtonWithFrame:CGRectMake(btnBack.right+18, 0, 46, 44) image:[UIImage imageNamed:@"a_btn_catalog.png"] target:_handler action:@selector(backToCatalog)];
	[self addSubview:btnCatalog];
    btnCatalog.showsTouchWhenHighlighted = YES;
    
    btnComment = [UIUtil createImageButtonWithFrame:CGRectMake(btnCatalog.right+18, 0, 51, 44) image:[UIImage imageNamed:@"a_btn_comment.png"] target:_handler action:@selector(openCommentView)];
	[self addSubview:btnComment];
    btnComment.showsTouchWhenHighlighted = YES;
    
	btnShare = [UIUtil createImageButtonWithFrame:CGRectMake(btnComment.right+18, 0, 50, 44) image:[UIImage imageNamed:@"a_btn_share.png"] target:_handler action:@selector(shareToWeibo)];
	[self addSubview:btnShare];
    btnShare.showsTouchWhenHighlighted = YES;
    
	btnCollect = [UIUtil createImageButtonWithFrame:CGRectMake(btnShare.right+18, 0, 49, 44) image:[UIImage imageNamed:@"a_btn_collect.png"] target:self action:@selector(collectThis)];
	[self addSubview:btnCollect];
    btnCollect.showsTouchWhenHighlighted = YES;
    
	btnSearch = [UIUtil createImageButtonWithFrame:CGRectMake(btnCollect.right+18, 0, 49, 44) image:[UIImage imageNamed:@"a_btn_search.png"] target:_handler action:@selector(searchThis)];
	[self addSubview:btnSearch];
    btnSearch.showsTouchWhenHighlighted = YES;
    
	btnHelp = [UIUtil createImageButtonWithFrame:CGRectMake(btnSearch.right+18, 0, 39, 44) image:[UIImage imageNamed:@"a_btn_help.png"] target:_handler action:@selector(showHelp:)];
	[self addSubview:btnHelp];
    btnHelp.showsTouchWhenHighlighted = YES;
    
    btnDecreaseFont = [UIUtil createImageButtonWithFrame:CGRectMake(self.width-210, 0, 39, 44) image:[UIImage imageNamed:@"a_btn_T-.png"] target:_handler action:@selector(decreaseFont)];
    [self addSubview:btnDecreaseFont];
    btnDecreaseFont.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
    btnDecreaseFont.showsTouchWhenHighlighted = YES;
    
    btnDefaultFont = [UIUtil createImageButtonWithFrame:CGRectMake(self.width-165, 0, 39, 44) image:[UIImage imageNamed:@"a_btn_T.png"] target:_handler action:@selector(resetFont)];
    [self addSubview:btnDefaultFont];
    btnDefaultFont.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
    btnDefaultFont.showsTouchWhenHighlighted = YES;
    
    btnIncreaseFont = [UIUtil createImageButtonWithFrame:CGRectMake(self.width-120, 0, 39, 44) image:[UIImage imageNamed:@"a_btn_T+.png"] target:_handler action:@selector(increaseFont)];
    [self addSubview:btnIncreaseFont];
    btnIncreaseFont.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
    btnIncreaseFont.showsTouchWhenHighlighted = YES;

    
/////////////////////////////////////////////////
//
/////////////////////////////////////////////////    
	btnPizhu = [UIUtil createImageButtonWithFrame:CGRectMake(btnHelp.right+37, 0, 49, 44) image:[UIImage imageNamed:@"a_btn_pizhu.png"] target:_handler action:@selector(pizhuThis)];
	[self addSubview:btnPizhu];
    UIImageView *pizhuShadow = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"a_btn_pizhu_shadow.png"]];
    pizhuShadow.frame = CGRectMake(btnPizhu.left, btnPizhu.bottom, 49, 18);
    [self addSubview:pizhuShadow];
    [pizhuShadow release];
	btnBluePen = [UIUtil newImageButtonWithFrame:CGRectMake(btnPizhu.right+18, 14, 22, 22) image:[UIImage imageNamed:@"a_blue_pen.png"] target:_handler action:@selector(bluePenPizhu)];
	[self addSubview:btnBluePen];
    UIImageView *bluePenShadow = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"a_blue_pen_shadow.png"]];
    bluePenShadow.frame = CGRectMake(btnBluePen.left, btnBluePen.bottom, 22, 12);
    [self addSubview:bluePenShadow];
    [bluePenShadow release];
	btnRedPen = [UIUtil newImageButtonWithFrame:CGRectMake(btnBluePen.right+18, 14, 22, 22) image:[UIImage imageNamed:@"a_red_pen.png"] target:_handler action:@selector(redPenPizhu)];
	[self addSubview:btnRedPen];
    UIImageView *redPenShadow = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"a_red_pen_shadow.png"]];
    redPenShadow.frame = CGRectMake(btnRedPen.left, btnRedPen.bottom, 22, 12);
    [self addSubview:redPenShadow];
    [redPenShadow release];
	btnMarkPen = [UIUtil newImageButtonWithFrame:CGRectMake(btnRedPen.right+18, 14, 22, 22) image:[UIImage imageNamed:@"a_mark_pen.png"] target:_handler action:@selector(markPenPizhu)];
	[self addSubview:btnMarkPen];
    UIImageView *markPenShadow = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"a_mark_pen_shadow.png"]];
    markPenShadow.frame = CGRectMake(btnMarkPen.left, btnMarkPen.bottom, 22, 12);
    [self addSubview:markPenShadow];
    [markPenShadow release];
	btnErase = [UIUtil newImageButtonWithFrame:CGRectMake(btnMarkPen.right+18, 14, 22, 22) image:[UIImage imageNamed:@"a_btn_erase.png"] target:_handler action:@selector(erasePizhu)];
	[self addSubview:btnErase];
    
    btnPizhu.hidden = YES;
    btnBluePen.hidden = YES;
    btnRedPen.hidden = YES;
    btnMarkPen.hidden = YES;
    btnErase.hidden = YES;
    pizhuShadow.hidden = YES;
    bluePenShadow.hidden = YES;
    redPenShadow.hidden = YES;
    markPenShadow.hidden = YES;
    
}

- (void) layoutSubviews{
}

- (void) resetBookmarkBtn{
    if(btnBookmark){
        [btnBookmark removeFromSuperview];
        RELEASE_SAFELY(btnBookmark);
    }
    btnBookmark = [UIUtil newImageButtonWithFrame:CGRectMake(self.width - 36 - 23, 0, 23, 60) image:[UIImage imageNamed:currentArticle.isBookmark?@"a_red_leaf.png":@"a_gray_leaf.png"] target:self action:@selector(toggleBookmark)];
    btnBookmark.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
    [self addSubview:btnBookmark];
}
- (void)setBackBtnImg:(BOOL)isCatalog {
    if (!isCatalog && _handler.launchFrom == 0)
    {
        [btnCatalog setImage:[UIImage imageNamedNocache:@"a_btn_catalog.png"] forState:UIControlStateNormal];
        [btnCatalog setImage:[UIImage imageNamedNocache:@"a_btn_catalog.png"] forState:UIControlStateHighlighted];
    } 
    else 
    {
        [btnCatalog setImage:[UIImage imageNamedNocache:@"a_btn_catalog.png"] forState:UIControlStateNormal];
        [btnCatalog setImage:[UIImage imageNamedNocache:@"a_btn_catalog.png"] forState:UIControlStateHighlighted];
    }
}
- (void)refresh {
    RELEASE_SAFELY(currentArticle);
    currentArticle = [[_handler currentArticle] retain];
    //设置收藏状态
    [self changeCollectState:[KSModelCollectionItem isInCollection:currentArticle.articleId]];
    //设置书签状态
    [self resetBookmarkBtn];
    //设置返回目录or返回首界面
//    if (currentArticle.artitype == 2) {//目录
//        [self setBackBtnImg:YES];
//    }else {
//        [self setBackBtnImg:NO];
//    }
    
    //根据页面类型设置header,footer
    if (currentArticle.artitype == 2) {//目录
        btnCatalog.hidden = YES;
        btnComment.hidden = YES;
        btnShare.hidden = YES;
        btnCollect.hidden = YES;
        btnDecreaseFont.hidden = YES;
        btnDefaultFont.hidden = YES;
        btnIncreaseFont.hidden = YES;
        btnBookmark.hidden = YES;
        btnSearch.frame = CGRectMake(btnBack.right+18, 0, 49, 44);
        btnHelp.frame = CGRectMake(btnCatalog.right+18, 0, 39, 44);
        
        //self.hidden = YES;
    }else {
        // [self setBackBtnImg:NO];
        btnCatalog.hidden = NO;
        btnComment.hidden = NO;
        btnShare.hidden = NO;
        btnCollect.hidden = NO;
        btnDecreaseFont.hidden = NO;
        btnDefaultFont.hidden = NO;
        btnIncreaseFont.hidden = NO;
        btnBookmark.hidden = NO;
        btnSearch.frame = CGRectMake(btnCollect.right+18, 0, 49, 44);
        btnHelp.frame = CGRectMake(btnSearch.right+18, 0, 39, 44);

        //self.hidden = NO;
    }
    
    //设置最后阅读状态
    [currentArticle toggleLastReadArticle];
    
    [self setNeedsLayout];
}
- (void) collectThis{
    if([KSModelCollectionItem isInCollection:currentArticle.articleId]){
        [KSModelCollectionItem unMarkCollection:currentArticle.articleId];
        [self changeCollectState:NO];
        return;
    }
    [KSModelCollectionItem markCollection:currentArticle.articleId];
    [self changeCollectState:YES];
}
- (void)changeCollectState:(BOOL)st {
    if (st) {
        [btnCollect setImage:[UIImage imageNamedNocache:@"a_btn_collect_tap.png"] forState:UIControlStateNormal];
    } else {
        [btnCollect setImage:[UIImage imageNamedNocache:@"a_btn_collect.png"] forState:UIControlStateNormal];
    }
}
- (void)changeFavState:(BOOL)st {
    [self changeCollectState:st];
}
- (void) toggleBookmark{
    [currentArticle toggleBookmark];
//    [_handler reloadData];
    [self resetBookmarkBtn];
}

- (void)dealloc{
    [btnCatalog release];
    [btnBack release];
    [btnComment release];
    [btnShare release];
    [btnCollect release];
    [btnSearch release];
    [btnHelp release];
    [btnPizhu release];
    [btnBluePen release];
    [btnRedPen release];
    [btnMarkPen release];
    [btnErase release];
    [currentArticle release];
    [btnBookmark release];
    [btnDecreaseFont release];
    [btnIncreaseFont release];
    [btnDefaultFont release];
    
    [super dealloc];
}
@end
