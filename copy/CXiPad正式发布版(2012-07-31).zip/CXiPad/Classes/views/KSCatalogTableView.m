//
//  KSCatalogTableView.m
//  CenturyWeeklyV2
//
//  Created by 广亮 高 on 12-6-19.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import "KSCatalogTableView.h"
#import "KSDirectoryMainView.h"





@implementation KSCatalogTableView

- (id)initWithFrame:(CGRect)frame magazine:(KSModelMagzine*)magazine hander:(id)hander
{
    self = [super initWithFrame:frame];
    if (self)
    {
        _hander = [hander retain];
        _lastIndexRow = 0;
        _magazine = [magazine retain];
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height) style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.separatorColor = [UIColor clearColor];
        _tableView.backgroundColor = [UIColor clearColor];
        _isFirstLunch = YES;
        
        _view = [[UIView alloc] init];
        
        _label = [[UILabel alloc] init];
        _label.backgroundColor = [UIColor clearColor];
        _label.text = @"目录";
        _label.font = [UIFont boldSystemFontOfSize:20];
        [_view addSubview:_label];
        _tableView.tableHeaderView = _view;
        [_label release];
        [_view release];

                
        [self addSubview:_tableView];
    }
    return self;
}

-(void)layoutSubviews
{
    _tableView.frame = CGRectMake(0, 0, self.width, self.height);

    if ([UIUtil currentOrientation]==0) 
    {

        _label.frame = CGRectZero;
        _view.frame = CGRectZero;
//        _tableView.tableHeaderView.frame = CGRectZero;
    }
    else
    {
        _label.frame = CGRectMake(0, 61, 200, 20);
        _view.frame = CGRectMake(0, 0, 100, 95);
//        [_label alignBottom];
//        _tableView.tableHeaderView.frame = CGRectMake(0, 0, 100, 88.5);
    }
    _tableView.tableHeaderView = _view;

}
-(void)dealloc
{
    RELEASE_SAFELY(_hander);
    RELEASE_SAFELY(_magazine);
    RELEASE_SAFELY(_tableView);
    RELEASE_SAFELY(_catalogArray);
    [super dealloc];
}

-(void)reloadData:(NSInteger)magazineId
{
    if (_catalogArray)
    {
        RELEASE_SAFELY(_catalogArray);
    }
    _catalogArray = [[KSModelCatalog catalogLeve1InMagazineId:magazineId inCatalog:YES] retain];
    
    //去除目录
    
    if ([_catalogArray count]>0)
    {
        NSRange range = [[[_catalogArray objectAtIndex:0] title] rangeOfString:@"封面"];
        if (range.length>0)
        {
            [_catalogArray removeObjectAtIndex:0];
        }
    }
    NSMutableArray *catalog2Array = [[KSModelCatalog catalogLeve2InMagazineId:magazineId] retain];

    //去除没有文章的目录
    NSMutableArray *deletArray = [[NSMutableArray alloc] init];
    for (int  i = 0; i<[_catalogArray count]; i++)
    {
        KSModelCatalog *catalog = [_catalogArray objectAtIndex:i];
        if (catalog.catalogId == 6441)
        {
            KSDINFO(@"");
        }
        if (![KSModelArticle articlesInCatalog:catalog.catalogId])
        {
            BOOL exist = NO;
            for (int j = 0; j<[catalog2Array count]; j++)
            {
                KSModelCatalog *catalog2 = [catalog2Array objectAtIndex:j];
                if (catalog2.parentId == catalog.catalogId)
                {
                    if ([KSModelArticle articlesInCatalog:catalog2.catalogId])
                    {
                        exist = YES;
                    }
                    
                }

            }
            if (!exist)
            {
                [deletArray addObject:catalog];
            }
        }
    }
    [_catalogArray removeObjectsInArray:deletArray];
    [deletArray release];
    //添加免费试读目录
    if (![_magazine isMybook])
    {
        KSModelCatalog *catalog = [[KSModelCatalog alloc] init];
        catalog.title = @"免费试读    FREE";
        catalog.catalogId = -1;
        [_catalogArray insertObject:catalog atIndex:0];
        [catalog release];
    }
    
    [_tableView reloadData];
    
    if (_isFirstLunch)
    {
        [self selectCatalog:[_catalogArray objectAtIndex:0]];
        _isFirstLunch = NO;
    }
}
-(void)selectCatalog:(KSModelCatalog*)catalog
{
    [_hander.articleTabelView reloadData:catalog.catalogId];
}

-(void)reloadCellData:(KSModelCatalog*)catalog cell:(UITableViewCell*)cell index:(NSInteger)currentRow
{
    UIImageView *bgImageView = (UIImageView*)[cell viewWithTag:100];
    UILabel *catalogLabel = (UILabel*)[cell viewWithTag:300];
    UILabel *leftImageView = (UILabel*)[cell viewWithTag:200];
    catalogLabel.text = catalog.title;
    bgImageView.hidden = NO;
    if (_lastIndexRow == currentRow )
    {

//        bgImageView.image = [UIImage imageNamed:@"bg_catalog_select.png"];
        leftImageView.backgroundColor = str2rgb(catalog.catalogColor);
//        catalogLabel.textColor = CELL_TEXT_SELECT_COLOR;
    }
    else 
    {
        bgImageView.hidden = YES;
//        bgImageView.image = [UIImage imageNamed:@"bg_catalog_cell.png"];
        leftImageView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_catalog_normal.png"]];
//        catalogLabel.textColor = CELL_TEXT_NORMAL_COLOR;
    }

}

#pragma UITableView



-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_catalogArray count];
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 46;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"usedCell";
    UITableViewCell *cell = (UITableViewCell*)[tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell==nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier] autorelease];
        CGFloat width = 0;
        if ([UIUtil currentOrientation]==0)
        {
            width = tableView.width-20;
        }
        else 
        {
            width = tableView.width - 12;
        }
        
        UIView *bg = [[UIView alloc] initWithFrame:CGRectMake(0, 0, width, 44)];
        bg.backgroundColor = [UIColor whiteColor];
        [cell addSubview:bg];
        [bg release];
        
        UIImageView *bgImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 15, 10, 13)];
        bgImageView.right=width-9;
        bgImageView.tag = 100;
        bgImageView.image = [UIImage imageNamed:@"Arr.png"];
        [cell addSubview:bgImageView];
        [bgImageView release];
        
        UILabel *leftLabel = [[UILabel alloc] initWithFrame:CGRectMake(3.5, 3.5, 10, 37)];
        leftLabel.tag = 200;
        [cell addSubview:leftLabel];
        [leftLabel release];
        
        UILabel *catalongLabel = [[UILabel alloc] initWithFrame:CGRectMake(leftLabel.right+15, 0, width-(leftLabel.right+15), 44)];
        catalongLabel.tag = 300;
        catalongLabel.backgroundColor = [UIColor clearColor];
        catalongLabel.font = CELL_TEXT_FONT;
        catalongLabel.textColor = CELL_TEXT_COLOR;
        [cell addSubview:catalongLabel];
        [catalongLabel release];
        
        cell.backgroundColor = [UIColor whiteColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }

    
    KSModelCatalog *catalog = [_catalogArray objectAtIndex:[indexPath row]];
    [self reloadCellData:catalog cell:cell index:[indexPath row]];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];

    if ([indexPath row]!=_lastIndexRow)
    {
        
        
        
        KSModelCatalog *catalog = [_catalogArray objectAtIndex:[indexPath row]];
        UITableViewCell *cell = (UITableViewCell*)[tableView cellForRowAtIndexPath:indexPath];
        UIImageView *bgImageView = (UIImageView*)[cell viewWithTag:100];
        UILabel *leftLabel = (UILabel*)[cell viewWithTag:200];
        UILabel *catalogLabel = (UILabel*)[cell viewWithTag:300];
        bgImageView.hidden = NO;
        leftLabel.backgroundColor = str2rgb(catalog.catalogColor);
//        catalogLabel.textColor = CELL_TEXT_SELECT_COLOR;
        
        
        cell = (UITableViewCell*)[tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:_lastIndexRow inSection:0]];
        bgImageView = (UIImageView*)[cell viewWithTag:100];
        leftLabel = (UILabel*)[cell viewWithTag:200];
        catalogLabel = (UILabel*)[cell viewWithTag:300];
        leftLabel.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_catalog_normal.png"]];
        bgImageView.hidden = YES;
//        catalogLabel.textColor = CELL_TEXT_NORMAL_COLOR;
        
    }

    KSModelCatalog *catalog = [_catalogArray objectAtIndex:[indexPath row]];
    
    [self selectCatalog:catalog];
    
    _lastIndexRow = [indexPath row];
}
@end
