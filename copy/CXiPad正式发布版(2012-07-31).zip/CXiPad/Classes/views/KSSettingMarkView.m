//
//  KSSettingMarkView.m
//  CenturyWeeklyV2
//
//  Created by 广亮 高 on 12-5-17.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import "KSSettingMarkView.h"

@implementation KSSettingMarkView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;

        self.backgroundColor = [UIColor clearColor];
        UILabel *tipLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 50, frame.size.width, 50)];
        tipLabel.backgroundColor = [UIColor clearColor];
        tipLabel.font = [UIFont systemFontOfSize:15.0f];
        tipLabel.numberOfLines = 0;
        tipLabel.tag = 111;

        tipLabel.text = @"感谢您使用财新《新世纪》iPad版，感谢您参与评分。各版本仅限评分操作一次。";
        tipLabel.textAlignment = UITextAlignmentLeft;
        [self addSubview:tipLabel];
        [tipLabel release];
        
        UIButton *markBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        markBtn.frame = CGRectMake(0, tipLabel.bottom+30, 84, 28);
        markBtn.centerX = tipLabel.centerX;
        markBtn.titleLabel.font = [UIFont systemFontOfSize:15.0f];
        [markBtn setBackgroundImage:[UIImage imageNamed:@"btn_com.png"] forState:UIControlStateNormal];
        [markBtn setTitle:@"评分" forState:UIControlStateNormal];
        [markBtn addTarget:self action:@selector(mark) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:markBtn];
    }
    return self;
}
-(void)mark
{
    [USER_DEFAULT setBool:YES forKey:@"marked"];
    [USER_DEFAULT synchronize];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"itms-apps://ax.itunes.apple.com/WebObjects/MZStore.woa/wa/viewContentsUserReviews?type=Purple+Software&id=391959946"]];
}
-(void)layoutSubviews
{
    UILabel *label = (UILabel*)[self viewWithTag:111];
    label.centerX = self.frame.size.width/2;
    label.left = 0;
    label.width = self.frame.size.width;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty 
{
implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/
-(void)dealloc
{
    [super dealloc];
}
@end
