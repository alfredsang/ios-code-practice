//
//  KSArticleDownloadingView.h
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSViewInitor.h"
#import "KSArticleIndexable.h"

@interface KSArticleDownloadingView : UIView<KSViewInitor, KSArticleIndexable> {
    UIActivityIndicatorView *_indicator;
    NSInteger _index;
}
- (id)initWithFrame:(CGRect)frame index:(NSInteger)index;
@end
