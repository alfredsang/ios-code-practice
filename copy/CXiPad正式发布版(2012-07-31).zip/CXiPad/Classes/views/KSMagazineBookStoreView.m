//
//  KSMagazineBookStoreView.m
//  CenturyWeeklyV2
//
//  Created by 广亮 高 on 12-6-11.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import "KSMagazineBookStoreView.h"
#import "KSMagzineViewController.h"



@implementation KSMagazineBookStoreView
@synthesize yearSeg,isEditModel;
@synthesize magazine=_magazine,lastCell=_lastCell,lastIndex = _lastIndex;


- (id)initWithFrame:(CGRect)frame controller:(id)controller
{
    self = [super initWithFrame:frame];
    if (self) 
    {
        _controller = [controller retain];
        self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"book_store_bg.png"]];
//        year = [[NSString alloc] initWithFormat:@"%d",[[allYears objectAtIndex:0] intValue]];
        existYear = [[NSMutableArray alloc] initWithObjects:year, nil];
        _magazinsArray = [[NSMutableArray alloc] init];
//        NSMutableArray *years = [[_controller getMagazinesYear] retain];
//        for (int i = 0; i<[allYears count]; i++)
//        {
//            NSArray *magazs = [_controller loadMagazineByYear:[[allYears objectAtIndex:i] intValue]];
//            [_magazinsArray addObjectsFromArray:magazs];
//
//            NSInteger emptyCount = 3-[magazs count]%3;
//            if (emptyCount>0&&emptyCount<3)
//            {
//                for(int i =0;i<emptyCount;i++)
//                {
//                    NSNull *null = [NSNull null];
//                    [_magazinsArray addObject:null];
//                }
//            }
////            [magazs release];
//
//        }
    
//        _magazinsArray = [[_controller loadMagazineByYear:[[years objectAtIndex:0] intValue]] retain];
//        NSInteger emptyCount = 3-[_magazinsArray count]%3;
//        for(int i =0;i<emptyCount;i++)
//        {
//            NSNull *null = [NSNull null];
//            [_magazinsArray addObject:null];
//        }

        
        _theTabelView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.width, self.height) style:UITableViewStylePlain];
        _theTabelView.delegate = self;
        _theTabelView.dataSource = self;
        _theTabelView.separatorStyle = UITableViewCellSelectionStyleNone;
        _theTabelView.allowsSelection = NO;
        _theTabelView.backgroundColor = [UIColor clearColor];
        _theTabelView.showsHorizontalScrollIndicator = NO;
        _theTabelView.showsVerticalScrollIndicator = NO;
        [self addSubview:_theTabelView];
        

        
    }
    return self;
}
-(void)drawRect:(CGRect)rect
{
    [self reloadData];
}
- (void) purchaseOccurs:(NSNotification *)notification
{
    NSDictionary *userInfo = [notification userInfo];
    NSString *type = [userInfo valueForKey:@"type"];
    if([@"buy" isEqualToString:type])
    {

        UIButton *buyBtn = (UIButton*)[_buyCell viewWithTag:buyIndex+400];
        [buyBtn setTitle:@"下载" forState:UIControlStateNormal];
        UIButton *imageView = (UIButton*)[_buyCell viewWithTag:buyIndex+100];
        buyBtn.centerX = imageView.centerX;
        UIButton *readBtn = (UIButton*)[_buyCell viewWithTag:buyIndex+300];
        readBtn.hidden = YES;
        readBtn.center = buyBtn.center;
    }
    else if([@"subscribe" isEqualToString:type])
    {
        if ([KSBootstrap currentUser])
        {
            [UIUtil showMsgAlertWithTitle:@"提示" message:@"订阅成功。"];
            //事件类型为1
            [CXFireSubscriptionEventDataRequest requestWithDelegate:_controller url:SERVER_URL(@"/fireEvent/%@/1/%@/%@", MAGZINE_TYPE,[KSBootstrap currentUser],[[UIDevice currentDevice] uniqueGlobalDeviceIdentifier]) withParameters:nil withIndicatorView:nil withCancelSubject:@"CXFireDonateEvent-sub"];
        } 
        else 
        {
            [[NSUserDefaults standardUserDefaults] setObject:[NSString stringWithFormat:@"%.f",[[NSDate date] timeIntervalSince1970]] forKey:UD_SUBSCRIPTION_DATE];
            [[NSUserDefaults standardUserDefaults] synchronize];
            
            [UIUtil hideProcessIndicatorWithView:self];
            
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"感谢您的订阅！" message:@"如您以财新网通行证登录，还可获赠全部《新世纪》过刊阅读权限，并可查阅您的订阅信息。" delegate:self cancelButtonTitle:@"稍后再说" otherButtonTitles:@"立即登录", nil];
            alert.tag = 1010;
            [alert show];
            [alert release];
            
            //[main.bookshelf reloadData];
        }
        
    }
    
}

-(void)reloadData
{
    if (allYears)
    {
        RELEASE_SAFELY(allYears);
    }
    allYears = [[_controller getMagazinesYear] retain];
    if ([allYears count]==0)
    {
        return;
    }
    if (_magazinsArray)
    {
        [_magazinsArray removeAllObjects];
    }
    for (int i = 0; i<[allYears count]; i++)
    {
        NSArray *magazs = [_controller loadMagazineByYear:[[allYears objectAtIndex:i] intValue]];
        [_magazinsArray addObjectsFromArray:magazs];
        
        NSInteger emptyCount = 3-[magazs count]%3;
        if (emptyCount>0&&emptyCount<3)
        {
            for(int i =0;i<emptyCount;i++)
            {
                NSNull *null = [NSNull null];
                [_magazinsArray addObject:null];
            }
        }
        //            [magazs release];
        
    }

    [_theTabelView reloadData];
    
}

//-(void)existYear
//{
//    if (!existYear)
//    {
//        existYear = [[NSMutableArray alloc] init];
//        
//    }
//    for (int i = 0; i<[_magazinsArray count]; i++)
//    {
//        if ([[_magazinsArray objectAtIndex:i] isKindOfClass:[KSModelMagzine class]])
//        {
//            KSModelMagzine *magazine = [_magazinsArray objectAtIndex:i];
//            NSDate *date = [NSDate dateWithTimeIntervalSince1970:magazine.pubDate];
//            NSInteger magazineYear = [DateUtil getYearByDate:date];
//            if ([[existYear lastObject] intValue] != [DateUtil getYearByDate:date])
//            {
//                [existYear addObject:INTEGER(magazineYear)];
//            }
//
//        }
//    }
//}
-(void)addYear:(NSInteger)currentYear
{
    if (year)
    {
        RELEASE_SAFELY(year);
    }
    year = [[NSString alloc] initWithFormat:@"%d",currentYear];
    BOOL find = NO;
    for (int i = 0; i<[existYear count]; i++)
    {
        if([[existYear objectAtIndex:i] intValue] == currentYear)
        {
            find = YES;
            break;
        }
    }
    if (!find)
    {
        [existYear addObject:INTEGER(currentYear)];
    }
}
-(void)selectYear:(NSInteger)selectYear
{

    NSInteger row = 0;
    for (int i = 0; i<[_magazinsArray count]; i++)
    {
        if ([[_magazinsArray objectAtIndex:i] isKindOfClass:[KSModelMagzine class]])
        {
            KSModelMagzine *magazine = [_magazinsArray objectAtIndex:i];
            NSDate *date = [NSDate dateWithTimeIntervalSince1970:magazine.pubDate];
            
            if ([DateUtil getYearByDate:date] == selectYear) 
            {
                row = i/3;
                break;
            }
            
        }
    }
//    if (row>=0)
//    {
        _theTabelView.contentOffset = CGPointMake(0, _theTabelView.height/3*row);
//        [self addYear:selectYear];
        return;
//    }
//    NSMutableArray *magazinsArray = [[_controller loadMagazineByYear:selectYear] retain];
//    if ([magazinsArray count]==0)
//    {
//        [self addYear:selectYear];
//        return;
//    }
//        
//    NSInteger emptyCount = 3-[magazinsArray count]%3;
//    if (emptyCount !=0 && emptyCount!=3)
//    {
//        for(int i =0;i<emptyCount;i++)
//        {
//            NSNull *null = [NSNull null];
//            [magazinsArray addObject:null];
//        }
//
//    }
//        
//    
////    [self existYear];
//    
//    if ([existYear count] == 0)
//    {
//        [self addYear:selectYear];
//
//        [_magazinsArray addObjectsFromArray:magazinsArray];
//        [_theTabelView reloadData];
//
//        return;
//    }
//    //当前年份在已存在的年份中的位置
//    if ([existYear count]==1)
//    {
//        [self addYear:selectYear];
//
//        if (selectYear>[[existYear objectAtIndex:0] intValue]) 
//        {
//            [_magazinsArray insertObjects:magazinsArray atIndexes:[NSIndexSet indexSetWithIndexesInRange:NSMakeRange(0, [magazinsArray count])]];
//            [_theTabelView reloadData];
//            _theTabelView.contentOffset = CGPointMake(0, 0);
//        }
//        else 
//        {
//            NSInteger count = [_magazinsArray count]/3;
//            [_magazinsArray addObjectsFromArray:magazinsArray];
//            [_theTabelView reloadData];
//            _theTabelView.contentOffset = CGPointMake(0, _theTabelView.height/3*count);
//
//        }
//
//        return;
//    }
//    for (int i = 0; i < [existYear count]; i++)
//    {
//        
//        if (selectYear>[[existYear objectAtIndex:0] intValue]) 
//        {
//            [self addYear:selectYear];
//
//            [_magazinsArray insertObjects:magazinsArray atIndexes:[NSIndexSet indexSetWithIndexesInRange:NSMakeRange(0, [magazinsArray count])]];
//            [_theTabelView reloadData];
//            _theTabelView.contentOffset = CGPointMake(0, 0);
//
//            return;
//        }
//        else if(selectYear<[[existYear lastObject] intValue])
//        {
//            NSInteger count = [_magazinsArray count]/3;
//            [self addYear:selectYear];
//
//            [_magazinsArray addObjectsFromArray:magazinsArray];
//            [_theTabelView reloadData];
//            _theTabelView.contentOffset = CGPointMake(0, _theTabelView.height/3*count);
//
//            return;
//        }
//        else 
//        {
//            for (int j = 0; j<[existYear count]-1; j++)
//            {
//                NSInteger first = [[existYear objectAtIndex:j] intValue];
//                NSInteger second = [[existYear objectAtIndex:j+1] intValue];
//                if (selectYear<first&&selectYear>second) 
//                {
//                    for (int k = 0; k<[_magazinsArray count]; k++)
//                    {
//                        if ([[_magazinsArray objectAtIndex:k] isKindOfClass:[KSModelMagzine class]])
//                        {
//                            KSModelMagzine *magazine = [_magazinsArray objectAtIndex:k];
//                            NSDate *date = [NSDate dateWithTimeIntervalSince1970:magazine.pubDate];
//                            
//                            if ([DateUtil getYearByDate:date] == second) 
//                            {
//                                [self addYear:selectYear];
//
//                                row = i/3;
//                                [_magazinsArray addObjectsFromArray:magazinsArray];
//                                [_theTabelView   reloadData];
//                                _theTabelView.contentOffset = CGPointMake(0, _theTabelView.height/3*row);
//
//                                return;
//                            }
//                            
//                        }
//                    }
//                    
//                }
//            }
//        }
//    }
//  
    
}



- (NSString *)calPubDate:(KSModelMagzine*)magazine
{
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:magazine.pubDate];
	NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
	[formatter setDateFormat:@"yyyy年"];
	NSString *year = [formatter stringFromDate:date];
    //9月26
    [formatter setDateFormat:@"MM月dd日"];
    NSString *monthAndDay = [formatter stringFromDate:date];
    NSString *str = [NSString stringWithFormat:@"%@第%@期\n%@出版",year, magazine.isSpecialIssue==0? [NSString stringWithFormat:@"%d", magazine.stageNumber]:magazine.customIssueNumber,monthAndDay];
	[formatter release];
	
	return str;
    
}



- (void)doDownload 
{
    UIButton *_maskImagView = (UIButton*)[[_buyCell viewWithTag:buyIndex+100] viewWithTag:buyIndex+600];
    _maskImagView.hidden = NO;
    KSShelfProgressView *progressView = (KSShelfProgressView*)[_buyCell viewWithTag:buyIndex+700];
    KSDownMagazineOperation *op = [[KSBootstrap dataCenter] valueForKey:KEY_DOWNLOADING_M_ID];
    if (op) 
    {
        if (![op isCancelled])
        {
            if ([op.progressView isKindOfClass:[KSShelfProgressView class]]) 
            {//将上一本下载进度条置灰

            }
            [op cancel];
            UIButton *bt = (UIButton*)[_lastCell viewWithTag:400+_lastIndex];
            [bt setTitle:@"继续" forState:UIControlStateNormal];
            KSModelMagzine *lastMagazine = [KSModelMagzine loadById:op.magazinId];
            NSInteger index = [[_theTabelView indexPathForCell:_lastCell] row]*3+_lastIndex;
            [_magazinsArray replaceObjectAtIndex:index withObject:lastMagazine];
            KSDINFO(@"%d   %d  %f",index,op.magazinId,lastMagazine.rateDownload);
            if ([self isKindOfClass:[KSMagazineBookShelfView class]]) 
            {
                
                [_controller.main.bookShelfView whenMagzineCancelDownload:lastMagazine.magzineId reloadData:NO];
                [_controller.main.bookStoreView whenMagzineCancelDownload:lastMagazine.magzineId reloadData:YES];
                
            }
            else  
            {
                [_controller.main.bookShelfView whenMagzineCancelDownload:lastMagazine.magzineId reloadData:YES];
                [_controller.main.bookStoreView whenMagzineCancelDownload:lastMagazine.magzineId reloadData:NO];   
            }

        }
        op.progressView = nil;
    }
    [[KSBootstrap dataCenter] removeObjectForKey:KEY_DOWNLOADING_M_ID];
    
    op = [[KSDownMagazineOperation alloc] initWithMagazineId:_magazine.magzineId];
    progressView.hidden = NO;
    [progressView setOriginProgress:progressView.progress];
    op.progressView = (UIProgressView *)progressView;
    [[KSBootstrap dataCenter] setValue:op forKey:KEY_DOWNLOADING_M_ID];
    
    [[KSBootstrap operationQueue] addOperation:op];
    [op release];

}

-(void)downloadMagazine
{
    if (![UIUtil checkInternetConnection])
    {
        return;
    }
    if ([KSGetAllArticlesDownloader isDownloading:_magazine.magzineId])
    {
        UIButton *_maskImagView = (UIButton*)[[_buyCell viewWithTag:buyIndex+100] viewWithTag:buyIndex+600];
        _maskImagView.hidden = NO;
        KSShelfProgressView *progressView = (KSShelfProgressView*)[_buyCell viewWithTag:buyIndex+700];
        KSDownMagazineOperation *op = [[KSBootstrap dataCenter] valueForKey:KEY_DOWNLOADING_M_ID];
        if (op && op.magazinId == _magazine.magzineId && [op.progressView isKindOfClass:[KSProgressView class]]) 
        {
            op.progressView = (UIProgressView *)progressView;
        }
        else 
        {

            if (op) 
            {
                [op cancel];

                op.progressView = nil;
                if ([self isKindOfClass:[KSMagazineBookShelfView class]]) 
                {
                    
                    [_controller.main.bookShelfView whenMagzineCancelDownload:_magazine.magzineId reloadData:NO];
                    [_controller.main.bookStoreView whenMagzineCancelDownload:_magazine.magzineId reloadData:YES];

                }
                else  
                {
                    [_controller.main.bookShelfView whenMagzineCancelDownload:_magazine.magzineId reloadData:YES];
                    [_controller.main.bookStoreView whenMagzineCancelDownload:_magazine.magzineId reloadData:NO];   
                }


            }
            _magazine.rateDownload = progressView.progress;

            [progressView setOriginProgress:progressView.progress];
            [[KSBootstrap dataCenter] removeObjectForKey:KEY_DOWNLOADING_M_ID];
            
        }
    }
    else 
    {
        [self doDownload];
    }

}
-(void)readMagazine
{
    if (_magazine.isArticlesDownload) 
    {
        [_controller gotoArticle:0 magzineId:_magazine.magzineId from:@"bookShelf"];
    } 
}
- (void) whenMagzineDownloader:(NSInteger)magzineId
{

    NSInteger index=0;
        
    for (int i=0; i<[_magazinsArray count]; i++) 
    {
        if ([[_magazinsArray objectAtIndex:i] isKindOfClass:[KSModelMagzine class]])
        {
            KSModelMagzine *item = [_magazinsArray objectAtIndex:i];
            if(item.magzineId ==magzineId) 
            {
                KSModelMagzine *m = [KSModelMagzine loadById:item.magzineId];
                [_magazinsArray replaceObjectAtIndex:i withObject:m];
                if (_magazine)
                {
                    RELEASE_SAFELY(_magazine);
                }
                _magazine = [m retain];
                index = i;
                break;
            }

        }
    }
    if (!_buyCell)
    {
        buyIndex = index%3;
        NSInteger row = ceil((CGFloat)index/3);
        NSIndexPath *path = [NSIndexPath indexPathForRow:row-1 inSection:0];
        _buyCell = [[_theTabelView cellForRowAtIndexPath:path] retain];
    }
    [_theTabelView reloadData];    

}
-(void)whenMagzineCancelDownload:(NSInteger)magzineId reloadData:(BOOL)isRelad
{
    for (int i=0; i<[_magazinsArray count]; i++) 
    {
        if ([[_magazinsArray objectAtIndex:i] isKindOfClass:[KSModelMagzine class]])
        {
            KSModelMagzine *item = [_magazinsArray objectAtIndex:i];
            if(item.magzineId ==magzineId) 
            {
                KSModelMagzine *m = [KSModelMagzine loadById:item.magzineId];
                [_magazinsArray replaceObjectAtIndex:i withObject:m];
                break;
            }

        }
    }
    
    if (isRelad)
    {
        [_theTabelView reloadData];
    }
}
-(void)whenMagzinePurchased:(NSInteger)magazineId
{
//    for (int i = 0; i<[_magazinsArray count]; i++)
//    {
//        if ([[_magazinsArray objectAtIndex:i] isKindOfClass:[KSModelMagzine class]])
//        {
//            KSModelMagzine *magaz = [_magazinsArray objectAtIndex:i];
//            if (magaz.magzineId == magazineId)
//            {
//                [_magazinsArray replaceObjectAtIndex:i withObject:[KSModelMagzine loadById:magazineId]];
//                break;
//                
//            }
//        }
//    }
    [self reloadData];
//    [_theTabelView reloadData];

}
- (void)whenMagzineDeleted:(KSModelMagzine *)magazine
{
    for (int i = 0;i<[_magazinsArray count];i++)
    {
        if ([[_magazinsArray objectAtIndex:i] isKindOfClass:[KSModelMagzine class]])
        {
            KSModelMagzine *magaz = [_magazinsArray objectAtIndex:i];
            if (magaz.magzineId == magazine.magzineId)
            {
                [_magazinsArray replaceObjectAtIndex:i withObject:[KSModelMagzine loadById:magazine.magzineId]];
                break;
            }
        }
        
    }
    [_theTabelView reloadData];
}
- (void) whenInitOrMagzineListUpdate
{
    [self reloadData];
//    if (allYears)
//    {
//        RELEASE_SAFELY(allYears);
//    }
//    allYears = [[_controller getMagazinesYear] retain];
//    if (year)
//    {
//        RELEASE_SAFELY(year);
//    }
//    year = [[NSString alloc] initWithFormat:@"%d",[[allYears objectAtIndex:0] intValue]];
//    if (existYear)
//    {
//        RELEASE_SAFELY(existYear);
//    }
//    existYear = [[NSMutableArray alloc] initWithObjects:year, nil];
//    if (_magazinsArray)
//    {
//        RELEASE_SAFELY(_magazinsArray);
//    }
//    _magazinsArray = [[_controller loadMagazineByYear:[year intValue]] retain];
//    NSInteger emptyCount = 3-[_magazinsArray count]%3;
//    for(int i =0;i<emptyCount;i++)
//    {
//        NSNull *null = [NSNull null];
//        [_magazinsArray addObject:null];
//    }
//    [_theTabelView reloadData];
}
- (void) whenMagzineCoverDownloaded:(NSInteger)magzineId
{
    for (int i = 0; i<[_magazinsArray count]; i++)
    {
        if ([[_magazinsArray objectAtIndex:i] isKindOfClass:[KSModelMagzine class]])
        {
            KSModelMagzine *magaz = [_magazinsArray objectAtIndex:i];
            if (magaz.magzineId == magzineId)
            {
                KSModelMagzine *magazine = [KSModelMagzine loadById:magzineId];
                [_magazinsArray replaceObjectAtIndex:i withObject:magazine];
                NSInteger row = ceil((CGFloat)i/3);
                NSInteger column = i%3;
                UITableViewCell *cell = (UITableViewCell*)[_theTabelView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:row inSection:0]];
                UIButton *imageBtn = (UIButton*)[cell viewWithTag:100+column];
                [imageBtn setBackgroundImage:[UIImage imageWithContentsOfFile:magazine.cover_2] forState:UIControlStateNormal];
                [imageBtn setBackgroundImage:[UIImage imageWithContentsOfFile:magazine.cover_2] forState:UIControlStateHighlighted];
                break;
                
            }
        }
    }

}
-(void)buyBtnPress:(UIButton*)btn
{

    if (_lastCell)
    {
        RELEASE_SAFELY(_lastCell); 
    }
    _lastCell = [_buyCell retain];
    _lastIndex = buyIndex;
    if (_buyCell)
    {
        RELEASE_SAFELY(_buyCell);
    }
    _buyCell = [(UITableViewCell*)[btn superview] retain];
    NSInteger cellRow = [[_theTabelView indexPathForCell:_buyCell] row];
    buyIndex = btn.tag-400;

    if (_magazine)
    {
        RELEASE_SAFELY(_magazine);
    }
    _magazine = [[_magazinsArray objectAtIndex:cellRow*3 + buyIndex] retain];


    if ([btn.titleLabel.text isEqualToString:@"购买"])
    {
        [_controller setCurrentMagzine:_magazine];
        [KSAppStoreProxy buy:_magazine fromView:self];
    }
    else if ([btn.titleLabel.text isEqualToString:@"下载"])
    {
        [self downloadMagazine];
        [btn setTitle:@"暂停" forState:UIControlStateNormal];
    }
    else if ([btn.titleLabel.text isEqualToString:@"暂停"])
    {
        [self downloadMagazine];
        [btn setTitle:@"继续" forState:UIControlStateNormal];
    }
    else if ([btn.titleLabel.text isEqualToString:@"继续"])
    {
        [self downloadMagazine];
        [btn setTitle:@"暂停" forState:UIControlStateNormal];
    }
    else if ([btn.titleLabel.text isEqualToString:@"阅读"])
    {
        [self readMagazine];
    }
    
}

-(void)probationRead:(UIButton*)btn
{
    if (_lastCell)
    {
        RELEASE_SAFELY(_lastCell); 
    }
    _lastCell = [_buyCell retain];
    _lastIndex = buyIndex;

    if (_buyCell)
    {
        RELEASE_SAFELY(_buyCell);
    }
    _buyCell = [(UITableViewCell*)[btn superview] retain];
    NSInteger cellRow = [[_theTabelView indexPathForCell:_buyCell] row];
    buyIndex = btn.tag-300;


    if (_magazine)
    {
        RELEASE_SAFELY(_magazine);
    }
    _magazine = [[_magazinsArray objectAtIndex:cellRow*3 + buyIndex] retain];
    if ([btn.titleLabel.text isEqualToString:@"试读"])
    {

        [btn setTitle:@"暂停" forState:UIControlStateNormal];
        [self downloadMagazine];

    }
    else if ([btn.titleLabel.text isEqualToString:@"暂停"])
    {
        [btn setTitle:@"继续" forState:UIControlStateNormal];
        [self downloadMagazine];

    }
    else if ([btn.titleLabel.text isEqualToString:@"继续"])
    {
        [btn setTitle:@"暂停" forState:UIControlStateNormal];
        [self downloadMagazine];
        
    }
    else if ([btn.titleLabel.text isEqualToString:@"预览"])
    {
        [_controller gotoArticle:0 magzineId:_magazine.magzineId from:@"bookself"];
    }
    
}

-(void)coverTaped:(UIButton*)btn
{

    if ([self isKindOfClass:[KSMagazineBookShelfView class]])
    {
        return;
    }
    UIButton *buy;
    if (btn.tag-600>=0)
    {
        buy = (UIButton*)[[btn.superview superview] viewWithTag:400+btn.tag-600];
    }
    else 
    {
        buy = (UIButton*)[btn.superview viewWithTag:400+btn.tag-100];
    }
    [self buyBtnPress:buy];
}

#define COVER_IMAGE_WIDTH    163
#define COVER_IMAGE_HEIGHT   210
#define COVER_IMAGE_MARGIN   94


-(void)addProgressView
{
    
}
-(NSInteger)getMinYear
{
    NSInteger minYear = 3000;
    for (int i = 0; i<[existYear count]; i++)
    {
        NSInteger tempYear = [[existYear objectAtIndex:i] intValue];
        if (minYear>tempYear)
        {
            minYear = tempYear;
        }
    }
    return minYear;
}
-(void)moreMagazine
{
    NSInteger nextYear = [self getMinYear]-1;
    if (nextYear<2010)
    {
        return ;
    }
    RELEASE_SAFELY(year);
    year = [[NSString alloc] initWithFormat:@"%d",nextYear];

    NSMutableArray *yearsArray = [_controller loadMagazineByYear:nextYear];
    [_magazinsArray addObjectsFromArray:yearsArray];
    NSInteger emptyCount = 3-[_magazinsArray count]%3;
    if (emptyCount>0&&emptyCount<3)
    {
        for(int i =0;i<emptyCount;i++)
        {
            NSNull *null = [NSNull null];
            [_magazinsArray addObject:null];
        }

    }
   
    [_theTabelView reloadData];
}
-(void)layoutTabelViewCellWithColumns:(NSInteger)columns onView:(UITableViewCell*)view
{
    for (int i = 0; i<columns; i++)
    {
        

        UIImageView *imageBackGround = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"book_shadow.png"]];
        imageBackGround.frame = CGRectMake(22+(COVER_IMAGE_WIDTH+COVER_IMAGE_MARGIN)*i, 0, 213, 253);
        imageBackGround.tag = 800+i;
        imageBackGround.contentMode = UIViewContentModeScaleToFill;
        [view addSubview:imageBackGround];
        [imageBackGround release];
        
        

        UIButton *imageView = [UIButton buttonWithType:UIButtonTypeCustom];
        imageView.frame = CGRectMake(47+(COVER_IMAGE_WIDTH+COVER_IMAGE_MARGIN)*i, 23, COVER_IMAGE_WIDTH, COVER_IMAGE_HEIGHT);
        imageView.tag = 100+i;
        imageView.hidden = YES;

        UIImage *image = [UIImage imageNamed:@"default_cover_225_290.png"];
        
        [imageView setBackgroundImage:image forState:UIControlStateNormal];
        [imageView setBackgroundImage:image forState:UIControlStateHighlighted];
        [view addSubview:imageView];

        
        UIButton *maskImagView = [UIButton buttonWithType:UIButtonTypeCustom];
        maskImagView.frame = CGRectMake(0, 0, imageView.width, imageView.height);
        [maskImagView setBackgroundImage:[UIImage imageNamed:@"book_shadow_bg.png"] forState:UIControlStateNormal];
        maskImagView.tag = i+600;
        maskImagView.alpha = 0.7;
        maskImagView.hidden = YES;
        [imageView addSubview:maskImagView];
        
        

        
        UIButton *tagImageBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        tagImageBtn.frame = CGRectMake(0, 0, 37, 34);
        tagImageBtn.tag = i+500;
        tagImageBtn.center = CGPointMake(imageView.right, imageView.top);
        tagImageBtn.hidden = YES;
        [view addSubview:tagImageBtn];
        
        UILabel *pubTimeLabel = [[UILabel alloc] init];
        pubTimeLabel.frame = CGRectMake(imageView.left, imageView.bottom+12, imageView.width, 10);
        pubTimeLabel.backgroundColor = [UIColor clearColor];
        pubTimeLabel.font = [UIFont boldSystemFontOfSize:10];
        pubTimeLabel.textColor = [UIColor whiteColor];
        pubTimeLabel.textAlignment = UITextAlignmentCenter;
        pubTimeLabel.tag = 200+i;
        [view addSubview:pubTimeLabel];
        [pubTimeLabel release];
        
        UIButton *probationReadBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        probationReadBtn.frame = CGRectMake(imageView.left, pubTimeLabel.bottom+10, 74, 30);
        [probationReadBtn setTitleColor:BTN_HIGHT_COLOR forState:UIControlStateNormal];
        [probationReadBtn.titleLabel setFont:[UIFont boldSystemFontOfSize:16]];
        [probationReadBtn setTitle:@"试读" forState:UIControlStateNormal];
        [probationReadBtn setBackgroundImage:[UIImage imageNamed:@"btn_buy_black.png"] forState:UIControlStateNormal];
        probationReadBtn.tag = 300+i;
        [probationReadBtn setContentHorizontalAlignment:UIControlContentHorizontalAlignmentCenter];
        [probationReadBtn setContentVerticalAlignment:UIControlContentVerticalAlignmentCenter];
        [probationReadBtn addTarget:self action:@selector(probationRead:) forControlEvents:UIControlEventTouchUpInside];
        [view addSubview:probationReadBtn];
        
        UIButton *buyBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        buyBtn.frame = CGRectMake(imageView.right-probationReadBtn.width, probationReadBtn.top, 74, probationReadBtn.height);
        buyBtn.tag = 400+i;
        [buyBtn setTitleColor:BTN_HIGHT_COLOR forState:UIControlStateNormal];
        [buyBtn setTitle:@"购买" forState:UIControlStateNormal];
        [buyBtn setBackgroundImage:[UIImage imageNamed:@"btn_buy_black.png"] forState:UIControlStateNormal];
        [buyBtn setContentHorizontalAlignment:UIControlContentHorizontalAlignmentCenter];
        [buyBtn setContentVerticalAlignment:UIControlContentVerticalAlignmentCenter];
        [buyBtn.titleLabel setFont:[UIFont boldSystemFontOfSize:16]];
        [buyBtn addTarget:self action:@selector(buyBtnPress:) forControlEvents:UIControlEventTouchUpInside];
        [view addSubview:buyBtn];
        
        
        
        
        
        KSShelfProgressView *progressView = [[KSShelfProgressView alloc] initWithFrame:CGRectMake(0, 160, 100, 11)];
        progressView.tag = i+700;

        progressView.centerX = imageView.centerX;
        [view addSubview:progressView];
        [progressView release];
        progressView.hidden = YES;


    }

       
}

-(void)reloadCellDataWithColumns:(NSInteger)columns rows:(NSInteger)rows Cell:(UIView*)cell
{

    for (int i =0; i<columns; i++)
    {
        
        if ([[_magazinsArray objectAtIndex:rows*3+i] isKindOfClass:[KSModelMagzine class]])
        {
            KSModelMagzine *magazine = [_magazinsArray objectAtIndex:rows*3+i];
            
            UIButton *imageView = (UIButton*)[cell viewWithTag:i+100];
            imageView.hidden = NO;

            UIImageView *bgImageView = (UIImageView*)[cell viewWithTag:i+800];
            bgImageView.hidden = NO;
            
            uint64_t start1 = mach_absolute_time();
            NSDictionary *dic = [[NSDictionary alloc] initWithObjectsAndKeys:magazine,@"magazine",imageView,@"btn", nil];
            [NSThread detachNewThreadSelector:@selector(loadCoverImage:) toTarget:self withObject:dic];
            [dic release];
//            UIImage *image = [UIImage imageWithContentsOfFile:magazine.cover_2];
//            uint64_t start2 = mach_absolute_time();
//            
//            if (image)
//            {
//
//                [imageView setBackgroundImage:image forState:UIControlStateNormal];
////                [imageView setBackgroundImage:image forState:UIControlStateHighlighted];
//            }
//            uint64_t start3 = mach_absolute_time();
//            KSDINFO(@"%llu    %llu\n    %llu",start1,start3,start3-start1);
            UILabel *tempPubLabel = (UILabel*)[cell viewWithTag:200+i];
            tempPubLabel.text = [self calPubDate:magazine];
            tempPubLabel.hidden = NO;
            UIButton *probBtn = (UIButton*)[cell viewWithTag:300+i];
            UIButton *buyBtn = (UIButton*)[cell viewWithTag:400+i];
            buyBtn.right = imageView.right;
            probBtn.hidden = NO;
            buyBtn.hidden = NO;
            
            UIButton *tagImageView = (UIButton*)[cell viewWithTag:i+500];
            UIButton *maskImageView = (UIButton*)[imageView viewWithTag:i+600];
            KSShelfProgressView *progressView = (KSShelfProgressView*)[cell viewWithTag:i+700];
            maskImageView.userInteractionEnabled = YES;
            imageView.userInteractionEnabled = YES;
            //已购买
            if ([magazine isMybook])
            {
                probBtn.centerX = imageView.centerX;
                buyBtn.centerX = imageView.centerX;
                
                [maskImageView addTarget:self action:@selector(coverTaped:) forControlEvents:UIControlEventTouchUpInside];
                [imageView addTarget:self action:@selector(coverTaped:) forControlEvents:UIControlEventTouchUpInside];
                
                //未下载
                if (magazine.rateDownload==0)
                {
                    tagImageView.hidden = NO;
                    [tagImageView setImage:[UIImage imageNamed:@"btn_download_big.png"] forState:UIControlStateNormal];
                    [buyBtn setTitle:@"下载" forState:UIControlStateNormal];
                    probBtn.hidden = YES;
                    maskImageView.hidden = YES;
                    progressView.hidden = YES;


                }
                //已下载
                else if (magazine.rateDownload==1) 
                {
                    tagImageView.hidden = YES;
                    [buyBtn setTitle:@"阅读" forState:UIControlStateNormal];
                    probBtn.hidden = YES;
                    maskImageView.hidden = YES;
                    progressView.hidden = YES;
                    if (isEditModel) 
                    {
                        tagImageView.hidden = NO;
                        [tagImageView setImage:[UIImage imageNamed:@"btn_delete_big.png"] forState:UIControlStateNormal];
                        
                    }


                    
                }                          
                //下载中
                else 
                {
                    maskImageView.hidden = NO;
                    [buyBtn setTitle:@"继续" forState:UIControlStateNormal];
                    probBtn.hidden = YES;
                    progressView.hidden = NO;
                    [progressView setOriginProgress:magazine.rateDownload];
                    [tagImageView setImage:[UIImage imageNamed:@"btn_download_big.png"] forState:UIControlStateNormal];


                }
                
            }
            else 
            {
                [imageView removeTarget:self action:@selector(coverTaped:) forControlEvents:UIControlEventTouchUpInside];
                [maskImageView removeTarget:self action:@selector(coverTaped:) forControlEvents:UIControlEventTouchUpInside];

                progressView.hidden = YES;
                tagImageView.hidden = NO;
                maskImageView.hidden = YES;
                [tagImageView setImage:[UIImage imageNamed:@"btn_lock_big.png"] forState:UIControlStateNormal];
                
                probBtn.left = imageView.left;
                [buyBtn setTitle:@"购买" forState:UIControlStateNormal];
                
                if (magazine.rateDownload==1)
                {
                    [probBtn setTitle:@"预览" forState:UIControlStateNormal];
                }
                else 
                {
                    [probBtn setTitle:@"试读" forState:UIControlStateNormal];
                    
                    if (magazine.rateDownload>0&&magazine.rateDownload<1)
                    {
                        maskImageView.hidden = NO;
                        progressView.hidden = NO;
                        [progressView setOriginProgress:magazine.rateDownload];
                        [probBtn setTitle:@"继续" forState:UIControlStateNormal];
                        
                    }
                }
                
            }
            
            KSDownMagazineOperation *op = [[KSBootstrap dataCenter] valueForKey:KEY_DOWNLOADING_M_ID];
            if (op&&op.magazinId == magazine.magzineId)
            {

                maskImageView.hidden = NO;
                progressView.hidden = NO;
                [progressView setOriginProgress:magazine.rateDownload];
                [probBtn setTitle:@"暂停" forState:UIControlStateNormal];
                    

            }

        }
        else
        {

                UIButton *imageView = (UIButton*)[cell viewWithTag:i+100];
                UILabel *tempPubLabel = (UILabel*)[cell viewWithTag:200+i];
                UIButton *probBtn = (UIButton*)[cell viewWithTag:300+i];
                UIButton *buyBtn = (UIButton*)[cell viewWithTag:400+i];
                UIButton *tagBtn = (UIButton*)[cell viewWithTag:500+i];
                UIButton *maskImageView = (UIButton*)[imageView viewWithTag:i+600];
                KSShelfProgressView *progressView = (KSShelfProgressView*)[cell viewWithTag:i+700];
                UIImageView *bgImageView = (UIImageView*)[cell viewWithTag:i+800];
                imageView.hidden = YES;
                tempPubLabel.hidden = YES;
                probBtn.hidden = YES;
                buyBtn.hidden = YES;
                progressView.hidden = YES;
                maskImageView.hidden = YES;
                bgImageView.hidden = YES;
                tagBtn.hidden = YES;
            

        }
        
        
    }



}

#pragma tableView


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSInteger rows = [_magazinsArray count]/3;

//    if ([year intValue] == 2010 || [existYear count] == [allYears count] )
//    {
//        rows--;
//    }
    
    return rows;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([indexPath row]==[_magazinsArray count]/3)
    {
        return 90;
    }

    return tableView.height/3;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
//    if ([indexPath row]==[_magazinsArray count]/3)
//    {
//        UITableViewCell *cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil] autorelease];
//        UIButton *moreBtn = [UIButton buttonWithType:UIButtonTypeCustom];
//        [moreBtn setTitleColor:BTN_HIGHT_COLOR forState:UIControlStateNormal];
//        [moreBtn.titleLabel setFont:[UIFont boldSystemFontOfSize:16]];
//        [moreBtn setBackgroundImage:[UIImage imageNamed:@"btn_more.png"] forState:UIControlStateNormal];
//        [moreBtn setTitle:@"点击下载更多" forState:UIControlStateNormal];
//        [moreBtn setFrame:CGRectMake(0, 20, 316, 50)];
//        [moreBtn addTarget:self action:@selector(moreMagazine) forControlEvents:UIControlEventTouchUpInside];
//        moreBtn.centerX = self.centerX;
//        moreBtn.userInteractionEnabled = YES;
//        [cell addSubview:moreBtn];
//        
//        
//        return cell;
//    }
    static NSString *identifier = @"userCell";

    UITableViewCell *cell = (UITableViewCell*)[tableView dequeueReusableCellWithIdentifier:identifier];

    if (cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier] autorelease];


        [self layoutTabelViewCellWithColumns:3 onView:cell];

                        
    }

    [self reloadCellDataWithColumns:3 rows:[indexPath row] Cell:cell];


    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}
-(void)dealloc
{
    RELEASE_SAFELY(_magazinsArray);
    RELEASE_SAFELY(_controller);
    RELEASE_SAFELY(_theTabelView);
    RELEASE_SAFELY(yearSeg);
    RELEASE_SAFELY(existYear);
//    [KSBootstrap unlisten:NOTIFY_PURCHASE_COMPLETED target:self];

    [super dealloc];
}
-(void)loadCoverImage:(NSDictionary*)dic
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    KSModelMagzine *magazine = [dic objectForKey:@"magazine"];
    UIButton *btn = [dic objectForKey:@"btn"];
//    uint64_t start1 = mach_absolute_time();

    UIImage *image = [UIImage imageWithContentsOfFile:magazine.cover_2];
    if (!image)
    {
        image = [UIImage imageNamed:@"default_cover_225_290.png"];
    }
    if (NULL != UIGraphicsBeginImageContextWithOptions)
        UIGraphicsBeginImageContextWithOptions(btn.size, YES, 0);
    else
        UIGraphicsBeginImageContext(btn.size);
    [image drawInRect:CGRectMake(0, 0, btn.width, btn.height)];
    image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();

//    uint64_t start2 = mach_absolute_time();
//    KSDINFO(@"==========  %lld ",start2-start1);

//    uint64_t start2 = mach_absolute_time();
    
    if (image)
    {
        NSDictionary *dic = [[ NSDictionary alloc] initWithObjectsAndKeys:image,@"img",btn,@"btn", nil];
        [self performSelectorOnMainThread:@selector(showCoverImage:) withObject:dic  waitUntilDone:YES];
        [dic release];
    }
    [pool release];
}
-(void)showCoverImage:(NSDictionary*)dic
{ 
    UIImage *img = [dic objectForKey:@"img"];
    UIButton *btn = [dic objectForKey:@"btn"];

//    uint64_t start1 = mach_absolute_time();
    [btn setBackgroundImage:img forState:UIControlStateNormal];
    [btn setBackgroundImage:img forState:UIControlStateHighlighted];
//    uint64_t start2 = mach_absolute_time();
//    KSDINFO(@"*************  %lld ",start2-start1);
    
//    [UIUtil showFadeInAnimation:btn endAlpha:1];
    
}
@end
