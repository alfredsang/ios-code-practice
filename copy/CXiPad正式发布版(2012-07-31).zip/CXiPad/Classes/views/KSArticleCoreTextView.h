//
//  KSArticleCoreTextView.h
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AKOMultiPageTextView.h"
#import "AKOMultiColumnTextViewDataSource.h"
#import "KSViewInitor.h"
#import "KSModelArticle.h"
#import "KSArticleCoreTextHeaderView.h"
#import "KSArticleViewController.h"
#import "KSArticleIndexable.h"
#import "KSPageTextView.h"
#import "KSColumnTextView.h"

@class KSArticleViewController;

@interface KSArticleCoreTextView : UIView<UIGestureRecognizerDelegate,KSArticleIndexable, AKOMultiColumnTextViewDataSource, KSViewInitor,KSColumnTextViewDataSource>{
    KSPageTextView *multiPageView;
    
    float _previousScale;
    float _fontSize;
    float _defaultFontSize;
    float _fontScaleRate;
    
    KSModelArticle *currentArticle;
    NSMutableDictionary *blocks;
    UIImageView *logoView;
    KSArticleViewController* _handler;
    UIButton *catalogNameView;
    UIImageView *catalogNameImageView;
    UIImageView *doubleLineView;
    NSInteger vColumnNum;
    NSInteger hColumnNum;
    CGPoint offset;
    NSInteger _index;
    
    BOOL _shouldGoNext;
}
- (id) initWithFrame:(CGRect)frame article:(KSModelArticle *)article handler:(KSArticleViewController*)handler index:(NSInteger)index;
- (void) refresh;
- (void)locateToLastPage;
- (void)locateToFirstPage;
- (void)decreaseFont;
- (void)resetFont;
- (void)increaseFont;
@end
