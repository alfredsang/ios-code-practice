//
//  KSMagazineSecondAdView.m
//  CenturyWeeklyV2
//
//  Created by jerry gao on 12-7-24.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import "KSMagazineSecondAdView.h"
#import "KSMagzineMainView.h"

@implementation KSMagazineSecondAdView
- (void)initSubviews {
    UIWebView *web = [[UIWebView alloc] initWithFrame:self.bounds];
    web.delegate = self;
    web.scalesPageToFit = YES;
    self.webView = web;
    [web release];
    

    
    [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:KEY_INDEX_AD_URL_2]]];
    [self addSubview:self.webView];
    
    
    tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGesture)];
    tap.delegate = self;
}
- (id)initWithFrame:(CGRect)frame handler:(id)handler
{
    self = [super initWithFrame:frame handler:handler];
    if (self)
    {
    }
    return self;
}
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
    
    if (self.imgStr&&self.urlStr)
    {
        if (![self.urlStr isEqualToString:KEY_INDEX_AD_URL_2])
        {
            [self removeGestureRecognizer:tap];
            [KSWebViewController presentWithURL:request.URL.absoluteString inController:self.viewController];
            return NO;
        }
    }
    else if (self.imgStr&&!self.urlStr)
    {
//        [_handler showWhiteBoardView];
        return NO;
        
    }
    else if (!self.imgStr&&self.urlStr)
    {
//        if ([request.URL.absoluteString length]>7)
//        {
//            if ([request.URL.absoluteString rangeOfString:@"http://caixin.adsame.com/c?"].length>0)
//            {
//                return YES;
//            }
//        }
        [self removeGestureRecognizer:tap];

        return YES;
        
    }

    
    return YES;
}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    if ([webView.request.URL.absoluteString isEqualToString:KEY_INDEX_AD_URL_2])
    {
        NSString *htmlStr =[webView stringByEvaluatingJavaScriptFromString:@"document.documentElement.innerHTML"];
        htmlStr = [htmlStr stringByReplacingOccurrencesOfString:@"&amp;" withString:@"&"];
        NSRange urlStartRange = [htmlStr rangeOfString:@"<a href=\""];
        htmlStr = [htmlStr substringFromIndex:urlStartRange.location+urlStartRange.length];
        NSRange urlEndRange = [htmlStr rangeOfString:@"\""];
        NSRange urlMakeRange = NSMakeRange(0, urlEndRange.location);
        if (urlMakeRange.length>0)
        {
            NSString *fullUrl = [htmlStr substringWithRange:urlMakeRange];
            NSString *url = [fullUrl substringFromIndex:[fullUrl rangeOfString:@"&u="].location+[fullUrl rangeOfString:@"&u="].length];
            if (![url isEqualToString:@""])
            {
                self.urlStr = fullUrl;
            }
        }
        NSRange imgStartRange = [htmlStr rangeOfString:@"<img src=\""];
        htmlStr = [htmlStr substringFromIndex:imgStartRange.location+imgStartRange.length];
        
        NSRange imgEndRange = [htmlStr rangeOfString:@"\""];
        NSRange imgMakeRange = NSMakeRange(0, imgEndRange.location);


        if (imgMakeRange.length>0)
        {
            
            self.imgStr = [htmlStr substringWithRange:imgMakeRange];
            
        }
        KSDINFO(@"%@  \n  %@",self.urlStr,self.imgStr);
    }
    else if ([[webView.request.URL.absoluteString substringToIndex:7] isEqualToString:@"file://"])
    {
        KSDINFO(@"%@",webView.request.URL.absoluteString);
        self.imgStr = @"ad.png";
    }
    
    static BOOL isLoaded = NO;
    if (self.urlStr&&!self.imgStr && !isLoaded)
    {
        [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:self.urlStr]]];
        isLoaded = YES;
    }


}
//- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
//    [self.webView loadHTMLString:[NSString stringWithFormat:@"<html><head><meta name='viewport' content=\"user-scalable=no, width=680, height=80\" /><style>*{padding:0px;margin:0;}body{padding:0;margin:0;}</style></head><body><a href='www.baidu.com'><img src='ad.png' style='width:680px;height:80px;'></a></body><html>",KSPathForDocumentsResource(KEY_STORAGE_DIR@"/ad.png")] baseURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] bundlePath]]];
//}
-(void)dealloc
{
    RELEASE_SAFELY(_webView);
    RELEASE_SAFELY(tap);
    [super dealloc];
}
@end
