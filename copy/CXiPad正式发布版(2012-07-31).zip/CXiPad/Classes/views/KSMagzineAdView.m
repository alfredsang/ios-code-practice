//
//  KSMagzineAdView.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 1/28/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KSMagzineAdView.h"
#import "KSMagzineMainView.h"


@implementation KSMagzineAdView
@synthesize isShow;
@synthesize urlStr,imgStr;
@synthesize webView = _webView;

- (void)dealloc {
    _webView.delegate = nil;
    [_webView stopLoading];
    [_webView release];
    [_handler release];
    [tap release];
    if (urlStr)
    {
        RELEASE_SAFELY(urlStr);
    }
    if (imgStr)
    {
        RELEASE_SAFELY(imgStr);
    }
    [super dealloc];
}
- (void)initSubviews {
    UIWebView *web = [[UIWebView alloc] initWithFrame:self.bounds];
    web.backgroundColor = [UIColor clearColor];
    web.delegate = self;
    web.scalesPageToFit = YES;
    self.webView = web;
    [web release];

    
    IF_IOS5_OR_GREATER(
       self.webView.scrollView.scrollEnabled = NO;
       self.webView.scrollView.backgroundColor = [UIColor clearColor];                
                       );
    IF_PRE_IOS5(
    ((UIScrollView*)[self.webView.subviews objectAtIndex:0]).backgroundColor = [UIColor clearColor];
    ((UIScrollView*)[self.webView.subviews objectAtIndex:0]).scrollEnabled = NO;
            );
    
    [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:KEY_INDEX_AD_URL]]];
    [self addSubview:self.webView];
    
    
    tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGesture)];
    tap.delegate = self;
}
- (id)initWithFrame:(CGRect)frame handler:(id)handler
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        _handler = [handler retain];
        [self initSubviews];
    }
    return self;
}

-(void)tapGesture
{
    if (!isShow)
    {
        if (_handler.adWebView.imgStr)
        {
            [_handler showWhiteBoardView];
        }
        else if (_handler.adWebView.urlStr)
        {
            [_handler.adWebView.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:_handler.adWebView.urlStr]]];
        }
    }
    else
    {
        [_handler hiddenWhiteBoardView];
    }
}

#pragma mark - UIWebViewDelegate
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
    if (self.urlStr&&self.imgStr)
    {
        if (![self.urlStr isEqualToString:KEY_INDEX_AD_URL])
        {
            [self removeGestureRecognizer:tap];
            [KSWebViewController presentWithURL:request.URL.absoluteString inController:self.viewController];
            return NO;
        }
    }

    else if(self.imgStr)
    {
        [self removeGestureRecognizer:tap];
        if (_handler.adWebView.alpha==0)
        {
            [_handler showWhiteBoardView];

        }

        return NO;
    }

    return YES;
}
- (void)webViewDidStartLoad:(UIWebView *)webView {
    
}
- (void)webViewDidFinishLoad:(UIWebView *)webView {
    if ([webView.request.URL.absoluteString isEqualToString:KEY_INDEX_AD_URL])
    {
        NSString *htmlStr =[webView stringByEvaluatingJavaScriptFromString:@"document.documentElement.innerHTML"];
        htmlStr = [htmlStr stringByReplacingOccurrencesOfString:@"&amp;" withString:@"&"];
        NSRange urlStartRange = [htmlStr rangeOfString:@"<a href=\""];
        htmlStr = [htmlStr substringFromIndex:urlStartRange.location+urlStartRange.length];
        NSRange urlEndRange = [htmlStr rangeOfString:@"\""];
        NSRange urlMakeRange = NSMakeRange(0, urlEndRange.location);
        if (urlMakeRange.length>0)
        {
            NSString *fullUrl = [htmlStr substringWithRange:urlMakeRange];
            NSString *url = [fullUrl substringFromIndex:[fullUrl rangeOfString:@"&u="].location+[fullUrl rangeOfString:@"&u="].length];
            if (![url isEqualToString:@""])
            {
                self.urlStr = fullUrl;
            }
            
            
            
        }
        NSRange imgStartRange = [htmlStr rangeOfString:@"<img src=\""];
        htmlStr = [htmlStr substringFromIndex:imgStartRange.location+imgStartRange.length];

        NSRange imgEndRange = [htmlStr rangeOfString:@"\""];
        NSRange imgMakeRange = NSMakeRange(0, imgEndRange.location);
        

        if (imgMakeRange.length>0)
        {

            self.imgStr = [htmlStr substringWithRange:imgMakeRange];
                
        }
        KSDINFO(@"%@  \n  %@",urlStr,imgStr);
    }
    else if ([[webView.request.URL.absoluteString substringToIndex:7] isEqualToString:@"file://"])
    {
        KSDINFO(@"%@",webView.request.URL.absoluteString);
//        [self.webView addGestureRecognizer:tap];
        
        
    }


    
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
    [self.webView loadHTMLString:[NSString stringWithFormat:@"<html><head><meta name='viewport' content=\"user-scalable=no, width=680, height=80\" /><style>*{padding:0px;margin:0;}body{padding:0;margin:0;}</style></head><body><img src='ad_01.png' style='width:680px;height:80px;'></body><html>"] baseURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] bundlePath]]];
}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer
{
    return YES;
}
@end
