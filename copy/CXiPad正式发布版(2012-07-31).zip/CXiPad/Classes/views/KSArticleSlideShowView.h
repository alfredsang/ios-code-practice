//
//  KSArticleSlideShowView.h
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSViewInitor.h"
#import "KSPageView.h"

@interface KSArticleSlideShowView : KSPageView<KSViewInitor>{
    NSArray* _images;
//    UIScrollView *imagesScrollView;
    UIButton *_dismissBtn;
}
- (id)initWithFrame:(CGRect)frame images:(NSArray *)images;
@end
