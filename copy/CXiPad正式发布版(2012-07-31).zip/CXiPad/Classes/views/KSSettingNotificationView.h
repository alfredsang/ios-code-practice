//
//  KSNotificationSettingView.h
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-7.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>

@class KSSettingView;
@interface KSSettingNotificationView : UIView<UIPickerViewDataSource, UIPickerViewDelegate> {
    
    NSInteger _beginTime;
    NSInteger _endTime;
    BOOL _shouldPushNews;
    BOOL _shouldPushMagazine;
    
    KSSettingView *_parent;
}
@property(nonatomic, assign)KSSettingView *parent;

@end
