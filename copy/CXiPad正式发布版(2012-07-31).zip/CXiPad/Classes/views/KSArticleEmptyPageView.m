//
//  KSArticleEmptyPageView.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 12-1-2.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import "KSArticleEmptyPageView.h"

@implementation KSArticleEmptyPageView

- (id)initWithFrame:(CGRect)frame index:(NSInteger)index
{
    self = [super initWithFrame:frame];
    if (self) {
        _index = index;
        [self initSubviews];
    }
    return self;
}
- (void)dealloc{
    [super dealloc];
}

- (void)initSubviews{
}

- (NSInteger)getIndex{
    return _index;
}
@end
