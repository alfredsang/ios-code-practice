//
//  KSSettingFaqView.h
//  CenturyWeeklyV2
//
//  Created by zyk on 12/22/11.
//  Copyright (c) 2011 KSMobile. All rights reserved.
//

#import <MessageUI/MessageUI.h>
#import <UIKit/UIKit.h>

@interface KSSettingFaqView : UIView<UIWebViewDelegate,MFMailComposeViewControllerDelegate> {
    UIScrollView *_scrollView;
    UIImageView *_imageView;
    UIWebView *_webView;
    NSString *_faqHtmlStr;
}

@end
