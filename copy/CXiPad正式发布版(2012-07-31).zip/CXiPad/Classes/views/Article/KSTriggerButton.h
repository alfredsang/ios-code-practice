//
//  KSTriggerButton.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 3/11/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KSTriggerButton : UIButton {
    NSString *_imagePath;
}

@end
