//
//  KSTriggerView.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 3/11/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KSTriggerView : UIView {
    NSString *_imagePath;
}
@property(nonatomic, retain)NSString *imagePath;

@end
