//
//  KSTriggerView.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 3/11/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KSTriggerView.h"

@implementation KSTriggerView
@synthesize imagePath = _imagePath;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
