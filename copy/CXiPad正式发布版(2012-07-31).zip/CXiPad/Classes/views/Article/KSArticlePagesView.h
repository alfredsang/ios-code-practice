//
//  KSArticlePagesView.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 3/10/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KSPageView.h"
#import "KSDirectoryMainView.h"
#import "KSMainController.h"

@class KSArticleViewController;
@class KSArticleCoreTextView;
@interface KSArticlePagesView : KSPageView<UIGestureRecognizerDelegate> {
    KSArticleViewController *_handler;
    BOOL _shouldLocateLastPage;
    CGFloat _originalOffset;
    
    BOOL _shouldGoNext;
    
    CGPoint _beginPoint1;
    CGPoint _beginPoint2;
    CGPoint _endPoint1;
    CGPoint _endPoint2;
    //NSInteger _oldPageIndex;
}
@property(nonatomic, assign)KSArticleViewController *handler;
@property(nonatomic, assign)BOOL shouldLocateLastPage;

- (id)initWithFrame:(CGRect)frame articles:(NSMutableArray *)articles;

- (void)decreaseFont;
- (void)resetFont;
- (void)increaseFont;

- (void)didReceiveMemoryWarning;
- (void)removeAllPages;
- (void)setDataList:(NSMutableArray *)dataList;

@end
