//
//  KSArticleHeaderHelper.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 3/16/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KSArticleHeaderHelper.h"
#import "KSArticleCoreTextHeaderView.h"


@implementation KSArticleHeaderHelper

+ (CGFloat)calHeaderMoveGap:(KSModelArticle *)article leftImg:(NSString *)leftImage rightImg:(NSString *)rightImage oriRect:(CGRect)rect isV:(BOOL)isV 
{
    CGFloat moveGap = 0;
    if (rightImage && [rightImage length]) 
    {
        CGSize maxSz = CGSizeMake(rect.size.width-200-10.0f, 9999.0f);
        CGSize sz = [article.title sizeWithFont:ARTICLE_SINGLE_TITLE_FONT constrainedToSize:maxSz lineBreakMode:UILineBreakModeWordWrap];
        if (sz.height > 60) 
        {
            moveGap += (sz.height-60);
        }
        maxSz = CGSizeMake(rect.size.width-200-15.0f, 9999.0f);
        sz = [article.summary sizeWithFont:ARTICLE_SUMARRY_FONT constrainedToSize:maxSz lineBreakMode:UILineBreakModeWordWrap];
        if (sz.height > 30) 
        {
            moveGap += (sz.height-30.0f);
        }
    } 
    else if (leftImage && [leftImage length] && !isV)
    {
        CGSize maxSz = CGSizeMake(rect.size.width-10.0f, 9999.0f);
        CGSize sz = [article.title sizeWithFont:ARTICLE_SINGLE_TITLE_FONT constrainedToSize:maxSz lineBreakMode:UILineBreakModeWordWrap];
        CGFloat move1 = 0, move2 = 0;
        if (sz.height > 60) 
        {
            move1 += (sz.height-60);
        }
        if (![article.subtitle isEmpty])
        {
            move1+=DISTANCE_BETWEEN_TITLE_AND_SUBTITLE+30;
        }
        if (![article.summary isEmpty])
        {
            maxSz = CGSizeMake(rect.size.width-15.0f, 9999.0f);
            sz = [article.summary sizeWithFont:ARTICLE_SUMARRY_FONT constrainedToSize:maxSz lineBreakMode:UILineBreakModeWordWrap];
            if (sz.height > 30) 
            {
                move2 += (sz.height-30.0f)+DISTANCE_BETWEEN_SUBTITLE_AND_SUMMARY;
            }

        }
        if (move1 + move2 > 50) 
        {
            moveGap = move1+move2-50;
        }
    }
    else 
    {
        CGSize maxSz = CGSizeMake(rect.size.width-10.0f, 9999.0f);
        CGSize sz;
        if ([article.title rangeOfString:@"|"].length>0)
        {
            sz = [article.title sizeWithFont:ARTICLE_DOUBLE_TITLE_FONT constrainedToSize:maxSz lineBreakMode:UILineBreakModeWordWrap];
        }
        else 
        {
            sz = [article.title sizeWithFont:ARTICLE_SINGLE_TITLE_FONT constrainedToSize:maxSz lineBreakMode:UILineBreakModeWordWrap];            
        }
        if (sz.height > 60) 
        {
            moveGap += (sz.height-60);
        }
        if (![article.subtitle isEmpty])
        {
            moveGap+=DISTANCE_BETWEEN_TITLE_AND_SUBTITLE+30;
        }

        sz = [article.summary sizeWithFont:ARTICLE_SUMARRY_FONT constrainedToSize:maxSz lineBreakMode:UILineBreakModeWordWrap];
        if (sz.height > 30) 
        {
            moveGap += (sz.height-30.0f)+DISTANCE_BETWEEN_SUBTITLE_AND_SUMMARY;
        }
    }
    return moveGap;
}

@end
