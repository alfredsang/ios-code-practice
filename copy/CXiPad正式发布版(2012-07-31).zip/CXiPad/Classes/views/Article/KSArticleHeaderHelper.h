//
//  KSArticleHeaderHelper.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 3/16/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KSModelArticle.h"
@interface KSArticleHeaderHelper : NSObject

+ (CGFloat)calHeaderMoveGap:(KSModelArticle *)article leftImg:(NSString *)leftImage rightImg:(NSString *)rightImage oriRect:(CGRect)oriRect isV:(BOOL)isV;
@end
