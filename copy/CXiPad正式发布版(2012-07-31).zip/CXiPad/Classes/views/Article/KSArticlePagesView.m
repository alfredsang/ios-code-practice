//
//  KSArticlePagesView.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 3/10/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KSArticlePagesView.h"
#import "KSModelArticle.h"
#import "KSArticleWebView.h"
#import "KSArticleCoreTextView.h"
#import "KSArticleViewController.h"

@implementation KSArticlePagesView
@synthesize handler = _handler;
@synthesize shouldLocateLastPage = _shouldLocateLastPage;

- (void)dealloc {
    [super dealloc];
}


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame articles:(NSMutableArray *)articles {
    self = [super initWithFrame:frame];
    if (self) {
        _dataList = [articles retain];
        //_cacheViewsList = [[NSMutableArray alloc] initWithCapacity:30];
        for (int i = 0; i < [articles count]; i++) {
            [_cacheViewsList addObject:[NSNull null]];
        }
        _pageSize = 1;
        _pageCount = [_dataList count];
        _cellWidth = _pageWidth = self.width;
        [self loadView];
        _scrollView.backgroundColor = [UIColor clearColor];
        _scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
        
        self.backgroundColor = [UIColor clearColor];
        
        _shouldLocateLastPage = YES;
    
        UIPanGestureRecognizer *doubleSwipGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(doubleSwipped:)];
        doubleSwipGesture.maximumNumberOfTouches = 2;
        doubleSwipGesture.minimumNumberOfTouches = 2;
        doubleSwipGesture.delegate = self;
        [self addGestureRecognizer:doubleSwipGesture];
        [doubleSwipGesture release];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void)doLayoutsubviews {
    _rotating = YES;
    self.superview.userInteractionEnabled = NO;
    _scrollView.contentSize = CGSizeMake(_pageWidth*_pageCount, _scrollView.height);
    _scrollView.contentOffset = CGPointMake(_pageWidth*_pageIndex, 0);
    for (int i = 0; i < [_cacheViewsList count]; i++) {
        UIView *view = [_cacheViewsList objectAtIndex:i];
        if ((NSNull *)view != [NSNull null]) {
            view.frame = CGRectMake(_pageWidth*i, 0, _pageWidth, _scrollView.height);
            [view setNeedsDisplay];
        }
    }
    self.superview.userInteractionEnabled = YES;
    NSInteger _oldPageIndex = ((KSArticleViewController *)self.viewController).currentPageIndex;
    if (_oldPageIndex !=_pageIndex) {
        [self moveToViewAtPage:_oldPageIndex animated:NO];
    }
    _rotating = NO;
}

- (void)layoutSubviews{
    if ([UIUtil currentOrientation] == 0) {
        _cellWidth = _pageWidth = 768;
    } else {
        _cellWidth = _pageWidth = 1024;
    }
    IF_PRE_IOS5(if (_scrolling) return;);
    
   // [self unloadAllPages];  //cxy
    
    self.superview.userInteractionEnabled = NO;
    _rotating = YES;
    if (_scrolling) {
        [self performSelector:@selector(doLayoutsubviews) withObject:nil afterDelay:0.1];
        return;
    }
    [self doLayoutsubviews];
}

#pragma mark -
- (UIView *)newCachedView:(NSInteger)index {
    //    CGFloat h = 1024;
    //    CGFloat w = 768;
    //    _pageWidth = _cellWidth = 768;
    //    if ([UIUtil currentOrientation]!=0) {
    //        h = 768;
    //        _cellWidth = _pageWidth = w = 1024;
    //    }
    CGRect currentFrame = CGRectMake(_pageWidth*index, 0, _pageWidth, self.height);
    UIView *v = nil;
    KSModelArticle *article = [_dataList objectAtIndex:index];
    if (article.artitype==2)
    {

        
        v = [[KSDirectoryMainView alloc] initWithFrame:currentFrame magazine:_handler.magzineId controller:_handler];
    }

    else if(article.isHtml )
    {
    
    
        
        v = [[KSArticleWebView alloc] initWithFrame:currentFrame article:article hanlder:_handler index:index];
            
        
    } 
    else 
    {
        v = [[KSArticleCoreTextView alloc] initWithFrame:currentFrame article:article handler:_handler index:index];
        if (index < _pageIndex) {
            
        }
    }
    //v.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    
    return v;
}


- (void)setCachedViewState:(NSInteger)index {
    
    KSArticleCoreTextView *v = [_cacheViewsList objectAtIndex:index];
    
    if ([v respondsToSelector:@selector(locateToFirstPage)] && _formerPageIndex == _pageIndex+1) {
        [v locateToFirstPage];
    }
    
    _formerPageIndex = _pageIndex;
    _shouldLocateLastPage = YES;
    
    [_handler articleDidLoad:index];
}
- (void)setDataList:(NSMutableArray *)dataList {
    [_dataList release];
    _dataList = [dataList retain];
    for (int i=0; i<[_cacheViewsList count]; i++) {
        UIView *v = [_cacheViewsList objectAtIndex:i];
        if (v != nil && (NSNull *)v != [NSNull null] && i!=_pageIndex) {
            [v removeFromSuperview];
        }
    }
    for (int i = 0; i<[_cacheViewsList count]; i++)
    {
        if (i!=_pageIndex)
        {
            [_cacheViewsList removeObjectAtIndex:i];
        }
    }
//    [_cacheViewsList removeAllObjects];
    _pageCount = [_dataList count];
    for (int i = 0; i < _pageCount; i++) {
        [_cacheViewsList addObject:[NSNull null]];
    }
    _scrollView.contentSize = CGSizeMake(_pageWidth * _pageCount, _scrollView.height);
}
#pragma mark -
#pragma mark UIScrollViewDelegate
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    if (scrollView == _scrollView) {
        _scrolling = YES;
        _originalOffset = scrollView.contentOffset.x;
    }
}

/*
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if (scrollView == _scrollView) {
        //NSLog(@"scrollViewDidScroll starting");
        if (_pageIndex != [self centerViewIndex] && !_rotating) {

            NSInteger newIndex = [self centerViewIndex];
            if (newIndex >= _pageCount || newIndex < 0) {
                return;
            }
            NSLog(@"scrollViewDidScroll _pageIndex = %d,newIndex=%d",_pageIndex,newIndex);
            if(abs(newIndex-_pageIndex)>1){
               // [self moveToViewAtPage:newIndex animated:YES];
                //[_scrollView setContentOffset:CGPointMake(_pageIndex*_pageWidth, 0) animated:NO];
            }
        }
        
    }
    
}
*/ 

#pragma mark -
- (void)changeFont:(UIView *)v {
    
}
- (void)decreaseFont {
    for (KSArticleCoreTextView *v in [_scrollView subviews]) {
        if ([v isKindOfClass:[KSArticleCoreTextView class]]) {
            [v decreaseFont];
        }
    }
}
- (void)resetFont {
    for (KSArticleCoreTextView *v in [_scrollView subviews]) {
        if ([v isKindOfClass:[KSArticleCoreTextView class]]) {
            [v resetFont];
        }
    }
}
- (void)increaseFont {
    for (KSArticleCoreTextView *v in [_scrollView subviews]) {
        if ([v isKindOfClass:[KSArticleCoreTextView class]]) {
            [v increaseFont];
        }
    }
}
#pragma mark -
- (void)unLoadScrollViewWithPage:(NSInteger)page {
    if (page < 0) return;
    if (page >= _pageCount) return;
    
    NSLog(@"begin unLoadScrollViewWithPage page=%d",page);    
    for (int i = 0; i < [_cacheViewsList count]; i++) {
        if (i<(page-1)*_pageSize || i>(page+1)*_pageSize) {
            UIView *view = [_cacheViewsList objectAtIndex:i];
            if ((NSNull *)view != [NSNull null]) {
                 NSLog(@"begin unLoadScrollViewWithPage valid i=%d",i);               
                [view removeFromSuperview];
                [_cacheViewsList replaceObjectAtIndex:i withObject:[NSNull null]];
                NSLog(@"end unLoadScrollViewWithPage valid i=%d",i);
            }
        }
    }
    
    NSLog(@"end unLoadScrollViewWithPage page=%d",page);   
}

#pragma mark -
- (void)removeAllPages {
    NSInteger count = 0;
    for (count=0; count < _pageCount; count++) {
        for (int i = 0; i < _pageSize; i++) {
            UIView *view = [_cacheViewsList objectAtIndex:(count*_pageSize+i)];
            if ((NSNull *)view != [NSNull null] && _pageIndex != count) {
                [view removeFromSuperview];
                [_cacheViewsList replaceObjectAtIndex:(count*_pageSize+i) withObject:[NSNull null]];
            }
        }
	}
}
#pragma mark -
- (void)doubleSwipped:(UIPanGestureRecognizer *)gesture {
    if (gesture.state == UIGestureRecognizerStateBegan) {
        _scrollView.scrollEnabled = NO;
                
    } else if(gesture.state == UIGestureRecognizerStateChanged){
        CGPoint p = [gesture translationInView:gesture.view];
        if (p.x < 0)
            _shouldGoNext = YES;
        else
            _shouldGoNext = NO;
                
    } else if(gesture.state == UIGestureRecognizerStateEnded) {
        _scrollView.scrollEnabled = YES; 
        if (_shouldGoNext) {
            [_handler gotoNextPage];
        } else {
            [_handler gotoPrevPage];
        }
    }
}
#pragma mark - UIGestureRecognizerDelegate
- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer {
    return YES;
}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer{
    return YES;
}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch{
    return YES;
}
#pragma mark -
- (void)didReceiveMemoryWarning {
    [self unloadAllPages];
}

@end
