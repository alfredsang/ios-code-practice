//
//  KSTriggerButton.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 3/11/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KSTriggerButton.h"

@implementation KSTriggerButton

- (void)dealloc {
    [_imagePath release];
    [super dealloc];
}
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
