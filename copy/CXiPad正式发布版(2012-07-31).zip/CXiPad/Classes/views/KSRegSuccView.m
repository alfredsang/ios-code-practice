//
//  KSRegSuccView.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-20.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSRegSuccView.h"
#import "KSLoginView.h"
#import "KSMagzineViewController.h"

@implementation KSRegSuccView
@synthesize parent = _parent;
@synthesize lbl_email;
@synthesize email = _email, handler=_handler;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

//- (void)awakeFromNib {
//    self.layer.borderColor = [UIColor redColor].CGColor;
//    self.layer.borderWidth = 1;
//}
- (void) layoutSubviews{
    lbl_email.text = _email;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (IBAction)onClose:(id)sender {
    [[NSNotificationCenter defaultCenter] postNotificationName:@"CXActiveUserDataRequest" object:nil];
    if (_parent) {
        [_parent dismissRegSuccView];
    } else {
        [_handler dismissRegSuccView];
    }
    
}

- (IBAction)onLoginToEmail:(id)sender {
    [(KSMagzineViewController *)_handler openMail:_email];
}

- (IBAction)onResend:(id)sender {
    NSData* data=[_email dataUsingEncoding:NSUTF8StringEncoding];
    NSString* email = [data base64EncodedString];
    [CXActiveUserDataRequest requestWithDelegate:self withParameters:[NSDictionary dictionaryWithObjectsAndKeys:email,@"email", nil] withCancelSubject:@"CXActiveUserDataRequest"];
    //[_handler resendTo:_email];
}

- (void)dealloc {
    [_email release];
    [lbl_email release];
    [super dealloc];
}

#pragma mark - KSDataRequestDelegate
- (void)requestDidStarted:(KSBaseDataRequest *)request {
    [UIUtil showProcessIndicatorWithView:self atPoint:CGPointMake(round(self.width/2), round(self.height/2)) hasMask:NO];
}
- (void)requestDidFinished:(KSBaseDataRequest *)request {
    [UIUtil hideProcessIndicatorWithView:self];
    [UIUtil showMsgAlertWithTitle:@"提示" message:@"成功发送邮件"];
}
- (void)requestDidCanceled:(KSBaseDataRequest *)request {
    [UIUtil hideProcessIndicatorWithView:self];
}
- (void)requestDidFailed:(KSBaseDataRequest *)request withError:(NSError*)error {
    [UIUtil hideProcessIndicatorWithView:self];
    [UIUtil showMsgAlertWithTitle:@"提示" message:request.requestResult.message];
}
@end
