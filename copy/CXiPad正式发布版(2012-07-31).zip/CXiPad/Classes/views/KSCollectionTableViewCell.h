//
//  KSCollectionTableViewCell.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 12/30/11.
//  Copyright (c) 2011 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSModelCollectionItem.h"

@interface KSCollectionTableViewCell : UITableViewCell {
    KSModelCollectionItem *_collectItem;
    UIImageView *_frameImageView;
    UIImageView *_cellImageView;
    UIImageView *_lockImageView;
    UILabel *_timeLabel;
}
@property(nonatomic, retain)KSModelCollectionItem *collectItem;

- (id)initWithCollectItem:(KSModelCollectionItem *)item reuseIdentifier:(NSString *)reuseIdentifier;
@end
