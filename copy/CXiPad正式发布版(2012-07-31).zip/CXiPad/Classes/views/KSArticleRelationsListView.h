//
//  KSArticleRelationsListView.h
//  CenturyWeeklyV2
//
//  Created by 广亮 高 on 12-5-28.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>




@interface KSArticleRelationsListCellView : UITableViewCell

@property(nonatomic,retain) UILabel *titleLabel;
@property(nonatomic,retain) UILabel *summaryLabel;
@property(nonatomic,retain) UIImageView *typeImage;

-(void)relaodData:(NSDictionary*)dic;

@end


@interface KSArticleRelationsListView : UIView<UITableViewDelegate,UITableViewDataSource>
{
    UITableView *theTableView;
}

@property(nonatomic,retain) NSMutableArray *dataArray;



@end
