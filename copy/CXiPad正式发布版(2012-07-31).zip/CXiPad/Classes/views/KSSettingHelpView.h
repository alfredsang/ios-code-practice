//
//  KSHelpView.h
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSPageViewController.h"

@interface KSSettingHelpView : UIView<UIScrollViewDelegate> {
    
    IBOutlet UIScrollView *_topScrollView;
    IBOutlet UILabel *_title1Label;
    IBOutlet UIScrollView *_help1ScrollView;
    IBOutlet KSPageViewController *_pageController1;
    
    IBOutlet UILabel *_title2Label;
    IBOutlet UIScrollView *_help2ScrollView;
    IBOutlet KSPageViewController *_pageController2;
    
    IBOutlet UILabel *_title3Label;
    IBOutlet UIScrollView *_help3ScrollView;
    IBOutlet KSPageViewController *_pageController3;
    
}

@end
