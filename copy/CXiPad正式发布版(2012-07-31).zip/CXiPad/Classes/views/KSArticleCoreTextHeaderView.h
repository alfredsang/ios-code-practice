//
//  KSArticleCoreTextHeaderView.h
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSModelArticle.h"
#import "KSViewInitor.h"


#define DISTANCE_BETWEEN_TITLE_AND_SUBTITLE     10
#define DISTANCE_BETWEEN_SUBTITLE_AND_SUMMARY   10

@interface KSArticleCoreTextHeaderView : UIView<KSViewInitor>{
    KSModelArticle *_article;
    NSString *_leftImage;
    NSString *_rightImage;
    UIImageView *_imageView;
    
    UILabel *titleView;
    UILabel *subtitleView;
    UILabel *summaryLabel;
    UILabel *authorsView;
    UILabel *columnistView;
    BOOL _shouldTuneFrame;
    BOOL    _isDoubleTitle;
    CGFloat _moveGap;
}
@property(nonatomic, assign)BOOL shouldTuneFrame;
@property(nonatomic, assign)CGFloat moveGap;

- (id) initWithFrame:(CGRect)frame article:(KSModelArticle *)article;
- (id)initWithFrame:(CGRect)frame article:(KSModelArticle *)article leftimg:(NSString *)leftImage rightimg:(NSString *)rightImge;
@end
