//
//  KSArticleProgressView.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 1/8/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "KSArticleProgressView.h"

#define PROGRESS_BAR_WIDTH 157

@implementation KSArticleProgressView
- (id)initWithFrame:(CGRect)frame{
    if(self = [super initWithFrame:frame]){
        self.backgroundColor = [UIColor clearColor];
        [self initSubviews];
    }
    return self;
}

- (void)dealloc{
    [lblProgress release];
    [progressBarView release];
    [super dealloc];
}

- (void)initSubviews{
    UIImageView *bgImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0,0,186,48)];
    bgImageView.image = [UIImage imageNamedNocache:@"a_progress_bar.png"];
    [self addSubview:bgImageView];
    [bgImageView release];
    
    //UILabel *lblDesc = [[UILabel alloc] initWithFrame:CGRectMake(5, 0, 120, 20)];
    //lblDesc.text = @"正在载入离线文章";
    //lblDesc.font = [UIFont systemFontOfSize:10.0];
    //lblDesc.backgroundColor = [UIColor clearColor];
    //[self addSubview:lblDesc];
    //[lblDesc release];
    lblProgress = [[UILabel alloc] initWithFrame:CGRectMake(115, 0, 60, 25)];
    lblProgress.textAlignment = UITextAlignmentCenter;
    lblProgress.textColor = [UIColor whiteColor];
    lblProgress.text = STR_FORMAT(@"%d/%d", 0, 0);
    lblProgress.font = [UIFont systemFontOfSize:10.0];
    lblProgress.backgroundColor = [UIColor clearColor];
    [self addSubview:lblProgress];
    progressBarView = [[UIView alloc] initWithFrame:CGRectMake(13, 22, 0, 2)];
    progressBarView.backgroundColor = [UIColor orangeColor];
    [self addSubview:progressBarView];
}

- (void) setProgress:(NSInteger)downloadNum allNums:(NSInteger)allNums{
    if(allNums<=0 || downloadNum>=allNums){
        self.hidden = YES;
        return;
    }
    self.hidden = NO;
    _downloadArticlesNum = downloadNum;
    _articlesNum = allNums;
    lblProgress.text = STR_FORMAT(@"%d/%d", _downloadArticlesNum, _articlesNum);
    progressBarView.width = PROGRESS_BAR_WIDTH*1.0*_downloadArticlesNum/_articlesNum;
}

@end
