//
//  KSMagazineCoverView.m
//  CenturyWeeklyV2
//
//  Created by 广亮 高 on 12-6-8.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import "KSMagazineCoverView.h"
#import "KSMagzineViewController.h"



static NSInteger lastPageIndex = 0;

@implementation KSMagazineCoverImageView
@synthesize imageView;

-(void)loadMagazine:(KSModelMagzine*)magazine
{
    if (magazine == nil)
    {
        return ;
    }
    else 
    {
        UIImage *image = [UIImage imageWithContentsOfFile:magazine.cover_2];
        if (image)
        {
            imageView.image = image;
        }
        else 
        {
            imageView.image = [UIImage imageNamed:@"default_cover_440_570.png"];
        }
    }
    UIImageView *unpurchased = (UIImageView*)[self viewWithTag:2222];
    if (unpurchased==nil)
    {
        unpurchased = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"btn_not_buy.png"]];
        unpurchased.frame = CGRectMake(imageView.right-93, imageView.height-92, 93, 92);
        unpurchased.tag = 2222;
        [imageView addSubview:unpurchased];
        [unpurchased release];
        
    }
    if (![magazine isMybook])
    {


        unpurchased.hidden = NO;
        

    }
    else
    {
        unpurchased.hidden = YES;
    }
}

-(id)initWithFrame:(CGRect)frame Magazine:(KSModelMagzine*)magazine controller:(id)controller
{
    self = [super initWithFrame:frame];
    if (self)
    {
        _controller = [controller retain];
        imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.width, self.height)];
        imageView.userInteractionEnabled = YES;
        [self addSubview:imageView];
        [self loadMagazine:magazine];
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapCover:)];
        [imageView addGestureRecognizer:tap];
        [tap release];
    }
    return self;
}
-(void)tapCover:(UIGestureRecognizer*)gesture
{
    KSModelMagzine *magazine = [_controller currentMagzine];
    if ([magazine isMybook])
    {
        [_controller buy:_controller.main.buy];
    }
//    else 
//    {
//        [_controller.main readMagazine:_controller.main.try_read];
//    }
}
-(void)gotoArticle
{
    if ([_controller currentMagzine].isDownload)
    {
        [_controller gotoArticle:0 magzineId:[_controller currentMagzine].magzineId from:@"bookself"];

    }
}
-(void)dealloc
{
    RELEASE_SAFELY(_controller);
    RELEASE_SAFELY(imageView);
    [super dealloc];
}
@end




@implementation KSMagazineCoverView
@synthesize controller = _controller,magzines = _magzines;
@synthesize lastIndex;


-(void)initSubView
{
    
}

- (id)initWithFrame:(CGRect)frame controller:(id)controller
{
    self = [super initWithFrame:frame];
    if (self) 
    {
        self.showsVerticalScrollIndicator = NO;
        self.showsHorizontalScrollIndicator = NO;
        self.contentSize = CGSizeMake(440, 570);
        self.pagingEnabled = YES;
        self.delegate = self;
        lastIndex = 0;
        _userdCoverViews = [[NSMutableArray alloc] init];
        _controller = [controller retain];
        [self reloadData];
    }
    return self;
}

-(void)loadMagazineByYear:(NSMutableArray*)magazines
{
    if (_magzines)
    {
        [_magzines removeAllObjects];
        RELEASE_SAFELY(_magzines);
    }
    _magzines = [magazines retain];
    [self reloadDataWithMagazines:_magzines];
}
-(void)selectYear:(NSInteger)selectYear
{
    
    NSInteger row = 0;
    for (int i = 0; i<[_magzines count]; i++)
    {
        if ([[_magzines objectAtIndex:i] isKindOfClass:[KSModelMagzine class]])
        {
            KSModelMagzine *magazine = [_magzines objectAtIndex:i];
            NSDate *date = [NSDate dateWithTimeIntervalSince1970:magazine.pubDate];
            
            if ([DateUtil getYearByDate:date] == selectYear) 
            {
                row = i;
                break;
            }
            
        }
    }

    self.contentOffset = CGPointMake(self.width*row, self.contentOffset.y);
}
-(void)addToUsedCoverViews:(KSMagazineCoverImageView*)item
{
    BOOL find = NO;
    for (KSMagazineCoverImageView *itemView in _userdCoverViews)
    {
        if (itemView == item)
        {
            find = YES;
        }
    }
    if (!find)
    {
        [_userdCoverViews addObject:item];
    }
}
-(KSMagazineCoverImageView*)getFormUsedCoverViews
{
    BOOL find = NO;
    NSArray *views = [self subviews];
    
    for (KSMagazineCoverImageView *usedItem in _userdCoverViews)
    {
        for (KSMagazineCoverImageView *usingItem in views)
        {
            if (usingItem == usedItem)
            {
                find = YES;
                break;
            }
            else
            {
                find = NO;
            }
        }
        if(!find)
        {
            return usedItem;
        }
    }

    return nil;
}
-(void)loadItemCoverView:(NSInteger)index
{
    if (index<0||index>[_magzines count]-1||[_magzines count]==0)
    {
        return;
    }
    KSModelMagzine *magazine = [_magzines  objectAtIndex:index];
    KSMagazineCoverImageView *item = (KSMagazineCoverImageView*)[self viewWithTag:magazine.magzineId];

    if (!item)
    {
        item = [self getFormUsedCoverViews];
        if (!item)
        {
            item = [[KSMagazineCoverImageView alloc] initWithFrame:CGRectMake(self.width*index, 0, 440, 570) Magazine:magazine controller:_controller];
            item.centerX = self.centerX+self.width*index;
            item.tag = magazine.magzineId;
            [self addSubview:item];
            [item release];
            [self addToUsedCoverViews:item];
        }
        else
        {
            item.centerX = self.centerX+self.width*index;
            item.tag = magazine.magzineId;
            [item loadMagazine:magazine];
            [self addSubview:item];
        }


    }
    else
    {
        if (item.tag != magazine.magzineId)
        {
            item.centerX = self.centerX+self.width*index;
            item.tag = magazine.magzineId;
            [item loadMagazine:magazine];
        }

    }
}
-(void)reloadDataWithMagazines:(NSMutableArray*)magazs
{
    self.contentSize = CGSizeMake(768*[magazs count], 570);

    for (int i = 0; i<[magazs count]; i++)
    {
        KSModelMagzine *magazine = [magazs objectAtIndex:i];
        KSMagazineCoverImageView *item = (KSMagazineCoverImageView*)[self viewWithTag:magazine.magzineId];
        if (item == nil)
        {
            item = [[KSMagazineCoverImageView alloc] initWithFrame:CGRectMake(self.width*i, 0, 440, 570) Magazine:magazine controller:_controller];
            item.centerX = self.centerX+self.width*i;
            item.tag = magazine.magzineId;
            [self addSubview:item];
            [item release];
        }
        else 
        {
            item.centerX = self.centerX+self.width*i;
            [item loadMagazine:magazine];
        }
    }
    
}
-(void)reloadData
{
    if (_magzines)
    {
        [_magzines removeAllObjects];
    }
    else {
        _magzines = [[NSMutableArray alloc] init];
    }
    [_magzines addObjectsFromArray:[_controller magzines]];
    self.contentSize = CGSizeMake(768*[_magzines count], 570);
    NSInteger firstIndex =0;
    for (int i = 0; i<[_magzines count]; i++)
    {
        KSModelMagzine *magaz = [_magzines objectAtIndex:i];
        if (magaz.magzineId==[_controller currentMagzine].magzineId)
        {
            firstIndex = i;
            break;
        }
    }
//    if ([[self subviews] count]>0)
//    {
//        UIView *view = (UIView*)[[self subviews] objectAtIndex:0];
//        firstIndex = view.left/self.width;
//    }
    [self removeAllSubviews];
    if ([_magzines count]>=3 && firstIndex==0)
    {
        [self loadItemCoverView:0];
        [self loadItemCoverView:1];
        [self loadItemCoverView:2];
    }
    else if ([_magzines count]>=3 && firstIndex==0)
    {
        for (int i = 0; i<[_magzines count]; i++)
        {
            [self loadItemCoverView:i];
        }
    }
    [self setContentOffset:CGPointMake(self.width*firstIndex, self.contentOffset.y)];
    if (firstIndex==lastIndex)
    {
        [self loadSubViewsWithIndex:firstIndex];
    }
//    [self reloadDataWithMagazines:_magzines];


}
-(void)whenMagzinePurchased:(NSInteger)magazineId
{
    for (int i = 0; i<[_magzines count]; i++)
    {
        KSModelMagzine *magaz = [_magzines objectAtIndex:i];
        if (magaz.magzineId == magazineId)
        {
            [_magzines replaceObjectAtIndex:i withObject:[KSModelMagzine loadById:magazineId]];
            break;
        }
    }
    for (KSMagazineCoverImageView *itemView in [self subviews]) 
    {
        
        if (itemView.tag == magazineId)
        {
            UIImageView *unpurchased = (UIImageView*)[itemView viewWithTag:2222];
            if (unpurchased)
            {
//                [unpurchased removeFromSuperview];
                unpurchased.hidden = YES;
                [self setNeedsDisplay];
                break;
            }
            
        }
        
    }
    
}
- (void) whenInitOrMagzineListUpdate
{
    [self reloadData];

}

- (void) whenMagzineDownloader:(NSInteger)magzineId{
    
    KSMagazineCoverImageView *itemView = (KSMagazineCoverImageView*)[self viewWithTag:magzineId];
    for (int i=0; i<_magzines.count; i++) 
    {
        KSModelMagzine *item = [_magzines objectAtIndex:i];
        if(item.magzineId ==magzineId) 
        {
            KSModelMagzine *m = [KSModelMagzine loadById:item.magzineId];
            [_magzines replaceObjectAtIndex:i withObject:m];
            if ([(KSMagzineViewController *)_controller currentMagzine].magzineId == m.magzineId) {
                [(KSMagzineViewController *)_controller setCurrentMagzine:m];
            }
            if (itemView)
            {
                
                [itemView loadMagazine:m];
                
            }
            
            break;
        }
    }
}
- (void)whenMagzineCover0Download:(NSInteger)magzineId
{
    KSMagazineCoverImageView *itemView = (KSMagazineCoverImageView*)[self viewWithTag:magzineId];
    KSModelMagzine *item = [KSModelMagzine loadById:magzineId];
    UIImage *image = [UIImage imageWithContentsOfFile:item.cover_2];
    if (image)
    {
        itemView.imageView.image = image;
    }



}

- (void)whenMagzineCover1Download:(NSInteger)magzineId{
    for (int i=0, n =_magzines.count; i<n; i++) 
    {
        if([[_magzines objectAtIndex:i] magzineId]!=magzineId)continue;
        KSModelMagzine *item = [KSModelMagzine loadById:magzineId];
        [_magzines replaceObjectAtIndex:i withObject:item];

        UIImage *cropImage = [UIImage imageWithContentsOfFile:item.cover_2];

        if ([cropImage CGImage] == nil)
        {
            cropImage = [UIImage imageNamed:@"default_cover_440_570.png"];
        }
        
        if (!IS_PREV_ISSUE && i==0 && [[UIApplication sharedApplication] respondsToSelector:@selector(setNewsstandIconImage:)]) {
            [[UIApplication sharedApplication] setNewsstandIconImage:cropImage];
            break;
        }
        

    }
}
- (void)whenMagzineDeleted:(KSModelMagzine*)magazine 
{
    KSMagazineCoverImageView *itemView = (KSMagazineCoverImageView*)[self viewWithTag:magazine.magzineId];
    if (itemView)
    {
        [itemView loadMagazine:magazine];
    }
    for (int i=0; i<_magzines.count; i++) 
    {
        KSModelMagzine *item = [_magzines objectAtIndex:i];
        if(item.magzineId ==magazine.magzineId) 
        {
            KSModelMagzine *m = [KSModelMagzine loadById:item.magzineId];
            [_magzines replaceObjectAtIndex:i withObject:m];

            break;
        }
    }
}
- (KSModelMagzine *)currentMagazine {
    if ([_magzines count]) 
    {
        return [_magzines objectAtIndex:self.contentOffset.x/self.width];
    }
    return nil;
}
-(void)leftCover
{
    if (self.contentOffset.x <= 0)
    {
        return;
    }
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDuration:0.5];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(scrollViewDidEndDecelerating:)];
    self.contentOffset = CGPointMake(self.contentOffset.x-self.width, self.contentOffset.y);
    [UIView commitAnimations];
}

-(void)rightCover
{
    if (self.contentOffset.x >= ([_magzines count]-1)*self.width)
    {
        return;
    }
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDuration:0.5];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(scrollViewDidEndDecelerating:)];
    self.contentOffset = CGPointMake(self.contentOffset.x+self.width, self.contentOffset.y);
    [UIView commitAnimations];
    
}
-(void)loadSubViewsWithIndex:(NSInteger)page
{
    if (page == 0)
    {
        [self loadItemCoverView:page+1];
        [self loadItemCoverView:page];
        [self loadItemCoverView:page+2];
    }
    else if(page == [_magzines count]-1)
    {
        [self loadItemCoverView:page-1];
        [self loadItemCoverView:page];
        [self loadItemCoverView:page-2];
    }
    if (page+1<[_magzines count]&&page-1>=0)
    {
        if (page-2>=0)
        {
            KSMagazineCoverImageView *item = (KSMagazineCoverImageView*)[self viewWithTag:[[_magzines objectAtIndex:page-2] magzineId]];
            if (item)
            {
                
                [item removeFromSuperview];
            }
            
        }
        if (page+2<[_magzines count])
        {
            KSMagazineCoverImageView *item = (KSMagazineCoverImageView*)[self viewWithTag:[[_magzines objectAtIndex:page+2] magzineId]];
            if (item)
            {
                [item removeFromSuperview];
            }
        }
        
        
        [self loadItemCoverView:page+1];
        [self loadItemCoverView:page];
        [self loadItemCoverView:page-1];
    }
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat pageWidth = scrollView.frame.size.width;
    int page = floor((scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    if (lastIndex == page || page<0 || page>[_magzines count]-1||[_magzines count]==0)
    {
        return;
    }

    [self loadSubViewsWithIndex:page];
    
    KSModelMagzine *magaz = [_magzines objectAtIndex:page];
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:magaz.pubDate];
    
    NSInteger currentYear = [[_controller.main.yearSeg currentYear] intValue];
    NSInteger magazineYear = [DateUtil getYearByDate:date];
    if (currentYear != magazineYear) 
    {
        NSString *yearStr = [[NSString alloc] initWithFormat:@"%d",magazineYear];
        NSInteger index = [_controller.main.yearSeg.titleArray indexOfObject:yearStr];
        [yearStr release];
        UIButton *btn = (UIButton*)[_controller.main.yearSeg viewWithTag:10+index];
        [_controller.main.yearSeg changeBtnWithAnimation:btn];
    }
    
    lastIndex = page;

}
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    CGFloat pageWidth = scrollView.frame.size.width;
    int page = floor((scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    KSModelMagzine *magaz = [_magzines objectAtIndex:page];
    KSMagazineCoverImageView *itemView = (KSMagazineCoverImageView*)[self viewWithTag:magaz.magzineId];


    UIImage *image = [UIImage imageWithContentsOfFile:magaz.cover_3];
    if (image)
    {
        itemView.imageView.image = image;
    }
    
    
    if (lastPageIndex != page)
    {
        KSModelMagzine *lastMagaz = [_magzines objectAtIndex:lastPageIndex];
        KSMagazineCoverImageView *lastItemView = (KSMagazineCoverImageView*)[self viewWithTag:lastMagaz.magzineId];
        image = [UIImage imageWithContentsOfFile:lastMagaz.cover_2];
        if (image)
        {
            lastItemView.imageView.image = image;
        }
    }
    
    
    
    lastPageIndex = page;
    if ([_controller respondsToSelector:@selector(selectCoverMagazineAtIndex:magazine:)])
    {
        NSInteger index = self.contentOffset.x/self.width ;
        [_controller selectCoverMagazineAtIndex:index magazine:[_magzines objectAtIndex:index]];
    }
    
}
-(void)dealloc
{
    RELEASE_SAFELY(_controller);
    RELEASE_SAFELY(_userdCoverViews);
    [super dealloc];
}
@end
