//
//  KSSearchTableViewCell.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 12/28/11.
//  Copyright (c) 2011 KSMobile. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "KSSearchTableViewCell.h"

@implementation KSSearchTableViewCell
@synthesize searchItem = _searchItem;
@synthesize cellImageView = _cellImageView;

- (void)dealloc
{
    [_cellImageView release];
    [_searchItem release];
    [_timeLabel release];
    [_titleLabel release];
    [_lockImageView release];
    [_frameImageView release];
    [super dealloc];
}

- (BOOL)hasImage {
    return _searchItem.image && [_searchItem.image length];
}
- (NSString *)calTimeString {
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:_searchItem.pubDate];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
	[formatter setDateFormat:@"yyyy年"];
	NSString *year = [formatter stringFromDate:date];
    [formatter setDateFormat:@"MM月"];
    NSString *month = [formatter stringFromDate:date];
    [formatter setDateFormat:@"dd日"];
    NSString *day = [formatter stringFromDate:date];
	[formatter release];
    
    NSString *str = [NSString stringWithFormat:@"来源：%@  %@第%@期%@%@出版", _searchItem.magazineTitle, year, _searchItem.stageNumber, month, day];
    //NSString *str = [NSString stringWithFormat:@" %@第%@期%@%@出版", year, _searchItem.stageNumber, month, day];
    return str;
    
}
- (id)initWithSearchItem:(KSModelSearchItem *)item reuseIdentifier:(NSString *)reuseIdentifier {
    self = [self initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:reuseIdentifier];
    if (self) {
        _searchItem = [item retain];
        self.textLabel.text = _searchItem.title;
        self.textLabel.font = [UIFont systemFontOfSize:15.0f];
        
        CGSize textLabelSize = [self.textLabel.text sizeWithFont:self.textLabel.font];
        self.textLabel.width = textLabelSize.width;
        
        self.detailTextLabel.text = _searchItem.summary;
        self.detailTextLabel.textColor = [UIColor colorWithWhite:0.3 alpha:1];
        self.detailTextLabel.font = [UIFont systemFontOfSize:13.0f];
        self.detailTextLabel.numberOfLines = 2;
        //CGSize size = [summary.newsInfo sizeWithFont:[UIFont systemFontOfSize:14] constrainedToSize:CGSizeMake(contentWidth, 3) lineBreakMode:UILineBreakModeWordWrap]
        
        _frameImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"def_frame.png"]];
        _frameImageView.frame = CGRectMake(13, 12, _frameImageView.width, _frameImageView.height);
        [self.contentView addSubview:_frameImageView];
        
        _cellImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"def_list.png"]];
        _cellImageView.frame = CGRectMake(15, 14, 130, 87);
            //_cellImageView.layer.cornerRadius = 5;
            //_cellImageView.clipsToBounds = YES;
        [self.contentView addSubview:_cellImageView];
        
            _lockImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"lbl_item_locked.png"]];
            [self.contentView addSubview:_lockImageView];
        _lockImageView.frame = CGRectMake(0, 15, _lockImageView.width, _lockImageView.height);
        _lockImageView.hidden = !_searchItem.lock;
        
        _timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.width - 250, 16, 450, 20)];
        _timeLabel.textAlignment = UITextAlignmentRight;
        //_timeLabel.textColor = [UIColor colorWithRed:0xAF/255.0f green:0xAE/255.0f blue:0xAA/255.0f alpha:1];
        _timeLabel.textColor = [UIColor colorWithWhite:0.4 alpha:1];
        _timeLabel.font = [UIFont systemFontOfSize:10.0f];
        _timeLabel.text = [self calTimeString];
        [self.contentView addSubview:_timeLabel];
        
//        _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 16, 240, 20)];
//        _titleLabel.backgroundColor = [UIColor clearColor];
//        _titleLabel.textAlignment = UITextAlignmentRight;
//        _titleLabel.textColor = [UIColor colorWithWhite:0.4 alpha:1];
//        _titleLabel.font = [UIFont systemFontOfSize:10.0f];
//        _titleLabel.text = [NSString stringWithFormat:@"来源：%@ ",_searchItem.magazineTitle];
//        [self.contentView addSubview:_titleLabel];
        
        if ([self hasImage]) {
            [UIUtil imageWithUrl:_searchItem.image toView:_cellImageView shouldResize:YES];
        }
        self.accessoryType = UITableViewCellAccessoryNone;
        //self.accessoryView = [[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"icon_arrow.png"]] autorelease];
        //self.accessoryView.tag = 1010;
    }
    return self;
}
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (void)layoutSubviews {
    [super layoutSubviews];
    _cellImageView.frame = CGRectMake(15, 14, 130, 87);
//    if ([self hasImage ]) {
        _cellImageView.hidden = NO;
        self.textLabel.frame = CGRectMake(156, 12, self.textLabel.width, 27);
    _lockImageView.left = self.textLabel.right+5;
    
    self.detailTextLabel.frame = CGRectMake(156, 40, self.width - 166.0f, 50);
    [self.detailTextLabel alignTop];
    _timeLabel.right = self.width - 20.0f;
    _timeLabel.bottom = self.height - 10;
    _titleLabel.right = _timeLabel.left;
//    }else {
//        _cellImageView.hidden = YES;
//        self.textLabel.frame = CGRectMake(12, 4, 278, 18);
//        self.detailTextLabel.frame = CGRectMake(12, 22, 278, 50);
//    }
    self.detailTextLabel.numberOfLines = 3;
}
- (void)setSearchItem:(KSModelSearchItem *)searchItem {
    if (_searchItem != searchItem) {
        [_searchItem release];
        _searchItem = [searchItem retain];
        
        [_cellImageView removeFromSuperview];
        [_cellImageView release];
        _cellImageView = nil;
        _cellImageView = [[UIImageView alloc] initWithFrame:CGRectMake(12, 15, 100, 66)];
        _cellImageView.image = [UIImage imageNamed:@"def_list.png"];
        [self.contentView addSubview:_cellImageView];
        
        if ([self hasImage]) {
            [UIUtil imageWithUrl:_searchItem.image toView:_cellImageView shouldResize:YES];
        }
        
        self.textLabel.text = _searchItem.title;
        CGSize textLabelSize = [self.textLabel.text sizeWithFont:self.textLabel.font];
        self.textLabel.width = textLabelSize.width;
        
        self.detailTextLabel.text = _searchItem.summary;
        _lockImageView.hidden = !_searchItem.lock;
        
        _timeLabel.text = [self calTimeString];
        _titleLabel.text = [NSString stringWithFormat:@"来源：%@ ",_searchItem.magazineTitle];
        [self setNeedsLayout];
    }
}
@end
