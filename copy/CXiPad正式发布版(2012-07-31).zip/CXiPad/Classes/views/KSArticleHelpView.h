//
//  UIArticleHelpView.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 2/3/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSTapableView.h"
#import "KSSettingHelpView.h"

@interface KSArticleHelpView : UIView<KSTapableDelegate> {
    KSTapableView *_tapableView;
    KSSettingHelpView *_helpView;
}

@end
