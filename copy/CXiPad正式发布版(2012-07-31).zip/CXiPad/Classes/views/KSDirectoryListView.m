//
//  KSDirectoryListView.m
//  CenturyWeeklyV2
//
//  Created by 广亮 高 on 12-6-19.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import "KSDirectoryListView.h"
#import "KSArticleViewController.h"

static BOOL oldStatus; // 用于保存header,footer状态（显示、隐藏）

static NSInteger lastSection = -1;
static BOOL isScale = NO;
static NSInteger selectSection = -1;

@implementation KSDirectoryListView
@synthesize ToolBarStatus = _ToolBarStatus;

- (id)initWithFrame:(CGRect)frame magazineId:(NSInteger)magazineId hander:(id)hander
{
    self = [super initWithFrame:frame];
    if (self) 
    {
        _hander = [hander retain];
        //自动隐藏工具条
        _ToolBarStatus = _hander.headerHide;
        [_hander hideHeaderAndFooter];
        _hander.forceHideHeader = YES;
        
        UIView *bg = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 1024, 1024)];
        bg.backgroundColor = [UIColor blackColor];
        bg.alpha = 0.7;
        bg.autoresizingMask = UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleWidth;
        [self addSubview:bg];
        [bg release];
        
        _tableViewBg = [[UIImageView alloc] initWithFrame:CGRectMake(-411, 0, 411, 1024)];
        _tableViewBg.image = [UIImage imageNamed:@"catalog_list_bg.png"];
        _tableViewBg.userInteractionEnabled = YES;
        [self addSubview:_tableViewBg];
        
        _theTableView = [[UITableView alloc] initWithFrame:CGRectMake(28, 0, 354,1024) style:UITableViewStylePlain];
        _theTableView.delegate = self;
        _theTableView.dataSource = self;
        _theTableView.showsVerticalScrollIndicator = NO;
        _theTableView.showsHorizontalScrollIndicator = NO;
        _theTableView.separatorStyle = UITableViewCellSelectionStyleNone;
        _theTableView.backgroundColor = [UIColor clearColor];
        [_tableViewBg addSubview:_theTableView];
        
        
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 100, 103)];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(28, 70, 50, 20)];
        label.text = @"目录";
        label.backgroundColor = [UIColor clearColor];
        label.font = [UIFont boldSystemFontOfSize:20];
        [view addSubview:label];
        [label release];
        UILabel *enlabel = [[UILabel alloc] initWithFrame:CGRectMake(84, 76, 100, 14)];
        enlabel.text = @"CONTENTS";
        enlabel.backgroundColor = [UIColor clearColor];
        enlabel.font = [UIFont boldSystemFontOfSize:14];
        [view addSubview:enlabel];
        [enlabel release];
        _theTableView.tableHeaderView = view;
        [view release];
        
        _visialeArticles = [[NSMutableArray alloc] init];
        _catalogArray = [[NSMutableArray alloc] init];
        _titleArray = [[NSMutableArray alloc] init];
        [self reloadDataSourceWith:magazineId];
        
        UIPinchGestureRecognizer *pin = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(pinch:)];
        [_theTableView addGestureRecognizer:pin];
        [pin release];
    }
    return self;
}

-(void)dealloc
{
    //恢复工具条原来状态
    if(oldStatus == NO){
        [_hander showHeaderAndFooter];
    }
    _hander.forceHideHeader = NO;
    
    RELEASE_SAFELY(_theTableView);
    RELEASE_SAFELY(_titleArray);
    RELEASE_SAFELY(_catalogArray);
    RELEASE_SAFELY(_hander);
    RELEASE_SAFELY(_visialeArticles);
    RELEASE_SAFELY(_tableViewBg);
    [super dealloc];
}

-(void)pinch:(UIPinchGestureRecognizer*)gesture
{
    NSMutableIndexSet *set = [[NSMutableIndexSet alloc] init];

    if (gesture.numberOfTouches==2)
    {
        KSDINFO(@"33333333333");
    }
    KSDINFO(@"sclae:%f   %f    %d",gesture.scale,gesture.velocity,gesture.numberOfTouches);
    if (gesture.scale >= 2 && !isScale)
    {
        isScale = YES;

        KSDINFO(@"1111111111111111111");
        [_visialeArticles removeAllObjects];
        [_visialeArticles addObjectsFromArray:_titleArray];
        for (int i = 0; i<[_titleArray count]; i++)
        {
            [set addIndex:i];
        }
        [_theTableView reloadSections:set withRowAnimation:UITableViewRowAnimationAutomatic];
    }
    else if(gesture.scale <=0.5 && isScale)
    {
        isScale = NO;

//        selectSection = -1;
        
        KSDINFO(@"2222222222222222222");
        [_visialeArticles removeAllObjects];
        NSDictionary *dic = [_titleArray objectAtIndex:selectSection];
        [_visialeArticles addObject:dic];
        [set removeAllIndexes];
        for (int i = 0; i<[_titleArray count]; i++)
        {
            if (i!=selectSection)
            {
                [set addIndex:i];

            }
        }
        [_theTableView reloadSections:set withRowAnimation:UITableViewRowAnimationAutomatic];
    }
    [set release];
//    lastSection = -1;
}

-(void)reloadDataSourceWith:(NSInteger)magazineId
{
    if (_titleArray)
    {
        [_titleArray removeAllObjects];
    }
    
    NSMutableArray *articleTitles = [[KSModelArticle articlesInMagzine:magazineId] retain];
    if (_catalogArray)
    {
        [_catalogArray removeAllObjects];
    }

    [_catalogArray addObjectsFromArray:[KSModelCatalog catalogLeve1InMagazineId:magazineId inCatalog:YES]];
    if ([_catalogArray count]>0)
    {
        NSRange range = [[[_catalogArray objectAtIndex:0] title] rangeOfString:@"封面"];
        if (range.length>0)
        {
            [_catalogArray removeObjectAtIndex:0];
        }
    }
    NSMutableArray *catalog2 = [[KSModelCatalog catalogLeve2InMagazineId:magazineId] retain];

    NSMutableArray *deletArray = [[NSMutableArray alloc] init];
    for (int  i = 0; i<[_catalogArray count]; i++)
    {
        KSModelCatalog *catalog = [_catalogArray objectAtIndex:i];
        if (![KSModelArticle articlesInCatalog:catalog.catalogId])
        {
            BOOL exist = NO;
            for (int j = 0; j<[catalog2 count]; j++)
            {
                KSModelCatalog *tempCatalog = [catalog2 objectAtIndex:j];
                if (tempCatalog.parentId == catalog.catalogId)
                {
                    if ([KSModelArticle articlesInCatalog:tempCatalog.catalogId])
                    {
                        exist = YES;
                    }
                    
                }
                
                
            }
            if (!exist)
            {
                [deletArray addObject:catalog];
            }
        }
    }
    [_catalogArray removeObjectsInArray:deletArray];
    [deletArray release];
//    for (int  i = 0; i<[_catalogArray count]; i++)
//    {
//        KSModelCatalog *catalog = [_catalogArray objectAtIndex:i];
//        if (![KSModelArticle articlesInCatalog:catalog.catalogId])
//        {
//            [_catalogArray removeObjectAtIndex:i];
//        }
//    }
    
    
    NSMutableArray *catalogLeve2Title = [[KSModelCatalog catalogLeve2InMagazineId:magazineId] retain];

    for (int i =0; i<[articleTitles count]; i++)
    {
        KSModelArticle *article = [articleTitles objectAtIndex:i];
        for (int j = 0; j<[catalogLeve2Title count]; j++)
        {
            KSModelCatalog *catalogLeve2 = [catalogLeve2Title objectAtIndex:j];
            if (article.catagoryId == catalogLeve2.catalogId)
            {
                article.catagoryId = catalogLeve2.parentId;
            }
            
        }
    }
    for (int i =0; i<[_catalogArray count]; i++)
    {
        KSModelCatalog *catalogLeve1 = [_catalogArray objectAtIndex:i];


        NSMutableArray *array = [[NSMutableArray alloc] init];
        for (int j = 0; j<[articleTitles count]; j++)
        {
            KSModelArticle *article = [articleTitles objectAtIndex:j];

            if (article.catagoryId == catalogLeve1.catalogId)
            {

                [array addObject:article];

            }


        }
        NSDictionary *dic = [[NSDictionary alloc] initWithObjectsAndKeys:array,INTEGER(catalogLeve1.catalogId), nil];
        [_titleArray addObject:dic];
        [array release];
        [dic release];

    }
    

    NSLog(@"%d",[_titleArray count]);

    [_theTableView reloadData];
    [articleTitles release];
    [catalogLeve2Title release];
}
-(void)layoutSubviews
{
    _theTableView.height = self.height;
    
}
-(void)showTableViewWithArticleId:(NSInteger)articleId
{

    [self reloadDataSourceWith:[_hander currentMagzine].magzineId];
    NSInteger index = 0;
    for (int i = 0;i<[_titleArray count]; i++)
    {

        KSModelCatalog *catalog = [_catalogArray objectAtIndex:i];
        NSDictionary *dic = [_titleArray objectAtIndex:i];
        NSArray *articles = [dic objectForKey:INTEGER(catalog.catalogId)];
        for (int j = 0; j<[articles count]; j++)
        {
            KSModelArticle *article = [articles objectAtIndex:j];
            if (article.articleId == articleId)
            {
                index = i;
                break;
            }
            
        }

    }
    

    

    UIView *view = (UIView*)[_theTableView.delegate tableView:_theTableView viewForHeaderInSection:index];
    [self selectCatalog:(UIButton*)[view viewWithTag:index]];

    if ([_visialeArticles count]>0)
    {
        [_theTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:index] atScrollPosition:UITableViewScrollPositionTop animated:NO];
    }
    _tableViewBg.right = 0;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDuration:0.25];
    _tableViewBg.left = 20;
    [UIView commitAnimations];
}
-(void)showHeadFoot
{
    [_hander.view sendSubviewToBack:self]; //设置自己置后，防止挡住目录条等view
    _hander.headerHide = _ToolBarStatus;
    if(NO ==_hander.headerHide){
        [_hander showHeaderAndFooter];
    }
    _hander.forceHideHeader = NO;
}
-(void)hiddenTableView
{

    [UIView animateWithDuration:0.25 animations:^{
        _tableViewBg.right = 0;

    } completion:^(BOOL finished){
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDuration:0.25];
    self.alpha = 0;

    [UIView commitAnimations];
    }];
    
    [self performSelector:@selector(showHeadFoot) withObject:nil afterDelay:0.5];

}

-(void)loadCellData:(NSIndexPath*)indexPath  cell:(UITableViewCell*)cell
{
    UIImageView *arrImageView = (UIImageView*)[cell viewWithTag:100];
    UILabel *contentLabel = (UILabel*)[cell viewWithTag:200];
    UIImageView *line = (UIImageView*)[cell viewWithTag:300];
    arrImageView.hidden = YES;
    NSArray *articles = nil;
    KSModelCatalog *catalog = [_catalogArray objectAtIndex:[indexPath section]];
    for (int i = 0; i<[_visialeArticles count]; i++)
    {
        NSDictionary *dic = [_visialeArticles objectAtIndex:i];
        if ([[[dic allKeys] objectAtIndex:0] intValue] == catalog.catalogId)
        {
            articles = [dic objectForKey:INTEGER(catalog.catalogId)];
            break;
        }
    }

    KSModelArticle *article = [articles objectAtIndex:[indexPath row]];
    contentLabel.text = article.title;

    

    if (article.articleId == [_hander currentArticle].articleId)
    {
        arrImageView.hidden = NO;
    }
    
    
//    if (![_hander articleById:article.articleId])
//    {
//        contentLabel.textColor = TITLE_GRAY_COLOR;
//
//    }
//    else
//    {
        
//        bg.backgroundColor = [UIColor clearColor];
//    }
//    contentLabel.height = 44;
//    leftLabel.height = 37;

    line.hidden = NO;
    if ([articles count]-1 == [indexPath row])
    {

        line.hidden = YES;

    }


}
//-(void)reloadSection:(id)section
//{
//    [_theTableView reloadSections:[NSIndexSet indexSetWithIndex:[section intValue]] withRowAnimation:UITableViewRowAnimationBottom];
//}
-(void)insertRows:(NSArray*)rows
{
    [_theTableView insertRowsAtIndexPaths:rows withRowAnimation:UITableViewRowAnimationTop];

}
-(void)selectCatalog:(UIButton*)btn
{
//    str2rgb([[_catalogArray objectAtIndex:section] catalogColor]

    selectSection = btn.tag;
    NSMutableIndexSet *set = [[NSMutableIndexSet alloc] init];
    if (isScale)
    {
        for (int i = 0; i<[_titleArray count]; i++)
        {
            [set addIndex:i];
            
        }
    }
    else
    {
        if (lastSection>=0)
        {
            [set addIndex:lastSection];

        }
        [set addIndex:btn.tag];
    }
    if (lastSection == btn.tag && [_visialeArticles count]!=0&&!isScale)
    {
        [_visialeArticles removeAllObjects];
        isScale = NO;

        [_theTableView reloadSections:set withRowAnimation:UITableViewRowAnimationAutomatic];
        
    }
    else
    {
        [_visialeArticles removeAllObjects];
        NSDictionary *dic = [_titleArray objectAtIndex:btn.tag];
        [_visialeArticles addObject:dic];
        isScale = NO;

        [_theTableView reloadSections:set withRowAnimation:UITableViewRowAnimationAutomatic];
    }

    lastSection = btn.tag;
    
    [set release];
    
//    UIView *view = (UIView*)[btn superview];
//    UILabel *leftLabel = (UILabel*)[view viewWithTag:100];
//    if (leftLabel)
//    {
//        leftLabel.backgroundColor = str2rgb([[_catalogArray objectAtIndex:btn.tag] catalogColor]);
//    }
    
    //        [_theTableView deleteRowsAtIndexPaths:array withRowAnimation:UITableViewRowAnimationAutomatic];

//    NSMutableArray *array = [[NSMutableArray alloc] init];
//    KSModelCatalog *catalog = [_catalogArray objectAtIndex:btn.tag];
//    NSDictionary *dic;
//    NSArray *articles;

//    if ([_visialeArticles count]>0 && lastSection == btn.tag)
//    {
////        dic = [_visialeArticles objectAtIndex:0];
////        articles = [dic objectForKey:INTEGER(catalog.catalogId)];
////        for (int i = 0; i<[articles count]; i++)
////        {
////            [array addObject:[NSIndexPath indexPathForRow:i inSection:btn.tag]];
////        }
//        [_visialeArticles removeAllObjects];
////        [_theTableView deleteRowsAtIndexPaths:array withRowAnimation:UITableViewRowAnimationAutomatic];
//        [_theTableView reloadSections:set withRowAnimation:UITableViewRowAnimationAutomatic];
//
//    }
//    else
//    {
//        if ([_visialeArticles count]>0)
//        {
//            dic = [_visialeArticles objectAtIndex:0];
//            articles = [dic objectForKey:INTEGER([[_catalogArray objectAtIndex:lastSection] catalogId])];
//            for (int i = 0; i<[articles count]; i++)
//            {
//                [array addObject:[NSIndexPath indexPathForRow:i inSection:lastSection]];
//            }
//            [_visialeArticles removeAllObjects];
//            [_theTableView deleteRowsAtIndexPaths:array withRowAnimation:UITableViewRowAnimationAutomatic];
//            
//
//        }
//        
//        dic = [_titleArray objectAtIndex:btn.tag];
//        [_visialeArticles addObject:dic];
//        articles = [dic objectForKey:INTEGER(catalog.catalogId)];
//        [array removeAllObjects];
//        for (int i = 0; i<[articles count]; i++)
//        {
//            [array addObject:[NSIndexPath indexPathForRow:i inSection:btn.tag]];
//        }
//        [_theTableView insertRowsAtIndexPaths:array withRowAnimation:UITableViewRowAnimationTop];
//    }
//    



}
#pragma tableView
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [_catalogArray count];
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 45;
}
-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.width, 44)];
    UIView *bg = [[UIView alloc] initWithFrame:CGRectMake(6, 0, 350, 44)];
    bg.backgroundColor = [UIColor whiteColor];
    [view addSubview:bg];
    
    UILabel *leftLabel = [[UILabel alloc] initWithFrame:CGRectMake(9.5, 3.5, 10, 37)];
    if (!isScale)
    {
        if (section == selectSection)
        {
            leftLabel.backgroundColor = str2rgb([[_catalogArray objectAtIndex:section] catalogColor]);
            
        }
        else
        {
            leftLabel.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_catalog_normal.png"]];
            
        }

    }
    else
    {
        leftLabel.backgroundColor = str2rgb([[_catalogArray objectAtIndex:section] catalogColor]);
    }
    leftLabel.tag = 100;
    
    [view addSubview:leftLabel];
    [leftLabel release];
    
//    NSString *text = [[NSString alloc] initWithFormat:@"%@",[[_catalogArray objectAtIndex:section] title]];

    UILabel *contentLabel = [[UILabel alloc] initWithFrame:CGRectMake(leftLabel.right+10, 0, 350-(leftLabel.right+10), 44)];
    contentLabel.backgroundColor = [UIColor whiteColor];
    contentLabel.tag = 200;
    contentLabel.font = [UIFont boldSystemFontOfSize:18];
    contentLabel.textColor = CELL_TEXT_COLOR;
    contentLabel.text = [[_catalogArray objectAtIndex:section] title];
//    [text release];
    [view addSubview:contentLabel];
    [contentLabel release];

    
    UIButton *bt = [UIButton buttonWithType:UIButtonTypeCustom];
    bt.tag = section;
//    [bt setTitle:[[_catalogArray objectAtIndex:section] title] forState:UIControlStateNormal];
    [bt addTarget:self action:@selector(selectCatalog:) forControlEvents:UIControlEventTouchUpInside];
    bt.frame = view.frame;
    [view addSubview:bt];
    return [view autorelease];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
//    for (NSDictionary *dic in _titleArray)
//    {
        NSInteger catalogId = [[_catalogArray objectAtIndex:section] catalogId];
//        if ([[[dic allKeys] objectAtIndex:0] intValue]==catalogId)
//        {
//            return [[dic objectForKey:INTEGER(catalogId)] count];
//            break;
//        }
//
//    }

    
    if ([_visialeArticles  count]==0)
    {
        return 0;
    }

    else
    {
        NSInteger num = 0;
        for (int i = 0; i<[_visialeArticles count]; i++)
        {
            NSDictionary *dic  = [_visialeArticles objectAtIndex:i];
            if (dic && [[dic allKeys] count]>0)
            {
                if ([[[dic allKeys] objectAtIndex:0] intValue]==catalogId)
                {
                    num = [[dic objectForKey:INTEGER(catalogId)] count];
                    break;
                }
            }

        }
        return num;
    }
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 47;
    
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"userdCell";
    UITableViewCell *cell = (UITableViewCell*)[tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell==nil) 
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier] autorelease];

//        UIView *bg = [[UIView alloc] initWithFrame:CGRectMake(6+28, 0, 350, 44)];
//        bg.backgroundColor = [UIColor whiteColor];
//        bg.tag = 400;
//        [cell addSubview:bg];
//        [bg release];
        
//        UILabel *leftLabel = [[UILabel alloc] initWithFrame:CGRectMake(7+28, 3.5, 10, 37)];
//        leftLabel.backgroundColor = [UIColor clearColor];
//        leftLabel.tag = 100;
//        [cell addSubview:leftLabel];
//        [leftLabel release];
        
        UILabel *contentLabel = [[UILabel alloc] initWithFrame:CGRectMake(9.5+20, 0, 354-42, 44)];
        contentLabel.backgroundColor = [UIColor clearColor];
        contentLabel.font = [UIFont boldSystemFontOfSize:16];
        contentLabel.tag = 200;
        contentLabel.textColor = CONTENT_COLOR;
        [cell addSubview:contentLabel];
        [contentLabel release];
        
        UIImageView *line = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"directory_line.png"]];
        line.contentMode = UIViewContentModeScaleToFill;
        line.frame = CGRectMake(0, 44, 354, 3);
        line.tag = 300;
        [cell addSubview:line];
        [line release];

        UIImageView *arrImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 17, 10, 13)];
        arrImageView.right = 354-5;
        arrImageView.tag = 100;
        arrImageView.image = [UIImage imageNamed:@"Arr.png"];
        [cell addSubview:arrImageView];
        [arrImageView release];
        cell.selectionStyle = UITableViewCellSeparatorStyleNone;
    }

    [self loadCellData:indexPath cell:cell];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    KSModelCatalog *catalog = [_catalogArray objectAtIndex:[indexPath section]];
    NSDictionary *dic = [_titleArray objectAtIndex:[indexPath section]];
    NSArray *articles = [dic objectForKey:INTEGER(catalog.catalogId)];
    KSModelArticle *article = [articles objectAtIndex:[indexPath row]];

//    if ([obj isKindOfClass:[NSDictionary class]])
//    {
//        NSDictionary *obj1 = (NSDictionary*)obj;
//        NSInteger catalogId = [[[obj1 allKeys] objectAtIndex:0] intValue];
//        KSModelArticle *article = [obj1 objectForKey:INTEGER(catalogId)];
//        [_hander gotoArticleId:article.articleId];
        if (![_hander articleById:article.articleId])
        {
            //如果没有权限 不跳转直接返回
            
            [_hander showNoPermissionView:[_hander currentMagzine] delegate:_hander];
            
        }
        else
        {
            [_hander gotoArticleId:article.articleId];
            
        }
        [self touchesBegan:nil withEvent:nil];
//    lastSection = [indexPath section];

//    }

}

#pragma uitouch
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{

//    [UIView beginAnimations:nil context:nil];
//    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
//    [UIView setAnimationDuration:0.25];
    [self hiddenTableView];
    [_visialeArticles removeAllObjects];
    [_theTableView reloadData];
//    lastSection = -1;

//    [UIView commitAnimations];
}

@end
