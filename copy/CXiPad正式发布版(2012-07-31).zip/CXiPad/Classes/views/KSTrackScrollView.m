//
//  KSTrackScrollView.m
//  CenturyWeeklyV2
//
//  Created by 木参 傅 on 12-7-2.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import "KSTrackScrollView.h"

@implementation KSTrackScrollView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (BOOL)touchesShouldBegin:(NSSet *)touches withEvent:(UIEvent *)event inContentView:(UIView *)view
{
    int touch_cnt = [[event allTouches] count];
    NSLog(@"touch_cnt  =%d",touch_cnt);
    
    if(touch_cnt > 1){
        return NO;
    }else {
        return YES;
    }
}

- (BOOL)touchesShouldCancelInContentView:(UIView *)view
{
    return NO;
}

@end
