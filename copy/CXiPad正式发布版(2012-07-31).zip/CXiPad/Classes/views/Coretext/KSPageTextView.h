//
//  KSPageTextView.h
//  CenturyWeeklyV2
//
//  Created by zyk on 5/17/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreText/CoreText.h>
#import "KSColumnTextView.h"

//#define ADD_MARGIN  40
#define ADD_MARGIN  0  //不再整体下移  2012.07.04 防止图片的不完整

@interface KSPageTextView : UIView <UIScrollViewDelegate> {
@private
    NSMutableArray *_pages;
    UIScrollView *_scrollView;
    NSInteger _columnCount;
    UIPageControl *_pageControl;
    BOOL _pageControlUsed;
    BOOL _scrollEnabled;
    CTFramesetterRef framesetter;
    CTLineBreakMode _lineBreakMode;
    CTTextAlignment _textAlignment;
    CGFloat _firstLineHeadIndent;
    CGFloat _spacing;
    CGFloat _topSpacing;
    CGFloat _lineSpacing;
    CGPoint _columnInset;
    NSMutableArray *_textRangeArray;
    
    id <KSColumnTextViewDataSource> _dataSource;
}
@property (nonatomic, retain)UIScrollView *scrollView;
@property (nonatomic, copy) NSString *text;
@property (nonatomic, retain) NSAttributedString *attributedString;
@property (nonatomic, retain) UIFont *font;
@property (nonatomic, retain) UIColor *color;
@property (nonatomic) NSInteger columnCount;
@property (nonatomic, assign)  BOOL scrollEnabled;

@property (nonatomic, assign, getter=getCurrentPageIndex) NSInteger currentPageIndex;
@property (nonatomic, assign, getter=getLastPageIndex) NSInteger lastPageIndex;

@property (nonatomic, retain) UIPageControl     *pageControl;
@property (nonatomic, assign) CTLineBreakMode   lineBreakMode;
@property (nonatomic, assign) CTTextAlignment   textAlignment;
@property (nonatomic, assign) CGFloat           firstLineHeadIndent;
@property (nonatomic, assign) CGFloat           firstCharacterFontsize;
@property (nonatomic, assign) CGFloat           spacing;
@property (nonatomic, assign) CGFloat           topSpacing;
@property (nonatomic, assign) CGFloat           lineSpacing;
@property (nonatomic, assign) CGPoint           columnInset;
@property (nonatomic, assign) CGRect           scrollOffset;

@property (nonatomic, assign) id <KSColumnTextViewDataSource> dataSource;

- (void)locateEndPage;
- (void)locateFirstPage;

@end
