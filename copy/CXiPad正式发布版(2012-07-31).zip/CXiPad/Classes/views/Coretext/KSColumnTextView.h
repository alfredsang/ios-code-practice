//
//  KSColumnTextView.h
//  CenturyWeeklyV2
//
//  Created by zyk on 5/17/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreText/CoreText.h>

@class KSColumnTextView;
@protocol KSColumnTextViewDataSource <NSObject>
@optional
- (CGRect)placeholder:(KSColumnTextView*)textView viewForColumn:(NSInteger)column onPage:(NSInteger)page blocksarr:(CGRect*)blocksarr columnRect:(CGRect)columnRect;
- (UIImage *) image:(KSColumnTextView*)textView runRef:(CTRunRef)runRef lineRef:(CTLineRef)lineRef frameRef:(CTFrameRef)frameRef;
- (void)addSubview:(KSColumnTextView*)textView onPage:(NSInteger)page;
- (void)appendSubview:(KSColumnTextView*)textView;
@end

@interface KSColumnTextView : UIView {
@private
    NSInteger _columnCount;
    NSMutableAttributedString *_attributedString;
    CFMutableArrayRef _columnPaths;
    CFMutableArrayRef _frames;
    CFIndex _startIndex;
    CFIndex _finalIndex;
    BOOL _moreTextAvailable;
    BOOL _needRemove;
    
    NSInteger _page;
    id <KSColumnTextViewDataSource> _dataSource;
}
@property (nonatomic) NSInteger columnCount;
@property (nonatomic, retain) NSAttributedString *attributedString;
@property (nonatomic, assign) CTFramesetterRef framesetter;
@property (nonatomic) CFIndex startIndex;
@property (nonatomic, readonly) CFIndex finalIndex;
@property (nonatomic, assign) CGPoint columnInset;
@property (nonatomic, readonly) BOOL moreTextAvailable;

@property BOOL needRemove;

@property (nonatomic, assign) id <KSColumnTextViewDataSource> dataSource;
- (void)updateFrames;

@end
