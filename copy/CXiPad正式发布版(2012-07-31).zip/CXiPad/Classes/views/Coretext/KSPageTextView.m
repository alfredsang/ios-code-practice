//
//  KSPageTextView.m
//  CenturyWeeklyV2
//
//  Created by zyk on 5/17/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KSPageTextView.h"
#import "KSColumnTextView.h"

@interface KSColumnTextView ()
- (void)setPage:(NSInteger)page;
@end
@interface KSPageTextView ()
@property (nonatomic, retain) NSMutableArray *pages;
@property (nonatomic) BOOL pageControlUsed;
- (void)setup;
- (void)changeColorForPageControl;
- (void) updateAttributedString;
@end

@implementation KSPageTextView
@synthesize pages = _pages;
@synthesize scrollView = _scrollView;
@synthesize pageControl = _pageControl;
@synthesize pageControlUsed = _pageControlUsed;
@synthesize dataSource = _dataSource;
@synthesize scrollEnabled = _scrollEnabled;
@synthesize lineBreakMode = _lineBreakMode;
@synthesize textAlignment = _textAlignment;
@synthesize firstLineHeadIndent = _firstLineHeadIndent;
@synthesize spacing = _spacing;
@synthesize topSpacing = _topSpacing;
@synthesize lineSpacing = _lineSpacing;
@synthesize columnInset = _columnInset;
@synthesize attributedString = _attributedString;
@synthesize font = _font;
@synthesize color = _color;
@synthesize text = _text;
@synthesize firstCharacterFontsize = _firstCharacterFontsize;
@synthesize currentPageIndex;
@synthesize lastPageIndex;
@synthesize scrollOffset = _scrollOffset;
@synthesize columnCount = _columnCount;

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self setup];
    }
    return self;
}

- (void)setup {
    _lineBreakMode = kCTLineBreakByWordWrapping;
    _textAlignment = kCTJustifiedTextAlignment;//kCTLeftTextAlignment;
    _firstLineHeadIndent = 0.0;
    _spacing = 5.0;
    _topSpacing = 0.0;
    _lineSpacing = 1.0;
    _columnCount = 2;
    _firstCharacterFontsize = 64.0;
    _columnInset = CGPointMake(10.0, 10.0);
    _scrollEnabled = YES;
    _font = [[UIFont fontWithName:@"Helvetica" size:18.0] retain];
    _color = [[UIColor blackColor] retain];
    _scrollOffset = CGRectZero;
    
    self.pages = [NSMutableArray arrayWithCapacity:5];
    _textRangeArray = [[NSMutableArray alloc] init];
    self.scrollView = [[[UIScrollView alloc] initWithFrame:self.bounds] autorelease];
    self.scrollView.scrollEnabled = self.scrollEnabled;
    self.scrollView.bounces = NO;
    self.scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.scrollView.pagingEnabled = YES;
    self.scrollView.delegate = self;
    CGRect pageControlFrame = CGRectMake(0.0, self.frame.size.height - 12, self.frame.size.width, 12);
    self.pageControl = [[[UIPageControl alloc] initWithFrame:pageControlFrame] autorelease];
    self.pageControl.numberOfPages = 2;
    self.pageControl.backgroundColor = [UIColor clearColor];
    self.pageControl.currentPage = 0;
    self.pageControl.hidden = NO;
    
    [self changeColorForPageControl];
    [self.pageControl addTarget:self action:@selector(changePage:) forControlEvents:UIControlEventValueChanged];
    [self addSubview:self.scrollView];
    [self addSubview:self.pageControl];
    
}

- (void)dealloc {
    self.pageControl = nil;
    self.scrollView = nil;
    self.pages = nil;
    [_textRangeArray release];
    [_attributedString release],_attributedString = nil;
    if(framesetter) CFRelease(framesetter);
    [_text release],_text = nil;
    [_font release],_font = nil;
    [_color release],_color = nil;
    
    [super dealloc];
}

- (void)changeColorForPageControl {
    for (NSUInteger subviewIndex = 0; subviewIndex < [self.pageControl.subviews	count]; subviewIndex++) {
        UIImageView* subview = [self.pageControl.subviews objectAtIndex:subviewIndex];
        if (subviewIndex == self.pageControl.currentPage) {
            if ([subview respondsToSelector:@selector(setImage:)]) {
                [subview setImage:[UIImage imageNamed:@"a_pagecontrol_selected.png"]];
            }
        } else {
            if ([subview respondsToSelector:@selector(setImage:)]) {
                [subview setImage:[UIImage imageNamed:@"a_pagecontrol_unselected.png"]];
            }
        }
    }
}

#pragma mark -
#pragma mark IBAction methods
- (IBAction)changePage:(id)sender {
    int page = self.pageControl.currentPage;
    CGRect frame = self.scrollView.frame;
    frame.origin.x = frame.size.width * page;
    frame.origin.y = 0;
    [self.scrollView scrollRectToVisible:frame animated:YES];
    self.pageControlUsed = YES;
}
- (void)locateEndPage {
    NSInteger p = [self getLastPageIndex];
    if (p != _pageControl.currentPage) {
        self.pageControlUsed = YES;
        [_scrollView scrollRectToVisible:CGRectMake(self.width*p, 0, self.width, self.height) animated:NO];
        [self changeColorForPageControl];
    }
}
- (void)locateFirstPage {
    NSInteger p = 0;
    if (p != _pageControl.currentPage) {
        self.pageControlUsed = YES;
        [_scrollView scrollRectToVisible:CGRectMake(self.width*p, 0, self.width, self.height) animated:NO];
        _pageControl.currentPage = p;
        [self changeColorForPageControl];
    }
}
#pragma mark -
#pragma mark Properties
- (void) setAttributedString:(NSAttributedString *)attributedString{
    if([attributedString length] == 0)
    {
        attributedString = [[NSAttributedString alloc] initWithString:@" "];
    }
    if(![self.attributedString isEqualToAttributedString:attributedString]){
        [_attributedString release];
        _attributedString = nil;
        _attributedString = [attributedString retain];
        //        [self updateAttributedString];
        if(framesetter){
            CFRelease(framesetter);
            framesetter = nil;
        }
        framesetter = CTFramesetterCreateWithAttributedString((CFAttributedStringRef)_attributedString);
    }
}
- (void)setScrollEnabled:(BOOL)scrollEnabled {
    _scrollEnabled = scrollEnabled;
    self.scrollView.scrollEnabled = scrollEnabled;
}

- (NSInteger)getCurrentPageIndex {
    return self.pageControl.currentPage;
}

- (NSInteger)getLastPageIndex {
    return [_pages count]-1;
}

- (KSColumnTextView *)newTextView:(NSInteger)page_ {
    CGRect currentFrame = CGRectMake(self.scrollView.frame.size.width * page_ + _scrollOffset.origin.x, _scrollOffset.origin.y, self.scrollView.frame.size.width - _scrollOffset.size.width, self.scrollView.frame.size.height - _scrollOffset.size.height-ADD_MARGIN*2);
    KSColumnTextView *view = [[KSColumnTextView alloc] initWithFrame:currentFrame];
    [view setPage:page_];
    
    view.columnCount = self.columnCount;
    view.startIndex = page_==0?0:[[_textRangeArray objectAtIndex:page_-1] intValue];
    view.framesetter = framesetter;
    view.attributedString = _attributedString;
    view.backgroundColor = self.backgroundColor;
    view.columnInset = _columnInset;
    
    view.dataSource = self.dataSource;
    [view updateFrames];
    self.pages.count>page_?[self.pages replaceObjectAtIndex:page_ withObject:view]:[self.pages addObject:view];
    if (!isRetina) {
        //[self.pages addObject:view]; //cxy added more one view
        if ([self.dataSource respondsToSelector:@selector(addSubview:onPage:)])[self.dataSource addSubview:view onPage:page_];
    }    
    [view release];
    [_textRangeArray count]>page_?[_textRangeArray replaceObjectAtIndex:page_ withObject:[NSNumber numberWithInt:view.finalIndex]]:
    [_textRangeArray addObject:[NSNumber numberWithInt:view.finalIndex]];
    return view;
}
- (void)checkPage:(NSInteger)page_ {
    KSColumnTextView *v = [self.pages objectAtIndex:page_];
    if ((NSNull *)v == [NSNull null]) v = [self newTextView:page_];
    if (!v.superview) {
        if ([self.dataSource respondsToSelector:@selector(addSubview:onPage:)])[self.dataSource addSubview:v onPage:page_];
        [self.scrollView addSubview:v];
    }
}
- (void)unloadPages:(NSNumber *)p {
    NSInteger page_ = [p intValue];
    for (int i=0; i<self.pages.count; i++){
        if(i<page_-1||i>page_+1){
            UIView *v=[self.pages objectAtIndex:i];
            if ((NSNull *)v != [NSNull null]){
                [v removeFromSuperview];
                [self.pages replaceObjectAtIndex:i withObject:[NSNull null]];
            }
        }
    }
}
- (void)displayPage:(NSInteger)page_ {
    if (page_<0||page_>=[self.pages count]) return;
    [self checkPage:page_];
    if (page_ > 0) [self checkPage:page_-1];
    if (page_+1<[self.pages count])[self checkPage:page_+1];
    if (isRetina) {
        [self unloadPages:[NSNumber numberWithInt:page_]];
    }
}
#pragma mark -
- (void)drawRect:(CGRect)rect{
    if(!_attributedString)return;
    [self.pages makeObjectsPerformSelector:@selector(removeFromSuperview)];
    [self.pages removeAllObjects];
    NSInteger _oldPage = self.pageControl.currentPage;
    
    CGRect pageControlFrame = CGRectMake(0.0, self.frame.size.height - 50 - 12.0, self.frame.size.width, 12.0);
    self.pageControl.frame = pageControlFrame;
    
    NSInteger iteration = 0;
    BOOL moreTextAvailable = YES;
    KSColumnTextView *view = nil;
    do 
    {
        view = [self newTextView:iteration];
        iteration += 1;
        moreTextAvailable = view.moreTextAvailable;
        if(view.needRemove)
        {
            iteration--;
        }
    } while (moreTextAvailable);
    
    self.scrollView.contentSize = CGSizeMake(self.scrollView.frame.size.width * iteration, self.scrollView.frame.size.height);
    self.scrollView.contentOffset = CGPointMake(0, 0);
    
    if ([self.dataSource respondsToSelector:@selector(appendSubview:)]) {
        [self.dataSource appendSubview:view];
    }
    self.pageControl.numberOfPages = iteration;
    _oldPage = _oldPage > iteration-1?iteration-1:_oldPage;
    [self displayPage:_oldPage];
    [_scrollView scrollRectToVisible:CGRectMake(self.width*_oldPage, 0, self.width, self.height) animated:NO];
    self.pageControl.currentPage = _oldPage;
    
    [self changeColorForPageControl];
}
#pragma mark -
#pragma mark UIScrollViewDelegate methods
- (void)scrollViewDidScroll:(UIScrollView *)sender {
    [self changeColorForPageControl];
    if (self.pageControlUsed) return;
    CGFloat pageWidth = self.scrollView.frame.size.width;
    int page = floor((self.scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    if (page!=self.pageControl.currentPage) {
        self.pageControl.currentPage = page;
        [self displayPage:page];
    }

}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView { 
    self.pageControlUsed = NO;
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    self.pageControlUsed = NO;
}



@end
