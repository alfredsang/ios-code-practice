//
//  KSArticleSlideShowView.m
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSArticleSlideShowView.h"

#define IMAGE_WIDTH 500
#define IMAGE_HEIGHT 750
#define IMAGE_TAG 99
#define IMAGE_INFO_TAG 100

@interface KSArticleSlideShowView()
//- (void) addImageViews;
@end
@implementation KSArticleSlideShowView

- (id)initWithFrame:(CGRect)frame images:(NSArray *)images
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor blackColor];
//        self.alpha = 0;
        _images = [images retain];
        _pageSize = 1;
        _pageCount = [_images count];
        _pageSize = 1;
        _pageWidth = self.width;
        _cellWidth = _pageWidth;
        
        for (int i=0; i<_pageCount; i++) {
            [_cacheViewsList addObject:[NSNull null]];
        }
        
        [self initSubviews];
        
        [self moveToViewAtPage:0 animated:NO];
    }
    return self;
}

-(void)dealloc{
    [_dismissBtn release];
    [_images release];
    [super dealloc];
}

- (void)initSubviews{
    UIView *background = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.width, self.height)];
    background.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    background.backgroundColor = [UIColor blackColor];
    [self addSubview:background];
    [background release];
//    [background addGestureRecognizer:[[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissThis:)]autorelease]];
//    [background release];
//	imagesScrollView = [[UIScrollView alloc] initWithFrame:self.bounds];
//    imagesScrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
//	imagesScrollView.center = self.center;
//	imagesScrollView.backgroundColor = [UIColor blackColor];
//	imagesScrollView.pagingEnabled = YES;
//	imagesScrollView.showsHorizontalScrollIndicator = NO;
//	imagesScrollView.showsVerticalScrollIndicator = NO;
//	imagesScrollView.scrollsToTop = NO;
//	imagesScrollView.bounces = YES;
//	[self addSubview:imagesScrollView];
    
    [self loadView];
    _dismissBtn = [[UIButton alloc] initWithFrame:CGRectMake(self.width-50, 0, 50, 50)];
    _dismissBtn.showsTouchWhenHighlighted = YES;
    [_dismissBtn setImage:[UIImage imageNamed:@"btn_slideshow_close.png"] forState:UIControlStateNormal];
    [_dismissBtn addTarget:self action:@selector(dismissThis:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_dismissBtn];
    _dismissBtn.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin|UIViewAutoresizingFlexibleBottomMargin;
    
}

- (void)layoutSubviews{
    if (_scrolling) {
        return;
    }
    _rotating = YES;
    CGFloat h = 1024.0f;
    CGFloat w = 768.0f;
    if ([UIUtil currentOrientation]!=0) {
        h = 768;
        w = 1024;
    }
    _pageWidth = _cellWidth = w;
    _scrollView.frame = CGRectMake(0, 0, w, h);
    _scrollView.contentSize = CGSizeMake(_pageWidth*_pageCount, h);
    _scrollView.scrollEnabled = NO;
    for (int i = 0; i< [_cacheViewsList count]; i++) {
        //UIImageView *v = [_cacheViewsList objectAtIndex:i];
        UIView *v = [_cacheViewsList objectAtIndex:i];
        if (v!= nil && (NSNull *)v != [NSNull null]) {
            UIImage *image = nil;
            NSString *imgPath = [[_images objectAtIndex:i] objectForKey:@"image"];
            if (![imgPath isKindOfClass:[NSString class]] || [imgPath isKindOfClass:[UIImage class]]) {
                image = (UIImage *)imgPath;
            } else {
                image = [UIImage imageWithContentsOfFile:[[_images objectAtIndex:i] objectForKey:@"image"]];
            }
            CGSize sz = image.size;
            UIImageView *vimg = (UIImageView *)[v viewWithTag:IMAGE_TAG];
            if (sz.height > self.height || sz.width > self.width) {
                vimg.contentMode = UIViewContentModeScaleAspectFit;
            } else {
                vimg.contentMode = UIViewContentModeCenter;
            }

            vimg.image = image;
            vimg.frame = CGRectMake(_pageWidth*i, 0, w, h);
            UIView *vimginfo = [v viewWithTag:IMAGE_INFO_TAG];
            vimginfo.frame = CGRectMake(vimg.left, vimg.height-100, vimg.width, 100);
        }
    }
    [_scrollView setContentOffset:CGPointMake(_pageWidth*_pageIndex, 0) animated:NO];
    _scrollView.scrollEnabled = YES;
    _rotating = NO;
}

#pragma mark -
/*
- (void)moveToViewAtPage:(NSInteger)page animated:(BOOL)animated{
    _pageIndex = page;
	if (!_cacheViewsList || ![_cacheViewsList count]) {
        return;
    }
    if (_pageIndex >= _pageCount) {
        _pageIndex = _pageCount-1;
    }
    
    [self loadScrollViewWithPage:_pageIndex];
    [self loadScrollViewWithPage:_pageIndex+1];
    [self loadScrollViewWithPage:_pageIndex-1];
	//[_scrollView scrollRectToVisible:((UIView *)[_cacheViewsList objectAtIndex:page*_pageSize]).frame animated:animated];
    [_scrollView setContentOffset:CGPointMake(_pageIndex*_pageWidth, 0) animated:animated];
    //[self layoutScrollViewSubviewsAnimated:NO];
    //[self setCachedViewState:_pageIndex];
    
}
*/

- (UIView *)newCachedView:(NSInteger)index {
    NSDictionary *imageDict = (NSDictionary *)[_images objectAtIndex:index];
    UIView *slideView = [[UIView alloc] initWithFrame:self.bounds];
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:self.bounds];
    imageView.userInteractionEnabled = YES;
    UIImage *image = nil;
    NSString *imgPath = [imageDict objectForKey:@"image"];
    if (![imgPath isKindOfClass:[NSString class]] || [imgPath isKindOfClass:[UIImage class]]) {
        image = (UIImage *)imgPath;
    } else {
        image = [UIImage imageWithContentsOfFile:[imageDict objectForKey:@"image"]];
    }
    CGSize sz = image.size;
    if (sz.height > self.height || sz.width > self.width) {
        imageView.contentMode = UIViewContentModeScaleAspectFit;
    } else {
        imageView.contentMode = UIViewContentModeCenter;
    }
    imageView.tag = IMAGE_TAG;
    imageView.image = image;
    imageView.frame = CGRectMake(_pageWidth*index, 0, self.width, self.height);
    [slideView addSubview:imageView];
    [imageView release];
    
/*    
    UIButton *infoMaskBtn = [[UIButton alloc] initWithFrame:imageView.bounds];
    infoMaskBtn.backgroundColor = [UIColor clearColor];
    [infoMaskBtn addTarget:self action:@selector(infoMaskBtnTapped:) forControlEvents:UIControlEventTouchUpInside];
    [imageView addSubview:infoMaskBtn];
    infoMaskBtn.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    [infoMaskBtn release];
    
    UIView *infoView = [[UIView alloc] initWithFrame:CGRectMake(0, imageView.height-100, imageView.width, 100)];
    infoView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
    [infoMaskBtn addSubview:infoView];
    infoView.autoresizingMask = UIViewAutoresizingFlexibleTopMargin|UIViewAutoresizingFlexibleWidth;
    [infoView release];
   
    
    NSString *imageTitle = [imageDict objectForKey:@"title"];
    CGSize maximumLabelSize = CGSizeMake(infoView.bounds.size.width-10,MAXFLOAT);
    CGSize expectedLabelSize = [imageTitle sizeWithFont:[UIFont systemFontOfSize:20] constrainedToSize:maximumLabelSize  lineBreakMode:UILineBreakModeWordWrap];
    UILabel *imageTitleLbl = [UIUtil newLabelWithFrame:CGRectMake(10, 0, infoView.bounds.size.width-20, expectedLabelSize.height) 
                                                  text:imageTitle
                                             textColor:[UIColor whiteColor] 
                                                  font:[UIFont systemFontOfSize:20]];
    imageTitleLbl.numberOfLines=0;
    imageTitleLbl.lineBreakMode = UILineBreakModeWordWrap;
    imageTitleLbl.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    [infoView addSubview:imageTitleLbl];
    [imageTitleLbl release];
    
    NSString *imageContent = [imageDict objectForKey:@"content"];
    UILabel *imageContentLbl = [UIUtil newLabelWithFrame:CGRectMake(10, imageTitleLbl.frame.size.height, imageTitleLbl.frame.size.width, infoView.bounds.size.height-imageTitleLbl.frame.size.height) 
                                                    text:imageContent
                                               textColor:[UIColor whiteColor] 
                                                    font:[UIFont systemFontOfSize:15]];
    imageContentLbl.numberOfLines=0;
    [infoView addSubview:imageContentLbl];
    [imageContentLbl release];
*/ 
    
    //UIView *infoView = [[UIView alloc] initWithFrame:CGRectMake(0, imageView.height-100, imageView.width, 100)];
    UIView *infoView = [[UIView alloc] initWithFrame:CGRectMake(imageView.left, imageView.height-100, imageView.width, 100)];
    infoView.tag = IMAGE_INFO_TAG;
    infoView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
    infoView.autoresizingMask = UIViewAutoresizingFlexibleTopMargin|UIViewAutoresizingFlexibleWidth;

    NSString *imageTitle = [imageDict objectForKey:@"title"];
    CGSize maximumLabelSize = CGSizeMake(infoView.bounds.size.width-10,MAXFLOAT);
    CGSize expectedLabelSize = [imageTitle sizeWithFont:[UIFont systemFontOfSize:20] constrainedToSize:maximumLabelSize  lineBreakMode:UILineBreakModeWordWrap];
    UILabel *imageTitleLbl = [UIUtil newLabelWithFrame:CGRectMake(10, 0, infoView.bounds.size.width-20, expectedLabelSize.height) 
                                                  text:imageTitle
                                             textColor:[UIColor whiteColor] 
                                                  font:[UIFont systemFontOfSize:20]];
    imageTitleLbl.numberOfLines=0;
    imageTitleLbl.lineBreakMode = UILineBreakModeWordWrap;
    imageTitleLbl.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    [infoView addSubview:imageTitleLbl];
    [imageTitleLbl release];
    
    NSString *imageContent = [imageDict objectForKey:@"content"];
    UILabel *imageContentLbl = [UIUtil newLabelWithFrame:CGRectMake(10, imageTitleLbl.frame.size.height, imageTitleLbl.frame.size.width, infoView.bounds.size.height-imageTitleLbl.frame.size.height) 
                                                    text:imageContent
                                               textColor:[UIColor whiteColor] 
                                                    font:[UIFont systemFontOfSize:15]];
    imageContentLbl.numberOfLines=0;
    [infoView addSubview:imageContentLbl];
    [imageContentLbl release];    

    [slideView addSubview:infoView];
    [infoView release];
    return slideView;
}


- (void)infoMaskBtnTapped:(id)sender{
	UIButton *infoMaskBtn = (UIButton *)sender;
	UIView *infoView = (UIView *)[infoMaskBtn.subviews objectAtIndex:0];
	if( infoView.alpha==1 ){
		[UIUtil addAnimationFade:infoView];
	}else{
		[UIUtil addAnimationShow:infoView];
	}
}

- (void) dismissThis:(id)rec{
    [self removeFromSuperview];
}

@end
