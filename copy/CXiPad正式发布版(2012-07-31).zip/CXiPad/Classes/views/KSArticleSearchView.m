//
//  KSArticleSearchView.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 1/6/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "KSArticleSearchView.h"
#import "KSArticleSearchTableCell.h"
#import "KSArticleViewController.h"
#import "KSAppStoreProxy.h"
#import "KSModelMagzine.h"
#import "KSMagzineViewController.h"

@implementation KSArticleSearchView
@synthesize controller = _controller;

- (void)dealloc {
    [KSBootstrap unlisten:self];
    
    [_request cancel];
    [_request release];
    
    [_tapableView release];
    [_tableView release];
    [_searchItemList release];
    [_searchTextField release];
    [_indicatorView release];
    [_resutTextLabel release];
    
    [super dealloc];
}
- (void) initData{
    _searchItemList = [[NSMutableArray alloc] init];
    _page = 1;
    _totalPage = 1;
    _pageSize = 20;
    _hasMorePage = NO;
    _loadingMore = NO;
}
- (void) initSubviews{
    self.backgroundColor = [UIColor clearColor];
    _tapableView = [[KSTapableView alloc] initWithFrame:self.bounds];
    _tapableView.backgroundColor = [UIColor clearColor];
    _tapableView.tapDelegate = self;
    [self addSubview:_tapableView];
    
    UIImageView *backImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamedNocache:@"bg_article_search.png"]];
    backImageView.frame = CGRectMake(140, 31, 541, 675);//CGRectMake(106, 32, 404, 436);
    [self addSubview:backImageView];
    backImageView.userInteractionEnabled = YES;
    [backImageView release];
    
    _searchTextField = [[UITextField alloc] initWithFrame:CGRectMake(181, 65, 483, 31)];
    _searchTextField.placeholder = @"请输入检索词";
    _searchTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
    _searchTextField.returnKeyType = UIReturnKeySearch;
    _searchTextField.delegate = self;
    _searchTextField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    [self addSubview:_searchTextField];
    
    _resutTextLabel = [[UILabel alloc] initWithFrame:CGRectMake(161, 98, 460, 37)];
    _resutTextLabel.backgroundColor = [UIColor clearColor];
    [self addSubview:_resutTextLabel];
    
    _indicatorView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    _indicatorView.frame = CGRectMake(620, 107, 20, 20);
    [self addSubview:_indicatorView];
    
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(157, 140, 500, 540)];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    //_tableView.backgroundColor = [UIColor clearColor];
    [self addSubview:_tableView];
    
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self initData];
        [self initSubviews];
    }
    
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/
#pragma mark - actions
- (void)dismiss {
    //[_controller dismissArticleSearchView];
    [(KSArticleViewController *)self.viewController dismissArticleSearchView];
}
- (void)searching:(NSInteger)page {
    [_request cancel];
    [_request release];
    
    //_request = [[KSUrlRequest alloc] initWithUrl:STR_FORMAT(SEARCH_ARTICLE_URL, ((KSArticleViewController *)self.viewController).magzineId, [KSUrlRequest encodeURL:_searchTextField.text], page, @"")];
    
    //需求改为全部杂志搜索
    _request = [[KSUrlRequest alloc] initWithUrl:SERVER_URL(@"/search/%@/0/%@/%d/%@",MAGZINE_TYPE,[KSUrlRequest encodeURL:_searchTextField.text],page,@"")];  
    
    _request.delegate = self;
    _request.asyn = YES;
    [_request start];
}
- (void) doSearch{
    if(_searchTextField.text == nil || ![_searchTextField.text length]) return;
    //[self cancelAllImageDownloads];
    //_imageDownloadsInProgress = [[NSMutableDictionary dictionaryWithCapacity:20] retain];
    _page = 1;
    [self searching:_page];
} 

-(void)loadMore {
    UIActivityIndicatorView	*activiter = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
	[activiter startAnimating];
	
	NSInteger lastRow = [_searchItemList count];
	NSIndexPath *lastIndexPath = [NSIndexPath indexPathForRow:lastRow inSection:0];
	[_tableView scrollToRowAtIndexPath:lastIndexPath atScrollPosition:UITableViewScrollPositionBottom animated:NO];
	[_tableView cellForRowAtIndexPath:lastIndexPath].textLabel.text = @"加载中...";
	[[_tableView cellForRowAtIndexPath:lastIndexPath] addSubview:activiter];
    
    activiter.frame = CGRectMake(ceilf(_tableView.width/2)-70, [_tableView cellForRowAtIndexPath:lastIndexPath].height/2-10, 20, 20);
	[activiter release];
    
    _loadingMore = YES;
    
    [self searching:_page+1];
}
#pragma mark - UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if(textField == _searchTextField){
        [_searchTextField resignFirstResponder];
        [self doSearch];
    }
    return YES;
}
#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == [_searchItemList count]) {
        return 45.0f;
    }
    CGFloat height = 70.0f;
    NSString *str = ((KSModelSearchItem *)[_searchItemList objectAtIndex:indexPath.row]).summary;
    if ([str length]) {
        CGSize conCZ = CGSizeMake(tableView.width-60.0f, 9999);
        CGSize cz = [str sizeWithFont:[UIFont systemFontOfSize:13.0f] constrainedToSize:conCZ lineBreakMode:UILineBreakModeWordWrap];
        height += cz.height;
    }
    return height;
    
    //return 92.0f;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];

    if (indexPath.row == [_searchItemList count]) {
        if (!_loadingMore) {
            [self loadMore];
        }
//        [tableView deselectRowAtIndexPath:indexPath animated:YES];
        return;
    } else {
        KSModelSearchItem *item = [_searchItemList objectAtIndex:indexPath.row];
        _currentMagazineId = item.magzineId;
        if (item.lock) {
            _currentMagazineId = item.magzineId;
//            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"您没有权限阅读该文章" message:@"若您已订阅或已获赠该杂志，您可以在设置中恢复购买及登录财新网帐号以获得阅读权限，您也可以立即购买该本杂志。" delegate:self cancelButtonTitle:@"立即购买" otherButtonTitles:@"取消",nil];
//            [alertView show];
//            [alertView release];
            KSArticleViewController *v = (KSArticleViewController *)self.viewController;
            KSModelMagzine *Magzine = [KSModelMagzine loadById:item.magzineId];
            //[(KSArticleViewController *)self.viewController init:item.magzineId articleId:item.articleId];
            
            
            //[(KSArticleViewController *)v showNoPermissionView:v.currentMagzine delegate:self]; //old
            
            [(KSArticleViewController *)v showNoPermissionView:Magzine delegate:self];
        }else{
            //全部杂志搜索结果处理
            KSModelMagzine *m = [KSModelMagzine loadById:item.magzineId];
            if (!m.isArticlesDownload) {
                UIAlertView *downloadAlert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"该内容所属期刊并未下载，请选择\n" delegate:self cancelButtonTitle:@"下载" otherButtonTitles:@"取消", nil];
                downloadAlert.tag = 123;
                [downloadAlert show];
                [downloadAlert release];
            //                NSArray *array = [[NSArray alloc] initWithObjects:@"取消", nil];
            //                [UIUtil showMsgAlertWithDelegate:self Title:nil message:@"该内容所属期刊并未下载，请选择" cancelButtonTitle:@"下载" otherButtonTitles:array];
            //                [array release];
            //                [UIUtil showMsgAlertWithTitle:@"不能阅读该文章" message:@"您没有下载该本杂志。"];
            } else {
                //[_handler gotoArticle:item.articleId magzineId:item.magzineId from:@"search"];
                [(KSArticleViewController *)self.viewController init:item.magzineId articleId:item.articleId];
                [(KSArticleViewController *)self.viewController reloadData];  
            }    
            //[(KSArticleViewController *)self.viewController init:item.magzineId articleId:item.articleId];
            // [(KSArticleViewController *)self.viewController reloadData];  
            //[(KSArticleViewController *)self.viewController gotoArticleId:item.articleId]; //old
            
        }
    }
}
#pragma mark -
#pragma mark Table view creation (UITableViewDataSource)

// customize the number of rows in the table view
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	if (_hasMorePage) {
        return [_searchItemList count]+1;
    }else return [_searchItemList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == [_searchItemList count] && _hasMorePage) {
        UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
        cell.textLabel.textAlignment = UITextAlignmentCenter;
        cell.textLabel.font = [UIFont fontWithName:@"Georgia-Italic" size:14];
        cell.textLabel.text = @"加载更多...";
        return [cell autorelease];
    }
	static NSString *CellIdentifier = @"KSArticleSearchTableCell";
    KSArticleSearchTableCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[KSArticleSearchTableCell alloc] initWithSearchItem:[_searchItemList objectAtIndex:indexPath.row] reuseIdentifier:CellIdentifier] autorelease];
    }
    cell.searchItem = [_searchItemList objectAtIndex:indexPath.row];
    
    return cell;
}

#pragma mark - KSTapableDelegate
- (void)didTapped {
    [self dismiss];
}
#pragma mark - KSUrlRequestDelegate
- (void)onRequestStart:(KSUrlRequest *)request{
    _indicatorView.hidden = NO; 
    [_indicatorView startAnimating];
    
    //RELEASE_SAFELY(entries);
    //lblResultHint.text = @"";
    //[_tableView reloadData];
}

- (void)onRequestSuccess:(KSUrlRequest *)request{
    [_indicatorView stopAnimating], _indicatorView.hidden = YES;
    NSDictionary *resultDict = [request resultDict];
    //NSLog(@"%@", resultDict);
    _page = DICT_INTVAL(resultDict, @"page");
    _pageSize = DICT_INTVAL(resultDict, @"pageSize");
    _totalPage = DICT_INTVAL(resultDict, @"totalPage");
    _totalRecord = DICT_INTVAL(resultDict, @"totalRecord");
    _hasMorePage = _totalPage > _page;
    _page = _page < 1?1:_page;
    _loadingMore = NO;
    //第1页数据显示时应将之前的数据清空
    if (_page <= 1) {
        [_searchItemList removeAllObjects];
    }
    //entries = [[NSMutableArray arrayWithCapacity:20] retain];
    NSArray *arr = [resultDict valueForKey:@"list"];
    for (NSDictionary *dict in arr) {
        KSModelSearchItem *item = [KSModelSearchItem searchItemWith:dict];
        [_searchItemList addObject:item];
    }
    _resutTextLabel.text = [NSString stringWithFormat:@"您搜索 %@ 获得大约 %d 条结果，以下是 %d 条", _searchTextField.text, _totalRecord, [_searchItemList count]];
    [_tableView reloadData];
}

- (void)onRequestFail:(KSUrlRequest *)request{
    KSDERROR(@"%@", request.error);
    [_indicatorView stopAnimating], _indicatorView.hidden = YES;
    [UIUtil showMsgAlertWithTitle:@"提示" message:[KSUrlRequest networkErrorMessage:request.error]];
}

#pragma mark - UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (alertView.tag == 123)
    {
        if (buttonIndex == 0)
        {
          //  [_handler downloadTheMagazineWithId:_currentMagazineId];
          //  [_handler showView:@"downladoMagazine"];
          //  [(KSArticleViewController *)self.viewController backToMagzineView];
          //  [[KSDownloadManager sharedManager] cancelWaiting];
            [[KSMainController mainController] presentMagzineViewController];
            KSMagzineViewController *MagzineViewController = (KSMagzineViewController *)[[KSMainController mainController] activeController];
            [MagzineViewController downloadTheMagazineWithId:_currentMagazineId];
            //[MagzineViewController showView:@"downladoMagazine"]; 
        }
    }
    else 
    {
        if (buttonIndex == 0)
        {
            KSModelMagzine *m = [KSModelMagzine loadById:_currentMagazineId];
            if (!m.isMybook) {
                [KSBootstrap listen:NOTIFY_PURCHASE_COMPLETED target:self selector:@selector(magazinePuchased:)];
                [KSAppStoreProxy buy:m fromView:self];
            }
        }
        
    } 
    /*
    if (buttonIndex == 0) {
        KSModelMagzine *m = [KSModelMagzine loadById:_currentMagazineId];
        if (!m.isMybook) {
            [KSBootstrap listen:NOTIFY_PURCHASE_COMPLETED target:self selector:@selector(magazinePuchased:)];
            [KSAppStoreProxy buy:m fromView:self];
        }
    }
    */ 
}
#pragma mark -
- (void)magazinePuchased:(NSNotification *)notify {
    NSDictionary *userInfo = [notify userInfo];
    NSString *type = [userInfo valueForKey:@"type"];
    if([@"buy" isEqualToString:type]){
        [self doSearch];
        [UIUtil showMsgAlertWithTitle:@"购买成功" message:@"您可重新搜索数据"];
        //重新加载阅读数据
        KSArticleViewController *controller = (KSArticleViewController *)self.viewController;
        controller.currentMagzine.isPurchased = YES;
        [controller reloadData];
        //[controller gotoArticleId:controller.currentArticle.articleId];
    }
    [KSBootstrap unlisten:self];
}
#pragma mark - KSNoPermissionAlertViewDelegate
- (void)afterDoBuy:(KSNoPermissionAlertView *)alertView {
    [self doSearch];
    [UIUtil showMsgAlertWithTitle:@"购买成功" message:@"您可重新搜索数据"];
    //重新加载阅读数据
    KSArticleViewController *controller = (KSArticleViewController *)self.viewController;
    controller.currentMagzine.isPurchased = YES;
    [controller reloadData];
    [(KSArticleViewController *)self.viewController dismissNoPermissionView];
}

@end
