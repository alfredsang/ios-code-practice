//
//  KSRegisterView.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-17.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "KSRegisterView.h"
#import "KSWebViewController.h"
#import "KSMagzineViewController.h"
#import "KSLoginView.h"

#import "DataUtil.h"

@implementation KSRegisterView

- (void) dealloc{
    [register_bg release];
    [agree_license release];
    [regUserButton release];
    [emailTextField release];
    [nameTextField release];
    [pwdTextField release];
    [confirmPwdTextField release];
    [tiaokuanButton release];
    [yinsiquanButton release];
    [closeButton release];
    [tipLabel release];
    [smileImageView release];
    [super dealloc];
}

- (id)initWithFrame:(CGRect)frame handler:(id)handler parent:(KSLoginView *)parent
{
    self = [super initWithFrame:frame];
    if (self) {
        _handler = handler;
        _parent = parent;
        self.backgroundColor = [UIColor clearColor];
        [self initSubviews];
    }
    return self;
}

- (void) initSubviews{
    register_bg = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.width, self.height)];
    register_bg.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self addSubview:register_bg];
    
    closeButton = [UIUtil newImageButtonWithFrame:CGRectZero image:nil target:self action:@selector(close)];
    closeButton.showsTouchWhenHighlighted = YES;
    [closeButton setImage:[UIImage imageNamed:@"btn_login_close.png"] forState:UIControlStateNormal];
    [self addSubview:closeButton];
    
    emailTextField = [[UITextField alloc] initWithFrame:CGRectZero];
    emailTextField.delegate = self;
    emailTextField.font = [UIFont systemFontOfSize:14.0f];
    emailTextField.keyboardType = UIKeyboardTypeEmailAddress;
    emailTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
    emailTextField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    emailTextField.placeholder = @"请输入真实有效的邮箱";
    [self addSubview:emailTextField];
    //    email.layer.borderWidth = 1;
    //    email.layer.borderColor = [UIColor redColor].CGColor;
    
    nameTextField = [[UITextField alloc] initWithFrame:CGRectZero];
    nameTextField.delegate = self;
    nameTextField.font = [UIFont systemFontOfSize:14.0f];
    nameTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
    nameTextField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    nameTextField.placeholder = @"3-16字符的汉字、字母、数字";
    [self addSubview:nameTextField];
    //    name.layer.borderWidth = 1;
    //    name.layer.borderColor = [UIColor redColor].CGColor;
    
    pwdTextField = [[UITextField alloc] initWithFrame:CGRectZero];
    pwdTextField.delegate = self;
    pwdTextField.font = [UIFont systemFontOfSize:14.0f];
    pwdTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
    pwdTextField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    pwdTextField.placeholder = @"密码长度6-16位";
    pwdTextField.secureTextEntry = YES;
    [self addSubview:pwdTextField];
    //    pwd.layer.borderWidth = 1;
    //    pwd.layer.borderColor = [UIColor redColor].CGColor;
    
    confirmPwdTextField = [[UITextField alloc] initWithFrame:CGRectZero];
    confirmPwdTextField.delegate = self;
    confirmPwdTextField.font = [UIFont systemFontOfSize:14.0f];
    confirmPwdTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
    confirmPwdTextField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    confirmPwdTextField.placeholder = @"再次输入上面您输入的密码";
    confirmPwdTextField.secureTextEntry = YES;
    [self addSubview:confirmPwdTextField];
    //    pwd_repeat.layer.borderWidth = 1;
    //    pwd_repeat.layer.borderColor = [UIColor redColor].CGColor;
    
    is_agree = YES;
    agree_license = [UIUtil newImageButtonWithFrame:CGRectMake(40, 152, 15, 15) image:nil tappedImage:nil target:self action:@selector(agreeLicense)];
    UIImage *img = [UIImage imageNamedNocache:@"checkbox_selected.png"];
    [agree_license setBackgroundImage:img forState:UIControlStateNormal];
    [self resetAgreeLicense];
    [self addSubview:agree_license];
    
    tiaokuanButton = [UIUtil newTextButtonWithFrame:CGRectZero title:@"财新网服务条款>>" titleColor:str2rgb(@"#FF3D01") tappedColor:[UIColor colorWithRed:0.5569 green:0.4824 blue:0.4314 alpha:1] font:[UIFont boldSystemFontOfSize:14.0f] target:self action:@selector(openTiaokuan)];
    [self addSubview:tiaokuanButton];
    
    //yinsiquan = [UIUtil newImageButtonWithFrame:CGRectZero image:nil target:self action:@selector(yinsiquan)];
    yinsiquanButton = [UIUtil newTextButtonWithFrame:CGRectZero title:@"隐私权声明>>" titleColor:str2rgb(@"#FF3D01") tappedColor:[UIColor colorWithRed:0.5569 green:0.4824 blue:0.4314 alpha:1] font:[UIFont boldSystemFontOfSize:14.0f] target:self action:@selector(openYinsiquan)];
    //    yinsiquan.layer.borderColor = [UIColor redColor].CGColor;
    //    yinsiquan.layer.borderWidth = 1;
    [self addSubview:yinsiquanButton];
    
    regUserButton = [UIUtil newImageButtonWithFrame:CGRectZero image:[UIImage imageNamedNocache:@"btn_register_atsoon_175_35.png"] target:self action:@selector(registerUser)];
    [self addSubview:regUserButton];
//    tipLabel = [[UILabel alloc] initWithFrame:CGRectZero];
//    tipLabel.text = @"注册财新网通行证，首次登录《新世纪》iPad，可获赠最新2期阅读权限。";//@"注册财新网用户，可获赠最新2期财新《新世纪》iPad版阅读权限。";
//    tipLabel.numberOfLines = 2;
//    tipLabel.textColor = [UIColor colorWithRed:0.3608 green:0.2275 blue:0.1451 alpha:1];
//    tipLabel.font = [UIFont systemFontOfSize:13.0f];
//    tipLabel.backgroundColor = [UIColor clearColor];
//    [self addSubview:tipLabel];
//    
//    smileImageView = [[UIImageView alloc] initWithImage:[UIImage imageWithContentsOfFile:KSPathForBundleResource(@"face_laugh_15_15.png")]];
//    [self addSubview:smileImageView];
    
}

- (void) layoutSubviews{
//    if([UIUtil currentOrientation]==0){
        register_bg.image = [UIImage imageNamedNocache:@"register_bg_v.png"];
        register_bg.frame = CGRectMake(0, 0, 420, 520);
        closeButton.frame = CGRectMake(382, 12, 25, 25);
        
        CGRect input_frame = CGRectMake(135, 80, 242, 28);
        emailTextField.frame = nameTextField.frame = pwdTextField.frame = confirmPwdTextField.frame = input_frame;
        nameTextField.top += 50;
        pwdTextField.top += 120;
        confirmPwdTextField.top += 170;
        
        agree_license.frame = CGRectMake(39, 329, 15, 15);
        
        tiaokuanButton.frame = CGRectMake(126, 325, 125, 25);
        yinsiquanButton.frame = CGRectMake(280, 325, 110, 25);
        
        tipLabel.frame = CGRectMake(33, 415, 382, 47);
        regUserButton.frame = CGRectMake(125, 380, 166, 29);
        smileImageView.frame = CGRectMake(15, 424, 15, 15);
        
//    }else{
//        register_bg.image = [UIImage imageNamedNocache:@"register_bg_h.png"];
//        register_bg.frame = CGRectMake(0, 0, 784, 328);
//        closeButton.frame = CGRectMake(740, 12, 25, 25);
//        
//        CGRect input_frame = CGRectMake(134, 76, 242, 28);
//        emailTextField.frame = nameTextField.frame = pwdTextField.frame = confirmPwdTextField.frame = input_frame;
//        nameTextField.top += 48;
//        confirmPwdTextField.frame = pwdTextField.frame = CGRectMake(507, 76, 242, 28);
//        confirmPwdTextField.top += 48;
//        agree_license.frame = CGRectMake(38, 188, 15, 15);
//        tiaokuanButton.frame = CGRectMake(125, 184, 125, 25);
//        yinsiquanButton.frame = CGRectMake(342, 184, 110, 25);
//        
//        regUserButton.frame = CGRectMake(540, 200, 175, 35);
//        
//        smileImageView.frame = CGRectMake(38, 228, 15, 15);
//        tipLabel.frame = CGRectMake(60, 222, 489, 27);
//    }
}

#pragma mark - helper
- (void)showError:(UITextField *)textField msg:(NSString *)text {
    UILabel *label = (UILabel *)textField.rightView;
    if (!label) {
        label = [UIUtil newLabelWithFrame:CGRectZero text:text textColor:[UIColor redColor] font:[UIFont systemFontOfSize:16]];
        textField.rightView = label;
        [label release];
    }else {
        label.text = text;
    }
    [label sizeToFit];
    textField.rightViewMode = UITextFieldViewModeAlways;
    label.hidden = NO;
    //textField.layer.borderColor = [[UIColor redColor] CGColor];
    //textField.layer.borderWidth = 1.0f;
}
#pragma mark - actions
- (void) resetAgreeLicense{
    UIImage *img = nil;
    if(is_agree){
        img = [UIImage imageNamedNocache:@"checkbox_selected.png"];
    }else{
        img = [UIImage imageNamedNocache:@"checkbox_unselect.png"];
    }
    [agree_license setBackgroundImage:img forState:UIControlStateNormal];
}
- (void) agreeLicense{
    is_agree = !is_agree;
    [self resetAgreeLicense];
}
-(void) changeVerifyCode{
    NSLog(@"changeVerifyCode");
}
//弹出条款WEB界面
- (void) openTiaokuan{
    [KSWebViewController presentWithURL:@"http://corp.caixin.cn/item/" inController:_handler];
}
//弹出隐私WEB界面
- (void) openYinsiquan{
    [KSWebViewController presentWithURL:@"http://corp.caixin.cn/priv/" inController:_handler];
}


- (void) registerUser{
    //[_parent animateShowRegSuccView];
    if(is_agree==NO){
        [UIUtil showMsgAlertWithTitle:@"提示" message:@"您未同意财新网服务条款。"];
        return;
    }
    [emailTextField resignFirstResponder];
    [pwdTextField resignFirstResponder];
    [nameTextField resignFirstResponder];
    [confirmPwdTextField resignFirstResponder];
    
    BOOL hasError = NO;
    NSString *mail = [emailTextField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    NSString *pwdStr = [pwdTextField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    NSString *confirmPwd = [confirmPwdTextField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    NSString *nickname = [nameTextField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    if (mail==nil || [mail length]==0) {
        hasError = YES;
        [self showError:emailTextField msg:@"邮箱不能为空  "];
    }else if(![DataUtil validateEmail:mail]){
        hasError = YES;
        [self showError:emailTextField msg:@"邮箱不合法  "];
    }
    if (pwdStr==nil || ![pwdStr length]) {
        hasError = YES;
        [self showError:pwdTextField msg:@"密码不能为空  "];
    } else if ([pwdStr length] < 6) {
        hasError = YES;
        [self showError:pwdTextField msg:@"密码太短  "];
    } else if ([pwdStr length] > 16) {
        hasError = YES;
        [self showError:pwdTextField msg:@"密码太长  "];
    } else if(![pwdStr isEqualToString:confirmPwd]){
        hasError = YES;
        [self showError:confirmPwdTextField msg:@"两次密码不相同  "];
    }
    if (nickname==nil || ![nickname length]) {
        hasError = YES;
        [self showError:nameTextField msg:@"用户名不能为空   "];
    }else if ([nickname length] < 3) {
        hasError = YES;
        [self showError:nameTextField msg:@"用户名太短   "];
    } else if ([nickname length] > 16) {
        hasError = YES;
        [self showError:nameTextField msg:@"用户名太长   "];
    }
    if (hasError) {
        return;
    }
    
    _emailStr = mail;
    _pwdStr = pwdStr;
    
    [CXRegDataRequest requestWithDelegate:self withParameters:[NSDictionary dictionaryWithObjectsAndKeys:mail,@"email",pwdStr,@"pwd",nickname,@"nickname", nil] withIndicatorView:_parent withCancelSubject:@"CXRegDataRequest"];
    
    //[UIUtil showProcessIndicatorWithView:self atPoint:CGPointMake(self.frame.size.width/2-5, 230) hasMask:NO];
    
    //[_handler registerUser:emailTextField.text name:nameTextField.text pwd:pwdTextField.text pwd_repeat:confirmPwdTextField.text verify_code:nil];
    //[_parent popView:self];
}

- (void)close{
    //    [self removeFromSuperview];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"CXRegDataRequest" object:nil];
    [_parent animateDismissRegFormView];
}

#pragma mark - UITextFieldDelegate
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    textField.rightView.hidden = YES;
    textField.rightViewMode = UITextFieldViewModeNever;
    return YES;
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    textField.rightView.hidden = YES;
    textField.rightViewMode = UITextFieldViewModeNever;
    return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

#pragma mark - KSDataRequestDelegate 
- (void)requestDidStarted:(KSBaseDataRequest *)request {
    if ([request isKindOfClass:[CXRegDataRequest class]]) {
        [UIUtil showProcessIndicatorWithView:regUserButton atPoint:CGPointMake(regUserButton.centerX+30, regUserButton.centerY) hasMask:NO];
        regUserButton.userInteractionEnabled = NO;
    }
}
- (void)requestDidFinished:(KSBaseDataRequest *)request {
    if ([request isKindOfClass:[CXRegDataRequest class]]) {
        regUserButton.userInteractionEnabled = YES;
        
//        if ([[request.resultDict objectForKey:@"error"] intValue] != 0) {
//            [self showError:emailTextField msg:[request.resultDict objectForKey:@"message"] ];
//            [UIUtil hideProcessIndicatorWithView:regUserButton];
//            return;
//        }
        NSString *rltStr = [request.resultDict objectForKey:@"data"];
        if( rltStr!=nil && ![rltStr isEqualToString:@""] ){
            if( [rltStr integerValue] == -1 ){
                [self showError:emailTextField msg:@"注册信息不合法  "];
                [UIUtil hideProcessIndicatorWithView:regUserButton];
                return;
            }else if( [rltStr integerValue] == 1 ){
                [self showError:emailTextField msg:@"邮箱或用户名已存在  "];
                [UIUtil hideProcessIndicatorWithView:regUserButton];
                return;
            } else if( [rltStr integerValue] == 0) {
                [CXActiveUserDataRequest requestWithDelegate:self withParameters:[NSDictionary dictionaryWithObjectsAndKeys:_emailStr, @"email", nil]];
                regUserButton.userInteractionEnabled = NO;
                //[DataPersistence execWithDelegate:self operationName:@"activeUser"];
                //[UIUtil showProcessIndicatorWithView:self atPoint:CGPointMake(self.frame.size.width/2-5, 300) hasMask:NO];
                
                //[controller showAccountActiveView];
            }else {
                [UIUtil hideProcessIndicatorWithView:regUserButton];
                [self showError:emailTextField msg:@"未知问题  "];
                return;
            }
        }else{
            [UIUtil hideProcessIndicatorWithView:regUserButton];
            [self showError:emailTextField msg:@"未知错误  "];
            return;
        }
    } else if ([request isKindOfClass:[CXActiveUserDataRequest class]]) {
        regUserButton.userInteractionEnabled = YES;
        [UIUtil hideProcessIndicatorWithView:regUserButton];
        [_parent displayRegSuccView:_emailStr password:_pwdStr];
    }
    
}
- (void)requestDidCanceled:(KSBaseDataRequest *)request {
    regUserButton.userInteractionEnabled = YES;
    [UIUtil hideProcessIndicatorWithView:regUserButton];

}
- (void)requestDidFailed:(KSBaseDataRequest *)request withError:(NSError*)error {
    regUserButton.userInteractionEnabled = YES;
    [UIUtil hideProcessIndicatorWithView:regUserButton];
    [UIUtil showMsgAlertWithTitle:@"提示" message:request.requestResult.message];
}

@end
