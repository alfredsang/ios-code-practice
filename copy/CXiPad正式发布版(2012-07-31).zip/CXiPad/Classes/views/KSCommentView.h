//
//  KSCommentView.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 1/4/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSUrlRequest.h"
#import "KSModelArticle.h"
#import "CXDataRequest.h"

@class KSCommentLeftView;
@class KSCommentRightView;
@class KSArticleViewController;
@interface KSCommentView : UIView<UITextViewDelegate,UITableViewDelegate,UITableViewDataSource, KSDataRequestDelegate> {
    UIImageView *_leftView;
    UIImageView *_rightView;
    UIImageView *_leftFrameView;
    UIImageView *_rightFrameView;
    UITableView *_tableView;
    UIButton *_closeButton;
    
    UILabel *_leftTitleLabel;
    UILabel *_leftTipLabel;
    
    UILabel *_rightTitleLabel;
    UILabel *_righttipLabel;
    UIView *_rightTitleBgView;
    UILabel *_rightNameLabel;
    
    UIButton *_submitButton;
    UIButton *_chooseNameButton;
    
    UITextView *_commentTextView;
    
    NSMutableArray *_commentList;
    NSInteger _page;
    NSInteger _pageSize;
    NSInteger _totalPage;
    NSInteger _totalRecord;
    BOOL _hasMorePage;
    BOOL _loadingMore;
    NSInteger _articleId;
    KSModelArticle *_modelArticle;
    
    NSString *_author;              //不需要release
    BOOL _isAnony;
    CGFloat _keyboardHeight;
    CGFloat _keyboardChangeHeight;
    BOOL _keyboardIsVisible;
    BOOL _editing;
    BOOL _scrolling;
    
    UIActivityIndicatorView *_indicatorView;
    
    KSArticleViewController *_controller;       //不需要release
}

@property(nonatomic, assign)KSArticleViewController *controller;

- (id)initWithFrame:(CGRect)frame article:(KSModelArticle *)article;
//- (id)initWithFrame:(CGRect)frame articleId:(NSInteger)aid;

@end

@interface KSCommentLeftView : UIView {
    
}
@end

@interface KSCommentRightView : UIView {

}
@end

