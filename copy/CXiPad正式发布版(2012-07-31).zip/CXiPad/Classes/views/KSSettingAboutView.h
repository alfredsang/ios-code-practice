//
//  KSAboutView.h
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-7.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <MessageUI/MessageUI.h>
#import <UIKit/UIKit.h>
#import "KSViewInitor.h"
#import "KSAppRecommendView.h"

@interface KSSettingAboutView : UIScrollView<UIWebViewDelegate,MFMailComposeViewControllerDelegate> {
    UIScrollView *_scrollView;
    UIImageView *_imageView;
    UIWebView *_webView;
    NSString *_aboutHtmlStr;
    KSAppRecommendView *_appRecommendView;
}

@end
