//
//  KSArticleListTabelView.m
//  CenturyWeeklyV2
//
//  Created by 广亮 高 on 12-6-19.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import "KSArticleListTabelView.h"
#import "KSDirectoryMainView.h"
#import "KSArticleViewController.h"

@implementation KSArticleListTabelViewCell

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {

        _topicLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        _topicLabel.backgroundColor = [UIColor clearColor];
        _topicLabel.font = TOPIC_FONT;
        _topicLabel.textColor = SUMMARY_COLOR;
    
        _titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        _titleLabel.font = CATALOG_AETICLE_TITLE_FONT;
        _titleLabel.textColor = TITLE_COLOR;
        _titleLabel.numberOfLines = 0;
        _titleLabel.lineBreakMode = UILineBreakModeCharacterWrap;
        _titleLabel.backgroundColor = [UIColor clearColor];
        
        _summaryLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        _summaryLabel.textColor = SUMMARY_COLOR;
        _summaryLabel.font = SUMMARY_FONT;
        _summaryLabel.numberOfLines = 0;
        _summaryLabel.lineBreakMode = UILineBreakModeCharacterWrap;
        _summaryLabel.backgroundColor = [UIColor clearColor];
        
        _author = [[UILabel alloc] init];
        _author.backgroundColor = [UIColor clearColor];
        _author.font = [UIFont systemFontOfSize:14];
        _author.textColor = TITLE_COLOR;
        _author.numberOfLines = 0;
        _author.lineBreakMode = UILineBreakModeCharacterWrap;

        
        _titleImageView = [[UIImageView alloc] initWithFrame:CGRectZero];
        
        [self addSubview:_topicLabel];
        [self addSubview:_titleLabel];
        [self addSubview:_summaryLabel];
        [self addSubview:_titleImageView];
        [self addSubview:_author];
        
    
    }
    return self;
}
-(void)reloadData:(KSModelArticle*)article hander:(KSDirectoryMainView*)hander
{
    _topicLabel.frame = CGRectMake(0, 36, 100, 0);
    _author.frame = CGRectZero;
    if (article.leve2CatalogName)
    {

        NSString *leve2Catalog = [[NSString alloc] initWithFormat:@"| %@ |",article.leve2CatalogName];
        _topicLabel.text = leve2Catalog;
        [leve2Catalog release];
        _topicLabel.height = 14;

    }

    NSString *title = [article.title stringByReplacingOccurrencesOfString:@"\|" withString:@"\n"];

    CGSize titleSize = [title sizeWithFont:CATALOG_AETICLE_TITLE_FONT constrainedToSize:CGSizeMake(283, MAXFLOAT) lineBreakMode:UILineBreakModeCharacterWrap];
    _titleLabel.size = titleSize;
    _titleLabel.text = title;
    _titleLabel.origin = CGPointMake(_topicLabel.left, _topicLabel.height>0?_topicLabel.bottom+6.5:36);
    
    BOOL isAuthor = NO;
    if (article.picAuthors && ![article.picAuthors isKindOfClass:[NSNull class]])
    {
        if (![[article.picAuthors stringByReplacingOccurrencesOfString:@" " withString:@""] isEqualToString:@""])
        {
            isAuthor = YES;
        }
    }
        
    if (article.catalogPicType == 0)
    {
        if (isAuthor)
        {
            CGSize authorSize = [article.picAuthors sizeWithFont:CATALOG_AETICLE_AUTHOR_FONT constrainedToSize:CGSizeMake(283, MAXFLOAT) lineBreakMode:UILineBreakModeCharacterWrap];
            _author.text = article.picAuthors;
            _author.frame = CGRectMake(_titleLabel.left, _titleLabel.bottom+11, authorSize.width, authorSize.height);
        }
        
        CGSize summarySize = [article.summary sizeWithFont:SUMMARY_FONT constrainedToSize:CGSizeMake(283, MAXFLOAT) lineBreakMode:UILineBreakModeCharacterWrap];
        _summaryLabel.size = summarySize;
        _summaryLabel.text = article.summary;
        _summaryLabel.origin = CGPointMake(_titleLabel.left, (_author.bottom>0?_author.bottom:_titleLabel.bottom)+11);
        
        _titleImageView.frame = CGRectZero;
    }
    else if (article.catalogPicType == 1)
    {
        if (isAuthor)
        {
            CGSize authorSize = [article.picAuthors sizeWithFont:CATALOG_AETICLE_AUTHOR_FONT constrainedToSize:CGSizeMake(283, MAXFLOAT) lineBreakMode:UILineBreakModeCharacterWrap];
            _author.text = article.picAuthors;
            _author.frame = CGRectMake(110, _titleLabel.bottom+11, authorSize.width, authorSize.height);

        }

        CGSize summarySize = [article.summary sizeWithFont:SUMMARY_FONT constrainedToSize:CGSizeMake(283-107, MAXFLOAT) lineBreakMode:UILineBreakModeCharacterWrap];
        _summaryLabel.size = summarySize;
        _summaryLabel.text = article.summary;
        _summaryLabel.origin = CGPointMake(110, (_author.bottom>0?_author.bottom:_titleLabel.bottom)+11);

        _titleImageView.frame= CGRectMake(0, _author.top>0?_author.top:_summaryLabel.top, 97, 97);
        _titleImageView.image = [UIImage imageWithContentsOfFile:article.catalogPicPath];
    }
    else if (article.catalogPicType == 2)
    {



        _titleImageView.frame= CGRectMake(0,36, 283, 150);
        _titleImageView.image = [UIImage imageWithContentsOfFile:article.catalogPicPath];
        _topicLabel.top =  _titleImageView.bottom+10;

        _titleLabel.origin = CGPointMake(_topicLabel.left, _topicLabel.bottom+6.5);

        if (isAuthor)
        {
            CGSize authorSize = [article.picAuthors sizeWithFont:CATALOG_AETICLE_AUTHOR_FONT constrainedToSize:CGSizeMake(283, MAXFLOAT) lineBreakMode:UILineBreakModeCharacterWrap];
            _author.text = article.picAuthors;
            _author.frame = CGRectMake(_titleLabel.left, _titleLabel.bottom+11, authorSize.width, authorSize.height);
        }
        
        CGSize summarySize = [article.summary sizeWithFont:SUMMARY_FONT constrainedToSize:CGSizeMake(283, MAXFLOAT) lineBreakMode:UILineBreakModeCharacterWrap];
        _summaryLabel.size = summarySize;
        _summaryLabel.text = article.summary;
        _summaryLabel.origin = CGPointMake(_titleLabel.left, (_author.bottom>0?_author.bottom:_titleLabel.bottom)+11);
    }

    if (![hander.controller articleById:article.articleId])
    {
        _titleLabel.textColor = TITLE_GRAY_COLOR;
    }
    else 
    {
        _titleLabel.textColor = TITLE_COLOR;
    }
}
-(void)dealloc
{
    RELEASE_SAFELY(_topicLabel);
    RELEASE_SAFELY(_titleLabel);
    RELEASE_SAFELY(_summaryLabel);
    RELEASE_SAFELY(_titleImageView);
    RELEASE_SAFELY(_author);
    [super dealloc];
}
@end






@implementation KSArticleListTabelView
@synthesize currentCatalogId;

- (id)initWithFrame:(CGRect)frame magazine:(KSModelMagzine*)magazine hander:(id)hander
{
    self = [super initWithFrame:frame magazine:magazine hander:hander];
    if (self) 
    {
        _hander = [hander retain];
        _magazine = [magazine retain];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _label.text = @"";
    
    }
    return self;
}

-(void)dealloc
{
    RELEASE_SAFELY(_magazine);
    RELEASE_SAFELY(_hander);
    [super dealloc];
}

-(void)removeAd:(NSMutableArray*)articles
{
    NSMutableIndexSet *set = [[NSMutableIndexSet alloc] init];
//    NSMutableArray *deleteIndexs = [[NSMutableArray alloc] init];
    for (int i = 0; i<[articles count]; i++)
    {
        KSModelArticle *article = [articles objectAtIndex:i];
        NSRange range = [article.title rangeOfString:@"封面"];
        if (article.artitype == 1 || article.artitype==2 || range.length>0)
        {
            [set addIndex:i];
        }
    }
    if([set count]>0)
    {
        [articles removeObjectsAtIndexes:set];
    }
    [set release];
}

-(void)reloadData:(NSInteger)catalogId
{
    currentCatalogId = catalogId;
    if (_catalogArray)
    {
        [_catalogArray removeAllObjects];
    }
    else 
    {
        _catalogArray = [[NSMutableArray alloc] init];
    }
    
    //未购买免费阅读文章
    if (catalogId<0)
    {
        [_catalogArray addObjectsFromArray:_hander.controller.readableArticlesArray];
        //去掉广告
        [self removeAd:_catalogArray];
//        for (int i = 0; i<[_catalogArray count]; i++)
//        {
//            KSModelArticle *article = [_catalogArray objectAtIndex:i];
//            NSRange range = [article.title rangeOfString:@"封面"];
//            if (article.artitype == 1 || article.artitype==2 || range.length>0)
//            {
//                [_catalogArray removeObjectAtIndex:i];
//            }
//        }
    }
    else
    {
        NSMutableArray *articleTitles = [[NSMutableArray alloc] initWithArray:_hander.controller.articles];
        //去掉广告
        [self removeAd:articleTitles];
//        for (int i = 0; i<[articleTitles count]; i++)
//        {
//            KSModelArticle *article = [articleTitles objectAtIndex:i];
//            
//            if (article.artitype == 1)
//            {
//                [articleTitles removeObjectAtIndex:i];
//            }
//        }
        NSMutableArray *catalogLeve2Title = [[KSModelCatalog catalogLeve2InMagazineId:_magazine.magzineId] retain];
        
        for (int i =0; i<[articleTitles count]; i++)
        {
            KSModelArticle *article = [articleTitles objectAtIndex:i];
            for (int j = 0; j<[catalogLeve2Title count]; j++)
            {
                KSModelCatalog *catalogLeve2 = [catalogLeve2Title objectAtIndex:j];
                if (article.catagoryId == catalogLeve2.catalogId)
                {
                    article.catagoryId = catalogLeve2.parentId;
                    article.leve2CatalogName = catalogLeve2.title;
                }
                
            }
        }
        for (int i = 0; i<[articleTitles count]; i++)
        {
            KSModelArticle *article = [articleTitles objectAtIndex:i];
            if (article.catagoryId==catalogId)
            {
                [_catalogArray addObject:article];
                
            }
            
        }
        [articleTitles release];
        [catalogLeve2Title release];
    }

    [_tableView reloadData];


}

-(void)layoutSubviews
{
    _tableView.frame = CGRectMake(0, 0, self.width, self.height);

    if ([UIUtil currentOrientation]==0) 
    {
        

        _label.frame = CGRectMake(0, 0, 100, 39);
    }
    else
    {

        _label.frame = CGRectMake(0, 0, 100, 25);
//        [_label alignBottom];
//        _tableView.tableHeaderView.frame = CGRectMake(0, 0, 100, 88.5);
        //        _tableView.tableHeaderView.hidden = NO;
    }
    _tableView.tableHeaderView = _label;

}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CGFloat height = 0;
    KSModelArticle *article = [_catalogArray objectAtIndex:[indexPath row]];
    NSString *title = [article.title stringByReplacingOccurrencesOfString:@"\|" withString:@"\n"];

    CGSize titleSize = [title sizeWithFont:TITLE_FONT constrainedToSize:CGSizeMake(283, MAXFLOAT) lineBreakMode:UILineBreakModeCharacterWrap];
    CGSize summarySize = [article.summary sizeWithFont:SUMMARY_FONT constrainedToSize:CGSizeMake(283, MAXFLOAT) lineBreakMode:UILineBreakModeCharacterWrap];
    BOOL isAuthor = NO;
    if (article.picAuthors && ![article.picAuthors isKindOfClass:[NSNull class]])
    {
        if (![[article.picAuthors stringByReplacingOccurrencesOfString:@" " withString:@""] isEqualToString:@""])
        {
            isAuthor = YES;

        }
    }

//    BOOL isAuthor = article.picAuthors&&![[article.picAuthors stringByReplacingOccurrencesOfString:@" " withString:@""] isEqualToString:@""];
    if (article.leve2CatalogName)
    {
        height += 14+6.5;
    }
    if (article.catalogPicType==2)
    {
        height+=150+10+titleSize.height+summarySize.height+60+11;
        if (isAuthor)
        {
            CGSize authorSize = [article.picAuthors sizeWithFont:CATALOG_AETICLE_AUTHOR_FONT constrainedToSize:CGSizeMake(283, MAXFLOAT) lineBreakMode:UILineBreakModeCharacterWrap];

            height+=authorSize.height+11;
        }
    }
    else if (article.catalogPicType==1)
    {
        summarySize = [article.summary sizeWithFont:SUMMARY_FONT constrainedToSize:CGSizeMake(283-107, MAXFLOAT) lineBreakMode:UILineBreakModeCharacterWrap];
        CGFloat summaryHeight = summarySize.height;
        if (isAuthor)
        {
            CGSize authorSize = [article.picAuthors sizeWithFont:CATALOG_AETICLE_AUTHOR_FONT constrainedToSize:CGSizeMake(283, MAXFLOAT) lineBreakMode:UILineBreakModeCharacterWrap];

            summaryHeight+=authorSize.height+11;
        }
        if (summaryHeight<97)
        {
            height+=titleSize.height+97+60+11;
        }
        else 
        {
            height+=titleSize.height+summaryHeight+60+11;
        }
    }
    else
    {
        height += titleSize.height+summarySize.height+60+11;
    }
    return height;
    
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString* identifier = @"usedCell";
    KSArticleListTabelViewCell *cell = (KSArticleListTabelViewCell*)[tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil)
    {
        cell = [[[KSArticleListTabelViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier] autorelease];
        UIImageView *lineImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"article_cut_off_line.png"]];
        UIImageView *highlightView = [[UIImageView alloc] initWithImage:[[UIImage imageNamed:@"select_article_bg.png"] stretchableImageWithLeftCapWidth:0 topCapHeight:20]];
        highlightView.alpha = 0;
        if ([UIUtil currentOrientation]==0) 
        {
            lineImageView.frame = CGRectMake(0, 0, tableView.width-50, 13);
            highlightView.frame = CGRectMake(-20, 20, tableView.width-50+20, cell.height);

        }
        else 
        {
            lineImageView.frame = CGRectMake(0, 0, tableView.width-25, 13);
            highlightView.frame = CGRectMake(-20, 20, tableView.width-25+20, cell.height);

        }
        lineImageView.tag = 400;
        highlightView.tag = 500;
        [cell insertSubview:highlightView atIndex:0];
        [cell addSubview:lineImageView];
        [lineImageView release];
        [highlightView release];

        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    UIImageView *line = (UIImageView*)[cell viewWithTag:400];
    if ([indexPath row]==0)
    {
        line.hidden = YES;
    }
    else 
    {
        line.hidden = NO;
    }
    KSModelArticle *article = [_catalogArray objectAtIndex:[indexPath row]];
    [cell reloadData:article hander:_hander];

    //自定义UITableViewCell选中时背景
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath  
{
    UITableViewCell *cell = (UITableViewCell*)[tableView cellForRowAtIndexPath:indexPath];
    UIImageView *highlightView = (UIImageView*)[cell viewWithTag:500];
    highlightView.height = cell.height-30;
    [UIView animateWithDuration:0.125 animations:^{
        highlightView.alpha = 1;
        
    } completion:^(BOOL finish){
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
        [UIView setAnimationDuration:0.125];
        highlightView.alpha = 0;
        [UIView commitAnimations];
    
    }];
    
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    KSModelArticle *article = [_catalogArray objectAtIndex:[indexPath row]];
   if (![_hander.controller articleById:article.articleId])  
    {
        //如果没有权限 不跳转直接返回
        
        [_hander.controller showNoPermissionView:_magazine delegate:_hander.controller];
        
    }
    else 
    {
        [_hander.controller gotoArticleId:article.articleId];

    }

    
}
@end
