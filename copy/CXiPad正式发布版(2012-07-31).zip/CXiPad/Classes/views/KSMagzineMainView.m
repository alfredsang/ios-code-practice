//
//  KSMagzineMainView.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-10.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "KSMagzineMainView.h"
#import "KSMagzineViewController.h"
#import "KSGetAllArticlesDownloader.h"
#import "KSDownMagazineOperation.h"
#import "KSMagazineBookStoreView.h"
#import "KSMagazineBookShelfView.h"


@implementation KSMagzineMainView
@synthesize bookshelf = _bookshelf, adView = _adView;
@synthesize coverScrollView = _coverScrollView;
@synthesize bottomShelfView = _bottomShelfView;
@synthesize bookShelfView = _bookShelfView;
@synthesize bookStoreView = _bookStoreView;
@synthesize years;
@synthesize buy,try_read;
@synthesize controller = _controller;
@synthesize selectYear = _selectYear;
@synthesize progressView = _progressView;
@synthesize yearSeg;
@synthesize editBtn = _editBtn;
@synthesize adWebView = _adWebView;

- (id)initWithFrame:(CGRect)frame controller:(id)controller
{
    self = [super initWithFrame:frame];
    if (self) {
        _controller = controller;

        self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        self.backgroundColor = [UIColor clearColor];
        [self initSubviews]; 
        _currentMagzineIndex = 0;
    }
    return self;
}

-(void)initYearNaviBar
{
    if (years)
    {
        RELEASE_SAFELY(years);
    }
    years = [[NSMutableArray alloc] initWithArray:[_controller getMagazinesYear]];
    if ([years count]>0)
    {
        _selectYear = [[years objectAtIndex:0] intValue];

    }
    if (_yearNaviBarImageView)
    {
        [_yearNaviBarImageView removeFromSuperview];
    }
    _yearNaviBarImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"navigation_bar_top_bg.png"]];
    _yearNaviBarImageView.frame = CGRectMake(0, _coverScrollView.bottom+44, self.width, 77);
    _yearNaviBarImageView.userInteractionEnabled = YES;
    [self addSubview:_yearNaviBarImageView];
    [_yearNaviBarImageView release];
    
    if (_bookShelfView.top!=1024||_bookStoreView.top!=1024)
    {
        _yearNaviBarImageView.top = 0;
    }
    
    yearSeg = (KSNavigationSegBtnView*)[self viewWithTag:2000];
    if (yearSeg)
    {
        [yearSeg removeAllSubviews];
    }
    yearSeg = [[KSNavigationSegBtnView alloc] initWithFrame:CGRectMake(28, 7, 55*[years count], 26) titles:years delegate:self];
    yearSeg.tag = 2000;
    yearSeg.userInteractionEnabled = YES;
    [_yearNaviBarImageView addSubview:yearSeg];
    [yearSeg release];
    
    typeSeg = (KSNavigationSegBtnView*)[self viewWithTag:2001];
    if (typeSeg)
    {
        [typeSeg removeAllSubviews];
    }
    NSMutableArray *types = [[NSMutableArray alloc] initWithObjects:@"最新",@"全部", nil];
    typeSeg = [[KSNavigationSegBtnView alloc] initWithFrame:CGRectMake(yearSeg.right+51, yearSeg.top, 55*[types count], yearSeg.height) titles:types delegate:self];
    typeSeg.tag = 2001;
    typeSeg.userInteractionEnabled = YES;
    [_yearNaviBarImageView addSubview:typeSeg];
    [typeSeg release];
    [types release];
    
    IF_IOS5_OR_GREATER(
                       NSString *title = [USER_DEFAULT boolForKey:BACKGROUND_DOWNLOAD]?@"后台下载":@"取消后台下载";
                       _backDownloadBtn = [UIButton buttonWithType:UIButtonTypeCustom];
                       _backDownloadBtn.frame = CGRectMake(typeSeg.right+55,yearSeg.top, 90, 26);
                       [_backDownloadBtn setBackgroundImage:[UIImage imageNamed:@"btn_download_bg.png"] forState:UIControlStateNormal];
                       [_backDownloadBtn addTarget:self action:@selector(chooseOpenBackgroundDownload) forControlEvents:UIControlEventTouchUpInside];
                       [_backDownloadBtn setTitle:title forState:UIControlStateNormal];
                       [_backDownloadBtn.titleLabel setFont:[UIFont boldSystemFontOfSize:13]];
                       [_backDownloadBtn setTitleColor:BTN_HIGHT_COLOR forState:UIControlStateNormal];
                       _backDownloadBtn.hidden = YES;
                       [_yearNaviBarImageView addSubview:_backDownloadBtn];

                       )
        
    _discubBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _discubBtn.frame = CGRectMake(typeSeg.right+55,yearSeg.top, 150, 26);
    _discubBtn.right = self.width-38.5;
    [_discubBtn setBackgroundImage:[UIImage imageNamed:@"discub_365.png"] forState:UIControlStateNormal];
    [_discubBtn addTarget:self action:@selector(subscription) forControlEvents:UIControlEventTouchUpInside];
    _discubBtn.hidden = YES;
    [_yearNaviBarImageView addSubview:_discubBtn];
    
    _editBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _editBtn.frame = CGRectMake(typeSeg.right+55,yearSeg.top, 87, 26);
    _editBtn.right = self.width-38.5;
    [_editBtn setTitleColor:BTN_HIGHT_COLOR forState:UIControlStateNormal];
    [_editBtn.titleLabel setFont:[UIFont boldSystemFontOfSize:13]];
    [_editBtn setBackgroundImage:[UIImage imageNamed:@"btn_download_bg.png"] forState:UIControlStateNormal];
    [_editBtn setTitle:@"编辑" forState:UIControlStateNormal];
    [_editBtn addTarget:_bookShelfView action:@selector(editBtnPress:) forControlEvents:UIControlEventTouchUpInside];
    _editBtn.hidden = YES;
    [_yearNaviBarImageView addSubview:_editBtn];
    
    
    UISwipeGestureRecognizer *swipeUp = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(bookStoreGesture:)];
    swipeUp.direction = UISwipeGestureRecognizerDirectionUp;
    [_yearNaviBarImageView addGestureRecognizer:swipeUp];
    [swipeUp release];
    
    swipeUp = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(bookStoreGesture:)];
    swipeUp.direction = UISwipeGestureRecognizerDirectionDown;
    [_yearNaviBarImageView addGestureRecognizer:swipeUp];
    [swipeUp release];

}

- (void) initSubviews{
    
    UIImageView *topImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"top_store_bg"]];
    topImageView.frame = CGRectMake(0, 0, self.width, 782);
    [self addSubview:topImageView];
    [topImageView release];
    
    _bookShelfBgView = [[UIView alloc] init];
    _bookShelfBgView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"book_store_bg.png"]];
    _bookShelfBgView.frame = CGRectMake(0, 783, 768, 243);
    

    [self addSubview:_bookShelfBgView];
    
    _adView = [[KSMagzineAdView alloc] initWithFrame:CGRectMake(44, 44, 680, 80) handler:self];
    [self addSubview:_adView];
    

    
    _coverScrollView = [[KSMagazineCoverView alloc] initWithFrame:CGRectMake(0, _adView.bottom+45 , self.width, 570) controller:_controller];
    _coverScrollView.centerX = self.centerX;

    [self addSubview:_coverScrollView];
    

    
    UIImage *i1 = [UIImage imageNamed:@"btn_subscription.png"];
    subscibe = [UIUtil newImageButtonWithFrame:CGRectMake(642, 533, 87, 54) image:i1 tappedImage:nil target:self action:@selector(subscription)];
    subscibe.right = self.width-38;
    [self addSubview:subscibe];

    
    try_read = [UIUtil newImageButtonWithFrame:CGRectMake(buy.right+30, 0, 87, 29) image:BTN_FREE_TO_READ_IMAGE tappedImage:nil target:self action:@selector(readMagazine:)];
    [try_read.titleLabel setFont:[UIFont boldSystemFontOfSize:14]];
    [try_read setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    try_read.right = subscibe.right;
    try_read.top = subscibe.bottom+40;
    [self addSubview:try_read];
    
    buy = [UIUtil newImageButtonWithFrame:CGRectMake(0, 0, 87, 29) image:BTN_BUY_IMAGE tappedImage:nil target:_controller action:@selector(buy:)];
    buy.right = subscibe.right;
    buy.top = try_read.bottom+40;
    [self addSubview:buy];

    
    _adWebView = [[KSMagazineSecondAdView alloc] initWithFrame:CGRectMake(_adView.left, _adView.bottom+20, 680, 375) handler:self];
    _adWebView.alpha = 0;
    [self addSubview:_adWebView];
    [_adWebView release];
    
    _closeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _closeBtn.bounds = CGRectMake(0, 0, 37, 34);
    _closeBtn.alpha = 0;
    _closeBtn.center = CGPointMake(_adWebView.right, _adWebView.top);
    [_closeBtn setImage:[UIImage imageNamed:@"btn_delete_big.png"] forState:UIControlStateNormal];
    [_closeBtn addTarget:self action:@selector(hiddenWhiteBoardView) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_closeBtn];
    
    
    _progressView = [[DDProgressView alloc] initWithFrame:CGRectMake(7, 13, try_read.width-14, 11)];
    _progressView.innerColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_white_progress.png"]];//[UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_blue_progress.png"]];
    _progressView.outerColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_progress_blue.png"]];
    _progressView.emptyColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_progress_blue.png"]];
    _progressView.layer.cornerRadius = 0.5f * _progressView.height;
    _progressView.clipsToBounds = YES;
    _progressView.userInteractionEnabled = NO;
    [self addSubview:_progressView];

    
    _bookStoreView = [[KSMagazineBookStoreView alloc] initWithFrame:CGRectMake(0, 0, self.width, self.height-_yearNaviBarImageView.height-90) controller:_controller];

    _bookShelfView = [[KSMagazineBookShelfView alloc] initWithFrame:CGRectMake(0, 0, self.width, self.height-_yearNaviBarImageView.height-90) controller:_controller];
    _bookStoreView.top = 1024;
    _bookShelfView.top = 1024;
    [self addSubview:_bookShelfView];
    [self addSubview:_bookStoreView];
    
    [self initYearNaviBar];

    _bottomShelfView = [[KSMagazinMainBottomShelfView alloc] initWithFrame:CGRectMake(0, _coverScrollView.bottom+80, self.width, 150) controller:_controller];
    [self addSubview:_bottomShelfView];
}
UIButton *_closeBtn;
-(void)showWhiteBoardView
{

    [UIUtil showFadeInAnimation:_adWebView endAlpha:1];
    [UIUtil showFadeInAnimation:_closeBtn endAlpha:1];
    _adView.isShow = YES;

}
-(void)hiddenWhiteBoardView
{
    if (_adWebView)
    {
        [UIUtil animatedHideView:_adWebView duration:0.3];
        [UIUtil animatedHideView:_closeBtn duration:0.3];
        _adView.isShow = NO;
    }


}
- (void) s_1y
{

    [KSAppStoreProxy subscribe:12 fromView:self];
}

//- (void) setCoverDocTitle:(NSArray *)articles index:(NSInteger)index{
//    UILabel *view = index==0?cover_doc_1:(index==1?cover_doc_2:(index==2?cover_doc_3:cover_doc_4));
//    view.hidden = index+1>[articles count];
//    if(index+1<=[articles count]){
//        KSModelMagzineCoverArticle *dict = [articles objectAtIndex:index];
//        view.text = dict.articleTitle;
//    }
//}

- (void) layoutSubviews
{
    KSModelMagzine *magzine = [_controller currentMagzine];
    BOOL isDownloading = NO;
    if (magzine.rateDownload>0&&magzine.rateDownload<1)
    {
        isDownloading = YES;
    }


    if ([magzine isMybook])
    {
        try_read.hidden = YES;
        if (magzine.rateDownload>0 && magzine.rateDownload<1)
        {
            [buy setBackgroundImage:BTN_PAUSE_IMAGE forState:UIControlStateNormal];
            _progressView.progress = magzine.rateDownload;
            _progressView.center = CGPointMake(buy.centerX, buy.centerY+7);

            
        }
        else if (magzine.rateDownload == 0)
        {
            [buy setBackgroundImage:BTN_DOWNLOAD_IMAGE forState:UIControlStateNormal];
            
        }
        else
        {
            [buy setBackgroundImage:BTN_READ_IMAGE forState:UIControlStateNormal];
        }
    }
    else 
    {
        try_read.hidden = NO;

        if (magzine.isDownload)
        {
            [try_read setBackgroundImage:BTN_PREVIEW_IMAGE forState:UIControlStateNormal];
        }
        else 
        {
            [try_read setBackgroundImage:BTN_FREE_TO_READ_IMAGE forState:UIControlStateNormal];
        }
        if (isDownloading)
        {
            [try_read setBackgroundImage:BTN_PAUSE_IMAGE forState:UIControlStateNormal];
            _progressView.progress = magzine.rateDownload;
            _progressView.center = CGPointMake(try_read.centerX, try_read.centerY+7);
//            _progressView.hidden = NO;

        }
        
        [buy setBackgroundImage:BTN_BUY_IMAGE forState:UIControlStateNormal];

    }
    _progressView.hidden = !isDownloading;

    //切换大图
    UIImage *image = [UIImage imageWithContentsOfFile:magzine.cover_3];
    if (image)
    {
        KSMagazineCoverImageView *item = (KSMagazineCoverImageView*)[_coverScrollView viewWithTag:magzine.magzineId];
        if (item) {
            item.imageView.image = image;
        }
    }
}


-(void)chooseOpenBackgroundDownload
{
    if ([_backDownloadBtn.titleLabel.text isEqualToString:@"后台下载"])
    {
        [_backDownloadBtn setTitle:@"取消后台下载" forState:UIControlStateNormal];
        [USER_DEFAULT setBool:NO forKey:BACKGROUND_DOWNLOAD];
        
    }
    else 
    {
        [_backDownloadBtn setTitle:@"后台下载" forState:UIControlStateNormal];
        [USER_DEFAULT setBool:YES forKey:BACKGROUND_DOWNLOAD];
    }
    [USER_DEFAULT synchronize];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"您已切换下载模式！请重启应用程序以生效：按Home键关闭应用，按两次Home调出多任务栏，找到财新《新世纪》周刊图标，长按出现减号后点减号关闭，然后重新打开应用。" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alert show];
    [alert release];

}

-(void)subscription
{
    [_bottomShelfView autoChangePosition];
    [_controller s_1y];

}
- (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag {

    _controller.purchaseing = NO;
}
//- (void)animateShowPurchased {
//    //动画显示时不转屏，以保证效果
//    _controller.purchaseing = YES;
//    
//    UIImageView *imageView = [[UIImageView alloc] initWithImage:_coverflow.openflow.selectedCoverView.imageView.image];
//    if (isRetina) {
//        imageView.width = round(imageView.width/2);
//        imageView.height = round(imageView.height/2);
//    }
//    imageView.tag = 1010;
//    imageView.center = _coverflow.center;
//    [self addSubview:imageView];
//    
//    CAKeyframeAnimation *keyFrameAnimation = [CAKeyframeAnimation animationWithKeyPath:@"position"];
//	[keyFrameAnimation setDuration:1.0];
//    CGFloat totalTime = 1.0;
//    CGPoint p1 = imageView.center;
//	if ([UIUtil currentOrientation] == 0) {
//        CGPoint p2 = CGPointMake(344, 426);
//        CGPoint p3 = CGPointMake(299, 405);
//        CGPoint p4 = CGPointMake(241, 388);
//        CGPoint p5 = CGPointMake(187, 382);
//        CGPoint p6 = CGPointMake(152, 391);
//        CGPoint p7 = CGPointMake(118, 400);
//        CGPoint p8 = CGPointMake(78, 483);
//        CGPoint p9 = CGPointMake(78, 889);
//        
//        [keyFrameAnimation setValues:[NSArray arrayWithObjects: 
//                                      [NSValue valueWithCGPoint:p1], 
//                                      [NSValue valueWithCGPoint:p2], 
//                                      [NSValue valueWithCGPoint:p3], 
//                                      [NSValue valueWithCGPoint:p4], 
//                                      [NSValue valueWithCGPoint:p5], 
//                                      [NSValue valueWithCGPoint:p6], 
//                                      [NSValue valueWithCGPoint:p7],
//                                      [NSValue valueWithCGPoint:p8],
//                                      [NSValue valueWithCGPoint:p9],
//                                      nil]];
//        [keyFrameAnimation setKeyTimes:[NSArray arrayWithObjects:
//                                        [NSNumber numberWithFloat:0.0],
//                                        [NSNumber numberWithFloat:0.05],
//                                        [NSNumber numberWithFloat:0.1],
//                                        [NSNumber numberWithFloat:0.2],
//                                        [NSNumber numberWithFloat:0.3],
//                                        [NSNumber numberWithFloat:0.4],
//                                        [NSNumber numberWithFloat:0.5],
//                                        [NSNumber numberWithFloat:0.6],
//                                        [NSNumber numberWithFloat:1.0],
//                                        nil]];
//    } else {
//        //352,369
//        CGPoint p2 = CGPointMake(304, 326);
//        CGPoint p3 = CGPointMake(254, 308);
//        CGPoint p4 = CGPointMake(214, 298);
//        CGPoint p5 = CGPointMake(151, 316);
//        CGPoint p6 = CGPointMake(121, 367);
//        CGPoint p7 = CGPointMake(110, 405);
//        CGPoint p8 = CGPointMake(110, 500);
//        CGPoint p9 = CGPointMake(110, 638);
//        
//        [keyFrameAnimation setValues:[NSArray arrayWithObjects: 
//                                      [NSValue valueWithCGPoint:p1], 
//                                      [NSValue valueWithCGPoint:p2], 
//                                      [NSValue valueWithCGPoint:p3], 
//                                      [NSValue valueWithCGPoint:p4], 
//                                      [NSValue valueWithCGPoint:p5], 
//                                      [NSValue valueWithCGPoint:p6], 
//                                      [NSValue valueWithCGPoint:p7],
//                                      [NSValue valueWithCGPoint:p8],
//                                      [NSValue valueWithCGPoint:p9],
//                                      nil]];
//        [keyFrameAnimation setKeyTimes:[NSArray arrayWithObjects:
//                                        [NSNumber numberWithFloat:0.0],
//                                        [NSNumber numberWithFloat:0.02],
//                                        [NSNumber numberWithFloat:0.05],
//                                        [NSNumber numberWithFloat:0.1],
//                                        [NSNumber numberWithFloat:0.2],
//                                        [NSNumber numberWithFloat:0.3],
//                                        [NSNumber numberWithFloat:0.4],
//                                        [NSNumber numberWithFloat:0.5],
//                                        [NSNumber numberWithFloat:0.8],
//                                        nil]];
//        totalTime = 0.8;
//    }
//	
//	//[imageView.layer addAnimation:keyFrameAnimation forKey:@"move"];
//    
//    CABasicAnimation *scaleAnimation = [CABasicAnimation animationWithKeyPath:@"transform"];
//    CATransform3D transform1 = CATransform3DIdentity;//CATransform3DMakeScale(0.4, 0.4, 1.0);
//    CATransform3D transform2 = CATransform3DMakeScale(0.4, 0.4, 1.0);
//    scaleAnimation.fromValue = [NSValue valueWithCATransform3D:transform1];
//    scaleAnimation.toValue = [NSValue valueWithCATransform3D:transform2];
//    scaleAnimation.duration = 0.8;
//    
//    
//    CAAnimationGroup *animGroup = [CAAnimationGroup animation];
//    animGroup.animations = [NSArray arrayWithObjects:keyFrameAnimation, scaleAnimation, nil];
//    animGroup.timingFunction=[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
//    animGroup.duration = totalTime;
//    animGroup.delegate = self;
//    [imageView.layer addAnimation:animGroup forKey:nil];
//    
//    imageView.center = CGPointMake(78, 889);
//    imageView.transform = CGAffineTransformMakeScale(0.4, 0.4);
//    
//    [imageView release];
//    [_bookshelf animateAddMagazine:[_controller currentMagzine]];
//
//}
- (void)reloadData {
//    [_bookshelf reloadData];
//    [_coverflow reloadData];
    [_bottomShelfView reloadData];
    [_coverScrollView reloadData];
}

-(void)reloadDataWithYear:(NSInteger)year
{
    _selectYear = year;
    [_coverScrollView selectYear:year];

    [_bottomShelfView selectYear:year];
    [_bookStoreView selectYear:year];
    [_bookShelfView selectYear:year];
    NSMutableArray *magazinsArray = [[_controller loadMagazineByYear:year] retain];
    if ([magazinsArray count]>0)
    {
        [_controller setCurrentMagzine:[magazinsArray objectAtIndex:0]];

    }
     [magazinsArray release];
    [self setNeedsLayout];
    
}

-(void)showBookStore
{
    [self cancelDownload:[_controller currentMagzine]];

    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDuration:0.5];
 
    _yearNaviBarImageView.top = 0;
    _bookStoreView.top = _yearNaviBarImageView.height-36;

    _backDownloadBtn.hidden = NO;
    _discubBtn.hidden = NO;
    _editBtn.hidden = YES;
    typeSeg.hidden = NO;
    
    
    NSArray *array = [typeSeg subviews];
    for (int i = 0;i<[array count];i++)
    {
        if ([[array objectAtIndex:i] isKindOfClass:[UIButton class]])
        {
            UIButton *btn = [array objectAtIndex:i];
            if ([btn.titleLabel.text isEqualToString:@"最新"]) 
            {
                btn.selected = NO;
            }
            if ([btn.titleLabel.text isEqualToString:@"全部"]) 
            {
                btn.selected = YES;
                [typeSeg changeBtnWithAnimation:btn];

            }

        }
    }

    [UIView commitAnimations];

}

-(void)showBookShlefView
{
    [self cancelDownload:[_controller currentMagzine]];
    if (_bookShelfView.isEditModel) 
    {
        [_bookShelfView editBtnPress:self.editBtn];
    }
    [self bringSubviewToFront:_bookShelfView];
    [self bringSubviewToFront:_yearNaviBarImageView];
    [self bringSubviewToFront:_controller.footer];
    _yearNaviBarImageView.top = 0;
    _bookShelfView.top = _yearNaviBarImageView.height-36;
    _backDownloadBtn.hidden = YES;
    _discubBtn.hidden = YES;
    _editBtn.hidden = NO;
    typeSeg.hidden = YES;
//    [UIView beginAnimations:nil context:nil];
//    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
//    [UIView setAnimationDuration:1];
//    [UIView setAnimationTransition: UIViewAnimationTransitionFlipFromLeft forView:self.superview cache:YES];  //从左向右
//    [UIView commitAnimations];
//    [_controller.footer.bookShelfBtn setImage:[UIImage imageNamed:@"store_normal.png"] forState:UIControlStateNormal];
//    [_controller.footer.bookShelfBtn setImage:[UIImage imageNamed:@"store_light.png"] forState:UIControlStateHighlighted];



}
-(void)hiddenBookShelf
{
    [self cancelDownload:[_controller currentMagzine]];
    _bookShelfView.top = 1024;
    _bookStoreView.top = 1024;
    _yearNaviBarImageView.top = _coverScrollView.bottom+44;
//    [_controller.footer.bookShelfBtn setImage:[UIImage imageNamed:@"bookshelf_normal.png"] forState:UIControlStateNormal];
//    [_controller.footer.bookShelfBtn setImage:[UIImage imageNamed:@"bookshelf_light.png"] forState:UIControlStateHighlighted];
    
    _backDownloadBtn.hidden = YES;
    _discubBtn.hidden = YES;
    _editBtn.hidden = YES;
    typeSeg.hidden = NO;
    _bottomShelfView.alpha = 1;

//    [UIView beginAnimations:nil context:nil];
//    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
//    [UIView setAnimationDuration:1];
//    
//    
//    [UIView setAnimationTransition: UIViewAnimationTransitionFlipFromLeft forView:self.superview cache:YES];  //从左向右
//
//    
//    [UIView commitAnimations];
    
    NSArray *array = [typeSeg subviews];
    for (int i = 0;i<[array count];i++)
    {
        if ([[array objectAtIndex:i] isKindOfClass:[UIButton class]])
        {
            UIButton *btn = [array objectAtIndex:i];
            if ([btn.titleLabel.text isEqualToString:@"最新"]) 
            {
                btn.selected = YES;
                [typeSeg changeBtnWithAnimation:btn];
            }
            if ([btn.titleLabel.text isEqualToString:@"全部"]) 
            {
                btn.selected = NO;
            }
            
        }
    }

    
}
-(void)showBookStoreView
{
    
    [self cancelDownload:[_controller currentMagzine]];

        [self bringSubviewToFront:_bookStoreView];
        [self bringSubviewToFront:_yearNaviBarImageView];
        [UIView animateWithDuration:0.25 
                         animations:
         ^{
             
             _bottomShelfView.alpha = 0;
             
         } 
                         completion:^(BOOL finished){
                             [self showBookStore];
                         }];
        


}
-(void)hiddenStoreView
{
    [self cancelDownload:[_controller currentMagzine]];
    [UIView animateWithDuration:0.5 
                     animations:
     ^{
         _bookStoreView.top = 1024;
         if (_bookShelfView.top==1024)
         {
             _yearNaviBarImageView.top = _coverScrollView.bottom+44;

         }
         _backDownloadBtn.hidden = YES;
         _discubBtn.hidden = YES;
         _editBtn.hidden = YES;
         typeSeg.hidden = NO;
         NSArray *array = [typeSeg subviews];
         for (int i = 0;i<[array count];i++)
         {
             if ([[array objectAtIndex:i] isKindOfClass:[UIButton class]])
             {
                 UIButton *btn = [array objectAtIndex:i];
                 if ([btn.titleLabel.text isEqualToString:@"最新"])
                 {
                     btn.selected = YES;
                     [typeSeg changeBtnWithAnimation:btn];

                 }
                 if ([btn.titleLabel.text isEqualToString:@"全部"])
                 {
                     btn.selected = NO;
                     
                 }
                 
             }
         }

         
         
     } 
                     completion:^(BOOL finished){
                         _bottomShelfView.alpha = 1;
                     }];

}
-(void)hiddenStoreViewWithNoAnimation
{
    [self cancelDownload:[_controller currentMagzine]];
    _bottomShelfView.alpha = 1;
    _bookStoreView.top = 1024;
    if (_bookShelfView.top==1024)
    {
        _yearNaviBarImageView.top = _coverScrollView.bottom+44;
        
    }
    _backDownloadBtn.hidden = YES;
    _discubBtn.hidden = YES;
    _editBtn.hidden = YES;
    typeSeg.hidden = NO;
    NSArray *array = [typeSeg subviews];
    for (int i = 0;i<[array count];i++)
    {
        if ([[array objectAtIndex:i] isKindOfClass:[UIButton class]])
        {
            UIButton *btn = [array objectAtIndex:i];
            if ([btn.titleLabel.text isEqualToString:@"最新"])
            {
                btn.selected = YES;
                [typeSeg changeBtnWithAnimation:btn];
                
            }
            if ([btn.titleLabel.text isEqualToString:@"全部"])
            {
                btn.selected = NO;
                
            }
            
        }
    }

}
-(void)bookStoreGesture:(UISwipeGestureRecognizer*)gesture
{
    if (gesture.direction == UISwipeGestureRecognizerDirectionUp)
    {
        [self showBookStoreView];
    }
    if (gesture.direction == UISwipeGestureRecognizerDirectionDown) {
        [self hiddenStoreView];
    }

}
//-(void)showStoreView:(UISwipeGestureRecognizer*)gesture
//{
//    if (gesture.direction == UISwipeGestureRecognizerDirectionUp)
//    {
//        [self showBookStoreView];
//    }
//    else if (gesture.direction == UISwipeGestureRecognizerDirectionDown)
//    {
//        [self
//    }
//}

- (void)dealloc{
    
    [_coverScrollView release];
    [_adView release];
    [years release];
//    RELEASE_SAFELY(_yearNaviBarImageView);
    _bottomShelfView.controller = nil; [_bottomShelfView release];
    [subscibe release];
//    [cover_title release];
//    [cover_desc release];
//    [cover_doc_1 release];
//    [cover_doc_2 release];
//    [cover_doc_3 release];
//    [cover_doc_4 release];
//    [actions release];
    [buy release];
//    [buyTitle release];
    [try_read release];
//    [try_readTitle release];
    [_editBtn release];
    [_discubBtn release];
    [_progressView release];
    [_bookShelfBgView release];

    [super dealloc];
}

#pragma mark -
- (void)doRead {
    [(KSMagzineViewController *)_controller try_read];
}
//- (void)doDownload 
//{
//    KSModelMagzine *magazine = [_controller currentMagzine];
//    if (magazine.isArticlesDownload) 
//    {
//        [self doRead];
//    }
//    else
//    {
////        if ([try_read backgroundImageForState:UIControlStateNormal] == BTN_FREE_TO_READ_IMAGE || [try_read backgroundImageForState:UIControlStateNormal] == BTN_PAUSE_IMAGE) 
////        {
//            _progressView.hidden = NO;
//            // 增加下载整包逻辑
//            if ([KSGetAllArticlesDownloader isDownloading:magazine.magzineId])
//            {
//                KSDownMagazineOperation *op = [[KSBootstrap dataCenter] valueForKey:KEY_DOWNLOADING_M_ID];
//                if (op && op.magazinId == magazine.magzineId && [op.progressView isKindOfClass:[DDProgressView class]])
//                {
//                    [try_read setBackgroundImage:BTN_PAUSE_IMAGE forState:UIControlStateNormal];
//                    op.progressView = (UIProgressView *)_progressView;
//                } 
//                else
//                {
//                    if (op) 
//                    {
//                        [op cancel];
//                        op.progressView = nil;
//                    }
//                    [try_read setBackgroundImage:BTN_PAUSE_IMAGE forState:UIControlStateNormal];
//
//                    magazine.rateDownload = _progressView.progress;
//                    [_progressView setProgress:_progressView.progress];
//                    [[KSBootstrap dataCenter] removeObjectForKey:KEY_DOWNLOADING_M_ID];
//                }
//            } 
//            else 
//            {
//                [try_read setBackgroundImage:BTN_DOWNLOADING_IMAGE forState:UIControlStateNormal];
//                KSDownMagazineOperation *op = [[KSBootstrap dataCenter] valueForKey:KEY_DOWNLOADING_M_ID];
//                if (![op isCancelled]) 
//                {
//
//                    [op cancel];
//                    op.progressView = nil;
//                }
//                [[KSBootstrap dataCenter] removeObjectForKey:KEY_DOWNLOADING_M_ID];
//                
//                op = [[KSDownMagazineOperation alloc] initWithMagazineId:magazine.magzineId];
//                op.progressView = (UIProgressView *)_progressView;
//                [[KSBootstrap dataCenter] setValue:op forKey:KEY_DOWNLOADING_M_ID];
//                
//                [[KSBootstrap operationQueue] addOperation:op];
//                [op release];
//            }
////        }
////        else if([try_read backgroundImageForState:UIControlStateNormal] == BTN_DOWNLOADING_IMAGE)
////        {
////            [try_read setBackgroundImage:BTN_PAUSE_IMAGE forState:UIControlStateNormal];
////        }
//    }
//    
//}





- (void)doDownload 
{
    KSModelMagzine *magazine = [_controller currentMagzine];
    KSDownMagazineOperation *op = [[KSBootstrap dataCenter] valueForKey:KEY_DOWNLOADING_M_ID];
    if (op) {
        if (![op isCancelled]) 
        {
            if ([op.progressView isKindOfClass:[DDProgressView class]]) 
            {//将上一本下载进度条置灰
                
            }
            [op cancel];
            [_bookShelfView whenMagzineCancelDownload:magazine.magzineId reloadData:YES];
            [_bookStoreView whenMagzineCancelDownload:magazine.magzineId reloadData:YES];
        }
        op.progressView = nil;
    }
    [[KSBootstrap dataCenter] removeObjectForKey:KEY_DOWNLOADING_M_ID];
    
    op = [[KSDownMagazineOperation alloc] initWithMagazineId:magazine.magzineId];
    _progressView.hidden = NO;
    op.progressView = (UIProgressView *)_progressView;
    [[KSBootstrap dataCenter] setValue:op forKey:KEY_DOWNLOADING_M_ID];
    
    [[KSBootstrap operationQueue] addOperation:op];
    [op release];
    KSDINFO(@"presseView:  %@",_progressView);
}
- (void)readMagazine:(UIButton*)btn
{
    [_bottomShelfView autoChangePosition];
    _progressView.center = CGPointMake(btn.centerX, btn.centerY+7);
    KSModelMagzine *magazine = [_controller currentMagzine];


    if (magazine.isArticlesDownload) 
    {
        [_controller gotoArticle:0 magzineId:magazine.magzineId from:@"bookself"];
    } 
    else 
    {
        if (![UIUtil checkInternetConnection])
        {
            return;
        }
        
        if ([KSGetAllArticlesDownloader isDownloading:magazine.magzineId]) 
        {
            KSDownMagazineOperation *op = [[KSBootstrap dataCenter] valueForKey:KEY_DOWNLOADING_M_ID];
            if (op && op.magazinId == magazine.magzineId && [op.progressView isKindOfClass:[KSProgressView class]]) 
            {
                op.progressView = (UIProgressView *)_progressView;
            }
            else 
            {
                //[_progressView setTintColor:[UIColor colorWithRed:0.1490 green:0.4627 blue:0.8392 alpha:1]];
                if (op) 
                {
                    [op cancel];
                    op.progressView = nil;
                    [_bookShelfView whenMagzineCancelDownload:magazine.magzineId reloadData:YES];
                    [_bookStoreView whenMagzineCancelDownload:magazine.magzineId reloadData:YES];
                }
                magazine.rateDownload = _progressView.progress;
                [_progressView setProgress:_progressView.progress];
                [try_read setBackgroundImage:BTN_PAUSE_IMAGE forState:UIControlStateNormal];
                [[KSBootstrap dataCenter] removeObjectForKey:KEY_DOWNLOADING_M_ID];
            }
        }
        else 
        {
            [try_read setBackgroundImage:BTN_DOWNLOADING_IMAGE forState:UIControlStateNormal];
            [self doDownload];
        }
    }
    
}

- (void)cancelDownload:(KSModelMagzine*)magazine {


    KSDownMagazineOperation *op = [[KSBootstrap dataCenter] valueForKey:KEY_DOWNLOADING_M_ID];
    KSDINFO(@"cancel downloading...%d", op.magazinId);
    
    if (op) 
    {
//        KSModelMagzine *magazine = [_controller currentMagzine];
        
        [op cancel];
        [_bookShelfView whenMagzineCancelDownload:op.magazinId reloadData:YES];
        [_bookStoreView whenMagzineCancelDownload:op.magazinId reloadData:YES];
        op.progressView = nil;
        magazine.rateDownload = _progressView.progress;
        [_progressView setProgress:_progressView.progress];
        [try_read setBackgroundImage:BTN_PAUSE_IMAGE forState:UIControlStateNormal];
        [[KSBootstrap dataCenter] removeObjectForKey:KEY_DOWNLOADING_M_ID];
        
    }
    [self setNeedsLayout];


}
- (void)cancelDownload {
    

    try_read.hidden = NO;
    _progressView.hidden = YES;
    KSDownMagazineOperation *op = [[KSBootstrap dataCenter] valueForKey:KEY_DOWNLOADING_M_ID];
    KSDINFO(@"cancel downloading...%d", op.magazinId);

    if (op) 
    {
        KSModelMagzine *magazine = [_controller currentMagzine];

        [op cancel];
        [_bookShelfView whenMagzineCancelDownload:magazine.magzineId reloadData:YES];
        [_bookStoreView whenMagzineCancelDownload:magazine.magzineId reloadData:YES];
        op.progressView = nil;
        magazine.rateDownload = _progressView.progress;
        [_progressView setProgress:_progressView.progress];
        [try_read setBackgroundImage:BTN_PAUSE_IMAGE forState:UIControlStateNormal];
        [[KSBootstrap dataCenter] removeObjectForKey:KEY_DOWNLOADING_M_ID];

    }
}

#pragma mark -
- (void)openCaixinIndex:(id)sender {
    [KSWebViewController presentWithURL:@"http://www.caixin.com/" inController:self.viewController];
}



@end
