//
//  KSSearchView.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-20.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSSearchView.h"
//#import "UIImageExtras.h"
#import "KSMagzineViewController.h"
#import "KSSearchTableViewCell.h"

@interface KSSearchView()
@property(nonatomic, retain) NSMutableDictionary *imageDownloadsInProgress;
//- (void)startImageDownload:(KSModelSearchItem *)item forIndexPath:(NSIndexPath *)indexPath;
//- (void) cancelAllImageDownloads;
- (void) doSearch;
@end

@implementation KSSearchView
@synthesize imageDownloadsInProgress = _imageDownloadsInProgress;

- (void) dealloc{
    [KSBootstrap unlisten:self];
    
    [_request cancel];
    [_request release];
    
//    [_bgImageView release];
    [_popImageView release];
    
    [background release];
    [btnBack release];
    [btnSearch release];
    [btnDelInputText release];
    [txtSearchWord release];
    [_indicatorView stopAnimating],[_indicatorView release];
    //[scrollView release];
    [_tableView release];
    [lblResultHint release];
    [_imageDownloadsInProgress release];
    [_entries release];
    
    [super dealloc];
}

- (id)initWithFrame:(CGRect)frame handler:(id)handler
{
    self = [super initWithFrame:frame];
    if (self) {
        _handler = handler;
//        self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageWithContentsOfFile:KSPathForBundleResource(@"book_store_bg.png")]];
        [self initSubviews];
    }
    return self;
}
- (void) initData{
    _entries = [[NSMutableArray alloc] initWithCapacity:10];
    _page = 1;
    _totalPage = 1;
    _pageSize = 20;
    _hasMorePage = NO;
    _loadingMore = NO;
}
- (void) initSubviews{
    [self initData];
//    _bgImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.width, self.height)];
//    _bgImageView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
//    [self addSubview:_bgImageView];
    
//    background = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.width, self.height)];
//    background.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
//    [self addSubview:background];
    
    _popImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamedNocache:@"pop_collect_v.png"]];
    _popImageView.frame = CGRectMake(30, 35, 708, 943);
    [self addSubview:_popImageView];
    _popImageView.userInteractionEnabled = YES;
    
    btnBack = [[UIButton alloc] initWithFrame:CGRectMake(32, 0, 72, 60)];
    btnBack.showsTouchWhenHighlighted = YES;
    [btnBack setImage:[UIImage imageNamedNocache:@"btn_back_inpanel.png"] forState:UIControlStateNormal];
    [btnBack setImage:[UIImage imageNamedNocache:@"btn_back_inpanel.png"] forState:UIControlStateHighlighted];
    [btnBack addTarget:_handler action:@selector(backToMain) forControlEvents:UIControlEventTouchUpInside];
    [_popImageView addSubview:btnBack];
    
    
    btnSearch = [[UIButton alloc] initWithFrame:CGRectMake(117, -1, 72, 60)];
    btnSearch.showsTouchWhenHighlighted = YES;
    [btnSearch setImage:[UIImage imageNamedNocache:@"btn_search_inpanel.png"] forState:UIControlStateNormal];
    [btnSearch setImage:[UIImage imageNamedNocache:@"btn_search_inpanel.png"] forState:UIControlStateHighlighted];
    [btnSearch addTarget:self action:@selector(doSearch) forControlEvents:UIControlEventTouchUpInside];
    [_popImageView addSubview:btnSearch];
    
    _indicatorView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    [_popImageView addSubview:_indicatorView];
    
    txtSearchWord = [[UITextField alloc] initWithFrame:CGRectMake(99, 105, 823, 24)];
    txtSearchWord.placeholder = @"请输入检索词";
    txtSearchWord.clearButtonMode = UITextFieldViewModeWhileEditing;
    txtSearchWord.returnKeyType = UIReturnKeySearch;
    txtSearchWord.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    txtSearchWord.delegate = self;
    [_popImageView addSubview:txtSearchWord];
    
//    btnDelInputText = [UIUtil newImageButtonWithFrame:CGRectZero image:nil target:self action:@selector(delinput)];
//    [_popImageView addSubview:btnDelInputText];
    lblResultHint = [[UILabel alloc] initWithFrame:CGRectZero];
    lblResultHint.backgroundColor = [UIColor clearColor];
    [_popImageView addSubview:lblResultHint];
//    scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(68, 95, 900, 600)];
//    scrollView.showsHorizontalScrollIndicator = NO;
//    scrollView.pagingEnabled = YES;
//    [self addSubview:scrollView];
    
    _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    _tableView.rowHeight = 93;
    _tableView.delegate = self;
    _tableView.dataSource = self;
    [_popImageView addSubview:_tableView];
//    recognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(gotoArticle:)];
    
    [UIUtil addAnimationShow:_popImageView];
}

- (void) layoutSubviews{
//    if([UIUtil currentOrientation]==0){
//        _bgImageView.image = [UIImage imageNamedNocache:@"bg_pop_v.png"];
        _popImageView.image = [UIImage imageNamedNocache:@"pop_search_v.png"];
        _popImageView.frame = CGRectMake(30, 35, 708, 943);
        
//        background.image = [UIImage imageNamedNocache:@"bg_search_index_v.png"];
//        btnBack.frame = CGRectMake(62, 45, 72, 37);
//        btnSearch.frame = CGRectMake(147, 45, 72, 37);
        
        txtSearchWord.frame = CGRectMake(68, 72, 610, 32);
//        btnDelInputText.frame = CGRectMake(656, 76, 31, 28);
        lblResultHint.frame = CGRectMake(40, 113, 660, 30);
        //scrollView.frame = CGRectMake(53, 184, 660, 840);
        _tableView.frame = CGRectMake(40, 150, 632, 764);
        _indicatorView.frame = CGRectMake(200, 19, 20, 20);//667
        //scrollView.contentSize = CGSizeMake(660, _tableView.height);
//    }else{
//        _bgImageView.image = [UIImage imageNamedNocache:@"bg_pop_h.png"];
//        _popImageView.image = [UIImage imageNamedNocache:@"pop_search_h.png"];
//        _popImageView.frame = CGRectMake(36, 30, 951, 696);
//        
////        background.image = [UIImage imageNamedNocache:@"bg_search_index_h.png"];
////        btnBack.frame = CGRectMake(77, 38, 72, 37);
////        btnSearch.frame = CGRectMake(163, 38, 72, 37);
//        
//        txtSearchWord.frame = CGRectMake(68, 72, 848, 32);
////        btnDelInputText.frame = CGRectMake(859, 73, 31, 30);
//        lblResultHint.frame = CGRectMake(40, 110, 871, 30);
//        //scrollView.frame = CGRectMake(76, 179, 871, 520);
//        _tableView.frame = CGRectMake(40, 149, 872, 520);
//        _indicatorView.frame = CGRectMake(222, 17, 20, 20);//894
//        //scrollView.contentSize = CGSizeMake(900, _tableView.height);
//    }
}

#pragma mark - UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if(textField == txtSearchWord){
        [txtSearchWord resignFirstResponder];
        [self doSearch];
    }
    return YES;
}
#pragma mark - actions
- (void)searching:(NSInteger)page {
    [_request cancel];
    [_request release];
    
    //_request = [[KSUrlRequest alloc] initWithUrl:STR_FORMAT(SEARCH_URL, [KSUrlRequest encodeURL:txtSearchWord.text], page, @"")];
    _request = [[KSUrlRequest alloc] initWithUrl:SERVER_URL(@"/search/%@/0/%@/%d/%@",MAGZINE_TYPE,[KSUrlRequest encodeURL:txtSearchWord.text],page,@"")];
    //SERVER_URL(@"/search/%@/%d/%@/%d")
    _request.delegate = self;
    _request.asyn = YES;
    [_request start];
}
- (void) doSearch{
    if(txtSearchWord.text == nil || ![txtSearchWord.text length]) return;
    //[self cancelAllImageDownloads];
    //_imageDownloadsInProgress = [[NSMutableDictionary dictionaryWithCapacity:20] retain];
    _page = 1;
    [self searching:_page];
} 

- (void) delinput{
    txtSearchWord.text = @"";
}
-(void)loadMore {
    UIActivityIndicatorView	*activiter = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
	[activiter startAnimating];
	
	NSInteger lastRow = [_entries count];
	NSIndexPath *lastIndexPath = [NSIndexPath indexPathForRow:lastRow inSection:0];
	[_tableView scrollToRowAtIndexPath:lastIndexPath atScrollPosition:UITableViewScrollPositionBottom animated:NO];
	[_tableView cellForRowAtIndexPath:lastIndexPath].textLabel.text = @"加载中...";
	[[_tableView cellForRowAtIndexPath:lastIndexPath] addSubview:activiter];
    
    activiter.frame = CGRectMake(ceilf(_tableView.width/2)-70, [_tableView cellForRowAtIndexPath:lastIndexPath].height/2-10, 20, 20);
	[activiter release];
    
    _loadingMore = YES;
    
    [self searching:_page+1];
}
//- (void) gotoArticle:(UIGestureRecognizer *)ges{
//    NSInteger row = [ges.view tag] - 100000;
//    KSModelSearchItem *item = [entries objectAtIndex:row];
//    NSLog(@"%@", item);
//    [_handler gotoArticle:item.articleId magzineId:item.magzineId from:@"search"];
//}
#pragma mark - KSUrlRequestDelegate
- (void)onRequestStart:(KSUrlRequest *)request{
    _indicatorView.hidden = NO; 
    [_indicatorView startAnimating];
    
    //RELEASE_SAFELY(entries);
    //lblResultHint.text = @"";
    //[_tableView reloadData];
}

- (void)onRequestSuccess:(KSUrlRequest *)request{
    [_indicatorView stopAnimating], _indicatorView.hidden = YES;
    NSDictionary *resultDict = [request resultDict];
    //NSLog(@"%@", resultDict);
    _page = DICT_INTVAL(resultDict, @"page");
    _pageSize = DICT_INTVAL(resultDict, @"pageSize");
    _totalPage = DICT_INTVAL(resultDict, @"totalPage");
    _totalRecord = DICT_INTVAL(resultDict, @"totalRecord");
    _hasMorePage = _totalPage > _page;
    _page = _page < 1?1:_page;
    _loadingMore = NO;
    //第1页数据显示时应将之前的数据清空
    if (_page <= 1) {
        [_entries removeAllObjects];
    }
    //entries = [[NSMutableArray arrayWithCapacity:20] retain];
    NSArray *arr = [resultDict valueForKey:@"list"];
    for (NSDictionary *dict in arr) {
        KSModelSearchItem *item = [KSModelSearchItem searchItemWith:dict];
        [_entries addObject:item];
    }
    lblResultHint.text = [NSString stringWithFormat:@"您搜索 %@ 获得大约 %d 条结果，以下是 %d 条", txtSearchWord.text, _totalRecord, [_entries count]];
    [_tableView reloadData];
}

- (void)onRequestFail:(KSUrlRequest *)request{
    KSDERROR(@"%@", request.error);
    [_indicatorView stopAnimating], _indicatorView.hidden = YES;
    [UIUtil showMsgAlertWithTitle:@"提示" message:[KSUrlRequest networkErrorMessage:request.error]];
}

#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == [_entries count]) {
        return 45.0f;
    }
    return 116.0;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == [_entries count]) {
        if (!_loadingMore) {
            [self loadMore];
        }
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
        return;
    } else {
        KSModelSearchItem *item = [_entries objectAtIndex:indexPath.row];
        _selectMagazineId = item.magzineId;
        if (item.lock) {
            _currentMagazineId = item.magzineId;
//            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"您没有权限阅读该文章" message:@"若您已订阅或已获赠该杂志，您可以在设置中恢复购买及登录财新网帐号以获得阅读权限，您也可以立即购买该本杂志。" delegate:self cancelButtonTitle:@"立即购买" otherButtonTitles:@"取消",nil];
//            [alertView show];
//            [alertView release];
            [(KSMagzineViewController *)self.viewController showNoPermissionView:[KSModelMagzine loadById:_currentMagazineId] delegate:self];
        }else {
            KSModelMagzine *m = [KSModelMagzine loadById:item.magzineId];
            if (!m.isArticlesDownload) {
                UIAlertView *downloadAlert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"该内容所属期刊并未下载，请选择\n" delegate:self cancelButtonTitle:@"下载" otherButtonTitles:@"取消", nil];
                downloadAlert.tag = 123;
                [downloadAlert show];
                [downloadAlert release];
//                NSArray *array = [[NSArray alloc] initWithObjects:@"取消", nil];
//                [UIUtil showMsgAlertWithDelegate:self Title:nil message:@"该内容所属期刊并未下载，请选择" cancelButtonTitle:@"下载" otherButtonTitles:array];
//                [array release];
//                [UIUtil showMsgAlertWithTitle:@"不能阅读该文章" message:@"您没有下载该本杂志。"];
            } else {
                [_handler gotoArticle:item.articleId magzineId:item.magzineId from:@"search"];
            }
        }
        
    }
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}
#pragma mark -
#pragma mark Table view creation (UITableViewDataSource)

// customize the number of rows in the table view
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	if (_hasMorePage) {
        return [_entries count]+1;
    }else return [_entries count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == [_entries count] && _hasMorePage) {
        UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
        cell.textLabel.textAlignment = UITextAlignmentCenter;
        cell.textLabel.font = [UIFont fontWithName:@"Georgia-Italic" size:14];
        cell.textLabel.text = @"加载更多...";
        return [cell autorelease];
    }
	static NSString *CellIdentifier = @"SearchTableCell";
    KSSearchTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[KSSearchTableViewCell alloc] initWithSearchItem:[_entries objectAtIndex:indexPath.row] reuseIdentifier:CellIdentifier] autorelease];
    }
    cell.searchItem = [_entries objectAtIndex:indexPath.row];
    
    return cell;
    
}

#pragma mark - UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex 
{

    if (alertView.tag == 123)
    {
        if (buttonIndex == 0)
        {
            [_handler downloadTheMagazineWithId:_selectMagazineId];
            [_handler showView:@"downladoMagazine"];
        }
    }
    else 
    {
        if (buttonIndex == 0)
        {
            KSModelMagzine *m = [KSModelMagzine loadById:_currentMagazineId];
            if (!m.isMybook) {
                [KSBootstrap listen:NOTIFY_PURCHASE_COMPLETED target:self selector:@selector(magazinePuchased:)];
                [KSAppStoreProxy buy:m fromView:self];
            }
        }

    }
}
#pragma mark -
- (void)magazinePuchased:(NSNotification *)notify {
    NSDictionary *userInfo = [notify userInfo];
    NSString *type = [userInfo valueForKey:@"type"];
    if([@"buy" isEqualToString:type]){
        [self doSearch];
        [UIUtil showMsgAlertWithTitle:@"购买成功" message:@"您可重新搜索数据"];
    }
    [KSBootstrap unlisten:self];
}
#pragma mark - KSNoPermissionAlertViewDelegate
- (void)afterDoBuy:(KSNoPermissionAlertView *)alertView {
    [self doSearch];
    [UIUtil showMsgAlertWithTitle:@"购买成功" message:@"您可重新搜索数据"];
    [(KSMagzineViewController *)self.viewController dismissNoPermissionView];
}
@end