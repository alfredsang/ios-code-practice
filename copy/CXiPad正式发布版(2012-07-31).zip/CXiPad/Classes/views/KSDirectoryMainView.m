//
//  KSDirectoryMainView.m
//  CenturyWeeklyV2
//
//  Created by 广亮 高 on 12-6-19.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import "KSDirectoryMainView.h"
#import "KSMagzineViewController.h"
#import "KSWebViewController.h"

@implementation KSDirectoryMainView
@synthesize catalogTabelView = _catalogTabelView;
@synthesize articleTabelView = _articleTabelView;
@synthesize controller = _controller;
@synthesize headerBarBgView = _headerBarBgView;

- (NSString *)calPubDate:(KSModelMagzine*)magazine
{
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:magazine.pubDate];
	NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
	[formatter setDateFormat:@"yyyy年"];
	NSString *year = [formatter stringFromDate:date];
    //9月26
    [formatter setDateFormat:@"MM月dd日"];
    NSString *monthAndDay = [formatter stringFromDate:date];
    NSString *str = [NSString stringWithFormat:@"%@第%@期 / %@出版 / 总第%d期 / 邮发代号：80-699",year, magazine.isSpecialIssue==0? [NSString stringWithFormat:@"%d", magazine.stageNumber]:magazine.customIssueNumber,monthAndDay,magazine.issueNumber];
	[formatter release];
	
	return str;
    
}

#define HEADER_MARGIN  18
-(void)initSubView
{
    _headerBarBgView = [[UIView alloc] initWithFrame:CGRectMake(32.5,12,700, 28)];
    [self addSubview:_headerBarBgView];
    
/*    
    UIButton *bookShelfBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    bookShelfBtn.frame = CGRectMake(0, 0, 74, 28);
    [bookShelfBtn setImage:[UIImage imageNamed:@"btn_menu_bookShelf.png"] forState:UIControlStateNormal];
    [bookShelfBtn addTarget:_controller action:@selector(backToMagzineView) forControlEvents:UIControlEventTouchUpInside];
    [_headerBarBgView addSubview:bookShelfBtn];
    
    UIButton *searchBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    searchBtn.frame = CGRectMake(bookShelfBtn.right+HEADER_MARGIN, 0, 74, 28);
    [searchBtn setBackgroundImage:[UIImage imageNamed:@"btn_menu_search.png"] forState:UIControlStateNormal];
    [searchBtn addTarget:_controller action:@selector(searchThis) forControlEvents:UIControlEventTouchUpInside];
    [_headerBarBgView addSubview:searchBtn];
    
    UIButton *helpBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    helpBtn.frame = CGRectMake(searchBtn.right+HEADER_MARGIN, 0, 74, 28);
    [helpBtn setBackgroundImage:[UIImage imageNamed:@"btn_menu_help.png"] forState:UIControlStateNormal];
    [helpBtn addTarget:_controller action:@selector(showHelp:) forControlEvents:UIControlEventTouchUpInside];
    [_headerBarBgView addSubview:helpBtn];
*/    
    _bgView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"bg_magazine.png"]];
    _bgView.size = CGSizeMake(268, 333);
    [self addSubview:_bgView];
    [_bgView release];
    
    _magazineCoverImageView = [[UIImageView alloc] initWithFrame:CGRectMake(19,16.5,230, 300)];

    UIImage *image = [UIImage imageWithContentsOfFile:_magazine.cover_2];
    if (image)
    {
        _magazineCoverImageView.image = image;
    }
    else 
    {
        _magazineCoverImageView.image = [UIImage imageNamed:@"default_cover_225_290.png"];
    }
    [_bgView addSubview:_magazineCoverImageView];
    
    
    _magazinePubdateLabel = [[UILabel alloc] init];
    _magazinePubdateLabel.size = CGSizeMake(self.width/2-25, 20);
    _magazinePubdateLabel.backgroundColor = [UIColor clearColor];
    _magazinePubdateLabel.font = PUBDATE_FONT;
    _magazinePubdateLabel.textAlignment = UITextAlignmentCenter;
    _magazinePubdateLabel.textColor = str2rgb(@"#434343");
    _magazinePubdateLabel.text = [self calPubDate:_magazine];
    [self addSubview:_magazinePubdateLabel];
    
    
    _firstCutOffImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"left_right_cut_off_line.png"]];
    _firstCutOffImageView.frame = CGRectMake(337, 0, 25, 1024);
    [self addSubview:_firstCutOffImageView];
    [_firstCutOffImageView release];
    
    _secondCutOffImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"left_right_cut_off_line.png"]];
    _secondCutOffImageView.frame = CGRectMake(690, 0, 25,1024);
    [self addSubview:_secondCutOffImageView];
    [_secondCutOffImageView release];
    
    _adCutOffImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ad_top_cut_off_line.png"]];
    _adCutOffImageView.frame = CGRectMake(0, 700, 238, 9);
    _adCutOffImageView.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin|UIViewAutoresizingFlexibleRightMargin;
    [self addSubview:_adCutOffImageView];
    [_adCutOffImageView release];
    
    

    
    
    _articleTabelView = [[KSArticleListTabelView alloc] initWithFrame:CGRectMake(self.width/2+25, 0, self.width/2-25, self.height) magazine:_magazine hander:self];
    //    [_articleTabelView reloadData:_magazine.magzineId];
    [self addSubview:_articleTabelView];
    
    _catalogTabelView = [[KSCatalogTableView alloc] initWithFrame:CGRectMake(_headerBarBgView.left, _magazinePubdateLabel.bottom, self.width/2-25, self.height-(_magazinePubdateLabel.bottom)) magazine:_magazine hander:self];
    [_catalogTabelView reloadData:_magazine.magzineId];
    [self addSubview:_catalogTabelView];
    
    


    _adImageView = [UIButton buttonWithType:UIButtonTypeCustom];
    UIImage *adImage = [UIImage imageWithContentsOfFile:_magazine.adPic];
    if (!adImage)
    {
        adImage = [UIImage imageNamed:@"ad_03_02.png"];
    }
    [_adImageView setBackgroundImage:adImage forState:UIControlStateNormal];
    [_adImageView addTarget:self action:@selector(showAdWebView) forControlEvents:UIControlEventTouchUpInside];
    _adImageView.frame = CGRectZero;
    [self addSubview:_adImageView];
    
//    UITapGestureRecognizer *tag = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(showAdWebView)];
//    [_adImageView addGestureRecognizer:tag];
//    [tag release];
}

- (id)initWithFrame:(CGRect)frame magazine:(NSInteger)magazineId controller:(id)controller
{
    self = [super initWithFrame:frame];
    if (self) 
    {
        _magazine = [[KSModelMagzine loadById:magazineId] retain];
        _controller = [controller retain];
        [self initSubView];
    }
    return self;
}
-(void)layoutSubviews
{

    if ([UIUtil currentOrientation]==0) 
    {
        _bgView.top = _headerBarBgView.bottom+21;
        _bgView.left = 57;
        _magazinePubdateLabel.top = _bgView.bottom;
        _magazinePubdateLabel.centerX = _bgView.centerX;
        _catalogTabelView.frame = CGRectMake(28.5,
                                             _magazinePubdateLabel.bottom+22, 
                                             325+20, 
                                             self.height-(_magazinePubdateLabel.bottom+22));
        _adCutOffImageView.hidden = NO;
        _adCutOffImageView.width = self.width/2;
        _adCutOffImageView.bottom = self.height-277;
        _adCutOffImageView.right = self.width;
        _adImageView.frame = CGRectMake(0, 0, 285, 197);
        _adImageView.bottom = self.height-40;
        _adImageView.right = self.width-51;
//        _adImageView.hidden = YES;
        _firstCutOffImageView.centerX = self.width/2+10;
        _secondCutOffImageView.hidden = YES;
        _articleTabelView.frame = CGRectMake(self.width/2+51.5,
                                             0, 
                                             283+50, 
                                             _adCutOffImageView.top);
        
    }
    else
    {
        _bgView.top = _headerBarBgView.bottom+10;
        _bgView.centerX = 337/2;
        _magazinePubdateLabel.top = _bgView.bottom;
        _magazinePubdateLabel.centerX = 337/2;
        _adCutOffImageView.hidden = NO;
        _adCutOffImageView.bottom = self.height-265;
        _adCutOffImageView.width = 337;
        _adCutOffImageView.left = 0;
        
//        _adImageView.hidden = NO;
        _adImageView.frame = CGRectMake(52.5, _adCutOffImageView.bottom+52.5, 230, 159);
        _firstCutOffImageView.left = 337;
        _secondCutOffImageView.hidden = NO;
        _catalogTabelView.frame = CGRectMake(350 ,
                                             0, 
                                             325+12, 
                                             self.height);
        _articleTabelView.frame = CGRectMake(715,
                                             0, 
                                             283+25, 
                                             self.height);
    }
//    _articleTabelView.right = self.width-25;
}

-(void)showAdWebView
{
    if ([_magazine.adUrl isKindOfClass:[NSNull class]]||[_magazine.adPic isKindOfClass:[NSNull class]])
    {
        return;
    }
//    [KSWebViewController presentWithURL:@"www.baidu.com" inController:self.viewController];

//    if (_magazine.adUrl && ![_magazine.adUrl isEqualToString:@""]) 
//    {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:_magazine.adUrl]];

//    }
}
-(void)showHeaderBar
{
    [UIView animateWithDuration:0.5 animations:^{
        _headerBarBgView.top = 12;

    }];
}
-(void)hiddenHeaderBar
{
    [UIView animateWithDuration:0.5 animations:^{
        _headerBarBgView.bottom = 0;

    }];
}
-(void)dealloc
{
    RELEASE_SAFELY(_catalogTabelView);
    RELEASE_SAFELY(_articleTabelView);
    RELEASE_SAFELY(_magazine);
    RELEASE_SAFELY(_controller);
    RELEASE_SAFELY(_headerBarBgView);
    RELEASE_SAFELY(_bgView);
//    RELEASE_SAFELY(_adImageView);
    RELEASE_SAFELY(_magazineCoverImageView);
    RELEASE_SAFELY(_magazinePubdateLabel);
    [super dealloc];
}



@end
