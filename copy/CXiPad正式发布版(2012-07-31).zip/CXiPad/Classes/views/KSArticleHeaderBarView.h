//
//  KSArticleHeaderBarView.h
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSViewInitor.h"
#import "KSModelArticle.h"
//#import "KSArticleViewController.h"

@class KSArticleViewController;
@interface KSArticleHeaderBarView : UIView<KSViewInitor>{
    KSArticleViewController *_handler;
    KSModelArticle *currentArticle;
    UIButton *btnCatalog;
    UIButton *btnBack;
    UIButton *btnComment;
    UIButton *btnShare;
    UIButton *btnCollect;
    UIButton *btnSearch;
    UIButton *btnHelp;
    UIButton *btnPizhu;
    UIButton *btnBluePen;
    UIButton *btnRedPen;
    UIButton *btnMarkPen;
    UIButton *btnErase;
    UIButton *btnBookmark;
    
    UIButton *btnDecreaseFont;
    UIButton *btnIncreaseFont;
    UIButton *btnDefaultFont;
}
@property(nonatomic,readonly)UIButton *btnShare;

- (id) initWithFrame:(CGRect)frame handler:(KSArticleViewController*)handler;
- (void) refresh;
- (void)changeCollectState:(BOOL)st;
@end
