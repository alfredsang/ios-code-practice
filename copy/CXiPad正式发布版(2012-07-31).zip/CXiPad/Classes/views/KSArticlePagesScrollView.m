//
//  KSArticlePagesScrollView.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 12-1-9.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import "KSArticlePagesScrollView.h"

@implementation KSArticlePagesScrollView
- (id)initWithFrame:(CGRect)frame handler:(KSArticleViewController *)handler{
    if(self = [super initWithFrame:frame]){
        _handler = handler;
        self.backgroundColor = [UIColor clearColor];
        [self initSubviews];
    }
    return self;
}
- (void)dealloc{
    RELEASE_SAFELY(scrollView);
    [super dealloc];
}

- (void)initSubviews{
    scrollView = [[UIScrollView alloc] initWithFrame:self.bounds];
    scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    scrollView.pagingEnabled = YES;
    scrollView.bounces = NO;
    scrollView.delegate = self;
    [self addSubview:scrollView];
    
    UIPanGestureRecognizer *doubleSwipGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(doubleSwipped:)];
    doubleSwipGesture.maximumNumberOfTouches = 2;
    doubleSwipGesture.minimumNumberOfTouches = 2;
    //UISwipeGestureRecognizer *doubleSwipGesture = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(doubleSwipped:)];
    //doubleSwipGesture.numberOfTouchesRequired = 2;
    doubleSwipGesture.delegate = self;
    [self addGestureRecognizer:doubleSwipGesture];
    [doubleSwipGesture release];
    
}
- (void)doLayoutsubviews {
    _roating = YES;
    self.superview.userInteractionEnabled = NO;
    scrollView.contentSize = CGSizeMake(scrollView.width*_pageNum, scrollView.height);
    scrollView.contentOffset = CGPointMake(scrollView.width*_current, 0);
    NSArray *subviews = [scrollView subviews];
    for (UIView *view in subviews) {
        if([view conformsToProtocol:@protocol(KSArticleIndexable)]){
            id<KSArticleIndexable> indexableView = (id<KSArticleIndexable>)view;
            NSInteger index = [indexableView getIndex];
            view.left = scrollView.width*index;
        }
    }
    self.superview.userInteractionEnabled = YES;
    _roating = NO;
}
- (void)layoutSubviews{
    IF_PRE_IOS5(if (_scrolling) return;);
    self.superview.userInteractionEnabled = NO;
    _roating = YES;
    if (_scrolling) {
        [self performSelector:@selector(doLayoutsubviews) withObject:nil afterDelay:0.1];
        return;
    }
    [self doLayoutsubviews];
}

#pragma mark UIScrollViewDelegate
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    if (_roating) {
        return;
    }
    _scrolling = YES;
}
- (void)scrollViewDidEndDecelerating:(UIScrollView *)sender{
    if (_roating) {
        return;
    }
	CGFloat pageWidth = self.width;
	int page = floor((scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
	
	if( page==_current)
		return;
    [_handler gotoPageWithIndex:page];
    _scrolling = NO;
}

- (void)loadPages:(NSArray *)pages current:(NSInteger)current{
    [scrollView removeAllSubviews];
    int iteration = 0, currentPage = _current = current;
    _pageNum = pages.count;
    int width = self.width;//[UIUtil currentOrientation]>=0?768:1024;
    int height = self.height;//[UIUtil currentOrientation]>=0?1024:768;
    BOOL isFreeMagzine = [[_handler currentMagzine] isMybook];
    for (KSModelArticle *article in pages) {
        CGRect currentFrame = CGRectMake(width * iteration, 0, width, height);
        if(currentPage==iteration){
            if(!article.isDownload){
                KSArticleDownloadingView *downloadView = [[KSArticleDownloadingView alloc] initWithFrame:currentFrame index:iteration];
                downloadView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
                downloadView.tag = 9000;
                [scrollView addSubview:downloadView];
                [downloadView release];
            }
            else if(!isFreeMagzine&&!article.isFree){
                KSArticleUnpurchasedView *unpurchasedView = [[KSArticleUnpurchasedView alloc] initWithFrame:currentFrame index:iteration];
                unpurchasedView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
                [scrollView addSubview:unpurchasedView];
                [unpurchasedView release];
            }
            else if(article.isHtml){
                KSArticleWebView *webView = [[KSArticleWebView alloc] initWithFrame:currentFrame article:article hanlder:_handler index:iteration];
                webView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
                [scrollView addSubview:webView];
                [webView release];
            }
            else{
                KSArticleCoreTextView *coretextView = [[KSArticleCoreTextView alloc] initWithFrame:currentFrame article:article handler:_handler index:iteration];
                coretextView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
                [scrollView addSubview:coretextView];
                [coretextView release];
            }
        }
        else if(currentPage==iteration-1||currentPage==iteration+1){
            KSArticleEmptyPageView *empty = [[KSArticleEmptyPageView alloc] initWithFrame:currentFrame index:iteration];
            empty.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
            [scrollView addSubview:empty];
            [empty release];
        }
        iteration++;
    }
    scrollView.contentSize = CGSizeMake(width*iteration, height);
    scrollView.contentOffset = CGPointMake(width*currentPage, 0);
    [self setNeedsLayout];
}
#pragma mark -
- (KSArticleCoreTextView *)articleCoreTextView {
    for (KSArticleCoreTextView *v in [scrollView subviews]) {
        if ([v isKindOfClass:[KSArticleCoreTextView class]]) {
            return v;
        }
    }
    return nil;
}
#pragma mark -
- (void)doubleSwipped:(UIPanGestureRecognizer *)gesture {
    if (gesture.state == UIGestureRecognizerStateBegan) {
        scrollView.scrollEnabled = NO;
    } else if(gesture.state == UIGestureRecognizerStateChanged){
        CGPoint p = [gesture translationInView:gesture.view];
        if (p.x < 0)
            _shouldGoNext = YES;
        else
            _shouldGoNext = NO;
    } else if(gesture.state == UIGestureRecognizerStateEnded) {
        //[self performSelector:@selector(didDoubleSwipped) withObject:nil afterDelay:0];
        scrollView.scrollEnabled = YES;
        if (_shouldGoNext) {
            [_handler gotoNextPage];
        } else {
            [_handler gotoPrevPage];
        }
    }
}

#pragma mark - UIGestureRecognizerDelegate
- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer {
    return YES;
}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer{
    return YES;
}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch{
    return YES;
}
@end
