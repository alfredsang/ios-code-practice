//
//  KSNotificationSettingView.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-7.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSSettingNotificationView.h"
#import "KSSettingView.h"

@implementation KSSettingNotificationView
@synthesize parent = _parent;

- (void)loadSubviews {
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(60, 48, 160, 33)];
    label.backgroundColor = [UIColor clearColor];
    label.tag = 1010;
    label.text = @"财新推送内容设置";
    label.font = [UIFont boldSystemFontOfSize:18.0f];
    [self addSubview:label];
    [label release];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(60, 48, 160, 33)];
    label.backgroundColor = [UIColor clearColor];
    label.tag = 1011;
    label.text = @"重要新闻推送";
    [self addSubview:label];
    [label release];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(60, 48, 160, 33)];
    label.backgroundColor = [UIColor clearColor];
    label.tag = 1012;
    label.text = @"新刊提醒";
    [self addSubview:label];
    [label release];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(60, 48, 160, 33)];
    label.backgroundColor = [UIColor clearColor];
    label.tag = 1013;
    label.text = @"推送时间";
    [self addSubview:label];
    [label release];
    
    UISwitch *s = [[UISwitch alloc] initWithFrame:CGRectMake(172, 102, 80, 27)];
    s.on = _shouldPushNews;
    s.tag = 1020;
    [self addSubview:s];
    [s addTarget:self action:@selector(change:) forControlEvents:UIControlEventTouchUpInside];
    [s release];
    
    s = [[UISwitch alloc] initWithFrame:CGRectMake(172, 141, 80, 27)];
    s.on = _shouldPushMagazine;
    s.tag = 1021;
    [self addSubview:s];
    [s addTarget:self action:@selector(change:) forControlEvents:UIControlEventTouchUpInside];
    [s release];
    
    UIPickerView *datePicker = [[UIPickerView alloc] initWithFrame:CGRectMake(161, 256, 263, 180)];
    datePicker.tag = 1040;
    datePicker.showsSelectionIndicator = YES;
    datePicker.delegate = self;
    datePicker.dataSource = self;
    [self addSubview:datePicker];
    [datePicker release];
    
    [datePicker selectRow:_beginTime inComponent:0 animated:NO];
    [datePicker selectRow:_endTime-_beginTime-1 inComponent:1 animated:NO];
    
    [self viewWithTag:1010].frame = CGRectMake(30, 48, 162, 33);
    
    [self viewWithTag:1011].frame = CGRectMake(30, 99, 104, 33);
    [self viewWithTag:1012].frame = CGRectMake(30, 148, 104, 33);   //新刊提醒
    [self viewWithTag:1013].frame = CGRectMake(30, 200, 104, 33);   //推送时间
    
    [self viewWithTag:1020].frame = CGRectMake(142, 102, 80, 27);   //新闻开关
    [self viewWithTag:1021].frame = CGRectMake(142, 151, 80, 27);   //新刊开关
    
    [self viewWithTag:1040].centerX = self.bounds.size.width/2;
    
}
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        _beginTime = [[KSDB stringForKey:PUSH_START_HOUR] intValue];
        _endTime = [[KSDB stringForKey:PUSH_END_HOUR] intValue];
        _shouldPushNews = YES;
        _shouldPushMagazine = YES;
        
        CXPushType type = [[KSDB stringForKey:PUSH_TYPE] intValue];
        if (type != -1 && ((type & cXPushTypeNews) != cXPushTypeNews)) {
            _shouldPushNews = NO;
        }
        if (type != -1 && ((type & cXPushTypeMagazine) != cXPushTypeMagazine)) {
            _shouldPushMagazine = NO;
        }
        [self loadSubviews];
    }
    return self;
}
- (void)change:(id)sender {
    UISwitch *s = (UISwitch *)[self viewWithTag:1020];
    UISwitch *s1 = (UISwitch *)[self viewWithTag:1021];
    
    CXPushType pushType = cXPushTypeNone|cxPushTypeUpMagazine;
    if (s.on) {
        pushType = pushType|cXPushTypeNews;
        _shouldPushNews = YES;
    } else {
        _shouldPushNews=NO;
    }
    if (s1.on) {
        _shouldPushMagazine = YES;
        pushType = pushType|cXPushTypeMagazine;
    } else {
        _shouldPushNews=NO;
    }
    [KSDB saveString:STR_FORMAT(@"%d", pushType) forKey:PUSH_TYPE];
    
    _parent.shouldUpdatePush = YES;
}
- (void)layoutSubviews {
//    if ([UIUtil currentOrientation] == 0) {
    //UIPickerView
        
//    } else {
//        [self viewWithTag:1010].frame = CGRectMake(60, 48, 160, 33);
//        
//        [self viewWithTag:1011].frame = CGRectMake(60, 99, 104, 33);
//        [self viewWithTag:1012].frame = CGRectMake(60, 148, 104, 33);   //新刊提醒
//        [self viewWithTag:1013].frame = CGRectMake(60, 306, 104, 33);   //推送时间
//        
//        [self viewWithTag:1020].frame = CGRectMake(172, 102, 80, 27);   //新闻开关
//        [self viewWithTag:1021].frame = CGRectMake(172, 151, 80, 27);   //新刊开关
//        
//        [self viewWithTag:1040].frame = CGRectMake(172, 236, 460, 180);    //UIPickerView
//    }
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

#pragma mark - UIPickerViewDataSource
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 2;
}

// returns the # of rows in each component..
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    if (component == 0) {
        return 24;
    } else if (component == 1) {
        return  24 - _beginTime;
    }
    return 0;
}
#pragma mark - UIPickerViewDelegate
- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component {
//    if ([UIUtil currentOrientation] == 0) {
        return 120;
//    } else {
//        return 215;
//    }
    
}
//- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component {
//    
//}

// these methods return either a plain UIString, or a view (e.g UILabel) to display the row for the component.
// for the view versions, we cache any hidden and thus unused views and pass them back for reuse. 
// If you return back a different object, the old one will be released. the view will be centered in the row rect  
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    NSInteger ret = row;
    if (component == 0) {
        
    } else {
        ret = _beginTime+row+1;
    }
    return [NSString stringWithFormat:@"%d:00",ret];
}
//- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view {
//    
//}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    if (component == 0) {
        _beginTime = row;
        [pickerView reloadComponent:1];
        if (_endTime <= _beginTime) {
            _endTime = _beginTime+1;
        } else {
            [pickerView selectRow:(_endTime-_beginTime-1) inComponent:1 animated:NO];
        }
    } else {
        _endTime = row + _beginTime+1;
    }
    _parent.shouldUpdatePush = YES;
    [KSDB saveString:STR_FORMAT(@"%d", _beginTime) forKey:PUSH_START_HOUR];
    [KSDB saveString:STR_FORMAT(@"%d", _endTime) forKey:PUSH_END_HOUR];
//    ((UITextField *)[self viewWithTag:1030]).text = [NSString stringWithFormat:@"%d:00 - %d:00", _beginTime, _endTime];
}

@end
