//
//  KSDirectoryListView.h
//  CenturyWeeklyV2
//
//  Created by 广亮 高 on 12-6-19.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSArticleListTabelView.h"
#import "KSCatalogTableView.h"

#define CONTENT_COLOR   str2rgb(@"#424242")


@class KSArticleViewController;
@interface KSDirectoryListView : UIView<UITableViewDelegate,UITableViewDataSource>
{
    @private
    UITableView *_theTableView;
    NSMutableArray *_titleArray;
    NSMutableArray  *_catalogArray;
    NSMutableArray  *_visialeArticles;
    KSArticleViewController *_hander;
    UIImageView *_tableViewBg;
}
@property(nonatomic,assign) BOOL ToolBarStatus;

- (id)initWithFrame:(CGRect)frame magazineId:(NSInteger)magazineId hander:(id)hander;
-(void)reloadDataSourceWith:(NSInteger)magazineId;
-(void)hiddenTableView;
-(void)showTableViewWithArticleId:(NSInteger)articleId;
-(void)selectCatalog:(UIButton*)btn;
@end
