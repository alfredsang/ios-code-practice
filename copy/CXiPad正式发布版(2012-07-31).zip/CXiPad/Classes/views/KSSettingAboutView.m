//
//  KSAboutView.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-7.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSSettingAboutView.h"
#import "KSWebViewController.h"

@implementation KSSettingAboutView

- (void)dealloc {
    [_scrollView release];
//    [_imageView release];
    [_appRecommendView release];
    [_aboutHtmlStr release];
    _webView.delegate = nil;
    [_webView stopLoading];
    [_webView release];
    
    [super dealloc];
}
- (void)initSubviews {
    //_imageView = [[UIImageView alloc] initWithFrame:CGRectZero];
    _scrollView = [[UIScrollView alloc] initWithFrame:self.bounds];
//    _scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    [self addSubview:_scrollView];
    [_scrollView addSubview:_imageView];
    
    _webView = [[UIWebView alloc] initWithFrame:self.bounds];
    _aboutHtmlStr = [[NSString alloc] initWithData:[NSData dataWithContentsOfFile:KSPathForBundleResource(@"about.html")] encoding:NSUTF8StringEncoding];
    
    //[_scrollView addSubview:_webView];
    _webView.backgroundColor = [UIColor clearColor];
    ((UIScrollView *)[[_webView subviews] objectAtIndex:0]).scrollEnabled = NO;
    _webView.delegate = self;
    
    if (!_appRecommendView) {
        NSArray *views = [[NSBundle mainBundle] loadNibNamed:@"KSAppRecommendView" owner:self options:nil];
        _appRecommendView = [[views objectAtIndex:0] retain];
        _appRecommendView.frame = CGRectMake(312, 68, 412, 450); //= [[KSAppRecommendView alloc] initWithFrame:CGRectMake(312, 68, 412, 700)];
    }
    [_scrollView addSubview:_appRecommendView];
    [_scrollView addSubview:_webView];
    
//    _imageView.image = [UIImage imageNamedNocache:@"setting_about_v.png"];
    //NSLog(@"%@", NSStringFromCGRect(_imageView.frame));
    //_imageView.frame = CGRectMake(0, 20, 401, 970);
    _webView.frame = CGRectMake(0, 20, 401, 820);
    _appRecommendView.frame = CGRectMake(0,_webView.bottom-45,_webView.width,450);
    _scrollView.contentSize = CGSizeMake(_webView.width, _appRecommendView.bottom+40);
    
    [_webView loadHTMLString:_aboutHtmlStr baseURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] bundlePath]]];
    KSDINFO(@"%@",[[_scrollView subviews] description]);
}

- (id) initWithFrame:(CGRect)frame{
    if(self = [super initWithFrame:frame]){
        self.backgroundColor = [UIColor clearColor];
        [self initSubviews];
    }
    return self;
}
- (void)layoutSubviews {
//    if ([UIUtil currentOrientation] == 0) {


//    } else {
//        _imageView.image = [UIImage imageNamedNocache:@"setting_about_h.png"];
//        //NSLog(@"%@", NSStringFromCGRect(_imageView.frame));
//        _webView.frame = CGRectMake(10, 20, 589, 750);
//        _appRecommendView.frame = CGRectMake(0,_webView.bottom-20,_webView.width,450);
//    }
   }
#pragma mark -
- (void)showService {
    [KSWebViewController presentWithURL:@"http://service.caixin.com/" inController:self.viewController];
}
- (void)showwebsite {
    [KSWebViewController presentWithURL:@"http://www.caixin.com/" inController:self.viewController];
}
- (void)sendServiceMail {
    if ([MFMailComposeViewController canSendMail]) {
        MFMailComposeViewController *mailController = [[[MFMailComposeViewController alloc] init] autorelease];
        mailController.navigationBar.barStyle = UIBarStyleDefault;
        mailController.mailComposeDelegate = self;
        [mailController setSubject:@"反馈订阅问题"];
        [mailController setToRecipients:[NSArray arrayWithObjects:@"service@caixin.com", nil]];
        [self.viewController presentModalViewController:mailController animated:YES];
    } else {
        [UIUtil showMsgAlertWithTitle:@"未配置邮箱" message:@"您可以在设置中配置好邮箱，可以直接发邮件。"];
    }
}
- (void)showCircMail {
    if ([MFMailComposeViewController canSendMail]) {
        MFMailComposeViewController *mailController = [[[MFMailComposeViewController alloc] init] autorelease];
        mailController.navigationBar.barStyle = UIBarStyleDefault;
        mailController.mailComposeDelegate = self;
        [mailController setSubject:@"反馈订阅问题"];
        [mailController setToRecipients:[NSArray arrayWithObjects:@"circ@caixin.com", nil]];
        [self.viewController presentModalViewController:mailController animated:YES];
    } else {
        [UIUtil showMsgAlertWithTitle:@"未配置邮箱" message:@"您可以在设置中配置好邮箱，可以直接发邮件。"];
    }
    
}
- (void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error {
    [self.viewController dismissModalViewControllerAnimated:YES];
}

#pragma mark - UIWebViewDelegate 
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
    NSString *requestURL = [[request URL] absoluteString];
	if( [requestURL rangeOfString:@"#showService"].length>0 ){
		[self showService];
		return NO;
	}else if( [requestURL rangeOfString:@"#sendServiceMail"].length>0 ){
		[self sendServiceMail];
		return NO;
	}else if( [requestURL rangeOfString:@"#showCircMail"].length>0 ){
		[self showCircMail];
		return NO;
	}else if( [requestURL rangeOfString:@"#showwebsite"].length>0 ){
		[self showwebsite];
		return NO;
	}
    return YES;
}

@end
