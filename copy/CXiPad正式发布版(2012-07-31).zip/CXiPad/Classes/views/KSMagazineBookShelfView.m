//
//  KSMagazineBookShelfView.m
//  CenturyWeeklyV2
//
//  Created by 广亮 高 on 12-6-11.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import "KSMagazineBookShelfView.h"
#import "KSMagzineViewController.h"
@implementation KSMagazineBookShelfView

- (id)initWithFrame:(CGRect)frame controller:(id)controller
{
    self = [super initWithFrame:frame controller:controller];
    self.backgroundColor = [UIColor colorWithPatternImage:[[UIImage imageNamed:@"book_shelf_bg.png"] stretchableImageWithLeftCapWidth:5 topCapHeight:0]];

    if (self) 
    {
        
//        year = [[NSString alloc] initWithFormat:@"%d",[[[_controller getMagazinesYear] objectAtIndex:0] intValue]];

        
//        NSMutableArray *_myMagazineArray = [[NSMutableArray alloc] init];
//
//        for (id obj in _magazinsArray)
//        {
//            if ([obj isKindOfClass:[KSModelMagzine class]])
//             {
//                 KSModelMagzine *magaz = obj;
//                 if ([magaz isMybook]) 
//                 {
//                     [_myMagazineArray addObject:magaz];
//                 }
//
//              }
//        }
//        if (_magazinsArray)
//        {
//            [_magazinsArray removeAllObjects];
//        }
//        [self selectMyMagazine:_myMagazineArray];
//        [_myMagazineArray release];
//
//        [_theTabelView reloadData];
        [self reloadData];
    }
    return self;
}
-(void)drawRect:(CGRect)rect
{
    [self reloadData];
    
}

-(void)addEmptyNull
{
    NSInteger emptyCount = 3-[_magazinsArray count]%3;
    if (emptyCount == 0 || emptyCount == 3)
    {
        return;
    }
    for(int i =0;i<emptyCount;i++)
    {
        NSNull *null = [NSNull null];
        [_magazinsArray addObject:null];
    }

}
-(void)insertEmptyNull
{
//    NSMutableArray *yearArray = [[NSMutableArray alloc] init];
//    [self existYear];
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
    for (int  i = 0; i<[_magazinsArray count]; i++)
    {
        if ([[_magazinsArray objectAtIndex:i] isKindOfClass:[KSModelMagzine class]])
        {
            KSModelMagzine *magazine = [_magazinsArray objectAtIndex:i];
            NSInteger year0 = [DateUtil getYearByDate:[NSDate dateWithTimeIntervalSince1970:magazine.pubDate]];
            for (int j= 0; j<[existYear count]; j++)
            {
                if ([[existYear objectAtIndex:j] intValue] == year0 && ![dic objectForKey:INTEGER(year0)])
                {
                    [dic setObject:INTEGER(i) forKey:INTEGER(year0)];
                }
            }

        }
    }
    for (int i = 0;i<[[dic allKeys] count];i++)
    {
        NSInteger tempIndex = [[dic objectForKey:[[dic allKeys] objectAtIndex:i]] intValue];
        NSInteger remainderCount = tempIndex%3;
        NSInteger emptyCount = 3-remainderCount;
        
        NSInteger index = tempIndex/3*3 ;
        if (remainderCount!=0)
        {
            if ([[_magazinsArray objectAtIndex:index] isKindOfClass:[NSNull class]])
            {
                for (int j = 0; j<remainderCount; j++)
                {
                    [_magazinsArray removeObjectAtIndex:index+j];
                }
                
            }
            else 
            {
                if (emptyCount>0 && emptyCount<3)
                {
                    for (int k = 0; k < emptyCount; k++) 
                    {
                        NSNull *null = [NSNull null];
                        [_magazinsArray insertObject:null atIndex:tempIndex];
                    }
                    
                }
            }

        }
    }
    
}
-(void)selectMyMagazine:(NSMutableArray*)magazineArray
{
    for (id obj in magazineArray)
    {
        if ([obj isKindOfClass:[KSModelMagzine class]])
        {
            KSModelMagzine *magaz = obj;
            if ([magaz isMybook]) 
            {
                [_magazinsArray addObject:magaz];
            }
            
        }
    }

    [self addEmptyNull];
}
- (void) whenMagzineDownloader:(NSInteger)magzineId
{
    for (int i=0; i<[_magazinsArray count]; i++) 
    {
        if ([[_magazinsArray objectAtIndex:i] isKindOfClass:[KSModelMagzine class]])
        {
            KSModelMagzine *item = [_magazinsArray objectAtIndex:i];
            if(item.magzineId ==magzineId) 
            {
                KSModelMagzine *m = [KSModelMagzine loadById:item.magzineId];
                [_magazinsArray replaceObjectAtIndex:i withObject:m];
                break;
            }

        }
    }

    

    [_theTabelView reloadData];


}


-(void)whenMagzineCancelDownload:(NSInteger)magzineId reloadData:(BOOL)isRelad
{
    for (int i=0; i<[_magazinsArray count]; i++) 
    {
        if ([[_magazinsArray objectAtIndex:i] isKindOfClass:[KSModelMagzine class]]) 
        {
            KSModelMagzine *item = [_magazinsArray objectAtIndex:i];
            if(item.magzineId ==magzineId) 
            {
                KSModelMagzine *m = [KSModelMagzine loadById:item.magzineId];
                [_magazinsArray replaceObjectAtIndex:i withObject:m];
                break;
            }
        }
        
    }

    if (isRelad)
    {
        [_theTabelView reloadData];
    }
}
- (void) whenInitOrMagzineListUpdate
{
    [self reloadData];

}
-(void)reloadData
{
    if (allYears)
    {
        RELEASE_SAFELY(allYears);
    }
    allYears = [[_controller getMagazinesYear] retain];
    if ([allYears count]==0)
    {
        return;
    }
    if (_magazinsArray)
    {
        [_magazinsArray removeAllObjects];
    }
    for (int i = 0; i<[allYears count]; i++)
    {
        NSMutableArray *magazs = [_controller loadMagazineByYear:[[allYears objectAtIndex:i] intValue]];
        [self selectMyMagazine:magazs];

    }

    
    [_theTabelView reloadData];
    
}
-(void)addExistYear:(NSInteger)currentYear
{
    BOOL find = NO;
    for (int  i = 0; i<[existYear count]; i++)
    {
        if ([[existYear objectAtIndex:i] intValue] == currentYear)
        {
            find = YES;
        }
    }
    if (find)
    {
        return;
    }

    [existYear addObject:INTEGER(currentYear)];
    if ([existYear count]>1)
    {
        for (int i = 0; i<[existYear count]-1; i++)
        {
            for (int j = i+1; j<[existYear count]; j++)
            {
                NSInteger first = [[existYear objectAtIndex:i] intValue];
                NSInteger last = [[existYear objectAtIndex:j] intValue];
                if (first<last)
                {
                    [existYear exchangeObjectAtIndex:i withObjectAtIndex:j];
                }
            }
        }

    }

}
-(void)selectYear:(NSInteger)selectYear
{
    NSInteger row = 0;
    for (int i = 0; i<[_magazinsArray count]; i++)
    {
        if ([[_magazinsArray objectAtIndex:i] isKindOfClass:[KSModelMagzine class]])
        {
            KSModelMagzine *magazine = [_magazinsArray objectAtIndex:i];
            NSDate *date = [NSDate dateWithTimeIntervalSince1970:magazine.pubDate];
            
            if ([DateUtil getYearByDate:date] == selectYear) 
            {
                row = i/3;
                break;
            }

        }
    }

    _theTabelView.contentOffset = CGPointMake(0, 280*row);
    
//    NSMutableArray *magazins = [[_controller loadMagazineByYear:selectYear] retain];
//    NSMutableArray *magazinsArray = [[NSMutableArray alloc] initWithCapacity:[magazins count]];
//
//    if ([magazins count]==0)
//    {
//        [self addExistYear:selectYear];
//        return;
//    }
//    for (id obj in magazins)
//    {
//        if ([obj isKindOfClass:[KSModelMagzine class]])
//        {
//            KSModelMagzine *magaz = obj;
//            if ([magaz isMybook]) 
//            {
//                [magazinsArray addObject:magaz];
//            }
//            
//        }
//    }
//    
//    NSInteger emptyCount = 3-[magazinsArray count]%3;
//    if (emptyCount!=0&&emptyCount!=3)
//    {
//        for(int i =0;i<emptyCount;i++)
//        {
//            NSNull *null = [NSNull null];
//            [magazinsArray addObject:null];
//        }
//
//    }
//    
//    
////    [self existYear];
//    
//    if ([existYear count] == 0)
//    {
//        [self addExistYear:selectYear];
//
//        [_magazinsArray addObjectsFromArray:magazinsArray];
//        [_theTabelView reloadData];
//        return;
//    }
//    //当前年份在已存在的年份中的位置
//    if ([existYear count]==1)
//    {
//        [self addExistYear:selectYear];
//
//        if (selectYear>[[existYear objectAtIndex:0] intValue]) 
//        {
//            [_magazinsArray insertObjects:magazinsArray atIndexes:[NSIndexSet indexSetWithIndexesInRange:NSMakeRange(0, [magazinsArray count])]];
//            [_theTabelView reloadData];
//            _theTabelView.contentOffset = CGPointMake(0, 0);
//        }
//        else 
//        {
//            _theTabelView.contentOffset = CGPointMake(0, 280*[_magazinsArray count]);
//            [_magazinsArray addObjectsFromArray:magazinsArray];
//            [_theTabelView reloadData];
//        }
//        
//        return;
//    }
//    for (int i = 0; i < [existYear count]; i++)
//    {
//        
//        if (selectYear>[[existYear objectAtIndex:0] intValue]) 
//        {
//            [self addExistYear:selectYear];
//
//            [_magazinsArray insertObjects:magazinsArray atIndexes:[NSIndexSet indexSetWithIndexesInRange:NSMakeRange(0, [magazinsArray count])]];
//            [_theTabelView reloadData];
//            _theTabelView.contentOffset = CGPointMake(0, 0);
//            return;
//        }
//        else if(selectYear<[[existYear lastObject] intValue])
//        {
//            [self addExistYear:selectYear];
//
//            _theTabelView.contentOffset = CGPointMake(0, 280*[_magazinsArray count]);
//            [_magazinsArray addObjectsFromArray:magazinsArray];
//            [_theTabelView reloadData];
//            return;
//        }
//        else 
//        {
//            for (int j = 0; j<[existYear count]-1; j++)
//            {
//                NSInteger first = [[existYear objectAtIndex:j] intValue];
//                NSInteger second = [[existYear objectAtIndex:j+1] intValue];
//                if (selectYear<first&&selectYear>second) 
//                {
//                    for (int k = 0; k<[_magazinsArray count]; k++)
//                    {
//                        if ([[_magazinsArray objectAtIndex:k] isKindOfClass:[KSModelMagzine class]])
//                        {
//                            KSModelMagzine *magazine = [_magazinsArray objectAtIndex:k];
//                            NSDate *date = [NSDate dateWithTimeIntervalSince1970:magazine.pubDate];
//                            
//                            if ([DateUtil getYearByDate:date] == second) 
//                            {
//                                [self addExistYear:selectYear];
//
//                                row = i/3;
//                                _theTabelView.contentOffset = CGPointMake(0, 280*row);
//                                [_magazinsArray addObjectsFromArray:magazinsArray];
//                                [_theTabelView   reloadData];
//                                return;
//                            }
//                            
//                        }
//                    }
//
//                }
//            }
//        }
//    }
//
//    [magazins release];
//    [magazinsArray release];
}
-(void)moreMagazine
{

    NSInteger nextYear = [year intValue]-1;
    RELEASE_SAFELY(year);
    year = [[NSString alloc] initWithFormat:@"%d",nextYear];
    if (nextYear<2010)
    {
        return ;
    }
    NSMutableArray *yearsArray = [_controller loadMagazineByYear:nextYear];
//    [_magazinsArray removeAllObjects]; 
    [self selectMyMagazine:yearsArray];
    [_theTabelView reloadData];
}
//-(void)reloadDataWithYear:(NSInteger)yearIndex
//{
//    if (year)
//    {
//        RELEASE_SAFELY(year);
//    }
//    year = [[NSString alloc] initWithFormat:@"%d",yearIndex];
//    [super reloadDataWithYear:yearIndex];
//}



-(void)editBtnPress:(UIButton*)btn
{
    if ([KSGetAllArticlesDownloader isDownloading:_magazine.magzineId])
    {
        [self downloadMagazine];
    }
    isEditModel = isEditModel?NO:YES;
    [btn setTitle:isEditModel?@"确认":@"编辑" forState:UIControlStateNormal];
    [_theTabelView reloadData];
}


-(void)whenMagzinePurchased:(NSInteger)magazineId
{
    [self reloadData];
//    KSModelMagzine *magazine = [KSModelMagzine loadById:magazineId];
//    if ([_magazinsArray count]==0)
//    {
//        [_magazinsArray addObject:magazine];
//        [self addEmptyNull];
//        [_theTabelView reloadData];
//        return;
//    }
//
//    KSModelMagzine *magaz;
//    NSInteger year0 = [DateUtil getYearByDate:[NSDate dateWithTimeIntervalSince1970:magazine.pubDate]];
//
//    //与第一个比较
//    if ([[_magazinsArray objectAtIndex:0] isKindOfClass:[KSModelMagzine class]])
//    {
//        magaz = [_magazinsArray objectAtIndex:0];
//        if (magaz.pubDate<magazine.pubDate)
//        {
//            [_magazinsArray insertObject:magazine atIndex:0];
//            if ([[_magazinsArray lastObject] isKindOfClass:[NSNull class]])
//            {
//                [_magazinsArray removeLastObject];
//            }
//
//            [self addEmptyNull];
//            [_theTabelView reloadData];
//            return;
//        }
//    }
//    
//    //与最后一个比较
//    if ([[_magazinsArray objectAtIndex:[_magazinsArray count]-1] isKindOfClass:[KSModelMagzine class]])
//    {
//        magaz = [_magazinsArray objectAtIndex:[_magazinsArray count]-1];
//        if (magaz.pubDate>magazine.pubDate)
//        {
//            [_magazinsArray addObject:magazine];
//            [self addEmptyNull];
//            [_theTabelView reloadData];
//            return;
//        }
//
//        
//    }
//     
//    //中间比较
//    for (int i = 0;i<[_magazinsArray count]-1;i++)
//    {
//        if ([[_magazinsArray objectAtIndex:i] isKindOfClass:[KSModelMagzine class]] && [[_magazinsArray objectAtIndex:i+1] isKindOfClass:[KSModelMagzine class]]) 
//        {
//            KSModelMagzine *firstMagaz = [_magazinsArray objectAtIndex:i];
//            KSModelMagzine *secMagaz = [_magazinsArray objectAtIndex:i+1];
// 
//            if (firstMagaz.pubDate>magazine.pubDate&&magazine.pubDate>secMagaz.pubDate)
//            {
//                [_magazinsArray insertObject:magazine atIndex:i+1];
//                
//                [self insertEmptyNull];
//                [_theTabelView reloadData];
//                return;
//
//            }
//
//                        
//
//        }
//        else if ([[_magazinsArray objectAtIndex:i] isKindOfClass:[KSModelMagzine class]] && [[_magazinsArray objectAtIndex:i+1] isKindOfClass:[NSNull class]])
//        {
//            NSInteger year1 = [DateUtil getYearByDate:[NSDate dateWithTimeIntervalSince1970:[[_magazinsArray objectAtIndex:i] pubDate]]];
//            if (year1 == year0)
//            {
//                [_magazinsArray replaceObjectAtIndex:i+1 withObject:magazine];
////                [self addEmptyNull];
//                [_theTabelView reloadData];
//                return;
//
//            }
//        }
//    }

    
}

-(void)reloadDataCellWithcell:(UITableViewCell*)cell  
                       counts:(NSInteger)counts
                    indexPath:(NSIndexPath*)indexPath
{

    for(int i = 0 ;i<counts;i++)
    {
        if ([[_magazinsArray objectAtIndex:[indexPath row]*3+i] isKindOfClass:[NSNull class]])
        {
            return;
        }
        KSModelMagzine *magaz = [_magazinsArray objectAtIndex:[indexPath row]*3+i];
        

//        sizeLabel.text = magaz.fileSize;
        
        UIButton *tempImageView = (UIButton*)[cell viewWithTag:100+i];
        tempImageView.userInteractionEnabled = YES;
        

        
        
        UIImageView *backImageView = (UIImageView*)[cell viewWithTag:800+i];
        
        tempImageView.top = 40;
        backImageView.top = 17;
        UILabel *pubTimeLabel = (UILabel*)[cell viewWithTag:200+i];
        pubTimeLabel.top = tempImageView.bottom+10;
        
        UILabel *sizeLabel = (UILabel*)[cell viewWithTag:900+i];
        sizeLabel.top = pubTimeLabel.bottom+10;

        
        UIButton *buyBtn = (UIButton*)[cell viewWithTag:300+i];
        UIButton *readBtn = (UIButton*)[cell viewWithTag:400+i];
        [buyBtn removeFromSuperview];
        [readBtn removeFromSuperview];

        UIButton *tagImageBtn = (UIButton*)[cell viewWithTag:500+i];
        
        
        tagImageBtn.centerY = tempImageView.top;
        tagImageBtn.userInteractionEnabled = YES;
        KSShelfProgressView *progressView = (KSShelfProgressView*)[cell viewWithTag:i+700];

        UIButton *maskImageView = (UIButton*)[tempImageView viewWithTag:600+i];
        maskImageView.userInteractionEnabled = YES;
        //未下载
        if (magaz.rateDownload>=0&&magaz.rateDownload<1 )
        {
            sizeLabel.hidden = YES;
            tagImageBtn.hidden = NO;
            [maskImageView addTarget:self action:@selector(downloadTheMagazine:) forControlEvents:UIControlEventTouchUpInside];

            if (isEditModel)
            {
                tagImageBtn.hidden = YES;

            }
            else
            {
                tagImageBtn.hidden = NO;

            }
            //下载中
            if (magaz.rateDownload!=0) 
            {
                [progressView setOriginProgress:magaz.rateDownload];
            }
            //未下载
            else 
            {
                if (isEditModel)
                {
                    maskImageView.hidden = NO;
                    [tempImageView removeTarget:self action:@selector(downloadTheMagazine:) forControlEvents:UIControlEventTouchUpInside];

                }
                else 
                {
                    [tempImageView addTarget:self action:@selector(downloadTheMagazine:) forControlEvents:UIControlEventTouchUpInside];

                }
            }

            
        }
        //已下载
        else 
        {
            if (isEditModel)
            {
                sizeLabel.hidden = NO;
                sizeLabel.text = magaz.fileSize;
            }
            else 
            {
                sizeLabel.hidden = YES;

            }

            tagImageBtn.hidden = YES;
            maskImageView.hidden = YES;
            if (isEditModel)
            {
                tagImageBtn.hidden = NO;
            }
            [tagImageBtn addTarget:self action:@selector(pressDeleteMagazineBtn:) forControlEvents:UIControlEventTouchUpInside];
             [tempImageView addTarget:self action:@selector(downloadTheMagazine:) forControlEvents:UIControlEventTouchUpInside];
        }

        
        
    }

    
}

#pragma tableView
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
//    NSInteger rows;
//
//    if ([existYear count]==[allYears count]||[year intValue]==2010)
//    {
//        rows = [_magazinsArray count]/3;
//    }
//    else 
//    {
//        rows = [_magazinsArray count]/3+1;
//    }
    return [_magazinsArray count]/3;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
//    if ([indexPath row]==[_magazinsArray count]/3)
//    {
//        return 90;
//    }
    return 280;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
//    NSInteger rows = [_magazinsArray count]/3;
//    NSInteger columns =  [_magazinsArray count]%3;

//    if ([indexPath row]==[_magazinsArray count]/3)
//    {
//        UITableViewCell *cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil] autorelease];
//        UIButton *moreBtn = [UIButton buttonWithType:UIButtonTypeCustom];
//        [moreBtn setTitleColor:BTN_HIGHT_COLOR forState:UIControlStateNormal];
//        [moreBtn.titleLabel setFont:[UIFont boldSystemFontOfSize:16]];
//        [moreBtn setBackgroundImage:[UIImage imageNamed:@"btn_more.png"] forState:UIControlStateNormal];
//        [moreBtn setTitle:@"点击下载更多" forState:UIControlStateNormal];
//        [moreBtn setFrame:CGRectMake(0, 20, 316, 50)];
//        [moreBtn addTarget:self action:@selector(moreMagazine) forControlEvents:UIControlEventTouchUpInside];
//        moreBtn.centerX = self.centerX;
//        [cell addSubview:moreBtn];
//        
//
//        return cell;
//    }
//    else 
//    {
    static NSString *identifier = @"identifier";
    UITableViewCell *cell = (UITableViewCell*)[tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil)
    {
        cell = [super tableView:tableView cellForRowAtIndexPath:indexPath];
        for (int i = 0; i<3; i++)
        {
            UIButton *imageButton = (UIButton*)[cell viewWithTag:100+i];
            
            UILabel *sizeLabel = [[UILabel alloc] init];
            sizeLabel.size = CGSizeMake(100, 15);
            sizeLabel.center = CGPointMake(imageButton.centerX, 0);
            sizeLabel.textAlignment = UITextAlignmentCenter;
            sizeLabel.backgroundColor = [UIColor clearColor];
            sizeLabel.textColor = [UIColor whiteColor];
            sizeLabel.tag = 900+i;
            [cell addSubview:sizeLabel];
            [sizeLabel release];
        }

    }
        
//        if ([indexPath row]<rows) 
//        {
//            counts = 3;
//        }
//        else 
//        {
//            counts = columns;
//        }
        [self reloadDataCellWithcell:cell counts:3 indexPath:indexPath];
        return cell;

//    }

}
-(void)pressDeleteMagazineBtn:(UIButton*)btn
{
    _deleteButton = btn;
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"是否确认删除该本杂志?" delegate:self cancelButtonTitle:@"否" otherButtonTitles:@"是", nil];
    [alert show];
    [alert release];
}
-(void)deleteMagazine:(UIButton*)btn
{

    UITableViewCell *cell = (UITableViewCell*)btn.superview;
    NSInteger indexRow = [[_theTabelView indexPathForCell:cell] row];
    KSModelMagzine *magazine = [_magazinsArray objectAtIndex:3*indexRow+(btn.tag-500)];
    [btn setImage:[UIImage imageNamed:@"download.png"] forState:UIControlStateNormal];
    [magazine remove:NO];

    magazine.downloadArticlesNumber = 0;
    magazine.isArticlesDownload = NO;
    magazine.rateDownload = 0;

    for (int i = 0;i<[_magazinsArray count];i++)
    {
        if ([[_magazinsArray objectAtIndex:i] isKindOfClass:[KSModelMagzine class]])
        {
            KSModelMagzine *magaz = [_magazinsArray objectAtIndex:i];
            if (magaz.magzineId == magazine.magzineId)
            {
                magaz.isDownload = NO;
                magaz.rateDownload = 0;
            }

        }
    }
    //如果主界面是当前杂志，需要同步更新主界面状态
    if (_controller.currentMagzine.magzineId == magazine.magzineId)
    {
        [_controller setCurrentMagzine:[KSModelMagzine loadById:magazine.magzineId]];
        [_controller.main setNeedsLayout];

    }
    [_controller whenMagzineDeleted:magazine];
    

    
}
-(void)downloadTheMagazine:(UIButton*)btn
{
    if (_lastCell)
    {
        RELEASE_SAFELY(_lastCell);
    }
    _lastCell = [_buyCell retain];
    _lastIndex = buyIndex;
    
    if (_buyCell) 
    {
        RELEASE_SAFELY(_buyCell);
    }

    if ([[btn superview] isKindOfClass:[UITableViewCell class]])
    {
        _buyCell = (UITableViewCell*)[[btn superview] retain];
        buyIndex = btn.tag - 100;

    }
    else 
    {
        
        _buyCell = (UITableViewCell*)[[[btn superview] superview] retain];
        buyIndex = btn.tag - 600;

    }
//    _buyCell = (UITableViewCell*)[[btn superview] superview];
    NSInteger cellRow = [[_theTabelView indexPathForCell:_buyCell] row];

    if (_magazine)
    {
//        NSInteger index = [_magazinsArray indexOfObject:_magazine];

        RELEASE_SAFELY(_magazine);
    }
    _magazine = [[_magazinsArray objectAtIndex:cellRow*3 + buyIndex] retain];
    
    if (!isEditModel) 
    {
        if (_magazine.isDownload)
        {
            [_controller gotoArticle:0 magzineId:_magazine.magzineId from:@"bookShelf"];
        }
        else 
        {
            [self downloadMagazine];
        }
        
        return;
    }
    else 
    {


    }


    
    
}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{ 
    return YES; 
} 
-(BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer
{
    return YES;
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 1)
    {
        [self deleteMagazine:_deleteButton];
    }
}

-(void)dealloc
{
    [super dealloc];
}

@end
