//
//  KSMagzineFooterBarView.m
//  CenturyWeekly2
//
//  Created by liuyou on 11-11-26.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "KSMagzineFooterBarView.h"
#import "KSMagzineViewController.h"

UIButton *lastBtn;


@implementation KSMagzineFooterBarView
@synthesize bookShelfBtn,bookStoreBtn;

- (id)initWithFrame:(CGRect)frame delegate:(id)delegate{
	if (self = [super initWithFrame:frame]) {
        _delegate = delegate;
//		self.backgroundColor = C_BLUE;
		self.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleTopMargin; 
        self.image = [UIImage imageNamed:@"bottom_nav_bg.png"];
        self.contentMode = UIViewContentModeScaleToFill;
        self.userInteractionEnabled = YES;
//        self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"navigation_bar_below_bg.png"]];
		[self initSubviews];
	}
	return self;
}
- (void) lightIcon:(NSString *)type{
    login.selected = NO;
    helpBt.selected = NO;
    search.selected = NO;
    setting.selected = NO;
    bookShelfBtn.selected = NO;
    bookStoreBtn.selected = NO;
    _restoreBtn.selected = NO;
    collect.selected = NO;
    if([type isEqualToString:@"helpView"]){
        helpBt.selected = YES;
        lastBtn = helpBt;
    }
    else if([type isEqualToString:@"search"]){
        search.selected = YES;
        lastBtn = search;

    }
    else if([type isEqualToString:@"setting"] || [type isEqualToString:@"account"]){
        setting.selected = YES;
        lastBtn = setting;

    }
    else if([type isEqualToString:@"bookShelf"])
    {
        bookShelfBtn.selected = YES;
        lastBtn = bookShelfBtn;

    }
    else if([type isEqualToString:@"bookStore"])
    {
        bookStoreBtn.selected = YES;
        lastBtn = bookStoreBtn;

    }
    else if([type isEqualToString:@"none"])
    {
        if ([[[_delegate.main subviews] objectAtIndex:[[_delegate.main subviews] count]-2] isKindOfClass:[KSMagazineBookShelfView class]] && [[[_delegate.main subviews] objectAtIndex:[[_delegate.main subviews] count]-2] top]!=1024)
        {
            bookShelfBtn.selected = YES;
            lastBtn = bookShelfBtn;
        }
        else
        {
            bookStoreBtn.selected = YES;
            lastBtn = bookStoreBtn;
        }
        
    }
    else if([type isEqualToString:@"restore"])
    {
        if (lastBtn)
        {
            lastBtn.selected = YES;
        }
        
    }
    else if([type isEqualToString:@"collection"])
    {
        collect.selected = YES;
    }

}

#define MARGIN_BETWEEN  30

- (void)initSubviews {
	// 收藏、搜索、设置、登录=>
    
    helpBt = [[KSStatedIconButton alloc] initWithFrame:CGRectMake(self.width-20-37, self.height-49, 37, 49) image:[UIImage imageNamedNocache:@"help_normal.png"] selectedImage:[UIImage imageNamedNocache:@"help_light.png"]  target:_delegate action:@selector(showHelpViews:)];
	helpBt.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
	[self addSubview:helpBt];
    

    //collect.layer.borderColor = [UIColor redColor].CGColor;
    //collect.layer.borderWidth = 1;
    
    search = [[KSStatedIconButton alloc] initWithFrame:CGRectMake(helpBt.left-MARGIN_BETWEEN-37, helpBt.top, 37, 49) image:[UIImage imageNamedNocache:@"search_normal.png"] selectedImage:[UIImage imageNamedNocache:@"search_light.png"]  target:_delegate action:@selector(showSearch:)];
	search.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
	[self addSubview:search];
    //search.layer.borderColor = [UIColor redColor].CGColor;
    //search.layer.borderWidth = 1;
    
    collect = [[KSStatedIconButton alloc] initWithFrame:CGRectMake(search.left-MARGIN_BETWEEN-37, self.height-49, 37, 49) image:[UIImage imageNamedNocache:@"collect_normal.png"] selectedImage:[UIImage imageNamedNocache:@"collect_light.png"]  target:_delegate action:@selector(showCollection:)];
	collect.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
	[self addSubview:collect];
    
    setting = [[KSStatedIconButton alloc] initWithFrame:CGRectMake(collect.left-MARGIN_BETWEEN-37, helpBt.top, 37, 49) image:[UIImage imageNamedNocache:@"setting_normal.png"] selectedImage:[UIImage imageNamedNocache:@"setting_light.png"]  target:_delegate action:@selector(showSetting)];
	setting.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
    [self addSubview:setting];
    //setting.layer.borderColor = [UIColor redColor].CGColor;
    //setting.layer.borderWidth = 1;
    
    login = [[KSStatedIconButton alloc] initWithFrame:CGRectMake(setting.left-MARGIN_BETWEEN-37, helpBt.top, 37, 49) image:[UIImage imageNamedNocache:@"login_normal.png"] selectedImage:[UIImage imageNamedNocache:@"login_light.png"] target:self action:@selector(showLogin)];
    login.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
    [self addSubview:login];
    
    _restoreBtn =  [[KSStatedIconButton alloc] initWithFrame:CGRectMake(setting.left-MARGIN_BETWEEN-40, helpBt.top, 40, 49) image:[UIImage imageNamedNocache:@"restore_normal.png"] selectedImage:[UIImage imageNamedNocache:@"restore_light.png"]  target:_delegate action:@selector(restorePurchases)];
	_restoreBtn.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
    [self addSubview:_restoreBtn];
    
//    bookShelfBtn =  [[KSStatedIconButton alloc] initWithFrame:CGRectMake(_restoreBtn.left-20-53, 0, 53, 44) image:[UIImage imageNamed:@"bookshelf_normal.png"] selectedImage:[UIImage imageNamed:@"bookshelf_light.png"]  target:_delegate action:@selector(showBookShelf)];
    bookShelfBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    bookShelfBtn.frame = CGRectMake(_restoreBtn.left-MARGIN_BETWEEN-37, helpBt.top, 37, 49);
    [bookShelfBtn setImage:[UIImage imageNamed:@"bookshelf_normal.png"] forState:UIControlStateNormal];
    [bookShelfBtn setImage:[UIImage imageNamed:@"bookshelf_light.png"] forState:UIControlStateSelected];
    [bookShelfBtn addTarget:_delegate action:@selector(showBookShelf) forControlEvents:UIControlEventTouchUpInside];
	bookShelfBtn.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
    [self addSubview:bookShelfBtn];
    
    bookStoreBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    bookStoreBtn.frame = CGRectMake(bookShelfBtn.left-MARGIN_BETWEEN-37, helpBt.top, 37, 49);

    [bookStoreBtn setImage:[UIImage imageNamed:@"store_normal.png"] forState:UIControlStateNormal];
    [bookStoreBtn setImage:[UIImage imageNamed:@"store_light.png"] forState:UIControlStateSelected];
    [bookStoreBtn addTarget:_delegate action:@selector(showBookStore) forControlEvents:UIControlEventTouchUpInside];
	bookStoreBtn.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
    [self addSubview:bookStoreBtn];
    
    bookStoreBtn.selected = YES;
    
//    _usernameLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 400, 40)];
//    _usernameLabel.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
//    _usernameLabel.right = collect.left - 20.0f;
//    _usernameLabel.backgroundColor = [UIColor clearColor];
//    _usernameLabel.textColor = [UIColor whiteColor];
//    _usernameLabel.font = [UIFont systemFontOfSize:16.0f];
//    //_usernameLabel.textAlignment = UITextAlignmentRight;
//    _usernameLabel.text = [KSBootstrap currentUser];
//    _usernameLabel.hidden = YES;
//    [self addSubview:_usernameLabel];
//    
//    _usernameLabel.layer.borderColor = [UIColor redColor].CGColor;
//    _usernameLabel.layer.borderWidth = 1;
    
    _usernameButton = [[UIButton alloc] initWithFrame:CGRectMake(ITEM_MARGIN/2, helpBt.top+2, 320, 40)];
    _usernameButton.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
    _usernameButton.width = bookStoreBtn.left - MARGIN_BETWEEN;
//    _usernameButton.right = bookStoreBtn.left - MARGIN_BETWEEN;
    _usernameButton.backgroundColor = [UIColor clearColor];
    [_usernameButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_usernameButton setTitleColor:[UIColor whiteColor] forState:UIControlStateHighlighted];
    _usernameButton.titleLabel.font = [UIFont systemFontOfSize:16.0f];
    _usernameButton.titleLabel.textAlignment = UITextAlignmentLeft;
    _usernameButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [_usernameButton setTitle:[KSBootstrap currentUser] forState:UIControlStateNormal];
    [_usernameButton setTitle:[KSBootstrap currentUser] forState:UIControlStateHighlighted];
    [_usernameButton addTarget:self.viewController action:@selector(showAccountView) forControlEvents:UIControlEventTouchUpInside];
    _usernameButton.hidden = YES;
    [self addSubview:_usernameButton];
    //_usernameButton.layer.borderColor = [UIColor redColor].CGColor;
    //_usernameButton.layer.borderWidth = 1;
    
    [self logstateChange];
}

- (void) layoutSubviews{
    // 登录、设置、收藏、搜索
//    if([UIUtil currentOrientation]==0){
//        helpBt.right = self.width-10;
//        search.right = helpBt.left - 20;
//        setting.right = search.left - 20;
//        login.right = setting.left - 20;
//        _restoreBtn.right = login.left - 20;
//        bookShelfBtn.right = _restoreBtn.left - 20;
////        login.left = self.width - 80*4 - 30;
////        setting.left = self.width - 80*3 - 27;
////        search.left = setting.right + 20;
////        helpBt.left = search.right + 20;
//        
//        _usernameButton.left = 20.0f;
//    }else{
//        helpBt.right = self.width-10;
//        search.right = helpBt.left - 20;
//        setting.right = search.left - 20;
//        login.right = setting.left - 20;
//        _restoreBtn.right = login.left - 20;
//        bookShelfBtn.right = _restoreBtn.left - 20;
////        login.left = self.width - 80*4 - 40;
////        setting.left = self.width - 80*3 - 33;
////        search.left = setting.right + 20;
////        helpBt.left = search.right + 20;
//        
//        _usernameButton.left = 40.0f;
//    }
//    if (login) {
//        _restoreBtn.right = login.left - 20;
//    }else {
//        _restoreBtn.right = setting.left - 20;
//    }
    //_usernameLabel.right = collect.left - 20.0f;
}
- (void) logstateChange{
    [login removeFromSuperview];
    [login release];
    login = nil;
    NSString *user = (NSString *)[_delegate getUser];
    if(user){
        //login = [UIUtil newImageButtonWithFrame:CGRectMake(setting.right + 20, 0, 67, 40) image:[UIImage imageNamedNocache:@"icon_logout_normal.png"] tappedImage:[UIImage imageNamedNocache:@"icon_logout_light.png"] target:_delegate action:@selector(logout)];
        _usernameButton.hidden = NO;
        [_usernameButton setTitle:user forState:UIControlStateNormal];
        [_usernameButton setTitle:user forState:UIControlStateHighlighted];
        _restoreBtn.right = setting.left - MARGIN_BETWEEN;
        bookShelfBtn.right = _restoreBtn.left - MARGIN_BETWEEN;
        bookStoreBtn.right = bookShelfBtn.left - MARGIN_BETWEEN;
    }else{

        login = [[KSStatedIconButton alloc] initWithFrame:CGRectMake(setting.left-MARGIN_BETWEEN-37, helpBt.top, 37, 49) image:[UIImage imageNamedNocache:@"login_normal.png"] selectedImage:[UIImage imageNamedNocache:@"login_light.png"]  target:_delegate action:@selector(showLogin)];
        _usernameButton.hidden = YES;
        _restoreBtn.right = login.left - MARGIN_BETWEEN;
        bookShelfBtn.right = _restoreBtn.left - MARGIN_BETWEEN;
        bookStoreBtn.right = bookShelfBtn.left - MARGIN_BETWEEN;
    }
//    login.layer.borderColor = [UIColor redColor].CGColor;
//    login.layer.borderWidth = 1;
	login.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
	[self addSubview:login];
}
- (void) dealloc{
    [_usernameLabel release];
    [_usernameButton release];
    [collect release];
    [search release];
    [setting release];
    [login release];
    [_restoreBtn release];
    [bookShelfBtn release];
    [super dealloc];
}
@end
