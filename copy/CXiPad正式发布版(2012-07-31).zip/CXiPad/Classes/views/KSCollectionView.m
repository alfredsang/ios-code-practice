//
//  KSCollectionView.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-12-20.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSCollectionView.h"
#import "KSMagzineViewController.h"
#import "KSCollectionTableViewCell.h"

@implementation KSCollectionView

- (void) dealloc{
//    [_bgImageView release];
    [_popImageView release];
    [_entriesArray release];
    [backgroundView release];
    [btnBack release];
    [btnMyCollection release];
    [btnEditDel release];
    [_tableView release];
    [super dealloc];
}

- (id)initWithFrame:(CGRect)frame handler:(id)handler
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageWithContentsOfFile:KSPathForBundleResource(@"book_store_bg.png")]];

        _handler = handler;
//        self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
//        self.backgroundColor = [UIColor clearColor];
        [self initSubviews];
    }
    return self;
}
- (void) initData{
    _entriesArray = [[NSMutableArray arrayWithArray:[KSModelCollectionItem collectionItems]] retain];
}

- (void) initSubviews{
    [self initData];
//    _bgImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.width, self.height)];
//    _bgImageView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
//    [self addSubview:_bgImageView];
    
    //backgroundView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.width, self.height)];
    //backgroundView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    //[self addSubview:backgroundView];
    
    _popImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamedNocache:@"pop_collect_v.png"]];
    _popImageView.frame = CGRectMake(30, 35, 708, 943);
    [self addSubview:_popImageView];
    _popImageView.userInteractionEnabled = YES;
    //_popImageView.layer.borderColor = [UIColor redColor].CGColor;
    //_popImageView.layer.borderWidth = 1;
    
    btnBack = [[UIButton alloc] initWithFrame:CGRectMake(83, 43, 57, 16)];
    [btnBack setImage:[UIImage imageNamedNocache:@"btn_back_inpanel.png"] forState:UIControlStateNormal];
    [btnBack addTarget:self action:@selector(backToMain) forControlEvents:UIControlEventTouchUpInside];
    btnBack.showsTouchWhenHighlighted = YES;
    [_popImageView addSubview:btnBack];
    
    btnMyCollection = [[UIButton alloc] initWithFrame:CGRectMake(83, 43, 57, 16)];
    [btnMyCollection setImage:[UIImage imageNamedNocache:@"lbl_collection.png"] forState:UIControlStateNormal];
    [btnMyCollection addTarget:self action:@selector(normal) forControlEvents:UIControlEventTouchUpInside];
    btnMyCollection.showsTouchWhenHighlighted = YES;
    [_popImageView addSubview:btnMyCollection];
    
    btnEditDel = [[UIButton alloc] initWithFrame:CGRectMake(83, 43, 62, 30)];
    [btnEditDel setImage:[UIImage imageNamedNocache:@"btn_fav_del.png"] forState:UIControlStateNormal];
    [btnEditDel setImage:[UIImage imageNamedNocache:@"btn_fav_del_tap.png"] forState:UIControlStateHighlighted];
    [btnEditDel addTarget:self action:@selector(btnEditDel) forControlEvents:UIControlEventTouchUpInside];
    btnEditDel.showsTouchWhenHighlighted = YES;
    [_popImageView addSubview:btnEditDel];
    
    
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, 900, 600) style:UITableViewStylePlain];
    _tableView.backgroundColor = [UIColor clearColor];
    _tableView.rowHeight = 120;
    _tableView.delegate = self;
    _tableView.dataSource = self;
    [_popImageView addSubview:_tableView];
    
    [UIUtil addAnimationShow:_popImageView];
}
- (void) layoutSubviews{
//    if([UIUtil currentOrientation]==0){
//        _bgImageView.image = [UIImage imageNamedNocache:@"bg_pop_v.png"];
//        _popImageView.image = [UIImage imageNamedNocache:@"pop_collect_v.png"];
//        _popImageView.frame = CGRectMake(30, 35, 708, 943);
        //backgroundView.image = [UIImage imageNamedNocache:@"bg_collection_v.png"];
        
        btnBack.frame = CGRectMake(44, 12, 72, 37);
        btnMyCollection.frame = CGRectMake(142, 9, 86, 37);
        btnEditDel.frame = CGRectMake(266, 15, 62, 30);
        //_tableView.frame = CGRectMake(0, 0, 660, 840);
        _tableView.frame = CGRectMake(23, 69, 660, 840);
//    }else{
//        _bgImageView.image = [UIImage imageNamedNocache:@"bg_pop_h.png"];
//        _popImageView.image = [UIImage imageNamedNocache:@"pop_collect_h.png"];
//        _popImageView.frame = CGRectMake(38, 30, 948, 694);
//        //backgroundView.image = [UIImage imageNamedNocache:@"bg_collection_h.png"];
//        
//        btnBack.frame = CGRectMake(44, 4, 72, 37);
//        btnMyCollection.frame = CGRectMake(142, 1, 86, 37);
//        btnEditDel.frame = CGRectMake(266, 7, 62, 30);
//        //_tableView.frame = CGRectMake(0, 0, 900, 600);
//        _tableView.frame = CGRectMake(46, 64, 871, 600);
//    }
}


#pragma mark - actions
-(void)backToMain
{
    [self removeFromSuperview];
    [UIUtil addAnimationFade:self];
    [_handler showView:@"none"];
}
- (void) normal{
    editing = NO;
    [btnEditDel setImage:[UIImage imageNamedNocache:@"btn_fav_del.png"] forState:UIControlStateNormal];
    [_tableView reloadData];
}
- (void) btnEditDel{
    editing = !editing;
    [_tableView setEditing:!_tableView.editing animated:YES];
    if (_tableView.editing) {
        [btnEditDel setImage:[UIImage imageNamedNocache:@"btn_fav_del_tap.png"] forState:UIControlStateNormal];
    }else {
        [btnEditDel setImage:[UIImage imageNamedNocache:@"btn_fav_del.png"] forState:UIControlStateNormal];
    }
}
//- (void) del:(id)target{
//    NSInteger row = [(UIView *)target tag] - 10000;
//    KSModelCollectionItem *item = [_entriesArray objectAtIndex:row];
//    if([item removeFromDb]){
//        [_entriesArray removeObjectAtIndex:row];
//        [_tableView reloadData];
//    }
//}
//- (void) gotoArticle:(UIGestureRecognizer *)ges{
//    NSInteger row = [ges.view tag] - 100000;
//    KSModelCollectionItem *item = [_entriesArray objectAtIndex:row];
//    [_handler gotoArticle:item.articleId magzineId:item.magzineId from:@"collection"];
//}
- (void)gotoArticle:(KSModelCollectionItem *)item {
    [_handler gotoArticle:item.articleId magzineId:item.magzineId from:@"collection"];
}

#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 116.0;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    KSModelCollectionItem *item = [_entriesArray objectAtIndex:indexPath.row];
    
    KSModelMagzine *m = [KSModelMagzine loadById:item.magzineId];
    if (!m.isArticlesDownload) {
        [UIUtil showMsgAlertWithTitle:@"不能阅读该文章" message:@"您已删除了该本杂志。"];
    } else {
        [self gotoArticle:item];
    }
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}
#pragma mark -
#pragma mark Table view creation (UITableViewDataSource)

// customize the number of rows in the table view
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return [_entriesArray count];
}
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    KSModelCollectionItem *item = [_entriesArray objectAtIndex:indexPath.row];
    if([item removeFromDb]){
        [_entriesArray removeObjectAtIndex:indexPath.row];
        [_tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	static NSString *CellIdentifier = @"CollectTableCell";
    KSCollectionTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[KSCollectionTableViewCell alloc] initWithCollectItem:[_entriesArray objectAtIndex:indexPath.row] reuseIdentifier:CellIdentifier] autorelease];
    }
    cell.collectItem = [_entriesArray objectAtIndex:indexPath.row];
    
    return cell;
}

@end
