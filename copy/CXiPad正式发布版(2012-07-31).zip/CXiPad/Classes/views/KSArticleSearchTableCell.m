//
//  KSArticleSearchTableCell.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 1/6/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "KSArticleSearchTableCell.h"

@implementation KSArticleSearchTableCell
@synthesize searchItem = _searchItem;

- (void)dealloc
{
    [_searchItem release];
    [_timeLabel release];
    [_lockImageView release];
    [_titleLabel release];
    [_summaryTextLabel release];
    [super dealloc];
}
- (NSString *)calTimeString {
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:_searchItem.pubDate];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
	[formatter setDateFormat:@"yyyy年"];
	NSString *year = [formatter stringFromDate:date];
    [formatter setDateFormat:@"MM月"];
    NSString *month = [formatter stringFromDate:date];
    [formatter setDateFormat:@"dd日"];
    NSString *day = [formatter stringFromDate:date];
	[formatter release];
    
    //NSString *str = [NSString stringWithFormat:@"%@第%@期%@%@出版", year, _searchItem.stageNumber, month, day];
    NSString *str = [NSString stringWithFormat:@"来源：%@  %@第%@期%@%@出版", _searchItem.magazineTitle, year, _searchItem.stageNumber, month, day];
    return str;
    
}
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}
- (id)initWithSearchItem:(KSModelSearchItem *)item reuseIdentifier:(NSString *)reuseIdentifier {
    self = [self initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:reuseIdentifier];
    if (self) {
        _searchItem = [item retain];
        _titleLabel = [[UILabel alloc] initWithFrame:self.textLabel.frame];
        _titleLabel.text = _searchItem.title;
        _titleLabel.font = [UIFont systemFontOfSize:15.0f];
        
        CGSize textLabelSize = [_titleLabel.text sizeWithFont:_titleLabel.font];
        _titleLabel.width = textLabelSize.width;
        _titleLabel.height = textLabelSize.height;
        [self addSubview:_titleLabel];
        
        _summaryTextLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        _summaryTextLabel.text = _searchItem.summary;
        _summaryTextLabel.numberOfLines = 0;
        _summaryTextLabel.backgroundColor = [UIColor clearColor];
        _summaryTextLabel.textColor = [UIColor colorWithWhite:0.27 alpha:1];
        _summaryTextLabel.font = [UIFont systemFontOfSize:13.0f];
        CGSize conCZ = CGSizeMake(self.width-60.0f, 9999);
        CGSize cz = [_summaryTextLabel.text sizeWithFont:_summaryTextLabel.font constrainedToSize:conCZ lineBreakMode:UILineBreakModeWordWrap];
        _summaryTextLabel.frame = CGRectMake(_titleLabel.left, 45, self.width-60.0f, cz.height);
        [self addSubview:_summaryTextLabel];
        
        _lockImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"lbl_item_locked.png"]];
        [self addSubview:_lockImageView];
        _lockImageView.frame = CGRectMake(0, 15, _lockImageView.width, _lockImageView.height);
        _lockImageView.hidden = !_searchItem.lock;
        
        [self.contentView addSubview:_lockImageView];
        
        _timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.width - 250, 16, 240, 20)];
        _timeLabel.backgroundColor = [UIColor clearColor];
        _timeLabel.textAlignment = UITextAlignmentRight;
        _timeLabel.textColor = [UIColor colorWithWhite:0.3 alpha:1];//[UIColor colorWithRed:0xAF/255.0f green:0xAE/255.0f blue:0xAA/255.0f alpha:1];
        _timeLabel.font = [UIFont systemFontOfSize:10.0f];
        _timeLabel.text = [self calTimeString];
        [self.contentView addSubview:_timeLabel];
        
        self.accessoryType = UITableViewCellAccessoryNone;
    }
    return self;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}
- (void)layoutSubviews {
    [super layoutSubviews];
    _titleLabel.frame = CGRectMake(20, 12, _titleLabel.width, 27);
    _lockImageView.left = _titleLabel.right+5;
    
    _summaryTextLabel.left = _titleLabel.left;
    CGSize conCZ = CGSizeMake(self.width-60.0f, 9999);
    CGSize cz = [_summaryTextLabel.text sizeWithFont:_summaryTextLabel.font constrainedToSize:conCZ lineBreakMode:UILineBreakModeWordWrap];
    _summaryTextLabel.frame = CGRectMake(_titleLabel.left, _summaryTextLabel.top, self.width-60, cz.height);
    
    _timeLabel.right = self.width - 10.0f;
    _timeLabel.bottom = self.height - 10.0f;
}
- (void)setSearchItem:(KSModelSearchItem *)searchItem {
    if (_searchItem != searchItem) {
        [_searchItem release];
        _searchItem = [searchItem retain];
        
        _titleLabel.text = _searchItem.title;
        CGSize textLabelSize = [_titleLabel.text sizeWithFont:_titleLabel.font];
        _titleLabel.width = textLabelSize.width;
        
        _summaryTextLabel.text = _searchItem.summary;
        
        _timeLabel.text = [self calTimeString]; //更新来源等信息
        
        _lockImageView.hidden = !_searchItem.lock;
        [self setNeedsLayout];
    }
}
@end
