//
//  KSAppDelegate.m
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-11-27.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import "KSAppDelegate.h"
#import "DateUtil.h"
#import "KSRootViewController.h"
#import "KSUIWindow.h"
#import "KSRemoteNotificationHanlder.h"
#import "KSNewsstandHandler.h"
#import "KSGetMagzineListOperation.h"

@implementation KSAppDelegate

@synthesize window = _window;
@synthesize viewController = _viewController;
@synthesize mainController = _mainController;
- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"ROTATION_OCCURS" object:nil];
    
    [_window release];
    [_viewController release];
    [_mainController release];
    [super dealloc];
}
static void uncaughtExceptionHandler(NSException *exception) {
    KSDINFO(@"CRASH: %@", exception);
    KSDINFO(@"Stack Trace: %@", [exception callStackSymbols]);
    // Internal error reporting
}

-(void)checkDatabase{
    NSString *oldVersion = [USER_DEFAULT objectForKey:@"oldVersion"];
    NSString *newVersion = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    if (![oldVersion isEqualToString:newVersion]) {
        if([oldVersion isEqualToString:@"2.1.2"]){
            KSGetAllArticlesDownloader *dl = [[KSGetAllArticlesDownloader alloc] init];
            [dl upgradeDB];
            [dl release];
        }  
    }
}


#pragma mark - launched
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{


//#if MODE==MODE_DEV
//    NSSetUncaughtExceptionHandler(&uncaughtExceptionHandler);
//#endif
    _mainController = [[KSMainController alloc] init];
    //[KStoreManager sharedManager];
    [KSBootstrap start];
    _window = [[KSUIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    _window.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    //
    [application setStatusBarHidden:YES];
    //init orientation
    KSDataCenter *dataCenter = [KSBootstrap dataCenter];
    NSInteger val = [application statusBarOrientation];
    val = (val==UIInterfaceOrientationPortrait || val==UIInterfaceOrientationPortraitUpsideDown)?0:1;
    [dataCenter setValue:[NSNumber numberWithInt:val] forKey:@"orientation"];
    
    // Override point for customization after application launch.
    //self.viewController = [[[KSRootViewController alloc] initWithNibName:nil bundle:nil] autorelease];
    //self.window.rootViewController = self.viewController;
    [self checkDatabase];
    [_mainController presentEmergenceViewController];
    //[_mainController presentMagzineViewController];
    
    [self.window makeKeyAndVisible];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(rotationOccurs:) name:@"ROTATION_OCCURS" object:nil];
    
    
#if MODE==MODE_PROD
    [MobClick setDelegate:self];
    [MobClick appLaunched];
#endif
    
#ifdef HOC
    KSDINFO(@"aaaaaaaaaaa");
#endif

    
    //启用push
    // 先注释条件判断以测试， 每次都注册push服务
    //if (![application enabledRemoteNotificationTypes]) {
        [application registerForRemoteNotificationTypes:(UIRemoteNotificationTypeNewsstandContentAvailability|UIRemoteNotificationTypeAlert | UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound )];
    //} 
    

    
    
    // 增加Newsstand代码
    
#if MODE==MODE_DEV
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"NKDontThrottleNewsstandContentNotifications"];
    [[NSUserDefaults standardUserDefaults] synchronize];
#endif
    
    // 通过newsstand push启动起来的应用
//    NSDictionary *userInfo = [launchOptions valueForKey:@"UIApplicationLaunchOptionsRemoteNotificationKey"];
//    [self handleNewsstandPushInfo:userInfo];
    //
    // 通过push消息启动起来的应用
    //
    NSDictionary *remoteNotif = [launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey];
    
    if (remoteNotif) 
    {
        [self handlePush:remoteNotif];
    }
    
    
    //继续未完成的杂志下载
    NKLibrary *nkLib = [NKLibrary sharedLibrary];
    for(NKAssetDownload *asset in [nkLib downloadingAssets])
    {
        KSDINFO(@"continue NKAssetDownload------------------");
        [asset downloadWithDelegate:[KSNewsstandHandler shareKSNewsstandHandler]];
    }
    
    NSDictionary *payload = [launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey];
    KSDINFO(@"payload------------------%@",[payload description]);
    if(payload) {
    
        // schedule for issue downloading in background
        NKIssue *issue4 = [[NKLibrary sharedLibrary] issueWithName:@"Magazine-4"];
        if(issue4) {
            NSURL *downloadURL = [NSURL URLWithString:@"http://www.viggiosoft.com/media/data/blog/newsstand/magazine-4.pdf"];
            NSURLRequest *req = [NSURLRequest requestWithURL:downloadURL];
            NKAssetDownload *assetDownload = [issue4 addAssetWithRequest:req];
            [assetDownload downloadWithDelegate:[KSNewsstandHandler shareKSNewsstandHandler]];
        }
    }
    

    
    // TODO: 增加开机检查版本代码
    [self showVersion];
    
    //评分提示
//    [self tipToMark];

   
    
    

    return YES;
}

-(void)tipToMark
{
    NSString *version = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    NSString *oldVersion = [USER_DEFAULT objectForKey:@"lastVersion"];
    //是否已经升级，升级后重新计算评分规则
    if (![version isEqualToString:oldVersion])
    {
        [USER_DEFAULT setBool:NO forKey:@"marked"];
        [USER_DEFAULT setObject:nil forKey:@"days"];
    }

    [USER_DEFAULT setObject:version forKey:@"lastVersion"];
    [USER_DEFAULT synchronize];
    
    //3天连续打开应用3次提示评分
    if (![USER_DEFAULT boolForKey:@"marked"])
    {
        [DateUtil addDate];
        if ([USER_DEFAULT boolForKey:@"mark"])
        {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"为新世纪打分。您的鼓励是我们永远的动力！\n" delegate:self cancelButtonTitle:nil otherButtonTitles:@"现在去评分",@"下次提醒我",@"不了，谢谢", nil];
            alert.tag = 1024;
            [alert show];
            [alert release];
        }
    }

}

- (void)rotationOccurs:(NSNotification *)notification
{
    NSDictionary *userInfo = [notification userInfo];
    KSDataCenter *dataCenter = [KSBootstrap dataCenter];
    NSInteger val = [[userInfo valueForKey:@"to"] intValue];
    val = (val==UIInterfaceOrientationPortrait || val==UIInterfaceOrientationPortraitUpsideDown)?0:1;
    [dataCenter setValue:[NSNumber numberWithInt:val] forKey:@"orientation"];
}

- (void)applicationWillResignActive:(UIApplication *)application
{

#if MODE==MODE_PROD
    [MobClick appTerminated];
#endif
    if ([[[KSMainController mainController] activeController] isKindOfClass:[KSArticleViewController class]]) {
        //KSDINFO(@"%d",[[[KSMainController mainController] activeController].view isPortrait]);
        [(KSArticleViewController*)[[KSMainController mainController] activeController] resetTripstate];
        [(KSArticleViewController*)[[KSMainController mainController] activeController] removeAllArticleViews];
    }
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     */
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
//    if ([KSNewsstandHandler shareKSNewsstandHandler].taskID == UIBackgroundTaskInvalid)
//    {
//        return;
//    }
//    IF_IOS5_OR_GREATER(
//                       if (![USER_DEFAULT boolForKey:BACKGROUND_DOWNLOAD])
//                       {
                           __block UIBackgroundTaskIdentifier taskID ;
                           taskID = [application beginBackgroundTaskWithExpirationHandler:^{
                               KSDINFO(@"end background task!");
                               [application endBackgroundTask:taskID];
                               taskID = UIBackgroundTaskInvalid;
                           }];
                           if (taskID == UIBackgroundTaskInvalid) {  
                               KSDINFO(@"Failed to start background task!");  
                               return;  
                           }  
                           KSDINFO(@"Starting background task with %f seconds remaining", application.backgroundTimeRemaining); 
                           
//                       }

    
//    );
       
//    [NSThread sleepForTimeInterval:10];  
//    KSDINFO(@"Finishing background task with %f seconds remaining",application.backgroundTimeRemaining);  
    //告诉系统我们完成了  
//    [application endBackgroundTask:taskID];  
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
     If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
     */
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    
    [self tipToMark];

    
#if MODE==MODE_PROD
    [MobClick setDelegate:self];
    [MobClick appLaunched];
#endif
    if ([[[KSMainController mainController] activeController] isKindOfClass:[KSArticleViewController class]]) {
        [[KSBootstrap dataCenter] setValue:[NSNumber numberWithInt:0] forKey:@"orientation"];
        [(KSArticleViewController*)[[KSMainController mainController] activeController] loadPages];
    }
    /*
     Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
     */
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    application.applicationIconBadgeNumber = 0;
    if ([[[KSMainController mainController] activeController] isKindOfClass:[KSArticleViewController class]]) {
        return;
    }
    KSGetMagzineListOperation *operGetMagzineList = [[KSGetMagzineListOperation alloc] init];
    [[KSBootstrap operationQueue] addOperation:operGetMagzineList];
    [operGetMagzineList release];
    /*
     Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
     */
}

- (void)applicationWillTerminate:(UIApplication *)application
{
#if MODE==MODE_PROD
    [MobClick appTerminated];
    [KSBootstrap end];
#endif
    
}

#pragma mark - MobClickDelegate
- (NSString *)appKey {
    return @"4f2f495c5270154ab8000003";//return @"4f151bf4527015266d00002e";
}
- (NSString *)channelId {
    return @"AppStore";
}

#pragma mark - Push
- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error {
    //增加测试代码
    //NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
	//[userDefaults setObject:@"352dcd27 f0cdb07b 20952686 827838b1 04fa3dc9 1fa25e9d 5e04d7ec 33cfd5e3" forKey:PUSH_DEVICE_TOKEN];
	//[userDefaults synchronize];
    //http://ipadtest.caing.com/magazine/listreaders/1
    //
    KSDINFO(@"didFailToRegisterForRemoteNotificationsWithError\n%@,%@", error.localizedDescription, error.localizedFailureReason);
}

//
// 从苹果拿到deviceToken, 将其保存到server端 以及local sqlite数据库
//
- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
    KSDINFO(@"devToken=%@",deviceToken);
    
    NSString *starthour = [KSDB stringForKey:PUSH_START_HOUR];
    if (starthour == nil || [starthour length] == 0) {
        starthour = @"0";
    }
    
    NSString *endhour = [KSDB stringForKey:PUSH_END_HOUR];
    if (endhour == nil || [endhour length] == 0) {
        endhour = @"24";
    }
    
    NSString *email = [KSDB stringForKey:@"login_name"];
    if (email == nil) {
        email = @"";
    }
    
    NSString *pushtype = [KSDB stringForKey:PUSH_TYPE];
    if (pushtype == nil || [pushtype length] == 0) {
        pushtype = [NSString stringWithFormat:@"%d", cXPushTypeNone|cxPushTypeUpMagazine|cXPushTypeNews|cXPushTypeMagazine];
        [KSDB saveString:pushtype forKey:PUSH_TYPE];
    }
    
    NSString *devicetoken = [[deviceToken description] stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"<>"]];
    //保存到sqlite数据库
    [KSDB saveString:devicetoken forKey:PUSH_DEVICE_TOKEN];
    //保存到用户默认数据库
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
	[userDefaults setObject:devicetoken forKey:PUSH_DEVICE_TOKEN];
	[userDefaults synchronize];
    //发送数据，提交到CMS后台请求
    [CXPushSetDataRequest requestWithDelegate:self 
                               withParameters:[NSDictionary dictionaryWithObjectsAndKeys: 
                                               email, @"email",
                                               devicetoken, @"devicetoken",
                                               pushtype, @"pushtype",
                                               @"", @"pushtime",
                                               PUSH_APP_NAME, @"appname",
                                               starthour, @"starthour",
                                               endhour, @"endhour",
                                               MAGZINE_TYPE, @"magazineid",
                                               nil]];
}
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo {
    KSDINFO(@"didReceiveRemoteNotification  %@",    [userInfo description]);
    
    [self handlePush:userInfo];
}
//- (void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification {
//    [self handlePush:notification.userInfo];
//}
#pragma mark - Handler Newsstand push
- (void)handleNewsstandPushInfo:(NSDictionary *)dict {
    
}
#pragma mark - Handler Push Notify
- (void)handlePush:(NSDictionary *)dict {
    KSDINFO(@"%@", dict);
    NSDictionary *dic = [dict objectForKey:@"aps"];
    if([dic objectForKey:@"content-available"]&&[[dic objectForKey:@"pushtype"] intValue]==2) {
        [KSNewsstandHandler handle:dic];
    } else {
        [KSRemoteNotificationHanlder handle:dic];
    }
    //NSString *pushType = [dict objectForKey:@"acm"];
    //  增加push消息 处理逻辑
}

#pragma mark - KSDataRequestDelegate 
- (void)requestDidStarted:(KSBaseDataRequest *)request {
    
}
- (void)requestDidFinished:(KSBaseDataRequest *)request {
    KSDINFO(@"%@", request.resultDict);
}
- (void)requestDidCanceled:(KSBaseDataRequest *)request {
    
}
- (void)requestDidFailed:(KSBaseDataRequest *)request withError:(NSError*)error {
    
}
#pragma mark -
- (void)showVersion {
    NSURL *nsUrl = [[NSURL alloc] initWithString:@"http://itunes.apple.com/lookup?id=391959946"];
    ASIFormDataRequest *_request = [[ASIFormDataRequest alloc] initWithURL:nsUrl];
    _request.delegate = self;
    _request.timeOutSeconds = 30;
    [_request startAsynchronous];
}
-(void)requestFinished:(ASIHTTPRequest *)request
{
    NSString *version = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    NSDictionary *dict = [[CJSONDeserializer deserializer] deserialize:request.responseData error:nil];
    NSString *newVersion = [[[dict objectForKey:@"results"] objectAtIndex:0] objectForKey:@"version"];
    //if (![newVersion isEqualToString:version]) // 防止老版本替换新版本，模拟器有这种提示
    if([newVersion localizedCompare:version] == NSOrderedDescending)
    {
//        [USER_DEFAULT setBool:NO forKey:@"updated"];
//        [USER_DEFAULT synchronize];
        NSString *tipMessage = [[NSString alloc] initWithFormat:@"目前有新版本%@已上线，是否升级？",newVersion];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:tipMessage delegate:self cancelButtonTitle:@"否" otherButtonTitles:@"是", nil];
        alert.tag = 1025;
        [alert show];
        [tipMessage release];
        [alert release];
    }
//    else 
//    {
//        if (![USER_DEFAULT boolForKey:@"updated"])
//        {
//            [USER_DEFAULT setBool:YES forKey:@"updated"];
//            [USER_DEFAULT setObject:NO forKey:@"marked"];
//            [USER_DEFAULT synchronize];
//        }
//
//    }

    KSDINFO(@"Current Version:%@,new version:%@", version, newVersion);

}
-(void)requestFailed:(ASIHTTPRequest *)request
{
//    if (![USER_DEFAULT boolForKey:@"updated"])
//    {
//        [USER_DEFAULT setBool:YES forKey:@"updated"];
//        [USER_DEFAULT setObject:NO forKey:@"marked"];
//        [USER_DEFAULT synchronize];
//    }
//    [self tipToMark];

    KSDINFO(@"%@",request.responseString);
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (alertView.tag)
    {
        case 1024:
        {
            switch (buttonIndex)
            {
                case 0:
                {
                    [USER_DEFAULT setBool:YES forKey:@"marked"];
                    [USER_DEFAULT synchronize];
                    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"itms-apps://ax.itunes.apple.com/WebObjects/MZStore.woa/wa/viewContentsUserReviews?type=Purple+Software&id=391959946"]];



                }
                    break;
                case 1:
                {
                    
                    [USER_DEFAULT setObject:nil forKey:@"days"];
                    [USER_DEFAULT synchronize];

                }
                    break;
                case 2:
                {
                    [USER_DEFAULT setBool:YES forKey:@"marked"];
                    [USER_DEFAULT setObject:nil forKey:@"days"];
                    [USER_DEFAULT synchronize];
                    
                }
                    break;
                    
                default:
                    break;
            }


        }
            break;
        case 1025:
        {
            if (buttonIndex==1)
            {
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://itunes.apple.com/cn/app/cai-xin-xin-shi-ji/id391959946?mt=8"]];
            }
            
        }
            break;
            
        default:
            break;
    }
}

@end
