//
//  KSAppDelegate.h
//  CenturyWeeklyV2
//
//  Created by liuyou on 11-11-27.
//  Copyright (c) 2011年 KSMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MobClick.h"
#import "CXDataRequest.h"
#import <NewsstandKit/NewsstandKit.h>

@class KSRootViewController;
@class KSMainController;
@interface KSAppDelegate : UIResponder <UIApplicationDelegate,KSDataRequestDelegate,MobClickDelegate,ASIHTTPRequestDelegate,UIAlertViewDelegate> {

}
@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) KSRootViewController *viewController;
@property(nonatomic, retain)KSMainController *mainController;

- (void)handlePush:(NSDictionary *)dict;
- (void)handleNewsstandPushInfo:(NSDictionary *)dict;

- (void)showVersion;
@end
