//
//  KUILoupeView.h
//  KSUI
//
//  Created by jinjian on 4/9/12.
//  Copyright (c) 2012 ksmobile. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum {
    KUILoupeStyleNone = 0,
    KUILoupeStyleRectangle,
} KUILoupeStyle;
extern NSString *const KSLoupeDidHide;

@interface KUILoupeView : UIView {
    
    CGPoint _touchPoint;
    CGPoint _touchPointOffset;
    CGFloat _magnification;
    CGPoint _magnifiedImageOffset;
    UIView *_targetView;
    UIView *_rootView;
    UIImage *_loupeFrameImage;
    UIImage *_loupeFrameBackgroundImage;
    UIImage *_loupeFrameMaskImage;
    KUILoupeStyle _style;
    BOOL _seeThroughMode;
    BOOL _drawDebugCrossHairs;
}
@property(nonatomic, assign) CGPoint touchPoint;
@property(nonatomic, assign) CGPoint touchPointOffset;
@property(nonatomic, assign) CGFloat magnification;
@property(nonatomic, assign) CGPoint magnifiedImageOffset;
@property(nonatomic, assign) UIView *targetView;
@property(nonatomic, assign) BOOL drawDebugCrossHairs;
@property(nonatomic, assign) BOOL seeThroughMode;
@property(nonatomic,assign) KUILoupeStyle style;

- (id)initWithTargetView:(UIView *)targetView;
- (void)presentLoupeFromLocation:(CGPoint)location;
- (void)dismissLoupeTowardsLocation:(CGPoint)location;

- (BOOL)isShowing;

@end
