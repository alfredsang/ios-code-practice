//
//  KUIProgressView.h
//  KSUI
//
//  Created by jinjian on 4/17/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KUIProgressView : UIProgressView {
    UIColor *_tintColor;
    NSTimer *_progressTimer;
    CGFloat _targetProgress;
}

- (void)setTintColor:(UIColor *)aColor;
- (void)setProgress:(CGFloat)progress animated:(BOOL)animated;

@end
