//
//  KUISwitch.h
//  KSUI
//
//  Created by jinjian on 4/2/11.
//  Copyright (c) 2012 ksmobile.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@class KUISwitchKnobLayer;
@class KUISwitchOutLineLayer;
@class KUISwitchToggleLayer;
@interface KUISwitch : UIControl {
@private
    KUISwitchOutLineLayer *outlineLayer;
    KUISwitchToggleLayer *toggleLayer;
    KUISwitchKnobLayer *knobLayer;
    CAShapeLayer *clipLayer;
    BOOL ignoreTap;
}

@property (nonatomic, retain) UIColor *onTintColor;
@property (nonatomic, getter=isOn) BOOL on;
@property (nonatomic, copy) NSString *onText;
@property (nonatomic, copy) NSString *offText;


- (void)setOn:(BOOL)newOn animated:(BOOL)animated;
- (void)setOn:(BOOL)newOn animated:(BOOL)animated ignoreControlEvents:(BOOL)ignoreControlEvents;

@end
