//
//  KSProgressView.h
//  KSUI
//
//  Created by jinjian on 4/7/11.
//  Copyright (c) 2012 ksmobile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KSProgressView : UIView {
@private
    float progress;
    UIColor *innerColor;
    UIColor *outerColor;
    UIColor *emptyColor;
}
@property(nonatomic, retain) UIColor *innerColor;
@property(nonatomic, retain) UIColor *outerColor;
@property(nonatomic, retain) UIColor *emptyColor;
@property(nonatomic, assign) float progress;

@end
