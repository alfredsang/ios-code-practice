//
//  AKOMultiPageTextView.m
//  CoreTextWrapper
//
//  Created by Adrian on 4/28/10.
//  Copyright 2010 akosma software. All rights reserved.
//
#import <QuartzCore/QuartzCore.h>
#import "AKOMultiPageTextView.h"
#import "UIFont+CoreTextExtensions.h"
#import "AKOMultiColumnTextView.h"


@interface AKOMultiColumnTextView ()
- (void)setPage:(NSInteger)page;
@end

@interface AKOMultiPageTextView ()


@property (nonatomic, retain) NSMutableArray *pages;
//@property (nonatomic, retain) UIScrollView *scrollView;
@property (nonatomic) BOOL pageControlUsed;

- (void)setup;
- (void)changeColorForPageControl;
- (void) updateAttributedString;
@end


@implementation AKOMultiPageTextView

@synthesize pages = _pages;
@synthesize scrollView = _scrollView;
@synthesize pageControl = _pageControl;
@synthesize pageControlUsed = _pageControlUsed;
@synthesize dataSource = _dataSource;
@synthesize scrollEnabled = _scrollEnabled;

@synthesize lineBreakMode = _lineBreakMode;
@synthesize textAlignment = _textAlignment;
@synthesize firstLineHeadIndent = _firstLineHeadIndent;
@synthesize spacing = _spacing;
@synthesize topSpacing = _topSpacing;
@synthesize lineSpacing = _lineSpacing;
@synthesize columnInset = _columnInset;
@synthesize attributedString = _attributedString;
@synthesize font = _font;
@synthesize color = _color;
@synthesize text = _text;
@synthesize firstCharacterFontsize = _firstCharacterFontsize;
@synthesize currentPageIndex;
@synthesize lastPageIndex;
@synthesize scrollOffset = _scrollOffset;
@synthesize columnCount = _columnCount;



- (id)initWithCoder:(NSCoder *)aDecoder
{
    if ((self = [super initWithCoder:aDecoder]))
    {
        [self setup];
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame 
{
    if ((self = [super initWithFrame:frame]))
    {
        [self setup];
    }
    return self;
}

- (void)setup
{
    _lineBreakMode = kCTLineBreakByWordWrapping;
    _textAlignment = kCTJustifiedTextAlignment;//kCTLeftTextAlignment;
    _firstLineHeadIndent = 0.0;
    _spacing = 5.0;
    _topSpacing = 0.0;
    _lineSpacing = 1.0;
    _columnCount = 2;
    _firstCharacterFontsize = 64.0;
    _columnInset = CGPointMake(10.0, 10.0);
    _scrollEnabled = YES;
    _font = [[UIFont fontWithName:@"Helvetica" size:18.0] retain];
    _color = [[UIColor blackColor] retain];
    _scrollOffset = CGRectZero;
    
    self.pages = [NSMutableArray arrayWithCapacity:5];
    
    CGRect scrollViewFrame = CGRectMake(0.0, 0.0, self.frame.size.width, self.frame.size.height);
    self.scrollView = [[[UIScrollView alloc] initWithFrame:scrollViewFrame] autorelease];
    self.scrollView.scrollEnabled = self.scrollEnabled;
    self.scrollView.bounces = NO;
    self.scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.scrollView.pagingEnabled = YES;
    self.scrollView.delegate = self;
    
    
    CGRect pageControlFrame = CGRectMake(0.0, self.frame.size.height - 12, self.frame.size.width, 12);
    self.pageControl = [[[UIPageControl alloc] initWithFrame:pageControlFrame] autorelease];
    self.pageControl.numberOfPages = 2;
    self.pageControl.backgroundColor = [UIColor clearColor];
    self.pageControl.currentPage = 0;
    self.pageControl.hidden = NO;
    
    [self changeColorForPageControl];
    
    [self.pageControl addTarget:self
                         action:@selector(changePage:) 
               forControlEvents:UIControlEventValueChanged];
    
    [self addSubview:self.scrollView];
    [self addSubview:self.pageControl];
}

- (void)dealloc 
{
    self.pageControl = nil;
    self.scrollView = nil;
    self.pages = nil;
  
    [_attributedString release];
    _attributedString = nil;
    if(framesetter){
        CFRelease(framesetter);
    }
    [_text release];
    _text = nil;
    [_font release];
    _font = nil;
    [_color release];
    _color = nil;

    [super dealloc];
}

#pragma mark -
#pragma mark UIScrollViewDelegate methods



- (void)scrollViewDidScroll:(UIScrollView *)sender 
{
    [self changeColorForPageControl];
    
    if (self.pageControlUsed) 
    {
        return;
    }
	
    CGFloat pageWidth = self.scrollView.frame.size.width;
    int page = floor((self.scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    self.pageControl.currentPage = page;
    
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView 
{ 
    self.pageControlUsed = NO;
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView 
{
    self.pageControlUsed = NO;
}

- (void)changeColorForPageControl
{
    for (NSUInteger subviewIndex = 0; subviewIndex < [self.pageControl.subviews	count]; subviewIndex++)
    {
        UIImageView* subview = [self.pageControl.subviews objectAtIndex:subviewIndex];
        if (subviewIndex == self.pageControl.currentPage)
        {
            if ([subview respondsToSelector:@selector(setImage:)])
            {
                [subview setImage:[UIImage imageNamed:@"a_pagecontrol_selected.png"]];
            }
        }
        else
        {
            if ([subview respondsToSelector:@selector(setImage:)])
            {
                [subview setImage:[UIImage imageNamed:@"a_pagecontrol_unselected.png"]];
            }
        }
        
    }
}

#pragma mark -
#pragma mark IBAction methods

- (IBAction)changePage:(id)sender 
{
    int page = self.pageControl.currentPage;
    CGRect frame = self.scrollView.frame;
    frame.origin.x = frame.size.width * page;
    frame.origin.y = 0;
    [self.scrollView scrollRectToVisible:frame animated:YES];
    self.pageControlUsed = YES;
}
- (void)locateEndPage {
    NSInteger p = [self getLastPageIndex];
    if (p != _pageControl.currentPage) {
        self.pageControlUsed = YES;
        [_scrollView scrollRectToVisible:CGRectMake(self.width*p, 0, self.width, self.height) animated:NO];
        [self changeColorForPageControl];
    }
}
- (void)locateFirstPage {
    NSInteger p = 0;
    if (p != _pageControl.currentPage) {
        self.pageControlUsed = YES;
        [_scrollView scrollRectToVisible:CGRectMake(self.width*p, 0, self.width, self.height) animated:NO];
        _pageControl.currentPage = p;
        [self changeColorForPageControl];
    }
}
#pragma mark -
#pragma mark Properties

- (void)setText:(NSString *)newText
{
    if (![self.text isEqualToString:newText])
    {
        [_text release];
        _text = [newText copy];
        _attributedString = [[NSMutableAttributedString alloc] initWithString:_text];
    }
}

- (void) setAttributedString:(NSAttributedString *)attributedString{
    if(![self.attributedString isEqualToAttributedString:attributedString]){
        [_attributedString release];
        _attributedString = nil;
        _attributedString = [attributedString retain];
//        [self updateAttributedString];
        if(framesetter){
            CFRelease(framesetter);
            framesetter = nil;
        }
        framesetter = CTFramesetterCreateWithAttributedString((CFAttributedStringRef)_attributedString);
    }
}
- (void)setScrollEnabled:(BOOL)scrollEnabled
{
    _scrollEnabled = scrollEnabled;
    self.scrollView.scrollEnabled = scrollEnabled;
}

- (NSInteger)getCurrentPageIndex
{
    return self.pageControl.currentPage;
}

- (NSInteger)getLastPageIndex
{
    return [_pages count]-1;
}

#pragma mark -
- (void)increaseFont:(CGFloat)fontsie {
    NSMutableAttributedString *attrString = (NSMutableAttributedString *)_attributedString;
    float rate = fontsie/(fontsie-2);
    if (attrString && rate != 1) {
        [attrString enumerateAttributesInRange:NSMakeRange(0, [attrString length]) options:NSAttributedStringEnumerationReverse usingBlock:^(NSDictionary *attrs, NSRange range, BOOL *stop) {
            
            CTFontRef f = (CTFontRef)[attrs objectForKey:(NSString *)kCTFontAttributeName];
            CTFontRef newFontRef = CTFontCreateCopyWithAttributes(f, CTFontGetSize(f)*rate,nil,nil);
            NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithDictionary:attrs];
            [dict setObject:(id)newFontRef forKey:(NSString *)kCTFontAttributeName];
            CFRelease(newFontRef);
            [attrString setAttributes:dict range:range];
//            if (range.length >= [attrString length]) {
//                *stop = YES;
//            }
        }];
    }
    if(framesetter){
        CFRelease(framesetter);
        framesetter = nil;
    }
    framesetter = CTFramesetterCreateWithAttributedString((CFAttributedStringRef)_attributedString);
    
    [self setNeedsDisplay];
}

#pragma mark -
- (void)drawRect:(CGRect)rect{
    if(!_attributedString)return;
    [self.pages makeObjectsPerformSelector:@selector(removeFromSuperview)];
    [self.pages removeAllObjects];
    
    NSInteger _oldPage = self.pageControl.currentPage;
    
    CGRect pageControlFrame = CGRectMake(0.0, self.frame.size.height + _scrollOffset.origin.y - _scrollOffset.size.height - 12.0, self.frame.size.width, 12.0);
    self.pageControl.frame = pageControlFrame;

    NSInteger currentPosition = 0;
    NSInteger iteration = 0;
    BOOL moreTextAvailable = YES;
    AKOMultiColumnTextView *view = nil;
    do 
    {
        CGRect currentFrame = CGRectMake(self.scrollView.frame.size.width * iteration + _scrollOffset.origin.x, _scrollOffset.origin.y, self.scrollView.frame.size.width - _scrollOffset.size.width, self.scrollView.frame.size.height - _scrollOffset.size.height);
//        CGRect currentFrame = CGRectOffset(self.scrollView.frame, self.scrollView.frame.size.width * iteration, 0.0);
        view = [[AKOMultiColumnTextView alloc] initWithFrame:currentFrame];
        [view setPage:iteration];
        
        view.columnCount = self.columnCount;
        view.startIndex = currentPosition;
        view.framesetter = framesetter;
        view.attributedString = _attributedString;
        view.backgroundColor = self.backgroundColor;
        
        // set the properties
        view.columnInset = _columnInset;

        view.dataSource = self.dataSource;
        [view updateFrames];
        [self.pages addObject:view];
        [view release];
        [self.scrollView addSubview:view];
        if ([self.dataSource respondsToSelector:@selector(addSubview:onPage:)])
        {
            [self.dataSource addSubview:view onPage:iteration];
        }

        currentPosition = view.finalIndex;
        iteration += 1;
        moreTextAvailable = view.moreTextAvailable;
    } 
    while (moreTextAvailable);
    
    self.scrollView.contentSize = CGSizeMake(self.scrollView.frame.size.width * iteration, self.scrollView.frame.size.height);
    self.scrollView.contentOffset = CGPointMake(0, 0);
    
    if ([self.dataSource respondsToSelector:@selector(appendSubview:)])
    {
        [self.dataSource appendSubview:view];
    }
    self.pageControl.numberOfPages = iteration;
    _oldPage = _oldPage > iteration-1?iteration-1:_oldPage;
    [_scrollView scrollRectToVisible:CGRectMake(self.width*_oldPage, 0, self.width, self.height) animated:NO];
    self.pageControl.currentPage = _oldPage;
    
    [self changeColorForPageControl];
}

- (void) updateAttributedString
{
    if(!_attributedString)return;
    NSMutableAttributedString *result = [[NSMutableAttributedString alloc] initWithAttributedString:_attributedString];
    [_attributedString release];
    NSRange range = NSMakeRange(0, [result length]);
    
    if (_font != nil)
    {
        CTFontRef ctfont = [_font CTFont];
        [result addAttribute:(NSString *)kCTFontAttributeName
                                      value:(id)ctfont
                                      range:range];
        CFRelease(ctfont);
    }
    
    if (_color != nil)
    {
        [result addAttribute:(NSString *)kCTForegroundColorAttributeName 
                                      value:(id)_color.CGColor
                                      range:range];
    }
    
    
    CFIndex theNumberOfSettings = 6;
    CTParagraphStyleSetting theSettings[6] =
    {
        { kCTParagraphStyleSpecifierAlignment, sizeof(CTTextAlignment), &_textAlignment },
        { kCTParagraphStyleSpecifierLineBreakMode, sizeof(CTLineBreakMode), &_lineBreakMode },
        { kCTParagraphStyleSpecifierFirstLineHeadIndent, sizeof(CGFloat), &_firstLineHeadIndent },
        { kCTParagraphStyleSpecifierParagraphSpacing, sizeof(CGFloat), &_spacing },
        { kCTParagraphStyleSpecifierParagraphSpacingBefore, sizeof(CGFloat), &_topSpacing },
        { kCTParagraphStyleSpecifierLineSpacing, sizeof(CGFloat), &_lineSpacing }
    };
    
    CTParagraphStyleRef paragraphStyle = CTParagraphStyleCreate(theSettings, theNumberOfSettings);
    [result addAttribute:(NSString *)kCTParagraphStyleAttributeName 
                                  value:(id)paragraphStyle
                                  range:range];
    
    CFRelease(paragraphStyle);
    /*
    if([result length]>1){
        CTFontRef firstFont = [[UIFont systemFontOfSize:_firstCharacterFontsize] CTFont];
        [result addAttribute:(NSString *)kCTFontAttributeName value:(id)firstFont range:NSMakeRange(0, 1)];
        CFRelease(firstFont);
    }*/
    _attributedString = result;
}

@end
