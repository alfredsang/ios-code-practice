
//  AKOMultiColumnTextView.m
//  CoreTextWrapper
//
//  Created by Adrian on 4/24/10.
//  Copyright 2010 akosma software. All rights reserved.
//

#import "AKOMultiColumnTextView.h"

@interface AKOMultiColumnTextView ()

- (void)setup;
- (void)createColumns;
- (void)setPage:(NSInteger)page;
- (void) drawImageIfExist:(CTFrameRef)frameRef context:(CGContextRef)context;
@end


@implementation AKOMultiColumnTextView

@synthesize columnCount = _columnCount;
@synthesize framesetter = _framesetter;
@synthesize startIndex = _startIndex;
@synthesize finalIndex = _finalIndex;
@synthesize moreTextAvailable = _moreTextAvailable;
@synthesize attributedString = _attributedString;
@synthesize columnInset = _columnInset;
@synthesize dataSource = _dataSource;

#pragma mark -
#pragma mark Init and dealloc

- (void)setup
{
    self.backgroundColor = [UIColor whiteColor];
    _columnCount = 3;
    _startIndex = 0;
    _finalIndex = 0;
    _moreTextAvailable = NO;
    _columnPaths = NULL;
    _frames = NULL;
    
}

- (id)initWithFrame:(CGRect)frame 
{
    if ((self = [super initWithFrame:frame]))
    {
        [self setup];
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    if ((self = [super initWithCoder:aDecoder]))
    {
        [self setup];
    }
    return self;
}

- (void)dealloc 
{
    if (_columnPaths != NULL)
    {
        CFRelease(_columnPaths);
    }
    
    if (_frames != NULL)
    {
        CFRelease(_frames);
    }
    
    [_attributedString release];
    _attributedString = nil;

    [super dealloc];
}

- (void) drawImageIfExist:(CTFrameRef)frameRef context:(CGContextRef)context{
    CGRect pathRect = CGPathGetBoundingBox(CTFrameGetPath(frameRef));
    CFArrayRef lines = CTFrameGetLines(frameRef);
    CGPoint *origins = malloc(sizeof(CGPoint)*[(NSArray *)lines count]);
    CTFrameGetLineOrigins(frameRef, CFRangeMake(0, 0), origins);
    NSInteger lineNum = 0;
    for (id oneLine in (NSArray*)lines) {
        CTLineRef lineRef = (CTLineRef)oneLine;
        CGPoint baselineOrigin = origins[lineNum++];			
        CGFloat ascent, descent, leading, width, offset = 0;
        CGRect frame;
        CFArrayRef runs = CTLineGetGlyphRuns(lineRef);
        for (id oneRun in (NSArray*) runs) {
            CTRunRef runRef =(CTRunRef)oneRun;
            CGPoint runOrigin = CGPointMake(baselineOrigin.x + offset, baselineOrigin.y);
            width = CTRunGetTypographicBounds(runRef, CFRangeMake(0, 0), &ascent, &descent, &leading);
            frame = CGRectMake(runOrigin.x, runOrigin.y, width, ascent + descent);
            offset += width;
            UIImage *image = nil;
            if ([self.dataSource respondsToSelector:@selector(image:runRef:lineRef:frameRef:)])
            {
                image = [self.dataSource image:self runRef:runRef lineRef:lineRef frameRef:frameRef];
            }
            if(!image)continue;
//            _imageIndex++;
//            if (_imageIndex > 1) {
//                _imageIndex = 0;
//                continue;
//            }
            CGPoint origin = frame.origin;
            origin.y = pathRect.origin.y + origin.y;
            origin.x = pathRect.origin.x + origin.x;
            CGSize imageSize = frame.size;
            CGFloat fixedWidth = pathRect.size.width - 10;
            if(width>fixedWidth){
                imageSize = CGSizeMake(fixedWidth, fixedWidth*frame.size.height*1.0/width);
                origin.y += (frame.size.height-imageSize.height)/2;
            }
            CGRect flippedRect = {origin, imageSize};
            CGContextDrawImage(context, flippedRect, image.CGImage);
        }
    }
	free(origins);
}

#pragma mark -
#pragma mark Drawing methods

- (void)drawRect:(CGRect)rect 
{
    // Initialize the text matrix to a known value.
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    // This is required, otherwise the text is drawn upside down in iPhone OS 3.2 (!?)
    CGContextSaveGState(context);
    
	CGContextSetTextMatrix(context, CGAffineTransformIdentity);
	
	// Set the usual "flipped" Core Text draw matrix
//	CGContextTranslateCTM(context, 0, ([self bounds]).size.height );
//	CGContextScaleCTM(context, -1.0, -1.0);
    CGAffineTransform flip = CGAffineTransformMake(1.0, 0.0, 0.0, -1.0, 0.0, self.frame.size.height);
    CGContextConcatCTM(context, flip);
    CGContextSetInterpolationQuality(context,kCGInterpolationLow);
    CFIndex pathCount = CFArrayGetCount(_columnPaths);
    
    for (int column = 0; column < pathCount; column++)
    {
        CTFrameRef frameRef = (CTFrameRef)CFArrayGetValueAtIndex(_frames, column);
        [self drawImageIfExist:frameRef context:context];
        CTFrameDraw(frameRef, context);
    }
    
    CGContextRestoreGState(context);
}

#pragma mark -
#pragma mark Private methods

- (void)createColumns
{
    
    int column;
    CGRect* columnRects = (CGRect*)calloc(_columnCount, sizeof(*columnRects));
    
    // Start by setting the first column to cover the entire view.
    columnRects[0] = self.bounds;

    // Divide the columns equally across the frame's width.
    CGFloat columnWidth = CGRectGetWidth(self.bounds) / _columnCount;
    for (column = 0; column < _columnCount - 1; column++) 
    {
        CGRectDivide(columnRects[column], 
                     &columnRects[column],
                     &columnRects[column + 1], 
                     columnWidth, 
                     CGRectMinXEdge);
    }
    
    // Inset all columns by a few pixels of margin.
    for (column = 0; column < _columnCount; column++) 
    {
//        columnRects[column] = CGRectInset(columnRects[column], _columnInset.x, _columnInset.y);
//        columnRects[column] = CGRectInset(columnRects[column], _columnInset.x, _columnInset.y);
    }
    
    // Create an array of layout paths, one for each column.
    if (_columnPaths != NULL)
    {
        CFRelease(_columnPaths);
    }
    _columnPaths = CFArrayCreateMutable(kCFAllocatorDefault, 2*_columnCount, &kCFTypeArrayCallBacks);
    for (column = 0; column < _columnCount; column++) 
    {
       
        CGRect columnRect = columnRects[column];
        // ask the delegate here
        CGRect columnFrame = CGRectZero;
        CGRect* blockRects = (CGRect*)malloc(sizeof(CGRect)*3);
        for (int i=0; i<3; i++) {
            blockRects[i] = CGRectZero;
        }
        if ([self.dataSource respondsToSelector:@selector(placeholder:viewForColumn:onPage:blocksarr:columnRect:)])
        {
            columnFrame = [self.dataSource placeholder:self viewForColumn:column onPage:_page blocksarr:blockRects columnRect:columnRect];
        }
        if(blockRects[0].size.height==0){
            blockRects[0] = columnFrame;
        }
        CGRect remainedColumnRect = columnRect;
        if(blockRects[0].size.height>0){
            NSMutableArray *arr = [NSMutableArray arrayWithCapacity:3];
            for (int i=0; i<3; i++) {
                CGRect blockRect = blockRects[i];
                if(blockRect.size.height==0)break;
                
                CGFloat cutLine1 = 0, cutLine2 = 0;
                cutLine1 = blockRect.origin.y-remainedColumnRect.origin.y;
                cutLine2 = cutLine1 + blockRect.size.height;
                if(cutLine1>0){
                    CGRect rect = CGRectMake(remainedColumnRect.origin.x, remainedColumnRect.origin.y, remainedColumnRect.size.width, cutLine1);
                    if(rect.size.height>2*_columnInset.y){
                        rect = CGRectInset(rect, _columnInset.x, _columnInset.y);
                        [arr insertObject:[NSValue valueWithCGRect:rect] atIndex:0];
                    }
                }
                if(cutLine2<columnRect.size.height){
                    remainedColumnRect = CGRectMake(remainedColumnRect.origin.x, remainedColumnRect.origin.y+cutLine2, remainedColumnRect.size.width, remainedColumnRect.size.height-cutLine2);
                }else{
                    remainedColumnRect = CGRectZero;
                    break;
                }
            }
            if(remainedColumnRect.size.height > 0){
                remainedColumnRect = CGRectInset(remainedColumnRect, _columnInset.x, _columnInset.y);
                if(remainedColumnRect.size.height>2*_columnInset.y&&remainedColumnRect.size.width>2*_columnInset.x){
                    [arr insertObject:[NSValue valueWithCGRect:remainedColumnRect] atIndex:0];
                }
            }
            NSInteger count = arr.count;
            for (int i=count-1; i>=0; i--) {
                NSValue *val = [arr objectAtIndex:i];
                CGRect rect = [val CGRectValue];
                rect.origin.y = columnRect.origin.y + columnRect.size.height - rect.origin.y - rect.size.height;
//                if(rect.origin.y<0)continue;
                CGMutablePathRef path = CGPathCreateMutable();
                CGPathAddRect(path, NULL, rect);
                CFArrayAppendValue(_columnPaths, path);
                CFRelease(path);
            }
        }
        else
        {
            CGMutablePathRef path = CGPathCreateMutable();
            CGPathAddRect(path, NULL, CGRectInset(columnRects[column], _columnInset.x, _columnInset.y));
            CFArrayAppendValue(_columnPaths, path);
            CFRelease(path);
        }
        free(blockRects);
    }
    free(columnRects);

}

- (void)updateFrames
{
    [self createColumns];
    
    CFIndex pathCount = CFArrayGetCount(_columnPaths);
    CFIndex currentIndex = self.startIndex;
    
    if (_frames != NULL)
    {
        CFRelease(_frames);
    }
    _frames = CFArrayCreateMutable(kCFAllocatorDefault, pathCount, &kCFTypeArrayCallBacks);
    
    for (int column = 0; column < pathCount; column++)
    {
        CGPathRef path = (CGPathRef)CFArrayGetValueAtIndex(_columnPaths, column);
        
        CTFrameRef frame = CTFramesetterCreateFrame(_framesetter, CFRangeMake(currentIndex, 0), path, NULL);
        CFArrayInsertValueAtIndex(_frames, column, frame);
        
        CFRange frameRange = CTFrameGetVisibleStringRange(frame);
        currentIndex += frameRange.length;
        CFRelease(frame);
    }
    
    _finalIndex = currentIndex;
    _moreTextAvailable = [_attributedString length] > self.finalIndex;
}

- (void)setPage:(NSInteger)page
{
    _page = page;
}

@end
