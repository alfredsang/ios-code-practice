//
//  AKOMultiColumnTextViewDataSource.h
//  CoreTextWrapper
//
//  Created by Christian Menschel on 12.05.11.
//  Copyright 2011 akosma software. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreText/CoreText.h>

@class AKOMultiColumnTextView;

@protocol AKOMultiColumnTextViewDataSource <NSObject>

@optional
- (CGRect)placeholder:(AKOMultiColumnTextView*)textView viewForColumn:(NSInteger)column onPage:(NSInteger)page blocksarr:(CGRect*)blocksarr columnRect:(CGRect)columnRect;

- (UIImage *) image:(AKOMultiColumnTextView*)textView runRef:(CTRunRef)runRef lineRef:(CTLineRef)lineRef frameRef:(CTFrameRef)frameRef;

- (void)addSubview:(AKOMultiColumnTextView*)textView onPage:(NSInteger)page;

- (void)appendSubview:(AKOMultiColumnTextView*)textView;
@end