//
//  SHKOAuthSharer.m
//  ShareKit
//
//  Created by Nathan Weiner on 6/21/10.

//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in
//  all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
//  THE SOFTWARE.
//
//

#import "SHKOAuthSharer.h"
#import "SHKOAuthView.h"
#import "OAuthConsumer.h" 
#import "SHKRenren.h"
#import "SHKTencent.h"

@implementation SHKOAuthSharer

@synthesize consumerKey, secretKey, authorizeCallbackURL;
@synthesize authorizeURL, requestURL, accessURL;
@synthesize consumer, requestToken, accessToken;
@synthesize signatureProvider;
@synthesize authorizeResponseQueryVars;


- (void)dealloc
{
	[consumerKey release];
	[secretKey release];
	[authorizeCallbackURL release];
	[authorizeURL release];
	[requestURL release];
	[accessURL release];
	[consumer release];
	[requestToken release];
	[accessToken release];
	[signatureProvider release];
	[authorizeResponseQueryVars release];
	
	[super dealloc];
}



#pragma mark -
#pragma mark Authorization

- (BOOL)isAuthorized
{		
	return [self restoreAccessToken];
}

- (void)promptAuthorization
{		
    //Edit by Rainbow, Renren don't need to get request token.
    if ([self isKindOfClass:[SHKRenren class]]) {
        [self tokenAuthorize];
    }
	[self tokenRequest];
}


#pragma mark Request

- (void)tokenRequest
{
	[[SHKActivityIndicator currentIndicator] displayActivity:@"连接中..."];
    OAMutableURLRequest *oRequest;
    if ([self isKindOfClass:[SHKTencent class]]) {
        oRequest = [[OAMutableURLRequest alloc] initWithURL:requestURL 
                                                   consumer:consumer token:nil 
                                                      realm:nil 
                                          signatureProvider:signatureProvider 
                                                      nonce:[self generateNonce] 
                                                  timestamp:[NSString stringWithFormat:@"%d", time(NULL)]];
    }
    else
    {
        
        oRequest = [[OAMutableURLRequest alloc] initWithURL:requestURL
                                                    consumer:consumer
                                                       token:nil   // we don't have a Token yet
                                                       realm:nil   // our service provider doesn't specify a realm
                                           signatureProvider:signatureProvider];
        
    }
																
	
    [oRequest setHTTPMethod:@"POST"];
	[self tokenRequestModifyRequest:oRequest];
	
    OAAsynchronousDataFetcher *fetcher = [OAAsynchronousDataFetcher asynchronousFetcherWithRequest:oRequest
                         delegate:self
                didFinishSelector:@selector(tokenRequestTicket:didFinishWithData:)
                  didFailSelector:@selector(tokenRequestTicket:didFailWithError:)];
    
    //Edit by Rainbow, special for Tencent, Tencent doesn't support header
    if ([self isKindOfClass:[SHKTencent class]]) {
        [fetcher startByUrl:[requestURL absoluteString]];
    }
    else
    {
        [fetcher start];	
    }
	[oRequest release];
}

- (void)tokenRequestModifyRequest:(OAMutableURLRequest *)oRequest{
	// Subclass to add custom paramaters and headers
}

- (void)tokenRequestTicket:(OAServiceTicket *)ticket didFinishWithData:(NSData *)data {
	//if (SHKDebugShowLogs) // check so we don't have to alloc the string with the data if we aren't logging
	//NSLog(@"tokenRequestTicket Response Body: %@", [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease]);
	
	[[SHKActivityIndicator currentIndicator] hide];
	
	if (ticket.didSucceed) 
	{
		NSString *responseBody = [[NSString alloc] initWithData:data
													   encoding:NSUTF8StringEncoding];
		self.requestToken = [[[OAToken alloc] initWithHTTPResponseBody:responseBody] autorelease];
		[responseBody release];
		
		[self tokenAuthorize];
	}
	
	else
	{}
		// TODO - better error handling here
		//[self tokenRequestTicket:ticket didFailWithError:[SHK error:SHKLocalizedString(@"There was a problem requesting authorization from %@"), [self sharerTitle]]];
}

- (void)tokenRequestTicket:(OAServiceTicket *)ticket didFailWithError:(NSError*)error
{
	[[SHKActivityIndicator currentIndicator] hide];
	
	[[[[UIAlertView alloc] initWithTitle:SHKLocalizedString(@"Request Error")
								 message:error!=nil?[error localizedDescription]:SHKLocalizedString(@"There was an error while sharing")
								delegate:nil
					   cancelButtonTitle:SHKLocalizedString(@"Close")
					   otherButtonTitles:nil] autorelease] show];
}


#pragma mark Authorize 

- (void)tokenAuthorize{	
    
    if ([self isKindOfClass:[SHKRenren class]]) {
        
        NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@?client_id=%@&response_type=token&redirect_uri=%@", authorizeURL.absoluteString, self.consumerKey ,authorizeCallbackURL.absoluteString]];	
        SHKOAuthView *auth = [[SHKOAuthView alloc] initWithURL:url delegate:self];
        [[SHK currentHelper] showViewController:auth];	
        [auth release];
    }
    else
    {
        NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@?oauth_token=%@&%d", authorizeURL.absoluteString, requestToken.key,[[NSDate date] timeIntervalSince1970]]];
        
        SHKOAuthView *auth = [[SHKOAuthView alloc] initWithURL:url delegate:self];
        [[SHK currentHelper] showViewController:auth];	
        [auth release];
    }
}

- (void)tokenAuthorizeView:(SHKOAuthView *)authView didFinishWithSuccess:(BOOL)success queryParams:(NSMutableDictionary *)queryParams error:(NSError *)error;{
	[[SHK currentHelper] hideCurrentViewControllerAnimated:YES];
	
	if (!success){
		[[[[UIAlertView alloc] initWithTitle:SHKLocalizedString(@"Authorize Error")
									 message:error!=nil?[error localizedDescription]:SHKLocalizedString(@"There was an error while authorizing")
									delegate:nil
						   cancelButtonTitle:SHKLocalizedString(@"Close")
						   otherButtonTitles:nil] autorelease] show];
	} else {
		self.authorizeResponseQueryVars = queryParams;
		NSLog(@"self.authorizeResponseQueryVars:%@",queryParams);
		[self tokenAccess];
	}
}

- (void)tokenAuthorizeCancelledView:(SHKOAuthView *)authView{
    [[SHK currentHelper] hideCurrentViewControllerAnimated:YES];
	self.shareDelegate = nil;
}


#pragma mark Access

- (void)tokenAccess{
	[self tokenAccess:NO];
}

- (void)tokenAccess:(BOOL)refresh
{
	if (!refresh)
		[[SHKActivityIndicator currentIndicator] displayActivity:@""];
	
    OAMutableURLRequest *oRequest;
    if ([self isKindOfClass:[SHKTencent class]]) {
        oRequest = [[OAMutableURLRequest alloc] initWithURL:accessURL 
                                                   consumer:consumer 
                                                      token:(refresh ? accessToken : requestToken) 
                                                      realm:nil 
                                          signatureProvider:signatureProvider 
                                                      nonce:[self generateNonce] 
                                                  timestamp:[NSString stringWithFormat:@"%d", time(NULL)]];
    }
    else
    {
        oRequest = [[OAMutableURLRequest alloc] initWithURL:accessURL
                                                   consumer:consumer
                                                      token:(refresh ? accessToken : requestToken)
                                                      realm:nil   // our service provider doesn't specify a realm
                                          signatureProvider:signatureProvider]; // use the default method, HMAC-SHA1
        
    }
    
    [oRequest setHTTPMethod:@"POST"];
	
	[self tokenAccessModifyRequest:oRequest];
	
    OAAsynchronousDataFetcher *fetcher = [OAAsynchronousDataFetcher asynchronousFetcherWithRequest:oRequest
                         delegate:self
                didFinishSelector:@selector(tokenAccessTicket:didFinishWithData:)
                  didFailSelector:@selector(tokenAccessTicket:didFailWithError:)];
    if ([self isKindOfClass:[SHKTencent class]]) {
        
        [fetcher startByUrl:[accessURL absoluteString]];
    }
    else
    {
        [fetcher start];
    }
	[oRequest release];
}

- (void)tokenAccessModifyRequest:(OAMutableURLRequest *)oRequest
{
	// Subclass to add custom paramaters or headers	
}

- (void)tokenAccessTicket:(OAServiceTicket *)ticket didFinishWithData:(NSData *)data 
{
	//if (SHKDebugShowLogs) // check so we don't have to alloc the string with the data if we aren't logging
		NSLog(@"tokenAccessTicket Response Body: %@", [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease]);
	
	[[SHKActivityIndicator currentIndicator] hide];
	
	if (ticket.didSucceed) 
	{
		NSString *responseBody = [[NSString alloc] initWithData:data
													   encoding:NSUTF8StringEncoding];
		self.accessToken = [[[OAToken alloc] initWithHTTPResponseBody:responseBody] autorelease];
		[responseBody release];
		
		[self storeAccessToken];
		
		[self tryPendingAction];
	}
	
	
	else
		// TODO - better error handling here
		[self tokenAccessTicket:ticket didFailWithError:[SHK error:SHKLocalizedString(@"There was a problem requesting access from %@", [self sharerTitle])]];
}

- (void)tokenAccessTicket:(OAServiceTicket *)ticket didFailWithError:(NSError*)error{
	[[SHKActivityIndicator currentIndicator] hide];
	
	[[[[UIAlertView alloc] initWithTitle:SHKLocalizedString(@"Access Error")
								 message:error!=nil?[error localizedDescription]:SHKLocalizedString(@"There was an error while sharing")
								delegate:nil
					   cancelButtonTitle:SHKLocalizedString(@"Close")
					   otherButtonTitles:nil] autorelease] show];
}

- (void)storeAccessToken{	
	[SHK setAuthValue:accessToken.key
					 forKey:@"accessKey"
				  forSharer:[self sharerId]];
	
	[SHK setAuthValue:accessToken.secret
					 forKey:@"accessSecret"
			forSharer:[self sharerId]];
	
	[SHK setAuthValue:accessToken.sessionHandle
			   forKey:@"sessionHandle"
			forSharer:[self sharerId]];
	
	if ([NSStringFromClass([self class]) isEqualToString:@"SHKSina"]) {
        [[NSNotificationCenter defaultCenter] postNotificationName:@"kSHSinaAuthenticationFinished" object:nil userInfo:nil];
    }
	if ([NSStringFromClass([self class]) isEqualToString:@"SHKTencent"]) {
        [[NSNotificationCenter defaultCenter] postNotificationName:@"kSHTencentAuthenticationFinished" object:nil userInfo:nil];
    }
}

+ (void)deleteStoredAccessToken
{
	NSString *sharerId = [self sharerId];
	
	[SHK removeAuthValueForKey:@"accessKey" forSharer:sharerId];
	[SHK removeAuthValueForKey:@"accessSecret" forSharer:sharerId];
	[SHK removeAuthValueForKey:@"sessionHandle" forSharer:sharerId];
}

+ (void)logout
{
	[self deleteStoredAccessToken];
}

- (BOOL)restoreAccessToken
{
	self.consumer = [[[OAConsumer alloc] initWithKey:consumerKey secret:secretKey] autorelease];
	
	if (accessToken != nil)
		return YES;
		
	NSString *key = [SHK getAuthValueForKey:@"accessKey"
				  forSharer:[self sharerId]];
	
	NSString *secret = [SHK getAuthValueForKey:@"accessSecret"
									 forSharer:[self sharerId]];
	
	NSString *sessionHandle = [SHK getAuthValueForKey:@"sessionHandle"
									 forSharer:[self sharerId]];
	
	if (key != nil && secret != nil)
	{
		self.accessToken = [[[OAToken alloc] initWithKey:key secret:secret] autorelease];
		
		if (sessionHandle != nil)
			accessToken.sessionHandle = sessionHandle;
		
		return accessToken != nil;
	}
	
	return NO;
}


#pragma mark Expired

- (void)refreshToken
{
	self.pendingAction = SHKPendingRefreshToken;
	[self tokenAccess:YES];
}

#pragma mark -
#pragma mark Pending Actions
#pragma mark -
#pragma mark Pending Actions

- (void)tryPendingAction
{
	switch (pendingAction) 
	{
		case SHKPendingRefreshToken:
			[self tryToSend]; // try to resend
			break;
			
		default:			
			[super tryPendingAction];			
	}
}

- (NSString *)generateNonce {
	// Just a simple implementation of a random number between 123400 and 9999999
	return [NSString stringWithFormat:@"%u", arc4random() % (9999999 - 123400) + 123400];
}

@end
