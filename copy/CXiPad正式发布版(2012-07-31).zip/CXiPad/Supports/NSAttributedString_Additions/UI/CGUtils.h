//
//  CGUtils.h
//  CoreTextExtensions
//
//  Created by Oliver Drobnik on 1/16/11.
//  Copyright 2011 Drobnik.com. All rights reserved.
//

CGPathRef newPathForRoundedRect(CGRect rect, CGFloat cornerRadius, BOOL roundTopCorners, BOOL roundBottomCorners);
CGSize sizeThatFitsKeepingAspectRatio(CGSize originalSize, CGSize sizeToFit);
CGPoint CGRectCenter(CGRect rect);
