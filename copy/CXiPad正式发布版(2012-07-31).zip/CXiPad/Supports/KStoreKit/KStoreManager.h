//
//  KStoreManager.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 4/19/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <StoreKit/StoreKit.h>
#import "KStoreObserver.h"
#import "JSONKit.h"

//#ifndef NDEBUG
//#define kReceiptValidationURL @"https://sandbox.itunes.apple.com/verifyReceipt"
//#else
//#define kReceiptValidationURL @"https://buy.itunes.apple.com/verifyReceipt"
//#endif

#ifndef NDEBUG
#define kReceiptValidationURL @"https://sandbox.itunes.apple.com/verifyReceipt"
#else
#define kReceiptValidationURL @"http://ipadcms.caing.com/check_receipt.php"
#endif

#define kProductFetchedNotification @"KStoreKitProductsFetched"
#define kSubscriptionsPurchasedNotification @"KStoreKitSubscriptionsPurchased"
#define kSubscriptionsInvalidNotification @"KStoreKitSubscriptionsInvalid"

#define kSharedSecret @"c9d9c75a498f4cecadfa5bcc487c3a76"

@class KSKSubscriptionProduct;
@class KSKBuySingleProduct;
@interface KStoreManager : NSObject<SKProductsRequestDelegate> {
    KSKSubscriptionProduct *_subscriptionProduct;
    KSKBuySingleProduct* _buySingleProduct;
    BOOL _isRestoring;
}
@property(nonatomic, assign)BOOL isRestoring;


// These are the methods you will be using in your app
+ (KStoreManager*)sharedManager;

// use this method to invoke a purchase
- (void) buyFeature:(NSString*) featureId
         onComplete:(void (^)(NSString*)) completionBlock         
        onCancelled:(void (^)(void)) cancelBlock;

// use this method to restore a purchase
- (void) restorePreviousTransactionsOnComplete:(void (^)(void)) completionBlock
                                       onError:(void (^)(NSError*)) errorBlock;

- (void) restorePreviousAndVerify:(void (^)(void)) completionBlock 
                     beforeVerify:(void (^)(NSNumber*))beforeVerifyBlock
                         onVerify:(void (^)(NSNumber*))verifyBlock 
                          onError:(void (^)(NSError*)) errorBlock;

- (BOOL) isSubscriptionActive:(NSString*) featureId;

-(void) restoreCompleted;
-(void) restoreFailedWithError:(NSError*) error;

@end
