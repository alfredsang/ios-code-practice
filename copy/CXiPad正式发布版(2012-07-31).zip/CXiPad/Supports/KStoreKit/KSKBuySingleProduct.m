//
//  KSKBuySingleProduct.m
//  CenturyWeeklyV2
//
//  Created by  on 12-6-4.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import "KSKBuySingleProduct.h"
#import "NSData+Base64.h"
#import "KStoreManager.h"

@implementation KSKBuySingleProduct

@synthesize onSubscriptionVerificationFailed;
@synthesize onSubscriptionVerificationCompleted;
@synthesize receipt;
@synthesize subscriptionDays;
@synthesize theConnection;
@synthesize dataFromConnection;
@synthesize productId;
@synthesize verifiedReceiptDictionary;


- (id)initWithProductId:(NSString *)aProductId {
    self = [super init];
    if (self) {
        self.productId = aProductId;
    }
    return self;
}

- (void)verifyReceiptOnComplete:(void (^)(NSNumber*))completionBlock
onError:(void (^)(NSError*))errorBlock {

    self.onSubscriptionVerificationCompleted = completionBlock;
    self.onSubscriptionVerificationFailed = errorBlock;

    NSString *urlStr = [[NSString alloc] initWithFormat:@"%@/check_receipt.php",SERVER_URL_HOST];
    NSURL *url = [NSURL URLWithString:urlStr];

    NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url 
                                                          cachePolicy:NSURLRequestReloadIgnoringCacheData 
                                                      timeoutInterval:60];
    KSDINFO(@"%@",[[NSString alloc] initWithData:receipt encoding:NSUTF8StringEncoding]);
    [theRequest setHTTPMethod:@"POST"];		
    [theRequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];

    NSString *receiptString = [NSString stringWithFormat:@"{\"receipt-data\":\"%@\"}", [self.receipt base64EncodedString]];        

    NSString *length = [NSString stringWithFormat:@"%d", [receiptString length]];	
    [theRequest setValue:length forHTTPHeaderField:@"Content-Length"];	

    [theRequest setHTTPBody:[receiptString dataUsingEncoding:NSUTF8StringEncoding]];

    self.theConnection = [NSURLConnection connectionWithRequest:theRequest delegate:self];    
    [self.theConnection start];    
}

#pragma mark -
#pragma mark NSURLConnection delegate

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {	
    self.dataFromConnection = [NSMutableData data];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    [self.dataFromConnection appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    NSString *s = [[NSString alloc] initWithData:dataFromConnection encoding:NSUTF8StringEncoding];
    KSDINFO(@"FFFFFFFFFFFFFFFF==========%@",s);
    self.verifiedReceiptDictionary = [[[self.dataFromConnection copy] autorelease] objectFromJSONData];
    if(self.onSubscriptionVerificationCompleted) {
        NSNumber* status = [self.verifiedReceiptDictionary objectForKey:@"status"];
        self.onSubscriptionVerificationCompleted(status);
        self.dataFromConnection = nil;
    }

    self.onSubscriptionVerificationCompleted = nil;
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    self.dataFromConnection = nil;
    if(self.onSubscriptionVerificationFailed)
        self.onSubscriptionVerificationFailed(error);
    self.onSubscriptionVerificationFailed = nil;
}


@end