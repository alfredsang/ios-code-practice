//
//  KStoreObserver.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 4/19/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <StoreKit/StoreKit.h>

@interface KStoreObserver : NSObject<SKPaymentTransactionObserver> {

}
//购买callback
- (void)paymentQueue:(SKPaymentQueue *)queue updatedTransactions:(NSArray *)transactions;
// 收到failed事务
- (void)failedTransaction: (SKPaymentTransaction *)transaction;
// 收到complete事务
- (void)completeTransaction: (SKPaymentTransaction *)transaction;
// 收到恢复事务
- (void)restoreTransaction: (SKPaymentTransaction *)transaction;

@end
