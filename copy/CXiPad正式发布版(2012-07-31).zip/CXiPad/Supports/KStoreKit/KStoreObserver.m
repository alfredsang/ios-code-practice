//
//  KStoreObserver.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 4/19/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KStoreObserver.h"
#import "KStoreManager.h"

@interface KStoreManager (private)

// these 4 functions are called from KStoreObserver
- (void)transactionCanceled:(SKPaymentTransaction *)transaction;
- (void)failedTransaction:(SKPaymentTransaction *)transaction;
- (void)provideContent:(NSString*)productIdentifier forReceipt:(NSData*)recieptData;
- (void)provideContent:(NSString*)productIdentifier forReceipt:(NSData*)receiptData restore:(BOOL)isRestore;
@end

@implementation KStoreObserver

- (void)paymentQueue:(SKPaymentQueue *)queue updatedTransactions:(NSArray *)transactions {
	for (SKPaymentTransaction *transaction in transactions) {
		switch (transaction.transactionState) {
			case SKPaymentTransactionStatePurchased:
				[self completeTransaction:transaction];
				break;
				
            case SKPaymentTransactionStateFailed:
				[self failedTransaction:transaction];
				break;
				
            case SKPaymentTransactionStateRestored:
				[self restoreTransaction:transaction];
				
            default:
				break;
		}			
	}
}

- (void)paymentQueue:(SKPaymentQueue *)queue restoreCompletedTransactionsFailedWithError:(NSError *)error {
    [[KStoreManager sharedManager] restoreFailedWithError:error];    
}

- (void)paymentQueueRestoreCompletedTransactionsFinished:(SKPaymentQueue *)queue {
    [[KStoreManager sharedManager] restoreCompleted];
}

- (void)failedTransaction:(SKPaymentTransaction *)transaction{	
	[[KStoreManager sharedManager] transactionCanceled:transaction];
    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];	
}

- (void)completeTransaction:(SKPaymentTransaction *)transaction {		
	[[KStoreManager sharedManager] provideContent:transaction.payment.productIdentifier 
                                        forReceipt:transaction.transactionReceipt restore:NO];	
    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];	
}

- (void)restoreTransaction:(SKPaymentTransaction *)transaction {	
    //    [[KStoreManager sharedManager] provideContent: transaction.originalTransaction.payment.productIdentifier forReceipt:transaction.transactionReceipt];
    NSString *productIdentifier = transaction.originalTransaction.payment.productIdentifier;
    if (!productIdentifier) {
        productIdentifier = transaction.payment.productIdentifier;
    }
    [[KStoreManager sharedManager] provideContent:productIdentifier forReceipt:transaction.transactionReceipt restore:YES];
    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];	
}

@end
