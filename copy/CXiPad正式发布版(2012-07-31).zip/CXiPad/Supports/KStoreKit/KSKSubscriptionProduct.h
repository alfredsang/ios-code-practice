//
//  KSKSubscriptionProduct.h
//  CenturyWeeklyV2
//
//  Created by jinjian on 4/19/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface KSKSubscriptionProduct : NSObject {
    
}
@property (nonatomic, copy) void (^onSubscriptionVerificationFailed)();
@property (nonatomic, copy) void (^onSubscriptionVerificationCompleted)(NSNumber* isActive,NSNumber* status);
@property (nonatomic, retain) NSData *receipt;
@property (nonatomic, retain) NSDictionary *verifiedReceiptDictionary;
@property (nonatomic, assign) int subscriptionDays; 
@property (nonatomic, retain) NSString *productId;
@property (nonatomic, retain) NSURLConnection *theConnection;
@property (nonatomic, retain) NSMutableData *dataFromConnection;


- (void)verifyReceiptOnComplete:(void (^)(NSNumber*,NSNumber*)) completionBlock
                         onError:(void (^)(NSError*)) errorBlock;

-(BOOL)isSubscriptionActive;
-(id)initWithProductId:(NSString*)productId subscriptionDays:(int)days;
-(id)initWithProductId:(NSString*)productId;
@end
