//
//  KStoreManager.m
//  CenturyWeeklyV2
//
//  Created by jinjian on 4/19/12.
//  Copyright (c) 2012 KSMobile. All rights reserved.
//

#import "KStoreManager.h"
#import "KSKSubscriptionProduct.h"
#import "KSKBuySingleProduct.h"


@interface KStoreManager () //private methods and properties

@property (nonatomic, copy) void (^onTransactionCancelled)();
@property (nonatomic, copy) void (^onTransactionCompleted)(NSString *productId);

@property (nonatomic, copy) void (^onRestoreFailed)(NSError* error);
@property (nonatomic, copy) void (^onRestoreCompleted)();
@property (nonatomic, copy) void (^onRestoreVerify)(NSNumber* isVerify);
@property (nonatomic, copy) void (^beforeVerify)(NSNumber* hasVerify);

@property (nonatomic, retain) NSMutableArray *purchasableObjects;
@property (nonatomic, retain) NSMutableDictionary *subscriptionProducts;

@property (nonatomic, retain) KStoreObserver *storeObserver;
@property (nonatomic, assign, getter=isProductsAvailable) BOOL isProductsAvailable;


- (void) rememberPurchaseOfProduct:(NSString*) productIdentifier;
- (void) addToQueue:(NSString*) productId;
@end

@implementation KStoreManager
@synthesize isRestoring = _isRestoring;
@synthesize purchasableObjects = _purchasableObjects;
@synthesize storeObserver = _storeObserver;
@synthesize subscriptionProducts;

@synthesize isProductsAvailable;

@synthesize onTransactionCancelled;
@synthesize onTransactionCompleted;
@synthesize onRestoreFailed;
@synthesize onRestoreCompleted;
@synthesize onRestoreVerify;
@synthesize beforeVerify;
//@synthesize delegate = _delegate;
static KStoreManager* _sharedStoreManager;
- (void)dealloc {
    [_subscriptionProduct release], _subscriptionProduct = nil;
    [_buySingleProduct release], _buySingleProduct = nil;
    [_purchasableObjects release], _purchasableObjects = nil;
    [_storeObserver release], _storeObserver = nil;
    [onTransactionCancelled release], onTransactionCancelled = nil;
    [onTransactionCompleted release], onTransactionCompleted = nil;
    [onRestoreFailed release], onRestoreFailed = nil;
    [onRestoreCompleted release], onRestoreCompleted = nil;    
    [super dealloc];
}

+ (void)dealloc {
	[_sharedStoreManager release], _sharedStoreManager = nil;
	[super dealloc];
}
+ (KStoreManager *)sharedManager {
	@synchronized(self) {
		if (_sharedStoreManager == nil) {
            _sharedStoreManager = [[self alloc] init];					
			//_sharedStoreManager.purchasableObjects = [[NSMutableArray alloc] init];
			_sharedStoreManager.storeObserver = [[[KStoreObserver alloc] init] autorelease];
			[[SKPaymentQueue defaultQueue] addTransactionObserver:_sharedStoreManager.storeObserver];            
        }
    }
    return _sharedStoreManager;
}

#pragma mark - SKProductsRequestDelegate
- (void)forbidBuy {
    [UIUtil showMsgAlertWithTitle:@"不能购买该产品" message:@"网络故障或未通过苹果审核，请稍后再试。"];
    if(self.onTransactionCancelled) {
        self.onTransactionCancelled();
    }
    self.onTransactionCompleted = nil;
    self.onTransactionCancelled = nil;
}
- (void)productsRequest:(SKProductsRequest *)request didReceiveResponse:(SKProductsResponse *)response {
    NSArray *featureIds = response.products;
    KSDINFO(@"%@",[response.invalidProductIdentifiers description]);
    if (featureIds && [featureIds count] > 0) {
        SKProduct *skProduct = [response.products objectAtIndex:0];
        [self addToQueue:skProduct.productIdentifier];
    } else {
        [self forbidBuy];
    }
}
//- (void)requestDidFinish:(SKRequest *)request {
//    
//}
- (void)request:(SKRequest *)request didFailWithError:(NSError *)error {
    KSDINFO(@"%@",[error.userInfo description]);
    [self forbidBuy];
}
#pragma mark -
- (void)buyFeature:(NSString*)featureId 
        onComplete:(void (^)(NSString*))completionBlock 
       onCancelled:(void (^)(void))cancelBlock {
    if ([SKPaymentQueue canMakePayments]) {
        _isRestoring = NO;
        
        self.onTransactionCompleted = completionBlock;
        self.onTransactionCancelled = cancelBlock;
        
        SKProductsRequest *request= [[SKProductsRequest alloc] initWithProductIdentifiers:[NSSet setWithObject:featureId]];
        request.delegate = self;
        [request start];
    } else {
        [UIUtil showMsgAlertWithTitle:@"购买受限" message:@"您的设备没有权限使用苹果的购买服务或没有网络连接，请使用系统设置或itunes进行相关设置。"];
        self.onTransactionCancelled = cancelBlock;
        self.onTransactionCancelled();
    }
}

- (void)addToQueue:(NSString*)productId {
    SKPayment *payment = [SKPayment paymentWithProductIdentifier:productId];
    [[SKPaymentQueue defaultQueue] addPayment:payment];
}

#pragma mark - 
- (void)restorePreviousTransactionsOnComplete:(void (^)(void))completionBlock
                                       onError:(void (^)(NSError*))errorBlock {
    _isRestoring = YES;
    
    self.onRestoreCompleted = completionBlock;
    self.onRestoreFailed = errorBlock;
    
	[[SKPaymentQueue defaultQueue] restoreCompletedTransactions];
}

- (void)restorePreviousAndVerify:(void (^)(void)) completionBlock 
                     beforeVerify:(void (^)(NSNumber*))beforeVerifyBlock
                         onVerify:(void (^)(NSNumber*))verifyBlock 
                         onError:(void (^)(NSError*))errorBlock {
    _isRestoring = YES;
    
    self.onRestoreCompleted = completionBlock;
    self.beforeVerify = beforeVerifyBlock;
    self.onRestoreFailed = errorBlock;
    self.onRestoreVerify = verifyBlock;
    
	[[SKPaymentQueue defaultQueue] restoreCompletedTransactions];
}
#pragma mark - Buy Callback & Save
//
- (void)rememberPurchaseOfProduct:(NSString*)productIdentifier {
    if ([productIdentifier length]>[STORE_PRODUCT_PREFIX length]) {
        NSString *idenTifierId = [productIdentifier substringFromIndex:[STORE_PRODUCT_PREFIX length]];
        [[KSDB db] executeUpdate:@"update magzines set is_purchased=1 where issue_number=?",INTEGER([idenTifierId intValue])];
        [[KSDB db] executeUpdate:@"update magzines set is_purchased=1 where custom_number=? and is_special_issue=1",idenTifierId];
        NSDictionary *dic = [[NSDictionary alloc] initWithObjectsAndKeys:INTEGER([idenTifierId intValue]),@"issue_number", nil];
//        [KSBootstrap notify:NOTIFY_MAGAZINE_PURCHASED data:dic];
        
        [dic release];
    }
}
- (void)rememberPurchaseOfSubscription:(NSDictionary *)receipt verifiedReceiptDictionary:(NSDictionary *)verifiedReceiptDictionary {
    NSDate *begindate;//purchase_date
    
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    NSString *purchasedDateString = [receipt objectForKey:@"original_purchase_date"];
    if (!purchasedDateString) {
        purchasedDateString = [receipt objectForKey:@"purchase_date"];
    }
    purchasedDateString = [purchasedDateString substringToIndex:10];    
    NSLocale *POSIXLocale = [[[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"] autorelease];
    [df setLocale:POSIXLocale];
    [df setTimeZone:[NSTimeZone timeZoneForSecondsFromGMT:0]];    
    [df setDateFormat:@"yyyy-MM-dd"];
    
    begindate = [df dateFromString: purchasedDateString];
    [df release];
    
    NSString *tranId = [receipt objectForKey:@"original_transaction_id"];
    if (tranId == nil) {
        tranId = [receipt objectForKey:@"transaction_id"];
    }
    
    NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *components = [[NSDateComponents alloc] init];
    
    NSString *productIdentifier = [receipt objectForKey:@"product_id"];
    NSInteger months = [[productIdentifier substringFromIndex:STORE_SUBSCRIPTION_PREFIX.length] intValue];
    components.month = months;
    
    NSDate *endDate = [gregorian dateByAddingComponents:components toDate:begindate options:0];
    NSString *lastExpireDateStr = nil;
    if ([verifiedReceiptDictionary objectForKey:@"latest_receipt_info"]) {
        lastExpireDateStr = [[verifiedReceiptDictionary objectForKey:@"latest_receipt_info"] objectForKey:@"expires_date"];
    }else if([verifiedReceiptDictionary objectForKey:@"latest_expired_receipt_info"]) {
        lastExpireDateStr = [[verifiedReceiptDictionary objectForKey:@"latest_expired_receipt_info"] objectForKey:@"expires_date"];
    }
    
    if (lastExpireDateStr == nil) {
        lastExpireDateStr = [receipt objectForKey:@"expires_date"];
    }
    NSInteger endIssueDate = 0;
    if (lastExpireDateStr == nil) {
        endIssueDate = [endDate timeIntervalSince1970];
    }else {
        endIssueDate = [lastExpireDateStr floatValue]/1000;//expires_date
    }
    [components release];
    [gregorian release];
    
    //保存订阅信息
    [[KSDB db] executeUpdate:@"delete from subscribed where order_no=?", tranId];
    [[KSDB db] executeUpdate:@"insert into subscribed(order_no, start, end,subsribe_type) values(?, ?, ?,?)", tranId, INTEGER([begindate timeIntervalSince1970]), INTEGER(endIssueDate),productIdentifier];
}
- (void)rememberPurchaseOfSubscription:(KSKSubscriptionProduct *)product {
    [self rememberPurchaseOfSubscription:[product.verifiedReceiptDictionary objectForKey:@"receipt"] verifiedReceiptDictionary:product.verifiedReceiptDictionary];
}

- (void)showAlertWithTitle:(NSString*)title message:(NSString*)message {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title
                                                    message:message
                                                   delegate:nil 
                                          cancelButtonTitle:NSLocalizedString(@"确定", @"")
                                          otherButtonTitles:nil];
    [alert show];
    [alert release];
}

- (void)provideContent:(NSString *)productIdentifier forReceipt:(NSData*)receiptData restore:(BOOL)isRestore {
    KSDINFO(@"%@",productIdentifier);
    if ([self isSubscriptionActive:productIdentifier])
    {
        if (_subscriptionProduct)
        {
            [_subscriptionProduct release],_subscriptionProduct = nil;
        }
        _subscriptionProduct = [[KSKSubscriptionProduct alloc] initWithProductId:productIdentifier];
        _subscriptionProduct.receipt = receiptData;
        if (!_isRestoring) {
            [_subscriptionProduct verifyReceiptOnComplete:^(NSNumber* isActive,NSNumber* status) {
                
                if([status intValue] != 0){
                    KSDERROR(@"status=%d", [status intValue]);
#ifdef NDEBUG
                    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"无法完成订单验证" 
                                                                    message:@"建议您重试购买或通过财新网通行证登录恢复购买。"//[error localizedDescription] 
                                                                   delegate:nil 
                                                          cancelButtonTitle:@"确定" 
                                                          otherButtonTitles: nil];
                    [alert show];
                    [alert release];
#endif                
                    if(self.onTransactionCancelled) {
                        self.onTransactionCancelled(productIdentifier);
                    }
                    self.onTransactionCancelled = nil;
                    self.onTransactionCompleted = nil;
                }else{
                    if ([isActive intValue] > 0) {
                        if ([_subscriptionProduct.verifiedReceiptDictionary objectForKey:@"receipt"]) {
                            [self rememberPurchaseOfSubscription:_subscriptionProduct];
                        }
                    }
                    if(self.onTransactionCompleted) {
                        self.onTransactionCompleted(productIdentifier);
                    }
                    self.onTransactionCancelled = nil;
                    self.onTransactionCompleted = nil;                    
                }
                

            } onError:^(NSError* error) {
                KSDERROR(@"%@", [error description]);
#ifdef NDEBUG
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"无法完成订单验证" 
                                                                message:@"建议您重试购买或通过财新网通行证登录恢复购买。"//[error localizedDescription] 
                                                               delegate:nil 
                                                      cancelButtonTitle:@"确定" 
                                                      otherButtonTitles: nil];
                [alert show];
                [alert release];
#endif                
                if(self.onTransactionCancelled) {
                    self.onTransactionCancelled(productIdentifier);
                }
                self.onTransactionCancelled = nil;
                self.onTransactionCompleted = nil;
            }];
        }
    }else {
        //check single purchase
        if (_buySingleProduct) {
            [_buySingleProduct release],_buySingleProduct = nil;
        }
        _buySingleProduct = [[KSKBuySingleProduct alloc] initWithProductId:productIdentifier];
        _buySingleProduct.receipt = receiptData;
        if (!_isRestoring)
        {
            [_buySingleProduct verifyReceiptOnComplete:^(NSNumber* status)
            {
                if (!status || [status intValue] > 0 )
                {
                    NSLog(@"Receipt status=%d",[status intValue]);
                    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"无法完成订单验证" 
                                                                    message:@"建议您重试购买或通过财新网通行证登录恢复购买。"//[error localizedDescription] 
                                                                   delegate:nil 
                                                          cancelButtonTitle:@"确定" 
                                                          otherButtonTitles: nil];
                    [alert show];
                    [alert release];
                    //cancel the transaction
                    if(self.onTransactionCancelled){
                        self.onTransactionCancelled(productIdentifier);
                    }
                }
                else
                {
                    [self rememberPurchaseOfProduct:productIdentifier];
                    if(self.onTransactionCompleted)
                    {
                        self.onTransactionCompleted(productIdentifier);
                    }
                }
                self.onTransactionCancelled = nil;
                self.onTransactionCompleted = nil;
            } onError:^(NSError* error) {
                KSDERROR(@"%@", [error description]);
#ifdef NDEBUG
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"无法完成订单验证" 
                                                                message:@"建议您重试购买或通过财新网通行证登录恢复购买。"//[error localizedDescription] 
                                                               delegate:nil 
                                                      cancelButtonTitle:@"确定" 
                                                      otherButtonTitles: nil];
                [alert show];
                [alert release];
#endif                
                if(self.onTransactionCancelled) {
                    self.onTransactionCancelled(productIdentifier);
                }
                self.onTransactionCancelled = nil;
                self.onTransactionCompleted = nil;
            }];
        }
        else{
            [self rememberPurchaseOfProduct:productIdentifier];
            if(self.onTransactionCompleted) {
                self.onTransactionCompleted(productIdentifier);
            }
            self.onTransactionCancelled = nil;
            self.onTransactionCompleted = nil;
        }
        
    }
}
- (void)transactionCanceled:(SKPaymentTransaction *)transaction {
#ifndef NDEBUG
	NSLog(@"User cancelled transaction: %@", [transaction description]);
    NSLog(@"error: %@", transaction.error);
#endif
    if(transaction.error.code != SKErrorPaymentCancelled) {
        NSString *errMsg = [transaction.error localizedDescription];
        if (errMsg && [errMsg length]) {
            [self showAlertWithTitle:@"无法完成购买" message:errMsg];
        }
    }
    
    if(self.onTransactionCancelled)
        self.onTransactionCancelled();
    
    self.onTransactionCompleted = nil;
    self.onTransactionCancelled = nil;
    
}

- (void)failedTransaction:(SKPaymentTransaction *)transaction {
#ifndef NDEBUG
    NSLog(@"Failed transaction: %@", [transaction description]);
    NSLog(@"error: %@", transaction.error); 
    NSLog(@"error: %d", transaction.error.code);   
#endif
    if(transaction.error.code != SKErrorPaymentCancelled) {
        NSString *str =[transaction.error localizedFailureReason];
        if (str && [str length]) {
            [self showAlertWithTitle:str  message:[transaction.error localizedRecoverySuggestion]];
        }
    }
    if(self.onTransactionCancelled)
        self.onTransactionCancelled();
    
    self.onTransactionCompleted = nil;
    self.onTransactionCancelled = nil;
}


- (BOOL)isSubscriptionActive:(NSString*)featureId {
    if ([featureId isEqualToString:@"com.caing.ipad.s.s12"] ||[featureId isEqualToString:@"com.caing.ipad.s.s6"] || [featureId isEqualToString:@"com.caing.ipad.s.s3"]) {
        return YES;
    }
    return NO;
}


#pragma mark - restoring call back
- (void)restoreCompleted {
    if (_subscriptionProduct) {
        [_subscriptionProduct verifyReceiptOnComplete:^(NSNumber* isActive,NSNumber* status) {
            if ([_subscriptionProduct.verifiedReceiptDictionary objectForKey:@"receipt"]) {
                [self rememberPurchaseOfSubscription:_subscriptionProduct];
            }
            if(self.onRestoreCompleted)
                self.onRestoreCompleted();
            self.onRestoreCompleted = nil;
            self.onRestoreFailed = nil;
            RELEASE_SAFELY(_subscriptionProduct);
        } onError:^(NSError* error) {
            KSDERROR(@"%@", [error description]);
            
#ifdef NDEBUG
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"无法完成订单验证" 
                                                            message:@"建议您重试购买或通过财新网通行证登录恢复购买。"//[error localizedDescription] 
                                                           delegate:nil 
                                                  cancelButtonTitle:@"确定" 
                                                  otherButtonTitles: nil];
            [alert show];
            [alert release];
#endif            
            RELEASE_SAFELY(_subscriptionProduct);
            
            if(self.onRestoreFailed)
                self.onRestoreFailed(error);
        }];
    } else {
        if(self.onRestoreCompleted)
            self.onRestoreCompleted();
        self.onRestoreFailed = nil;
        self.onRestoreCompleted = nil;
    }
}

- (void)restoreFailedWithError:(NSError*)error {
    if(self.onRestoreFailed)
        self.onRestoreFailed(error);
    self.onRestoreFailed = nil;
    self.onRestoreCompleted = nil;
}

@end
