//
//  KSKBuySingleProduct.h
//  CenturyWeeklyV2
//
//  Created by  on 12-6-4.
//  Copyright (c) 2012年 KSMobile. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface KSKBuySingleProduct : NSObject


@property (nonatomic, copy) void (^onSubscriptionVerificationFailed)();
@property (nonatomic, copy) void (^onSubscriptionVerificationCompleted)(NSNumber* status);
@property (nonatomic, retain) NSData *receipt;
@property (nonatomic, retain) NSDictionary *verifiedReceiptDictionary;
@property (nonatomic, assign) int subscriptionDays; 
@property (nonatomic, retain) NSString *productId;
@property (nonatomic, retain) NSURLConnection *theConnection;
@property (nonatomic, retain) NSMutableData *dataFromConnection;


- (void)verifyReceiptOnComplete:(void (^)(NSNumber*)) completionBlock
                        onError:(void (^)(NSError*)) errorBlock;

-(id)initWithProductId:(NSString*)productId;
@end
