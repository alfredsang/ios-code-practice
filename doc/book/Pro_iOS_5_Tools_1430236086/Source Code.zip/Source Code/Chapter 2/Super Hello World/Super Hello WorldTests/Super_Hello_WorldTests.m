//
//  Super_Hello_WorldTests.m
//  Super Hello WorldTests
//
//  Created by Brandon Alexander on 2/21/11.
//  Copyright 2011 While This, Inc. All rights reserved.
//

#import "Super_Hello_WorldTests.h"


@implementation Super_Hello_WorldTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    //STFail(@"Unit tests are not implemented yet in Super Hello WorldTests");
}

@end
