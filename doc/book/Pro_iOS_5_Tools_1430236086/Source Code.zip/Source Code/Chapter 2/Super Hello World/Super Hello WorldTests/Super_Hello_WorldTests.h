//
//  Super_Hello_WorldTests.h
//  Super Hello WorldTests
//
//  Created by Brandon Alexander on 2/21/11.
//  Copyright 2011 While This, Inc. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface Super_Hello_WorldTests : SenTestCase {
@private
    
}

@end
