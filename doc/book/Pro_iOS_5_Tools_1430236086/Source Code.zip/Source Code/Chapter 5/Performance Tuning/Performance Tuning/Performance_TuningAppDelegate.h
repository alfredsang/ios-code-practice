//
//  Performance_TuningAppDelegate.h
//  Performance Tuning
//
//  Created by Brandon Alexander on 4/3/11.
//  Copyright 2011 While This, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Performance_TuningAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet UINavigationController *navigationController;

@end
