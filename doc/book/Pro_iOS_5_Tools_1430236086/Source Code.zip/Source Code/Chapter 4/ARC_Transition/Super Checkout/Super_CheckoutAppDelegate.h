//
//  Super_CheckoutAppDelegate.h
//  Super Checkout
//
//  Created by Brandon Alexander on 1/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Super_CheckoutViewController;

@interface Super_CheckoutAppDelegate : NSObject <UIApplicationDelegate> {
@private

}

@property (nonatomic, strong) IBOutlet UIWindow *window;

@property (nonatomic, strong) IBOutlet UINavigationController *viewController;

@end
