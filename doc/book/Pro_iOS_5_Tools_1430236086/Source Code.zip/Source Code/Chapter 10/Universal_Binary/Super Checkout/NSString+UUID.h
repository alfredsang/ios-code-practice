//
//  NSString+UUID.h
//  Super Checkout
//
//  Created by Brandon Alexander on 3/6/11.
//  Copyright 2011 While This, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSString (NSString_UUID)

+ (NSString*)stringWithNewUUID;

@end
