//
//  Super_CheckoutTests.h
//  Super CheckoutTests
//
//  Created by Brandon Alexander on 1/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface Super_CheckoutTests : SenTestCase {
@private
    
}

@end
